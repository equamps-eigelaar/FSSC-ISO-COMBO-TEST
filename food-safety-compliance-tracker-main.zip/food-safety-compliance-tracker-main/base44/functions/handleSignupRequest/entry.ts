import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    // This is an intentionally public endpoint (signup form — no login required).
    // It is rate-limited by email uniqueness and does not expose any secrets.
    const { email, full_name, company } = await req.json();

    if (!email || !full_name) {
      return Response.json({ error: 'Email and full name required' }, { status: 400 });
    }

    // Basic email format validation
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return Response.json({ error: 'Invalid email address' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);

    // Check if user already has a request
    const existing = await base44.asServiceRole.entities.UserAccessRequest.filter(
      { email },
      '-created_date',
      1
    );

    if (existing.length > 0 && existing[0].status !== 'rejected') {
      return Response.json(
        { error: 'Access request already submitted. Please wait for approval.' },
        { status: 400 }
      );
    }

    // Create access request with trial dates (7 days from now)
    const today = new Date();
    const trialEnd = new Date(today);
    trialEnd.setDate(trialEnd.getDate() + 7);

    const request = await base44.asServiceRole.entities.UserAccessRequest.create({
      email,
      full_name,
      company: company || '',
      status: 'pending',
      trial_start_date: today.toISOString().split('T')[0],
      trial_end_date: trialEnd.toISOString().split('T')[0],
      ip_address: req.headers.get('x-forwarded-for') || 'unknown',
      user_agent: req.headers.get('user-agent') || 'unknown',
    });

    // Send confirmation email
    await base44.integrations.Core.SendEmail({
      to: email,
      subject: 'Access Request Received',
      body: `Hi ${full_name},\n\nYour access request has been received. The admin will review and approve shortly.\n\nYou'll receive an email once approved.`,
    });

    return Response.json({
      success: true,
      message: 'Access request submitted. Check your email for confirmation.',
      request_id: request.id,
    });
  } catch (error) {
    console.error('Signup error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});