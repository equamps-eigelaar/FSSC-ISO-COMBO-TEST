import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

async function getValidXeroToken(base44) {
  const tokens = await base44.asServiceRole.entities.XeroToken.filter({});
  if (tokens.length === 0) throw new Error('Xero not connected');
  let token = tokens[0];
  if (new Date(token.expires_at) < new Date(Date.now() + 60000)) {
    const CLIENT_ID = Deno.env.get('XERO_CLIENT_ID');
    const CLIENT_SECRET = Deno.env.get('XERO_CLIENT_SECRET');
    const credentials = btoa(`${CLIENT_ID}:${CLIENT_SECRET}`);
    const res = await fetch('https://identity.xero.com/connect/token', {
      method: 'POST',
      headers: { 'Authorization': `Basic ${credentials}`, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: token.refresh_token }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error('Token refresh failed');
    token = { ...token, access_token: data.access_token, refresh_token: data.refresh_token, expires_at: new Date(Date.now() + data.expires_in * 1000).toISOString() };
    await base44.asServiceRole.entities.XeroToken.update(token.id, {
      access_token: token.access_token, refresh_token: token.refresh_token, expires_at: token.expires_at,
    });
  }
  return token;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Allow admin users OR automation context (no user = called by scheduler)
    const user = await base44.auth.me().catch(() => null);
    if (user !== null && user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Get all payment_pending requests that have a Xero invoice ID
    const pendingRequests = await base44.asServiceRole.entities.UserAccessRequest.filter({ status: 'payment_pending' });
    if (pendingRequests.length === 0) {
      return Response.json({ success: true, message: 'No pending payment requests', activated: 0 });
    }

    // Get valid Xero token
    const token = await getValidXeroToken(base44);
    const xeroHeaders = {
      'Authorization': `Bearer ${token.access_token}`,
      'Xero-tenant-id': token.tenant_id,
      'Accept': 'application/json',
    };

    // Pull paid invoices from Xero
    const xeroRes = await fetch('https://api.xero.com/api.xro/2.0/Invoices?Statuses=PAID&page=1', { headers: xeroHeaders });
    const xeroData = await xeroRes.json();
    if (!xeroRes.ok) return Response.json({ error: xeroData }, { status: 400 });

    const paidInvoiceIds = new Set((xeroData.Invoices || []).map(inv => inv.InvoiceID));
    const paidInvoiceNumbers = new Set((xeroData.Invoices || []).map(inv => inv.InvoiceNumber));

    let activated = 0;
    for (const request of pendingRequests) {
      if (!request.xero_invoice_id) continue;

      const isPaid = paidInvoiceIds.has(request.xero_invoice_id) || 
                     (request.xero_invoice_number && paidInvoiceNumbers.has(request.xero_invoice_number));

      if (isPaid) {
        // Grant access: update status to active
        await base44.asServiceRole.entities.UserAccessRequest.update(request.id, {
          status: 'active',
          approved_date: new Date().toISOString(),
        });

        // Invite the user to the app
        try {
          await base44.users.inviteUser(request.email, 'user');
        } catch (inviteErr) {
          console.log(`User invite skipped (may already exist): ${inviteErr.message}`);
        }

        // Send welcome email
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: request.email,
          subject: '🎉 Payment Confirmed — Your FSMS Compliance Tracker Account is Active!',
          body: `Hi ${request.full_name},\n\nWe have confirmed your payment and your account is now fully active!\n\nYou can log in at any time here:\nhttps://food-safety-compliance-tracker-6d44af17.base44.app\n\nPlan: ${request.plan_name || 'FSMS Compliance Tracker'}\n\nIf you have any questions, please reply to this email.\n\nThank you,\nFSMS Compliance Tracker Team`,
        });

        activated++;
      }
    }

    return Response.json({ success: true, activated, checked: pendingRequests.length });
  } catch (error) {
    console.error('Grant access error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});