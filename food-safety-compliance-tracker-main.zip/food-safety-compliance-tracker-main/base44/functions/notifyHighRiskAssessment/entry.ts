import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const risk = body.data;

    if (!risk) {
      return Response.json({ error: 'No risk data in payload' }, { status: 400 });
    }

    const adminUsers = await base44.asServiceRole.entities.User.filter({ role: 'admin' });

    const riskLevel = risk.risk_level?.toUpperCase() || 'HIGH';
    const hazardType = risk.hazard_type || 'Unknown';
    const hazardDesc = risk.hazard_description || 'No description provided';
    const likelihood = risk.likelihood || 'N/A';
    const severity = risk.severity || 'N/A';
    const assignedTo = risk.assigned_to || 'Unassigned';

    const emailBody = `
      <h2>⚠️ ${riskLevel} Risk Assessment Created</h2>
      <p>A new <strong>${riskLevel}</strong> risk assessment has been logged and requires your attention.</p>
      <table style="border-collapse: collapse; width: 100%; max-width: 600px;">
        <tr><td style="padding: 8px; border: 1px solid #ddd; font-weight: bold;">Hazard Type</td><td style="padding: 8px; border: 1px solid #ddd;">${hazardType}</td></tr>
        <tr><td style="padding: 8px; border: 1px solid #ddd; font-weight: bold;">Description</td><td style="padding: 8px; border: 1px solid #ddd;">${hazardDesc}</td></tr>
        <tr><td style="padding: 8px; border: 1px solid #ddd; font-weight: bold;">Likelihood</td><td style="padding: 8px; border: 1px solid #ddd;">${likelihood}</td></tr>
        <tr><td style="padding: 8px; border: 1px solid #ddd; font-weight: bold;">Severity</td><td style="padding: 8px; border: 1px solid #ddd;">${severity}</td></tr>
        <tr><td style="padding: 8px; border: 1px solid #ddd; font-weight: bold;">Assigned To</td><td style="padding: 8px; border: 1px solid #ddd;">${assignedTo}</td></tr>
      </table>
      <p style="margin-top: 16px;">Please review this risk assessment in the <strong>Risk Workflow</strong> section of the FSMS Compliance Tracker and take appropriate action.</p>
      <hr/>
      <p><small>This alert was generated automatically by the FSMS Compliance System.</small></p>
    `;

    let emailsSent = 0;
    for (const admin of adminUsers) {
      if (!admin.email) continue;

      // In-app notification
      await base44.asServiceRole.entities.Notification.create({
        recipient_email: admin.email,
        title: `${riskLevel} Risk Assessment Created`,
        message: `A new ${riskLevel.toLowerCase()} risk has been identified: ${hazardDesc.substring(0, 100)}${hazardDesc.length > 100 ? '...' : ''}`,
        type: 'compliance_alert',
        entity_type: 'RiskAssessment',
        entity_id: body.event?.entity_id || '',
        priority: risk.risk_level === 'critical' ? 'critical' : 'high',
        is_read: false,
      });

      // Email notification
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: admin.email,
        subject: `⚠️ ${riskLevel} Risk Assessment Created – Immediate Review Required`,
        body: emailBody,
      });

      emailsSent++;
    }

    return Response.json({
      success: true,
      risk_level: risk.risk_level,
      notifications_sent: emailsSent,
    });

  } catch (error) {
    console.error('Notify high risk assessment error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});