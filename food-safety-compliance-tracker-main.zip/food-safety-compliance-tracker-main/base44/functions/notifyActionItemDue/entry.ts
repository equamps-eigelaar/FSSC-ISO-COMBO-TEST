import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

// Triggered by entity automation on ActionItem create/update
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    const { event, data } = payload;

    if (!data.assigned_to || !data.due_date) {
      return Response.json({ success: true, message: 'No assigned_to or due_date' });
    }

    // Only notify on create, or when assigned_to/due_date changes
    const old_data = payload.old_data;
    const isNew = event.type === 'create';
    const assigneeChanged = old_data && old_data.assigned_to !== data.assigned_to;
    const dueDateChanged = old_data && old_data.due_date !== data.due_date;

    if (!isNew && !assigneeChanged && !dueDateChanged) {
      return Response.json({ success: true, message: 'No relevant change' });
    }

    const actionUrl = `/ActionItems`;
    const title = isNew
      ? `New Action Assigned: ${data.title}`
      : `Action Updated: ${data.title}`;
    const message = `You have been assigned action "${data.title}" due on ${data.due_date}. Priority: ${data.priority}.`;

    // In-app notification
    await base44.asServiceRole.entities.Notification.create({
      recipient_email: data.assigned_to,
      title,
      message,
      type: 'assignment',
      entity_type: 'ActionItem',
      entity_id: event.entity_id,
      action_url: actionUrl,
      is_read: false,
    });

    // Email
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: data.assigned_to,
      subject: title,
      body: `${message}\n\nLog in to the compliance tracker to take action.`,
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('notifyActionItemDue error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});