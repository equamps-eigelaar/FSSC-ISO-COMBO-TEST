import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { attendees, subject, body } = await req.json();

    if (!attendees || !Array.isArray(attendees) || attendees.length === 0) {
      return Response.json({ error: 'Attendees array is required' }, { status: 400 });
    }

    if (!subject || !body) {
      return Response.json({ error: 'Subject and body are required' }, { status: 400 });
    }

    // Get Gmail access token
    const { accessToken } = await base44.asServiceRole.connectors.getConnection('gmail');

    // Send email to each attendee
    const results = [];
    for (const email of attendees) {
      // Create RFC 2822 formatted email
      const emailLines = [
        `To: ${email}`,
        `Subject: ${subject}`,
        'Content-Type: text/plain; charset=utf-8',
        '',
        body
      ];
      const rawEmail = emailLines.join('\r\n');
      
      // Base64url encode (Gmail API requirement)
      const base64Email = btoa(unescape(encodeURIComponent(rawEmail)))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');

      // Send via Gmail API
      const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ raw: base64Email })
      });

      if (response.ok) {
        results.push({ email, status: 'sent' });
      } else {
        const error = await response.text();
        results.push({ email, status: 'failed', error });
      }
    }

    return Response.json({
      success: true,
      sent: results.filter(r => r.status === 'sent').length,
      failed: results.filter(r => r.status === 'failed').length,
      results
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});