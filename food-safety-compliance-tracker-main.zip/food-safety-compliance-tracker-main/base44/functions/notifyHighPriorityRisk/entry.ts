import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch(() => null);
    if (user && user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { event } = await req.json();
    
    if (!event || event.entity_name !== 'RiskAssessment') {
      return Response.json({ error: 'Invalid event' }, { status: 400 });
    }

    const risk = event.data;
    
    if (!risk || (risk.risk_level !== 'high' && risk.risk_level !== 'critical')) {
      return Response.json({ skipped: 'Not high priority risk' });
    }

    const allUsers = await base44.asServiceRole.entities.User.list();
    const preferences = await base44.asServiceRole.entities.NotificationPreference.list();

    let notificationsSent = 0;

    for (const targetUser of allUsers) {
      const userPref = preferences.find(p => p.user_email === targetUser.email);
      if (userPref && userPref.high_priority_risks === false) continue;

      await base44.asServiceRole.entities.Notification.create({
        recipient_email: targetUser.email,
        title: `${risk.risk_level.toUpperCase()} Risk ${event.type === 'create' ? 'Created' : 'Updated'}`,
        message: `A ${risk.risk_level} risk assessment has been ${event.type}d: ${risk.hazard_description?.substring(0, 80)}...`,
        type: 'high_priority_risk',
        entity_type: 'RiskAssessment',
        entity_id: risk.id,
        is_read: false
      });

      notificationsSent++;
    }

    return Response.json({
      success: true,
      notifications_sent: notificationsSent,
      risk_level: risk.risk_level
    });
  } catch (error) {
    console.error('Error notifying high priority risk:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});