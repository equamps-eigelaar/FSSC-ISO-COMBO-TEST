import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const { share_id, recipient_email, document_name, shared_by, share_type } = await req.json();

    if (!share_id || !recipient_email || !document_name) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Create notification record
    await base44.entities.Notification.create({
      recipient_email,
      title: `Proprietary ${share_type} shared with you`,
      message: `${shared_by} shared the ${share_type} "${document_name}" with you. You have access to view this proprietary information.`,
      type: 'document_review',
      entity_type: 'ProprietaryShare',
      entity_id: share_id,
      action_url: `/document-repository?share=${share_id}`,
      priority: 'high'
    });

    // Send email notification
    await base44.integrations.Core.SendEmail({
      to: recipient_email,
      subject: `Proprietary Information Shared: ${document_name}`,
      body: `<html><body>
        <h2>Proprietary Information Access</h2>
        <p>Dear user,</p>
        <p><strong>${shared_by}</strong> has shared proprietary information with you:</p>
        <p><strong>Document:</strong> ${document_name}</p>
        <p><strong>Type:</strong> ${share_type}</p>
        <p style="background-color: #fef3c7; padding: 12px; border-left: 4px solid #f59e0b; margin: 16px 0;">
          <strong>⚠️ Important:</strong> This document contains sensitive proprietary information. 
          Please handle it with appropriate confidentiality measures.
        </p>
        <p>You can access this information in the Document Repository under "Proprietary Shares".</p>
        <p>Best regards,<br/>Package Manufacturing Compliance Team</p>
      </body></html>`
    });

    return Response.json({ success: true, message: 'Notification sent' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});