import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Fetch today's monitoring logs
    const today = new Date().toISOString().split('T')[0];
    const logs = await base44.asServiceRole.entities.MonitoringLog.filter({ log_date: today });
    const cleaningRegisters = await base44.asServiceRole.entities.CleaningRegister.filter({ date: today });

    // Group logs by type
    const logsByType = logs.reduce((acc, log) => {
      if (!acc[log.log_type]) acc[log.log_type] = [];
      acc[log.log_type].push(log);
      return acc;
    }, {});

    // Build email content
    const emailLines = [
      `<h2>Daily Monitoring Report - ${today}</h2>`,
      `<h3>MONITORING LOGS (${logs.length} total)</h3>`,
    ];

    for (const [type, items] of Object.entries(logsByType)) {
      emailLines.push(`<h4>${type.toUpperCase().replace(/_/g, ' ')} (${items.length})</h4><ul>`);
      items.forEach(log => {
        const status = log.status || 'completed';
        const location = log.location || 'N/A';
        const shift = log.shift || 'N/A';
        let item = `<li><strong>${location}</strong> – ${shift} shift – Status: <em>${status}</em>`;
        if (log.readings?.length > 0) {
          item += '<ul>';
          log.readings.forEach(reading => {
            item += `<li>${reading.parameter}: ${reading.value} ${reading.unit || ''} [${reading.status || 'acceptable'}]</li>`;
          });
          item += '</ul>';
        }
        if (log.corrective_action) item += `<br/>⚠ Action: ${log.corrective_action}`;
        item += '</li>';
        emailLines.push(item);
      });
      emailLines.push('</ul>');
    }

    emailLines.push(`<h3>CLEANING REGISTERS (${cleaningRegisters.length} total)</h3><ul>`);
    cleaningRegisters.forEach(reg => {
      const result = reg.result || 'N/A';
      const area = reg.area || 'Unknown';
      let item = `<li><strong>${area}</strong> – Result: ${result}`;
      if (reg.chemicals_used?.length > 0) item += ` | Chemicals: ${reg.chemicals_used.join(', ')}`;
      item += '</li>';
      emailLines.push(item);
    });
    emailLines.push('</ul>');

    const totalIssues = logs.filter(log =>
      log.readings?.some(r => r.status === 'out_of_spec') || log.status === 'requires_review'
    ).length;

    emailLines.push(`<h3>SUMMARY</h3>`);
    emailLines.push(`<p>Total Logs: <strong>${logs.length}</strong><br/>`);
    emailLines.push(`Total Cleaning Entries: <strong>${cleaningRegisters.length}</strong><br/>`);
    emailLines.push(`Items Requiring Attention: <strong>${totalIssues}</strong></p>`);
    emailLines.push(`<hr/><p><small>This report was generated automatically by the FSMS Compliance System.</small></p>`);

    const emailBody = emailLines.join('\n');

    // Get admin users to send to
    const adminUsers = await base44.asServiceRole.entities.User.filter({ role: 'admin' });
    const managementEmails = adminUsers.map(u => u.email).filter(Boolean);

    if (managementEmails.length === 0) {
      return Response.json({ error: 'No admin emails found', logsProcessed: logs.length }, { status: 400 });
    }

    // Send via built-in email integration (no connector required)
    for (const recipientEmail of managementEmails) {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: recipientEmail,
        subject: `Daily Monitoring Report - ${today}`,
        body: emailBody,
      });
    }

    return Response.json({
      success: true,
      date: today,
      logsProcessed: logs.length,
      cleaningEntriesProcessed: cleaningRegisters.length,
      emailsSent: managementEmails.length,
      recipients: managementEmails,
    });

  } catch (error) {
    console.error('Error sending daily monitoring report:', error);
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
});