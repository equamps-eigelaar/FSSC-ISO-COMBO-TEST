import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { comment_id, mentioned_emails, author_email, entity_type, entity_id, excerpt } = await req.json();

    for (const mentioned_email of mentioned_emails) {
      // Skip if mentioning themselves
      if (mentioned_email === author_email) continue;

      // Create in-app notification
      await base44.asServiceRole.entities.Notification.create({
        recipient_email: mentioned_email,
        title: `You were mentioned in a comment`,
        message: `${author_email} mentioned you in a comment on ${entity_type}.`,
        type: 'comment',
        entity_type: 'Comment',
        entity_id: comment_id,
        priority: 'normal'
      });

      // Send email notification
      await base44.integrations.Core.SendEmail({
        to: mentioned_email,
        subject: `You were mentioned in a comment`,
        body: `Hello,\n\n${author_email} mentioned you in a comment on ${entity_type}:\n\n"${excerpt}"\n\nPlease log in to the application to view the full discussion.\n\nBest regards,\nPackage Manufacturing Compliance Team`
      });
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});