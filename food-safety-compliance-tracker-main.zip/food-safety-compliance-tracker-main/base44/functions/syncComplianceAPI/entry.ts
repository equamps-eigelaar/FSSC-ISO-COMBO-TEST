import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { integrationId } = await req.json();

    // Fetch integration details
    const integration = await base44.entities.ComplianceDataImport.read(integrationId);

    if (!integration) {
      return Response.json({ error: 'Integration not found' }, { status: 404 });
    }

    if (!integration.active) {
      return Response.json({ error: 'Integration is not active' }, { status: 400 });
    }

    let syncResults = {
      success: false,
      recordsImported: 0,
      recordsUpdated: 0,
      errors: [],
      message: '',
    };

    try {
      // Call the external API
      const apiResponse = await fetch(integration.api_url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${integration.api_key}`,
          'Content-Type': 'application/json',
        },
      });

      if (!apiResponse.ok) {
        throw new Error(`API returned status ${apiResponse.status}`);
      }

      const apiData = await apiResponse.json();

      // Parse API response based on provider
      const records = parseAPIResponse(apiData, integration.provider);

      if (!Array.isArray(records) || records.length === 0) {
        syncResults.message = 'No new data from API';
        syncResults.success = true;
      } else {
        // Import records
        const existingRequirements = await base44.entities.ComplianceRequirement?.list?.() || [];

        for (const record of records) {
          try {
            const requirementData = {
              clause_number: record.clauseNumber || record.id,
              clause_title: record.title || record.name,
              section: record.section || 'Other Requirements',
              description: record.description || '',
              status: record.status || 'not_started',
              priority: record.priority || 'medium',
              evidence_notes: `Synced from ${integration.provider} on ${new Date().toISOString()}`
            };

            const existing = existingRequirements.find(
              r => r.clause_number === requirementData.clause_number
            );

            if (existing) {
              await base44.entities.ComplianceRequirement.update(existing.id, requirementData);
              syncResults.recordsUpdated++;
            } else {
              await base44.entities.ComplianceRequirement.create(requirementData);
              syncResults.recordsImported++;
            }
          } catch (error) {
            syncResults.errors.push(`Failed to import record: ${error.message}`);
          }
        }

        syncResults.success = true;
        syncResults.message = `Synced ${syncResults.recordsImported} new and updated ${syncResults.recordsUpdated} requirements`;
      }
    } catch (error) {
      syncResults.success = false;
      syncResults.message = `API sync failed: ${error.message}`;
    }

    // Update integration with sync results
    await base44.entities.ComplianceDataImport.update(integrationId, {
      last_sync_date: new Date().toISOString(),
      last_sync_status: syncResults.success ? 'success' : 'error',
      last_sync_message: syncResults.message,
      records_imported: (integration.records_imported || 0) + syncResults.recordsImported,
      records_updated: (integration.records_updated || 0) + syncResults.recordsUpdated,
    });

    // Log activity
    await base44.functions.invoke('logActivity', {
      activity_type: 'system_event',
      entity_type: 'ComplianceDataImport',
      entity_id: integrationId,
      entity_label: integration.name,
      description: `API sync: ${syncResults.message}`,
      user_email: user.email,
    });

    return Response.json(syncResults);
  } catch (error) {
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});

function parseAPIResponse(data, provider) {
  if (provider === 'generic') {
    // Expect standard format with array of requirements
    return Array.isArray(data) ? data : data.requirements || data.data || [];
  }

  if (provider === 'iso_registry') {
    // ISO Registry specific format
    return data.clauses || data.requirements || [];
  }

  if (provider === 'fssc_database') {
    // FSSC Database specific format
    return data.requirements || data.items || [];
  }

  return [];
}