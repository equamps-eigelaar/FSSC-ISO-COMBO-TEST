import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const now = new Date();
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const allUsers = await base44.asServiceRole.entities.User.list();
    const preferences = await base44.asServiceRole.entities.NotificationPreference.list();
    
    const usersToNotify = allUsers.filter(user => {
      const userPref = preferences.find(p => p.user_email === user.email);
      return userPref?.email_digest_frequency === 'daily';
    });

    let sentCount = 0;

    for (const user of usersToNotify) {
      const notifications = await base44.asServiceRole.entities.Notification.filter({
        recipient_email: user.email,
        is_read: false
      });

      const recentNotifications = notifications.filter(n => 
        new Date(n.created_date) >= yesterday
      );

      if (recentNotifications.length === 0) continue;

      const emailBody = `
        <h2>Daily Compliance Digest</h2>
        <p>Hi ${user.full_name},</p>
        <p>You have ${recentNotifications.length} unread notification(s) from the last 24 hours:</p>
        <ul>
          ${recentNotifications.slice(0, 10).map(n => `
            <li>
              <strong>${n.title}</strong><br>
              ${n.message}
            </li>
          `).join('')}
        </ul>
        ${recentNotifications.length > 10 ? `<p>...and ${recentNotifications.length - 10} more</p>` : ''}
        <p>Visit the compliance portal to view all notifications.</p>
      `;

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: user.email,
        subject: `Daily Compliance Digest - ${recentNotifications.length} Updates`,
        body: emailBody
      });

      sentCount++;
    }

    return Response.json({
      success: true,
      digests_sent: sentCount,
      users_notified: usersToNotify.length
    });
  } catch (error) {
    console.error('Error sending digests:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});