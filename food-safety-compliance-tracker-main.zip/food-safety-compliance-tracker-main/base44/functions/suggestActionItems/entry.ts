import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch compliance data
    const requirements = await base44.asServiceRole.entities.ComplianceRequirement.list("-updated_date", 200);
    const risks = await base44.asServiceRole.entities.RiskAssessment.list("-created_date", 100);
    const audits = await base44.asServiceRole.entities.ComplianceAudit.list("-audit_date", 5);
    const existingActions = await base44.asServiceRole.entities.ActionItem.list("-created_date", 100);
    const users = await base44.asServiceRole.entities.User.list("full_name", 50);

    // Identify issues needing action
    const overdueRequirements = requirements.filter(r => 
      r.due_date && new Date(r.due_date) < new Date() && r.status !== 'compliant'
    ).slice(0, 5);

    const criticalRisks = risks.filter(r => 
      (r.risk_level === 'critical' || r.risk_level === 'high') && 
      r.workflow_status !== 'approved'
    ).slice(0, 5);

    const nonCompliantReqs = requirements.filter(r => 
      r.status === 'non_compliant' || r.status === 'not_started'
    ).slice(0, 10);

    const latestAuditFindings = audits.length > 0 && audits[0].findings 
      ? audits[0].findings.filter(f => f.severity === 'critical' || f.severity === 'high').slice(0, 5)
      : [];

    // Build context for AI
    const context = {
      overdueRequirements: overdueRequirements.map(r => ({
        clause: r.clause_number,
        title: r.clause_title,
        status: r.status,
        priority: r.priority,
        due_date: r.due_date,
        assigned_to: r.assigned_to
      })),
      criticalRisks: criticalRisks.map(r => ({
        hazard_type: r.hazard_type,
        description: r.hazard_description,
        risk_level: r.risk_level,
        mitigation: r.mitigation_strategy,
        assigned_to: r.assigned_to
      })),
      nonCompliantRequirements: nonCompliantReqs.map(r => ({
        clause: r.clause_number,
        title: r.clause_title,
        status: r.status,
        priority: r.priority,
        corrective_actions: r.corrective_actions
      })),
      auditFindings: latestAuditFindings.map(f => ({
        clause: f.clause_number,
        issue_type: f.issue_type,
        severity: f.severity,
        description: f.description,
        recommendation: f.recommendation
      })),
      availableUsers: users.map(u => u.email)
    };

    const prompt = `As a compliance management expert, analyze this compliance data and suggest 5-8 specific, actionable items that should be created to address gaps and risks.

OVERDUE REQUIREMENTS (${overdueRequirements.length}):
${JSON.stringify(context.overdueRequirements, null, 2)}

CRITICAL RISKS (${criticalRisks.length}):
${JSON.stringify(context.criticalRisks, null, 2)}

NON-COMPLIANT REQUIREMENTS (${nonCompliantReqs.length}):
${JSON.stringify(context.nonCompliantRequirements.slice(0, 5), null, 2)}

RECENT AUDIT FINDINGS (${latestAuditFindings.length}):
${JSON.stringify(context.auditFindings, null, 2)}

AVAILABLE TEAM MEMBERS:
${context.availableUsers.join(', ')}

For each suggested action item, provide:
1. A clear, specific title
2. Detailed description of what needs to be done
3. Recommended owner (email from available users, or "unassigned" if unclear)
4. Realistic timeline (e.g., "2 weeks", "1 month", "3 days")
5. Priority level (critical, high, medium, or low)
6. Source reference (which requirement, risk, or finding it addresses)

Focus on:
- Immediate corrective actions for overdue/critical items
- Preventive actions for identified risks
- Evidence gathering for non-compliant requirements
- Addressing audit findings

Return 5-8 actionable, realistic items that can be immediately assigned and tracked.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          suggested_actions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                recommended_owner: { type: "string" },
                timeline: { type: "string" },
                priority: { 
                  type: "string",
                  enum: ["critical", "high", "medium", "low"]
                },
                source_reference: { type: "string" },
                rationale: { type: "string" }
              }
            }
          },
          summary: { type: "string" }
        }
      }
    });

    return Response.json({
      success: true,
      suggestions: result.suggested_actions || [],
      summary: result.summary,
      context_analyzed: {
        overdue_requirements: overdueRequirements.length,
        critical_risks: criticalRisks.length,
        non_compliant: nonCompliantReqs.length,
        audit_findings: latestAuditFindings.length
      }
    });

  } catch (error) {
    console.error('Error suggesting action items:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});