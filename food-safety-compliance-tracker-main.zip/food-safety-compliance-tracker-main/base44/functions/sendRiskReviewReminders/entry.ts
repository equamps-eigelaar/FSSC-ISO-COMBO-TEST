import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const allRisks = await base44.asServiceRole.entities.RiskAssessment.list('-created_date', 500);
    const today = new Date();
    const reminders = [];

    for (const risk of allRisks) {
      if (!risk.review_date || !risk.assigned_to) continue;

      const reviewDate = new Date(risk.review_date);
      const daysUntilReview = Math.ceil((reviewDate - today) / (1000 * 60 * 60 * 24));

      // Send reminder if review is due within 7 days or overdue
      if (daysUntilReview <= 7 && daysUntilReview >= -30) {
        const requirement = await base44.asServiceRole.entities.ComplianceRequirement
          .list('-created_date', 200)
          .then(reqs => reqs.find(r => r.id === risk.requirement_id));

        const isOverdue = daysUntilReview < 0;
        const message = isOverdue
          ? `Risk assessment review is ${Math.abs(daysUntilReview)} days overdue`
          : `Risk assessment review is due in ${daysUntilReview} days`;

        await base44.asServiceRole.entities.Notification.create({
          recipient_email: risk.assigned_to,
          title: isOverdue ? 'Overdue Risk Review' : 'Upcoming Risk Review',
          message: `${message} for "${risk.hazard_description}" (${requirement?.clause_number || 'N/A'})`,
          type: 'due_soon',
          entity_type: 'RiskAssessment',
          entity_id: risk.id,
          action_url: `/RiskWorkflow`,
        });

        reminders.push({
          risk_id: risk.id,
          assigned_to: risk.assigned_to,
          days_until_review: daysUntilReview,
        });
      }
    }

    return Response.json({
      success: true,
      reminders_sent: reminders.length,
      details: reminders,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});