import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { data, mapping, framework, validationResults } = await req.json();

    const importResults = {
      created: 0,
      updated: 0,
      errors: [],
      importedRequirements: []
    };

    // Get existing requirements for comparison
    const existingRequirements = await base44.entities.ComplianceRequirement?.list?.() || [];

    // Process each record
    for (const record of data) {
      try {
        const clauseNum = getMappedValue(record, mapping, 'Clause Number');
        const title = getMappedValue(record, mapping, 'Clause Title');
        const description = getMappedValue(record, mapping, 'Description');
        const status = getMappedValue(record, mapping, 'Status') || 'not_started';
        const priority = getMappedValue(record, mapping, 'Priority') || 'medium';
        const section = getMappedValue(record, mapping, 'Section') || getDefaultSection(framework, clauseNum);

        if (!clauseNum || !title) continue;

        // Normalize status
        const normalizedStatus = normalizeStatus(status);

        const requirementData = {
          clause_number: clauseNum,
          clause_title: title,
          section: section,
          description: description || '',
          status: normalizedStatus,
          priority: normalizePriority(priority),
          evidence_notes: `Imported from ${framework} on ${new Date().toISOString()}`
        };

        // Check if requirement exists
        const existing = existingRequirements.find(r => r.clause_number === clauseNum);

        if (existing) {
          // Update existing
          await base44.entities.ComplianceRequirement.update(existing.id, requirementData);
          importResults.updated++;
        } else {
          // Create new
          const created = await base44.entities.ComplianceRequirement.create(requirementData);
          importResults.created++;
          importResults.importedRequirements.push(created.id);
        }
      } catch (error) {
        importResults.errors.push(`Row error: ${error.message}`);
      }
    }

    // Log the import activity
    await base44.functions.invoke('logActivity', {
      activity_type: 'system_event',
      entity_type: 'ComplianceDataImport',
      entity_id: `import-${Date.now()}`,
      entity_label: `Import from ${framework}`,
      description: `Bulk compliance data import: ${importResults.created} created, ${importResults.updated} updated`,
      user_email: user.email,
    });

    return Response.json({
      success: true,
      results: importResults,
      summary: `Import completed: ${importResults.created} new, ${importResults.updated} updated`
    });
  } catch (error) {
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});

function getMappedValue(record, mapping, field) {
  for (const [csvCol, mappedField] of Object.entries(mapping)) {
    if (mappedField === field && record[csvCol]) {
      return record[csvCol].toString().trim();
    }
  }
  return null;
}

function normalizeStatus(status) {
  const normalized = status.toLowerCase().replace(/\s+/g, '_');
  const validStatuses = ['not_started', 'in_progress', 'partial', 'compliant', 'non_compliant'];
  return validStatuses.includes(normalized) ? normalized : 'not_started';
}

function normalizePriority(priority) {
  const normalized = priority.toLowerCase();
  const validPriorities = ['critical', 'high', 'medium', 'low'];
  return validPriorities.includes(normalized) ? normalized : 'medium';
}

function getDefaultSection(framework, clauseNum) {
  if (framework === 'iso22000') {
    const majorSection = clauseNum.split('.')[0];
    const sections = {
      '4': '4 - Context of the Organization',
      '5': '5 - Leadership',
      '6': '6 - Planning',
      '7': '7 - Support',
      '8': '8 - Operation',
      '9': '9 - Performance Evaluation',
      '10': '10 - Improvement'
    };
    return sections[majorSection] || 'Other Requirements';
  }

  if (framework === 'ts22002_4') {
    return 'TS 22002-4 - Establishment';
  }

  return 'Other Requirements';
}