import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

async function getValidToken(base44) {
  const tokens = await base44.asServiceRole.entities.XeroToken.filter({});
  if (tokens.length === 0) throw new Error('Xero not connected');
  let token = tokens[0];

  if (new Date(token.expires_at) < new Date(Date.now() + 60000)) {
    const CLIENT_ID = Deno.env.get('XERO_CLIENT_ID');
    const CLIENT_SECRET = Deno.env.get('XERO_CLIENT_SECRET');
    const credentials = btoa(`${CLIENT_ID}:${CLIENT_SECRET}`);
    const res = await fetch('https://identity.xero.com/connect/token', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: token.refresh_token }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error('Token refresh failed: ' + JSON.stringify(data));
    token = { ...token, access_token: data.access_token, refresh_token: data.refresh_token, expires_at: new Date(Date.now() + data.expires_in * 1000).toISOString() };
    await base44.asServiceRole.entities.XeroToken.update(token.id, { access_token: token.access_token, refresh_token: token.refresh_token, expires_at: token.expires_at });
  }
  return token;
}

async function createXeroInvoice(token, { customerName, customerEmail, plan, billingCycle, reference }) {
  const unitAmount = billingCycle === 'annual' ? (plan.price_annual || Math.round(plan.price_monthly * 0.85)) : plan.price_monthly;
  const today = new Date().toISOString().split('T')[0];
  const dueDate = new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0];

  const headers = {
    'Authorization': `Bearer ${token.access_token}`,
    'Xero-tenant-id': token.tenant_id,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  const invoicePayload = {
    Type: 'ACCREC',
    Contact: { Name: customerName, EmailAddress: customerEmail || '' },
    Date: today,
    DueDate: dueDate,
    Status: 'DRAFT',
    Reference: reference || `SUB-${plan.tier?.toUpperCase()}-${Date.now()}`,
    CurrencyCode: plan.currency || 'ZAR',
    LineItems: [{
      Description: `${plan.name} Plan — ${billingCycle === 'annual' ? 'Annual' : 'Monthly'} Subscription`,
      Quantity: 1,
      UnitAmount: unitAmount,
      AccountCode: plan.xero_account_code || '200',
    }],
  };

  const res = await fetch('https://api.xero.com/api.xro/2.0/Invoices', {
    method: 'POST',
    headers,
    body: JSON.stringify({ Invoices: [invoicePayload] }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error('Xero invoice creation failed: ' + JSON.stringify(data));
  return data.Invoices?.[0];
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { action } = body;

    // ── SUBSCRIBE / UPGRADE / DOWNGRADE ──────────────────────────────────────
    if (action === 'subscribe') {
      const { planId, billingCycle = 'monthly', customerName, customerEmail } = body;
      if (!planId) return Response.json({ error: 'planId is required' }, { status: 400 });

      // Load plan
      const plans = await base44.asServiceRole.entities.PricePlan.filter({ id: planId });
      if (plans.length === 0) return Response.json({ error: 'Plan not found' }, { status: 404 });
      const plan = plans[0];

      const amount = billingCycle === 'annual'
        ? (plan.price_annual || Math.round(plan.price_monthly * 0.85))
        : plan.price_monthly;

      // Calculate dates
      const today = new Date().toISOString().split('T')[0];
      const nextBillingDate = billingCycle === 'annual'
        ? new Date(Date.now() + 365 * 86400000).toISOString().split('T')[0]
        : new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];

      // Find or create subscription record
      const existingSubs = await base44.entities.Subscription.filter({ user_email: user.email });
      let sub;

      const subData = {
        user_email: user.email,
        plan_id: plan.id,
        plan_name: plan.name,
        plan_tier: plan.tier,
        billing_cycle: billingCycle,
        amount,
        currency: plan.currency || 'ZAR',
        status: 'active',
        start_date: today,
        next_billing_date: nextBillingDate,
      };

      if (existingSubs.length > 0) {
        sub = await base44.entities.Subscription.update(existingSubs[0].id, subData);
      } else {
        sub = await base44.entities.Subscription.create(subData);
      }

      // Try to push Xero invoice (non-blocking — if Xero not connected, still succeed)
      let xeroInvoice = null;
      let xeroError = null;
      try {
        const token = await getValidToken(base44);
        xeroInvoice = await createXeroInvoice(token, {
          customerName: customerName || user.full_name || user.email,
          customerEmail: customerEmail || user.email,
          plan,
          billingCycle,
          reference: `SUB-${plan.tier?.toUpperCase()}-${user.email.split('@')[0]}`,
        });

        // Save xero invoice ID on subscription
        await base44.entities.Subscription.update(sub.id, { xero_repeating_invoice_id: xeroInvoice?.InvoiceID });

        // Also create billing record
        await base44.asServiceRole.entities.BillingRecord.create({
          transaction_date: today,
          billable_type: 'template_usage',
          entity_name: `${plan.name} Plan Subscription`,
          customer_type: 'external',
          customer_name: customerName || user.full_name || user.email,
          customer_email: customerEmail || user.email,
          quantity: 1,
          unit_cost: amount,
          total_cost: amount,
          currency: plan.currency || 'ZAR',
          description: `${billingCycle === 'annual' ? 'Annual' : 'Monthly'} subscription — ${plan.name}`,
          billing_status: 'pending',
          xero_invoice_id: xeroInvoice?.InvoiceID,
          xero_approval_status: 'draft_created',
          notes: `Auto-generated on plan selection. Xero ID: ${xeroInvoice?.InvoiceID}`,
        });
      } catch (e) {
        xeroError = e.message;
      }

      return Response.json({
        success: true,
        message: `Successfully subscribed to ${plan.name}!`,
        subscription: sub,
        xeroInvoice: xeroInvoice ? { id: xeroInvoice.InvoiceID, number: xeroInvoice.InvoiceNumber } : null,
        xeroError,
      });
    }

    // ── CANCEL ────────────────────────────────────────────────────────────────
    if (action === 'cancel') {
      const { subscriptionId } = body;
      const subs = await base44.entities.Subscription.filter({ user_email: user.email });
      const sub = subscriptionId
        ? subs.find((s) => s.id === subscriptionId)
        : subs[0];

      if (!sub) return Response.json({ error: 'No subscription found' }, { status: 404 });

      await base44.entities.Subscription.update(sub.id, {
        status: 'cancelled',
        cancelled_date: new Date().toISOString().split('T')[0],
      });

      return Response.json({ success: true, message: 'Subscription cancelled.' });
    }

    // ── GET MY SUBSCRIPTION ───────────────────────────────────────────────────
    if (action === 'get_my_subscription') {
      const subs = await base44.entities.Subscription.filter({ user_email: user.email });
      return Response.json({ success: true, subscription: subs[0] || null });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});