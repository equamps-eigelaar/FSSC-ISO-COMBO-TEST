import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

async function getValidToken(base44) {
  const tokens = await base44.asServiceRole.entities.XeroToken.filter({});
  if (tokens.length === 0) throw new Error('Xero not connected');
  let token = tokens[0];

  if (new Date(token.expires_at) < new Date(Date.now() + 60000)) {
    const CLIENT_ID = Deno.env.get('XERO_CLIENT_ID');
    const CLIENT_SECRET = Deno.env.get('XERO_CLIENT_SECRET');
    const credentials = btoa(`${CLIENT_ID}:${CLIENT_SECRET}`);
    const res = await fetch('https://identity.xero.com/connect/token', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: token.refresh_token,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error('Token refresh failed');
    token = { ...token, access_token: data.access_token, refresh_token: data.refresh_token, expires_at: new Date(Date.now() + data.expires_in * 1000).toISOString() };
    await base44.asServiceRole.entities.XeroToken.update(token.id, {
      access_token: token.access_token,
      refresh_token: token.refresh_token,
      expires_at: token.expires_at,
    });
  }
  return token;
}

function addMonths(date, n) {
  const d = new Date(date);
  d.setMonth(d.getMonth() + n);
  return d.toISOString().split('T')[0];
}

function addYears(date, n) {
  const d = new Date(date);
  d.setFullYear(d.getFullYear() + n);
  return d.toISOString().split('T')[0];
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const action = body.action;

    // === CREATE SUBSCRIPTION ===
    if (action === 'create_subscription') {
      const { plan_id, billing_cycle, customer_name, customer_email } = body;

      const plans = await base44.asServiceRole.entities.PricePlan.filter({ id: plan_id });
      if (!plans.length) return Response.json({ error: 'Plan not found' }, { status: 404 });
      const plan = plans[0];

      const amount = billing_cycle === 'annual' ? (plan.price_annual || plan.price_monthly * 12) : plan.price_monthly;
      const today = new Date().toISOString().split('T')[0];
      const nextBilling = billing_cycle === 'annual' ? addYears(today, 1) : addMonths(today, 1);

      // Check for existing active subscription
      const existing = await base44.asServiceRole.entities.Subscription.filter({
        user_email: customer_email,
        status: 'active',
      });
      if (existing.length > 0) {
        // Cancel old one first
        await base44.asServiceRole.entities.Subscription.update(existing[0].id, {
          status: 'cancelled',
          cancelled_date: today,
        });
      }

      // Create subscription record
      const subscription = await base44.asServiceRole.entities.Subscription.create({
        user_email: customer_email,
        plan_id: plan.id,
        plan_name: plan.name,
        plan_tier: plan.tier,
        billing_cycle,
        amount,
        currency: plan.currency || 'USD',
        status: 'active',
        start_date: today,
        next_billing_date: nextBilling,
      });

      // Push to Xero if connected
      let xeroResult = null;
      try {
        const token = await getValidToken(base44);
        const headers = {
          'Authorization': `Bearer ${token.access_token}`,
          'Xero-tenant-id': token.tenant_id,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        };

        // Create/find contact in Xero
        const contactRes = await fetch(`https://api.xero.com/api.xro/2.0/Contacts?where=EmailAddress="${customer_email}"`, { headers });
        const contactData = await contactRes.json();
        let xeroContactId = contactData.Contacts?.[0]?.ContactID;

        if (!xeroContactId) {
          const newContactRes = await fetch('https://api.xero.com/api.xro/2.0/Contacts', {
            method: 'POST',
            headers,
            body: JSON.stringify({
              Contacts: [{ Name: customer_name || customer_email, EmailAddress: customer_email }],
            }),
          });
          const newContactData = await newContactRes.json();
          xeroContactId = newContactData.Contacts?.[0]?.ContactID;
        }

        // Create an invoice for the first billing period
        const invoiceData = {
          Type: 'ACCREC',
          Contact: { ContactID: xeroContactId },
          Date: today,
          DueDate: nextBilling,
          LineItems: [{
            Description: `${plan.name} Plan - ${billing_cycle === 'annual' ? 'Annual' : 'Monthly'} Subscription`,
            Quantity: 1,
            UnitAmount: amount,
            AccountCode: plan.xero_account_code || '200',
          }],
          Status: 'AUTHORISED',
          Reference: `SUB-${subscription.id?.slice(-8).toUpperCase()}`,
          CurrencyCode: plan.currency || 'USD',
        };

        const invoiceRes = await fetch('https://api.xero.com/api.xro/2.0/Invoices', {
          method: 'POST',
          headers,
          body: JSON.stringify({ Invoices: [invoiceData] }),
        });
        const invoiceResult = await invoiceRes.json();
        xeroResult = invoiceResult.Invoices?.[0];

        if (xeroContactId && xeroResult?.InvoiceID) {
          await base44.asServiceRole.entities.Subscription.update(subscription.id, {
            xero_contact_id: xeroContactId,
            notes: `Xero Invoice ID: ${xeroResult.InvoiceID}`,
          });
        }
      } catch (xeroErr) {
        // Xero push failed but subscription still created
        xeroResult = { error: xeroErr.message };
      }

      return Response.json({ success: true, subscription, xeroInvoice: xeroResult });
    }

    // === CANCEL SUBSCRIPTION ===
    if (action === 'cancel_subscription') {
      const { subscription_id } = body;
      const subs = await base44.asServiceRole.entities.Subscription.filter({ id: subscription_id });
      if (!subs.length) return Response.json({ error: 'Subscription not found' }, { status: 404 });

      await base44.asServiceRole.entities.Subscription.update(subscription_id, {
        status: 'cancelled',
        cancelled_date: new Date().toISOString().split('T')[0],
      });

      return Response.json({ success: true });
    }

    // === GET USER SUBSCRIPTION ===
    if (action === 'get_subscription') {
      const { user_email } = body;
      const email = user_email || user.email;
      const subs = await base44.asServiceRole.entities.Subscription.filter({
        user_email: email,
        status: 'active',
      });
      return Response.json({ subscription: subs[0] || null });
    }

    // === LIST ALL SUBSCRIPTIONS (admin only) ===
    if (action === 'list_subscriptions') {
      if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });
      const subs = await base44.asServiceRole.entities.Subscription.list('-created_date', 100);
      return Response.json({ subscriptions: subs });
    }

    // === RENEW SUBSCRIPTION (create next invoice in Xero) ===
    if (action === 'renew_subscription') {
      if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });
      const { subscription_id } = body;
      const subs = await base44.asServiceRole.entities.Subscription.filter({ id: subscription_id });
      if (!subs.length) return Response.json({ error: 'Not found' }, { status: 404 });
      const sub = subs[0];

      const today = new Date().toISOString().split('T')[0];
      const nextBilling = sub.billing_cycle === 'annual' ? addYears(today, 1) : addMonths(today, 1);

      const token = await getValidToken(base44);
      const headers = {
        'Authorization': `Bearer ${token.access_token}`,
        'Xero-tenant-id': token.tenant_id,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

      const invoiceData = {
        Type: 'ACCREC',
        Contact: sub.xero_contact_id ? { ContactID: sub.xero_contact_id } : { Name: sub.user_email },
        Date: today,
        DueDate: nextBilling,
        LineItems: [{
          Description: `${sub.plan_name} Plan - ${sub.billing_cycle === 'annual' ? 'Annual' : 'Monthly'} Renewal`,
          Quantity: 1,
          UnitAmount: sub.amount,
          AccountCode: '200',
        }],
        Status: 'AUTHORISED',
        CurrencyCode: sub.currency || 'USD',
      };

      const invoiceRes = await fetch('https://api.xero.com/api.xro/2.0/Invoices', {
        method: 'POST',
        headers,
        body: JSON.stringify({ Invoices: [invoiceData] }),
      });
      const invoiceResult = await invoiceRes.json();
      const xeroInvoice = invoiceResult.Invoices?.[0];

      await base44.asServiceRole.entities.Subscription.update(subscription_id, {
        next_billing_date: nextBilling,
        notes: (sub.notes || '') + ` | Renewal Xero ID: ${xeroInvoice?.InvoiceID}`,
      });

      return Response.json({ success: true, xeroInvoice });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});