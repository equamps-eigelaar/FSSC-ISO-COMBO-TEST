import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Fetch active suppliers
    const suppliers = await base44.asServiceRole.entities.SupplierProfile.filter({ status: 'active' });

    if (suppliers.length === 0) {
      return Response.json({ success: true, message: 'No active suppliers found', emails_sent: 0 });
    }

    const supplierList = suppliers
      .map(s => `<li><strong>${s.supplier_name || s.name || 'Unknown'}</strong>${s.category ? ` – ${s.category}` : ''}</li>`)
      .join('');

    const quarter = Math.ceil((new Date().getMonth() + 1) / 3);
    const year = new Date().getFullYear();

    const emailBody = `
      <h2>Quarterly Supplier Evaluation Reminder – Q${quarter} ${year}</h2>
      <p>This is your quarterly reminder to complete supplier evaluations for all active suppliers.</p>
      <p>Please review and update the performance and compliance status for the following <strong>${suppliers.length} active supplier(s)</strong>:</p>
      <ul>${supplierList}</ul>
      <p>Evaluations help ensure continued compliance with ISO 22000:2018 supplier management requirements (Clause 7.1.6).</p>
      <p>Please navigate to <strong>Supplier Management</strong> in the FSMS Compliance Tracker to complete your evaluations.</p>
      <hr/>
      <p><small>This reminder was sent automatically by the FSMS Compliance System.</small></p>
    `;

    // Send to all admin users
    const adminUsers = await base44.asServiceRole.entities.User.filter({ role: 'admin' });
    const recipients = adminUsers.map(u => u.email).filter(Boolean);

    if (recipients.length === 0) {
      return Response.json({ success: false, error: 'No admin recipients found' }, { status: 400 });
    }

    for (const email of recipients) {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject: `Q${quarter} ${year} – Supplier Evaluation Reminder (${suppliers.length} suppliers)`,
        body: emailBody,
      });
    }

    return Response.json({
      success: true,
      quarter: `Q${quarter} ${year}`,
      suppliers_count: suppliers.length,
      emails_sent: recipients.length,
      recipients,
    });

  } catch (error) {
    console.error('Supplier evaluation reminder error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});