import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { product_name, product_code } = await req.json();

        // Fetch all available raw material batches
        const rawMaterials = await base44.entities.RawMaterialBatch.filter({
            status: { $in: ['approved', 'in_use'] }
        });

        if (rawMaterials.length === 0) {
            return Response.json({ suggestions: [] });
        }

        // Use AI to suggest relevant raw materials based on product name
        const prompt = `Given a food product named "${product_name}"${product_code ? ` (code: ${product_code})` : ''}, analyze which of these raw materials would likely be used in its production:

${rawMaterials.map(rm => `- ${rm.material_name} (${rm.material_code || 'no code'}): ${rm.batch_number}`).join('\n')}

Return a JSON array of suggested raw materials with confidence scores. Consider common food manufacturing ingredients and recipes. Include only materials that make sense for this product.

Response format:
{
  "suggestions": [
    {
      "batch_id": "id of the raw material batch",
      "material_name": "name",
      "batch_number": "batch number",
      "confidence": 0.95,
      "reason": "brief reason why this material is suggested"
    }
  ]
}`;

        const response = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: {
                type: "object",
                properties: {
                    suggestions: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                batch_id: { type: "string" },
                                material_name: { type: "string" },
                                batch_number: { type: "string" },
                                confidence: { type: "number" },
                                reason: { type: "string" }
                            }
                        }
                    }
                }
            }
        });

        // Validate that suggested batch IDs exist
        const validSuggestions = response.suggestions.filter(s => 
            rawMaterials.some(rm => rm.id === s.batch_id)
        );

        return Response.json({ 
            suggestions: validSuggestions,
            total_available: rawMaterials.length 
        });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});