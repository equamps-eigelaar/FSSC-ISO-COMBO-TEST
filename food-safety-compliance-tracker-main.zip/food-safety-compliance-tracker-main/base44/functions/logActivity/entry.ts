import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const EXCLUDED_FIELDS = ['id', 'created_date', 'updated_date', 'created_by'];

function getFieldChanges(oldData, newData) {
  const changes = [];
  const allKeys = new Set([
    ...Object.keys(oldData || {}),
    ...Object.keys(newData || {})
  ]);
  for (const key of allKeys) {
    if (EXCLUDED_FIELDS.includes(key)) continue;
    const oldVal = oldData?.[key];
    const newVal = newData?.[key];
    if (JSON.stringify(oldVal) !== JSON.stringify(newVal)) {
      changes.push({ field: key, old_value: truncate(oldVal), new_value: truncate(newVal) });
    }
  }
  return changes;
}

function truncate(val, len = 60) {
  if (val === null || val === undefined) return 'empty';
  if (typeof val === 'boolean') return val ? 'Yes' : 'No';
  if (Array.isArray(val)) return `[${val.length} item(s)]`;
  if (typeof val === 'object') return '[Object]';
  const s = String(val);
  return s.length > len ? s.substring(0, len) + '…' : s;
}

function buildEntry(event, data, old_data, userEmail, userName) {
  const { entity_name, entity_id, type: evtType } = event;
  let activity_type = '';
  let description = '';
  let entity_label = '';
  let field_changes = [];

  // ── ComplianceRequirement ──────────────────────────────
  if (entity_name === 'ComplianceRequirement') {
    const label = data?.clause_number
      ? `${data.clause_number} – ${data.clause_title || ''}`
      : (old_data?.clause_number || entity_id);
    entity_label = label;

    if (evtType === 'create') {
      activity_type = 'requirement_created';
      description = `Created requirement: ${label}`;
    } else if (evtType === 'delete') {
      activity_type = 'requirement_deleted';
      description = `Deleted requirement: ${label}`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      if (old_data?.status !== data?.status) {
        activity_type = 'status_changed';
        description = `Status changed on ${label}: "${old_data?.status}" → "${data?.status}"`;
      } else {
        activity_type = 'requirement_updated';
        const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
        description = `Updated requirement ${label} (${fields || 'no changes'})`;
      }
    }

  // ── RiskAssessment ─────────────────────────────────────
  } else if (entity_name === 'RiskAssessment') {
    const label = data?.hazard_description?.substring(0, 50) || entity_id;
    entity_label = label;

    if (evtType === 'create') {
      activity_type = 'risk_added';
      description = `Added ${data?.hazard_type} risk (${data?.risk_level} risk): ${label}`;
    } else if (evtType === 'delete') {
      activity_type = 'risk_deleted';
      description = `Deleted risk assessment: ${label}`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      if (old_data?.workflow_status !== data?.workflow_status) {
        activity_type = 'risk_workflow_changed';
        description = `Risk workflow changed on "${label}": "${old_data?.workflow_status}" → "${data?.workflow_status}"`;
      } else if (old_data?.risk_level !== data?.risk_level) {
        activity_type = 'risk_updated';
        description = `Risk level changed on "${label}": ${old_data?.risk_level} → ${data?.risk_level}`;
      } else {
        activity_type = 'risk_updated';
        const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
        description = `Updated risk assessment "${label}" (${fields || 'no changes'})`;
      }
    }

  // ── Document ───────────────────────────────────────────
  } else if (entity_name === 'Document') {
    const label = data?.file_name || old_data?.file_name || entity_id;
    entity_label = label;

    if (evtType === 'create') {
      activity_type = 'document_uploaded';
      description = `Uploaded document: "${label}" (${data?.document_type?.replace(/_/g, ' ') || 'unknown type'})`;
    } else if (evtType === 'delete') {
      activity_type = 'document_deleted';
      description = `Deleted document: "${label}"`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      if (old_data?.control_status !== data?.control_status) {
        activity_type = 'document_updated';
        description = `Control status changed on "${label}": "${old_data?.control_status}" → "${data?.control_status}"`;
      } else {
        activity_type = 'document_updated';
        const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
        description = `Updated document "${label}" (${fields || 'no changes'})`;
      }
    }

  // ── DocumentRevision ──────────────────────────────────
  } else if (entity_name === 'DocumentRevision') {
    const label = `v${data?.version || '?'}`;
    entity_label = label;

    if (evtType === 'create') {
      activity_type = 'document_version_added';
      description = `Added document revision ${label} for document ${data?.document_id}`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      activity_type = 'document_updated';
      description = `Updated document revision ${label}`;
    }

  // ── ActionItem ─────────────────────────────────────────
  } else if (entity_name === 'ActionItem') {
    const label = data?.title || old_data?.title || entity_id;
    entity_label = label;

    if (evtType === 'create') {
      activity_type = 'action_item_created';
      description = `Created action item: "${label}"`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      if (data?.status === 'completed' && old_data?.status !== 'completed') {
        activity_type = 'action_item_completed';
        description = `Completed action item: "${label}"`;
      } else {
        activity_type = 'action_item_updated';
        const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
        description = `Updated action item "${label}" (${fields || 'no changes'})`;
      }
    }

  // ── Generic fallback ───────────────────────────────────
  } else {
    entity_label = entity_id;
    if (evtType === 'create') {
      activity_type = 'system_event';
      description = `Created ${entity_name}`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      activity_type = 'system_event';
      description = `Updated ${entity_name}`;
    } else if (evtType === 'delete') {
      activity_type = 'system_event';
      description = `Deleted ${entity_name}`;
    }
  }

  return {
    activity_type,
    entity_type: entity_name,
    entity_id,
    entity_label,
    description,
    field_changes: field_changes.length ? field_changes : undefined,
    metadata: {
      event_type: evtType,
      change_count: field_changes.length || undefined
    },
    user_email: userEmail || data?.created_by || 'system',
    user_name: userName || undefined
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    const { event, data, old_data } = payload;

    if (!event?.entity_name) {
      return Response.json({ error: 'Missing event data' }, { status: 400 });
    }

    // Try to get the user who triggered this (best-effort)
    let userEmail = data?.created_by || data?.uploaded_by || 'system';
    let userName = undefined;
    try {
      const user = await base44.auth.me();
      if (user?.email) { userEmail = user.email; userName = user.full_name; }
    } catch (_) { /* unauthenticated context (automated triggers) */ }

    const entry = buildEntry(event, data, old_data, userEmail, userName);

    if (entry.activity_type) {
      await base44.asServiceRole.entities.ActivityLog.create(entry);
    }

    return Response.json({ success: true, logged: entry.activity_type });
  } catch (error) {
    console.error('logActivity error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});