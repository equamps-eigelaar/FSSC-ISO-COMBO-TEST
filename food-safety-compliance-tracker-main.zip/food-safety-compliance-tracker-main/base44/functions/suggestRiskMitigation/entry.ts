import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { riskId } = await req.json();

    if (!riskId) {
      return Response.json({ error: 'Risk ID required' }, { status: 400 });
    }

    // Fetch risk assessment details
    const risk = await base44.entities.RiskAssessment.list();
    const targetRisk = risk.find(r => r.id === riskId);

    if (!targetRisk) {
      return Response.json({ error: 'Risk not found' }, { status: 404 });
    }

    // Build context for AI
    const prompt = `As a food safety and packaging compliance expert, analyze this risk assessment and provide 2-3 specific, actionable mitigation strategies.

RISK DETAILS:
- Hazard Type: ${targetRisk.hazard_type}
- Risk Level: ${targetRisk.risk_level}
- Likelihood: ${targetRisk.likelihood}
- Severity: ${targetRisk.severity}
- Description: ${targetRisk.hazard_description}
${targetRisk.mitigation_strategy ? `- Current Mitigation: ${targetRisk.mitigation_strategy}` : ''}

Provide 2-3 specific mitigation strategies that include:
1. A clear, actionable strategy title
2. Detailed implementation steps
3. Recommended controls or best practices
4. Expected effectiveness (high, medium, low)
5. Implementation timeline estimate
6. Resource requirements

Focus on practical, industry-standard approaches for ${targetRisk.hazard_type} hazards in package manufacturing.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          mitigation_strategies: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                implementation_steps: {
                  type: "array",
                  items: { type: "string" }
                },
                controls: {
                  type: "array",
                  items: { type: "string" }
                },
                best_practices: {
                  type: "array",
                  items: { type: "string" }
                },
                effectiveness: {
                  type: "string",
                  enum: ["high", "medium", "low"]
                },
                timeline: { type: "string" },
                resources_needed: {
                  type: "array",
                  items: { type: "string" }
                }
              }
            }
          },
          overall_recommendation: { type: "string" }
        }
      }
    });

    return Response.json({
      success: true,
      risk: {
        id: targetRisk.id,
        hazard_type: targetRisk.hazard_type,
        risk_level: targetRisk.risk_level
      },
      suggestions: result.mitigation_strategies || [],
      recommendation: result.overall_recommendation
    });

  } catch (error) {
    console.error('Error suggesting risk mitigation:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});