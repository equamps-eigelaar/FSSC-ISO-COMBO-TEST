import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    if (!payload.action_type || !payload.description) {
      return Response.json({ error: 'Missing action_type or description' }, { status: 400 });
    }

    let user;
    try {
      user = await base44.auth.me();
    } catch (_) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Log the action
    const entry = {
      activity_type: payload.action_type,
      entity_type: payload.entity_type || 'System',
      entity_id: payload.entity_id || null,
      entity_label: payload.entity_label || payload.action_type,
      description: payload.description,
      user_email: user.email,
      user_name: user.full_name,
      metadata: {
        action_context: payload.context || {},
        details: payload.details || null
      },
      field_changes: payload.field_changes || null
    };

    await base44.asServiceRole.entities.ActivityLog.create(entry);

    return Response.json({ 
      success: true, 
      activity_id: entry.activity_type,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('logUserAction error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});