import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Allow scheduled automations (no user session) or admin users
    const user = await base44.auth.me().catch(() => null);
    if (user && user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized - Admin only' }, { status: 403 });
    }

    const [requirements, risks, audits, activities] = await Promise.all([
      base44.asServiceRole.entities.ComplianceRequirement.list("-updated_date", 500),
      base44.asServiceRole.entities.RiskAssessment.list("-updated_date", 500),
      base44.asServiceRole.entities.ComplianceAudit.list("-audit_date", 10),
      base44.asServiceRole.entities.ActivityLog.list("-created_date", 200)
    ]);

    // Calculate trends
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);

    const recentNonCompliant = requirements.filter(r => 
      r.status === 'non_compliant' && new Date(r.updated_date) > thirtyDaysAgo
    ).length;

    const previousNonCompliant = requirements.filter(r => 
      r.status === 'non_compliant' && 
      new Date(r.updated_date) > sixtyDaysAgo && 
      new Date(r.updated_date) <= thirtyDaysAgo
    ).length;

    const recentCriticalRisks = risks.filter(r => 
      r.risk_level === 'critical' && new Date(r.created_date) > thirtyDaysAgo
    ).length;

    const overdueCount = requirements.filter(r => {
      if (!r.due_date) return false;
      return new Date(r.due_date) < now && r.status !== 'compliant';
    }).length;

    const stagnantRequirements = requirements.filter(r => {
      const lastUpdate = new Date(r.updated_date);
      const daysSinceUpdate = (now - lastUpdate) / (1000 * 60 * 60 * 24);
      return r.status === 'in_progress' && daysSinceUpdate > 60;
    });

    // Section-level analysis
    const sectionStats = {};
    requirements.forEach(r => {
      if (!sectionStats[r.section]) {
        sectionStats[r.section] = { total: 0, compliant: 0, non_compliant: 0 };
      }
      sectionStats[r.section].total++;
      if (r.status === 'compliant') sectionStats[r.section].compliant++;
      if (r.status === 'non_compliant') sectionStats[r.section].non_compliant++;
    });

    const worstSections = Object.entries(sectionStats)
      .map(([section, stats]) => ({
        section,
        compliance_rate: stats.total > 0 ? (stats.compliant / stats.total * 100).toFixed(1) : 0,
        non_compliant: stats.non_compliant
      }))
      .sort((a, b) => parseFloat(a.compliance_rate) - parseFloat(b.compliance_rate))
      .slice(0, 5);

    const auditTrends = audits.length >= 2 ? 
      `Recent audit scores: ${audits.slice(0, 3).map(a => a.overall_score).join(', ')}` : 
      'Insufficient audit history';

    const prompt = `As a compliance risk prediction expert, analyze these trends and predict future risks:

TREND ANALYSIS (Last 30 days):
- Non-compliant requirements trend: ${previousNonCompliant} → ${recentNonCompliant} (${recentNonCompliant - previousNonCompliant >= 0 ? '+' : ''}${recentNonCompliant - previousNonCompliant})
- New critical risks: ${recentCriticalRisks}
- Currently overdue: ${overdueCount} requirements
- Stagnant in-progress items: ${stagnantRequirements.length} (no update in 60+ days)

AUDIT TRENDS:
${auditTrends}

WORST PERFORMING SECTIONS:
${worstSections.map(s => `- ${s.section}: ${s.compliance_rate}% compliant, ${s.non_compliant} non-compliant`).join('\n')}

STAGNANT REQUIREMENTS:
${stagnantRequirements.slice(0, 5).map(r => `- ${r.clause_number}: ${r.clause_title} (${Math.floor((now - new Date(r.updated_date)) / (1000 * 60 * 60 * 24))} days)`).join('\n')}

REGULATORY CONTEXT:
Consider current ISO 22000:2018 and TS 22002-4 requirements for packaging manufacturing.

Based on these trends and patterns, predict 3-5 high-priority future risks that are likely to materialize in the next 30-90 days. For each prediction:
- Identify specific risk area and type
- Assess likelihood and severity
- Provide confidence score
- List trend indicators
- Recommend proactive actions`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: "object",
        properties: {
          predictions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                risk_area: { type: "string" },
                risk_type: { 
                  type: "string",
                  enum: ["compliance_gap", "emerging_risk", "resource_constraint", "process_breakdown", "regulatory_change"]
                },
                likelihood: { 
                  type: "string",
                  enum: ["low", "medium", "high", "very_high"]
                },
                severity: { 
                  type: "string",
                  enum: ["low", "medium", "high", "critical"]
                },
                priority_score: { type: "number" },
                description: { type: "string" },
                indicators: {
                  type: "array",
                  items: { type: "string" }
                },
                recommended_actions: {
                  type: "array",
                  items: { type: "string" }
                },
                timeframe: { type: "string" },
                confidence: { type: "number" }
              }
            }
          }
        }
      }
    });

    // Store predictions
    const createdPredictions = [];
    for (const pred of result.predictions || []) {
      const prediction = await base44.asServiceRole.entities.RiskPrediction.create({
        prediction_date: now.toISOString(),
        ...pred,
        status: "active"
      });
      createdPredictions.push(prediction);

      // Create notifications for high-priority predictions
      if (pred.priority_score >= 70) {
        const admins = await base44.asServiceRole.entities.User.filter({ role: 'admin' });
        for (const admin of admins) {
          await base44.asServiceRole.entities.Notification.create({
            recipient_email: admin.email,
            title: "High-Priority Risk Prediction",
            message: `AI has predicted a ${pred.likelihood} likelihood risk: ${pred.description}`,
            type: "due_soon",
            entity_type: "RiskPrediction",
            entity_id: prediction.id
          });
        }
      }
    }

    await base44.asServiceRole.entities.ActivityLog.create({
      activity_type: "review_completed",
      entity_type: "RiskPrediction",
      description: `AI generated ${createdPredictions.length} risk predictions`,
      user_email: user?.email || 'system'
    });

    return Response.json({
      success: true,
      predictions_count: createdPredictions.length,
      high_priority_count: createdPredictions.filter(p => p.priority_score >= 70).length
    });

  } catch (error) {
    console.error('Risk prediction error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});