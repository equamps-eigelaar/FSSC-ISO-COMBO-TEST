import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const admin = await base44.auth.me();

    if (admin?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { request_id, rejection_reason } = await req.json();

    if (!request_id || !rejection_reason) {
      return Response.json({ error: 'Request ID and reason required' }, { status: 400 });
    }

    // Get the request
    const accessRequest = await base44.asServiceRole.entities.UserAccessRequest.filter(
      { id: request_id },
      null,
      1
    );

    if (!accessRequest.length) {
      return Response.json({ error: 'Request not found' }, { status: 404 });
    }

    const req_data = accessRequest[0];

    // Update status to rejected
    await base44.asServiceRole.entities.UserAccessRequest.update(request_id, {
      status: 'rejected',
      rejection_reason,
      approved_by: admin.email,
      approved_date: new Date().toISOString(),
    });

    // Send rejection email
    await base44.integrations.Core.SendEmail({
      to: req_data.email,
      subject: 'Access Request Status Update',
      body: `Hi ${req_data.full_name},\n\nUnfortunately, your access request has been declined.\n\nReason: ${rejection_reason}\n\nIf you have questions, please contact support.`,
    });

    return Response.json({
      success: true,
      message: 'User request rejected',
    });
  } catch (error) {
    console.error('Rejection error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});