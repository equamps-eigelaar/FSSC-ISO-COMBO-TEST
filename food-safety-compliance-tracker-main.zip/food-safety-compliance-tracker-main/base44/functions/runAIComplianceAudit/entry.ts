import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch(() => null);

    // Allow scheduled automations (no session) but block non-admin user calls
    if (user && user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized - Admin only' }, { status: 403 });
    }

    const auditRecord = await base44.asServiceRole.entities.ComplianceAudit.create({
      audit_date: new Date().toISOString(),
      status: "in_progress"
    });

    try {
      const [requirements, risks, documents] = await Promise.all([
        base44.asServiceRole.entities.ComplianceRequirement.list("-created_date", 500),
        base44.asServiceRole.entities.RiskAssessment.list("-created_date", 500),
        base44.asServiceRole.entities.Document.list("-created_date", 500)
      ]);

      const nonCompliant = requirements.filter(r => r.status === 'non_compliant');
      const notStarted = requirements.filter(r => r.status === 'not_started');
      const overdue = requirements.filter(r => {
        if (!r.due_date) return false;
        return new Date(r.due_date) < new Date() && r.status !== 'compliant';
      });
      const missingEvidence = requirements.filter(r => 
        r.status !== 'compliant' && (!r.evidence_files || r.evidence_files.length === 0)
      );

      const criticalRisks = risks.filter(r => r.risk_level === 'critical');
      const highRisks = risks.filter(r => r.risk_level === 'high');
      const requiresAction = risks.filter(r => r.status === 'requires_action');

      const auditContext = `
COMPLIANCE AUDIT - ${new Date().toLocaleString()}

REQUIREMENTS ANALYSIS:
- Total Requirements: ${requirements.length}
- Compliant: ${requirements.filter(r => r.status === 'compliant').length}
- In Progress: ${requirements.filter(r => r.status === 'in_progress').length}
- Non-Compliant: ${nonCompliant.length}
- Not Started: ${notStarted.length}
- Overdue: ${overdue.length}
- Missing Evidence: ${missingEvidence.length}

CRITICAL NON-COMPLIANT REQUIREMENTS:
${nonCompliant.slice(0, 5).map(r => 
  `- ${r.clause_number}: ${r.clause_title}\n  Status: ${r.status}, Priority: ${r.priority}${r.due_date ? `, Due: ${r.due_date}` : ''}`
).join('\n')}

RISK ASSESSMENT STATUS:
- Total Risks: ${risks.length}
- Critical: ${criticalRisks.length}
- High: ${highRisks.length}
- Requiring Action: ${requiresAction.length}

CRITICAL RISKS:
${criticalRisks.slice(0, 5).map(r => 
  `- ${r.hazard_type}: ${r.hazard_description?.substring(0, 100)}`
).join('\n')}

DOCUMENT STATUS:
- Total Documents: ${documents.length}
- Expiring Soon: ${documents.filter(d => {
  if (!d.expiry_date) return false;
  const expiry = new Date(d.expiry_date);
  const today = new Date();
  const days = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
  return days <= 30 && days >= 0;
}).length}

Perform a comprehensive compliance audit and identify:
1. Key discrepancies between stated status and actual evidence
2. Critical findings requiring immediate attention
3. Pattern analysis of compliance gaps
4. Risk-based priority recommendations
5. Executive summary for leadership
`;

      const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: auditContext,
        response_json_schema: {
          type: "object",
          properties: {
            overall_score: { type: "number" },
            summary: { type: "string" },
            findings: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  requirement_id: { type: "string" },
                  clause_number: { type: "string" },
                  issue_type: { type: "string" },
                  severity: { type: "string" },
                  description: { type: "string" },
                  recommendation: { type: "string" }
                }
              }
            },
            discrepancies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  description: { type: "string" },
                  impact: { type: "string" }
                }
              }
            },
            recommendations: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      const auditData = {
        status: "completed",
        overall_score: result.overall_score || 0,
        summary: result.summary,
        findings: result.findings || [],
        discrepancies: result.discrepancies || [],
        recommendations: result.recommendations || [],
        risk_summary: {
          critical: criticalRisks.length,
          high: highRisks.length,
          medium: risks.filter(r => r.risk_level === 'medium').length,
          low: risks.filter(r => r.risk_level === 'low').length
        },
        metrics: {
          total_requirements: requirements.length,
          compliant: requirements.filter(r => r.status === 'compliant').length,
          non_compliant: nonCompliant.length,
          in_progress: requirements.filter(r => r.status === 'in_progress').length,
          missing_evidence: missingEvidence.length,
          overdue: overdue.length
        }
      };

      await base44.asServiceRole.entities.ComplianceAudit.update(auditRecord.id, auditData);

      await base44.asServiceRole.entities.ActivityLog.create({
        activity_type: "review_completed",
        entity_type: "ComplianceAudit",
        entity_id: auditRecord.id,
        description: `AI Compliance Audit completed - Score: ${result.overall_score}/100`,
        user_email: user?.email || "system@automation"
      });

      return Response.json({
        success: true,
        audit_id: auditRecord.id,
        summary: result.summary,
        score: result.overall_score
      });

    } catch (error) {
      await base44.asServiceRole.entities.ComplianceAudit.update(auditRecord.id, {
        status: "failed"
      });
      throw error;
    }

  } catch (error) {
    console.error('Audit error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});