import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    const { event, data, old_data } = payload;

    // --- RiskAssessment: workflow_status changed to pending_review ---
    if (event.entity_name === 'RiskAssessment' && event.type === 'update') {
      const statusChanged = old_data && old_data.workflow_status !== data.workflow_status;
      if (statusChanged && data.workflow_status === 'pending_review') {
        const hazard = data.hazard_description || 'Risk Assessment';
        const subject = `Risk Assessment Pending Review: ${hazard}`;
        const body = `A risk assessment requires your review:\n\n"${hazard}"\n\nHazard type: ${data.hazard_type || 'N/A'}\nRisk level: ${data.risk_level || 'N/A'}\n\nPlease log in to approve or request revisions.`;

        const recipients = new Set();
        if (data.approver_email) recipients.add(data.approver_email);
        if (data.assigned_to) recipients.add(data.assigned_to);

        for (const email of recipients) {
          await base44.asServiceRole.entities.Notification.create({
            recipient_email: email,
            title: subject,
            message: `"${hazard}" has been submitted for review.`,
            type: 'status_change',
            entity_type: 'RiskAssessment',
            entity_id: event.entity_id,
            action_url: `/RiskWorkflow`,
            is_read: false,
          });
          await base44.asServiceRole.integrations.Core.SendEmail({ to: email, subject, body });
        }
      }

      // --- RiskAssessment: assigned_to changed ---
      if (data.assigned_to && (!old_data || old_data.assigned_to !== data.assigned_to)) {
        const hazard = data.hazard_description || 'Risk Assessment';
        const subject = `Risk Assessment Assigned: ${hazard}`;
        const body = `You have been assigned to a risk assessment:\n\n"${hazard}"\n\nHazard type: ${data.hazard_type || 'N/A'}\nRisk level: ${data.risk_level || 'N/A'}\n\nPlease log in to review and action.`;

        await base44.asServiceRole.entities.Notification.create({
          recipient_email: data.assigned_to,
          title: subject,
          message: `You have been assigned to: "${hazard}"`,
          type: 'assignment',
          entity_type: 'RiskAssessment',
          entity_id: event.entity_id,
          action_url: `/RiskWorkflow`,
          is_read: false,
        });
        await base44.asServiceRole.integrations.Core.SendEmail({ to: data.assigned_to, subject, body });
      }
    }

    // --- Task: newly created → notify assigned user ---
    if (event.entity_name === 'Task' && event.type === 'create') {
      if (data.assigned_to) {
        const subject = `New Task Assigned: ${data.title}`;
        const body = `Hello,\n\nYou have been assigned a new task:\n\n"${data.title}"\n${data.description ? `\n${data.description}\n` : ''}\nPriority: ${data.priority || 'medium'}\n${data.due_date ? `Due: ${data.due_date}\n` : ''}\nAssigned by: ${data.assigned_by || 'System'}\n\nPlease log in to view details.`;

        await base44.asServiceRole.entities.Notification.create({
          recipient_email: data.assigned_to,
          title: subject,
          message: `New task: "${data.title}"`,
          type: 'assignment',
          entity_type: 'Task',
          entity_id: event.entity_id,
          action_url: `/ActionItems`,
          is_read: false,
        });
        await base44.asServiceRole.integrations.Core.SendEmail({ to: data.assigned_to, subject, body });
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('notifyRiskAndTaskEvents error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});