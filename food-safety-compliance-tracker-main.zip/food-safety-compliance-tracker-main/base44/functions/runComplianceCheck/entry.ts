import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch all compliance requirements
    const requirements = await base44.entities.ComplianceRequirement.list();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const alerts = {
      pastDue: [],
      nonCompliant: [],
      missingEvidence: [],
    };

    requirements.forEach((req) => {
      // Check for past-due requirements
      if (req.due_date) {
        const dueDate = new Date(req.due_date);
        dueDate.setHours(0, 0, 0, 0);
        if (dueDate < today && req.status !== 'compliant') {
          alerts.pastDue.push({
            id: req.id,
            clause_number: req.clause_number,
            clause_title: req.clause_title,
            due_date: req.due_date,
            status: req.status,
            days_overdue: Math.floor((today - dueDate) / (1000 * 60 * 60 * 24)),
          });
        }
      }

      // Check for non-compliant requirements
      if (req.status === 'non_compliant') {
        alerts.nonCompliant.push({
          id: req.id,
          clause_number: req.clause_number,
          clause_title: req.clause_title,
          findings: req.findings,
          completion_percentage: req.completion_percentage || 0,
        });
      }

      // Check for missing evidence
      if (req.status !== 'compliant' && (!req.evidence_files || req.evidence_files.length === 0)) {
        alerts.missingEvidence.push({
          id: req.id,
          clause_number: req.clause_number,
          clause_title: req.clause_title,
          status: req.status,
        });
      }
    });

    const totalIssues = alerts.pastDue.length + alerts.nonCompliant.length + alerts.missingEvidence.length;

    return Response.json({
      check_date: new Date().toISOString(),
      total_issues: totalIssues,
      alerts,
      summary: {
        past_due_count: alerts.pastDue.length,
        non_compliant_count: alerts.nonCompliant.length,
        missing_evidence_count: alerts.missingEvidence.length,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});