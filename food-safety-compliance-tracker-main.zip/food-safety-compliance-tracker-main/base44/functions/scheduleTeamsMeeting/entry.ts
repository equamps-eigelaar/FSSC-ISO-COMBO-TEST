import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    const {
      title = 'Safety Audit Review Meeting',
      description = 'Recurring safety audit review meeting',
      duration = 60,
      recurrencePattern = 'weekly', // weekly, biweekly, monthly
      daysOfWeek = ['Monday'], // day(s) for weekly/biweekly
      dayOfMonth = 15, // for monthly
      startTime = '09:00' // HH:MM format
    } = payload;

    // Get Teams access token
    const { accessToken } = await base44.asServiceRole.connectors.getConnection('microsoft_teams');

    // Parse start time and create ISO datetime for tomorrow at specified time
    const now = new Date();
    const [hours, minutes] = startTime.split(':').map(Number);
    const startDate = new Date(now);
    startDate.setHours(hours, minutes, 0, 0);
    
    // If time has already passed today, schedule for next occurrence
    if (startDate <= now) {
      startDate.setDate(startDate.getDate() + 1);
    }

    // Adjust to next day of week if needed (for weekly meetings)
    if (daysOfWeek.length > 0 && daysOfWeek[0] !== 'Monday') {
      const dayMap = { 'Monday': 1, 'Tuesday': 2, 'Wednesday': 3, 'Thursday': 4, 'Friday': 5, 'Saturday': 6, 'Sunday': 0 };
      const targetDay = dayMap[daysOfWeek[0]] || 1;
      const currentDay = startDate.getDay();
      const daysUntil = (targetDay - currentDay + 7) % 7;
      if (daysUntil > 0) {
        startDate.setDate(startDate.getDate() + daysUntil);
      }
    }

    // Build recurrence rule
    let recurrence = null;
    if (recurrencePattern === 'weekly') {
      recurrence = {
        pattern: {
          type: 'weekly',
          interval: 1,
          daysOfWeek: daysOfWeek.map(d => d.slice(0, 3).toUpperCase())
        },
        range: {
          type: 'endDate',
          endDate: new Date(now.getFullYear() + 1, now.getMonth(), now.getDate()).toISOString().split('T')[0]
        }
      };
    } else if (recurrencePattern === 'biweekly') {
      recurrence = {
        pattern: {
          type: 'weekly',
          interval: 2,
          daysOfWeek: daysOfWeek.map(d => d.slice(0, 3).toUpperCase())
        },
        range: {
          type: 'endDate',
          endDate: new Date(now.getFullYear() + 1, now.getMonth(), now.getDate()).toISOString().split('T')[0]
        }
      };
    } else if (recurrencePattern === 'monthly') {
      recurrence = {
        pattern: {
          type: 'absoluteMonthly',
          dayOfMonth: dayOfMonth,
          interval: 1
        },
        range: {
          type: 'endDate',
          endDate: new Date(now.getFullYear() + 1, now.getMonth(), now.getDate()).toISOString().split('T')[0]
        }
      };
    }

    // Create online meeting via Microsoft Graph
    const endDate = new Date(startDate);
    endDate.setMinutes(endDate.getMinutes() + duration);

    const meetingPayload = {
      subject: title,
      description: description,
      startDateTime: startDate.toISOString(),
      endDateTime: endDate.toISOString(),
      recurrence: recurrence,
      isReminderOn: true,
      reminderMinutesBeforeStart: 15,
      allowNewTimeProposals: true,
      isOnlineMeeting: true,
      onlineMeetingProvider: 'teamsForBusiness'
    };

    const response = await fetch('https://graph.microsoft.com/v1.0/me/events', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(meetingPayload)
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('Teams meeting creation failed:', error);
      return Response.json({ error: error.error?.message || 'Failed to create meeting' }, { status: response.status });
    }

    const meeting = await response.json();

    // Log the activity
    await base44.asServiceRole.entities.ActivityLog.create({
      activity_type: 'system_event',
      entity_type: 'TeamsCalendar',
      entity_id: meeting.id,
      entity_label: title,
      description: `Scheduled recurring Teams meeting: ${title} (${recurrencePattern})`,
      user_email: user.email,
      user_name: user.full_name
    });

    return Response.json({
      success: true,
      message: 'Recurring meeting scheduled in Microsoft Teams',
      meeting_id: meeting.id,
      meeting_link: meeting.onlineMeeting?.joinUrl,
      first_occurrence: startDate.toISOString(),
      recurrence_pattern: recurrencePattern
    });

  } catch (error) {
    console.error('scheduleTeamsMeeting error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});