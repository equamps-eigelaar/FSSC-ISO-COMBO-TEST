import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const organizations = await base44.asServiceRole.entities.Organization.list('-created_date', 200);
    const greenOrgs = organizations.filter(o => o.health_status === 'green' && (o.contact_email || o.owner_email));

    if (greenOrgs.length === 0) {
      return Response.json({ message: 'No green clients to email', sent: 0 });
    }

    const month = new Date().toLocaleString('default', { month: 'long', year: 'numeric' });
    let sent = 0;
    const results = [];

    for (const org of greenOrgs) {
      const to = org.contact_email || org.owner_email;
      const body = `Hi ${org.contact_name || 'there'},<br><br>
Here is your monthly compliance summary for <strong>${month}</strong>.<br><br>
✅ <strong>Compliance Score:</strong> ${org.compliance_score != null ? org.compliance_score + '%' : 'Awaiting update'}<br>
📋 <strong>Open Action Items:</strong> ${org.open_actions_count || 0}<br>
⚠️ <strong>Critical Issues:</strong> ${org.critical_issues_count || 0}<br><br>
Great news — your organisation is on track and meeting all key compliance requirements. No immediate action is required this month.<br><br>
${org.last_review_date ? `Last compliance review: ${org.last_review_date}<br><br>` : ''}
If you have any questions or would like to discuss your compliance status, please don't hesitate to reach out.<br><br>
Kind regards,<br>Your Compliance Team`;

      await base44.asServiceRole.integrations.Core.SendEmail({
        to,
        subject: `Monthly Compliance Summary — ${org.name} — ${month}`,
        body,
      });

      await base44.asServiceRole.entities.Organization.update(org.id, {
        last_monthly_email_sent: new Date().toISOString().slice(0, 10),
      });

      sent++;
      results.push({ org: org.name, to, status: 'sent' });
    }

    return Response.json({
      message: `Monthly summaries sent to ${sent} green client(s)`,
      sent,
      results,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});