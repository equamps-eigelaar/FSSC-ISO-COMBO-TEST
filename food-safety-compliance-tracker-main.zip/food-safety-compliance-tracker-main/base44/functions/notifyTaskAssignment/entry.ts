import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { task_id, assigned_to, assigned_by, title, entity_type } = await req.json();

    // Create in-app notification
    const notification = await base44.asServiceRole.entities.Notification.create({
      recipient_email: assigned_to,
      title: `Task Assigned: ${title}`,
      message: `You have been assigned a new task related to ${entity_type}.`,
      type: 'assignment',
      entity_type: 'Task',
      entity_id: task_id,
      priority: 'high'
    });

    // Send email notification
    await base44.integrations.Core.SendEmail({
      to: assigned_to,
      subject: `Task Assigned: ${title}`,
      body: `Hello,\n\nYou have been assigned a new task:\n\n"${title}"\n\nAssigned by: ${assigned_by}\n\nPlease log in to the application to view details and start working on this task.\n\nBest regards,\nPackage Manufacturing Compliance Team`
    });

    return Response.json({ success: true, notification_id: notification.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});