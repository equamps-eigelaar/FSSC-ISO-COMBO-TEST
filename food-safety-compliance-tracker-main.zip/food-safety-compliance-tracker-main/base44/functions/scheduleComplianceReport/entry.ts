import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Support both direct calls (with user session) and scheduled automation (no session)
    const isAuthenticated = await base44.auth.isAuthenticated();
    if (isAuthenticated) {
      const user = await base44.auth.me();
      if (!user || user.role !== 'admin') {
        return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
      }
    }

    const payload = await req.json().catch(() => ({}));
    const { report_type = 'weekly', schedule_days = [] } = payload;

    // Fetch all compliance data
    const [requirements, risks, actions] = await Promise.all([
      base44.asServiceRole.entities.ComplianceRequirement.list("-created_date", 100),
      base44.asServiceRole.entities.RiskAssessment.list("-created_date", 100),
      base44.asServiceRole.entities.ActionItem.list("-created_date", 100),
    ]);

    // Calculate statistics
    const complianceStats = {
      total_requirements: requirements.length,
      compliant: requirements.filter(r => r.status === 'compliant').length,
      in_progress: requirements.filter(r => r.status === 'in_progress').length,
      non_compliant: requirements.filter(r => r.status === 'non_compliant').length,
      not_started: requirements.filter(r => r.status === 'not_started').length
    };

    const riskStats = {
      total_risks: risks.length,
      critical: risks.filter(r => r.risk_level === 'critical').length,
      high: risks.filter(r => r.risk_level === 'high').length,
      medium: risks.filter(r => r.risk_level === 'medium').length,
      low: risks.filter(r => r.risk_level === 'low').length
    };

    const completedActions = actions.filter(a => a.status === 'completed').length;
    const taskCompletionRate = actions.length > 0 ? Math.round((completedActions / actions.length) * 100) : 0;

    // Calculate overall compliance score
    const complianceScore = complianceStats.total_requirements > 0
      ? Math.round((complianceStats.compliant / complianceStats.total_requirements) * 100)
      : 0;

    // Generate AI-powered insights
    const reportPrompt = `As a compliance expert, generate a concise but comprehensive compliance report based on this data:

COMPLIANCE SNAPSHOT:
- Total Requirements: ${complianceStats.total_requirements}
- Compliant: ${complianceStats.compliant} (${complianceScore}%)
- In Progress: ${complianceStats.in_progress}
- Non-Compliant: ${complianceStats.non_compliant}
- Not Started: ${complianceStats.not_started}
- Task Completion Rate: ${taskCompletionRate}%

RISK LANDSCAPE:
- Total Risks: ${riskStats.total_risks}
- Critical: ${riskStats.critical}
- High: ${riskStats.high}
- Medium: ${riskStats.medium}
- Low: ${riskStats.low}

TOP NON-COMPLIANT REQUIREMENTS:
${requirements.filter(r => r.status === 'non_compliant').slice(0, 5).map(r => 
  `- ${r.clause_number}: ${r.clause_title}`
).join('\n')}

CRITICAL RISKS OVERVIEW:
${risks.filter(r => r.risk_level === 'critical').slice(0, 5).map(r => 
  `- ${r.hazard_type}: ${r.hazard_description?.substring(0, 80)}`
).join('\n')}

Generate a professional compliance report with:
1. Executive Summary (2-3 sentences highlighting overall health)
2. Compliance Status (brief analysis of compliance trends)
3. Top 3 Key Findings
4. Top 3 Critical Issues with recommendations
5. Risk Assessment Summary
6. Recommended Next Steps (3-4 actions)`;

    const reportContent = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: reportPrompt,
      response_json_schema: {
        type: "object",
        properties: {
          executive_summary: { type: "string" },
          compliance_status: { type: "string" },
          key_findings: {
            type: "array",
            items: { type: "string" }
          },
          critical_issues: {
            type: "array",
            items: {
              type: "object",
              properties: {
                issue: { type: "string" },
                impact: { type: "string" },
                recommendation: { type: "string" },
                priority: { type: "string" }
              }
            }
          },
          risk_summary: { type: "string" },
          action_plan: {
            type: "array",
            items: {
              type: "object",
              properties: {
                action: { type: "string" },
                owner: { type: "string" },
                timeline: { type: "string" }
              }
            }
          }
        }
      }
    });

    // Create the compliance report
    const today = new Date();
    const periodStart = new Date(today);
    periodStart.setDate(periodStart.getDate() - 7); // Last 7 days

    const report = await base44.asServiceRole.entities.ComplianceReport.create({
      title: `${report_type.charAt(0).toUpperCase() + report_type.slice(1)} Compliance Report - ${today.toLocaleDateString()}`,
      report_date: today.toISOString().split('T')[0],
      period_start: periodStart.toISOString().split('T')[0],
      period_end: today.toISOString().split('T')[0],
      report_type,
      executive_summary: reportContent.executive_summary,
      compliance_status: reportContent.compliance_status,
      compliance_score: complianceScore,
      key_findings: reportContent.key_findings,
      critical_issues: reportContent.critical_issues,
      risk_summary: reportContent.risk_summary,
      action_plan: reportContent.action_plan,
      compliance_stats: complianceStats,
      risk_stats: riskStats,
      task_completion_rate: taskCompletionRate,
      generated_by: "system@automation",
      status: 'finalized'
    });

    return Response.json({
      success: true,
      message: `${report_type} compliance report generated successfully`,
      report_id: report.id
    });
  } catch (error) {
    console.error('Error generating scheduled report:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});