import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    const { event, data, old_data } = payload;
    
    // Handle assignment notifications
    if (data.assigned_to && (!old_data || old_data.assigned_to !== data.assigned_to)) {
      const entityLabel = event.entity_name === 'ComplianceRequirement' 
        ? `Requirement ${data.clause_number || ''}`
        : 'Risk Assessment';
      
      await base44.asServiceRole.entities.Notification.create({
        recipient_email: data.assigned_to,
        title: `New Assignment: ${entityLabel}`,
        message: `You have been assigned to: ${data.clause_title || data.hazard_description}`,
        type: 'assignment',
        entity_type: event.entity_name,
        entity_id: event.entity_id,
        action_url: event.entity_name === 'ComplianceRequirement' 
          ? `/RequirementDetail?id=${event.entity_id}`
          : `/RequirementDetail?id=${data.requirement_id}`,
        is_read: false
      });
      
      // Send email notification
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: data.assigned_to,
        subject: `New Assignment: ${entityLabel}`,
        body: `You have been assigned to: ${data.clause_title || data.hazard_description}\n\nPlease log in to the compliance tracker to view details.`
      });
    }
    
    // Handle status change notifications
    if (event.entity_name === 'ComplianceRequirement' && old_data && old_data.status !== data.status && data.assigned_to) {
      const statusTitle = `Status Changed: ${data.clause_number}`;
      const statusMsg = `"${data.clause_number} – ${data.clause_title}" status changed from "${old_data.status.replace(/_/g,' ')}" to "${data.status.replace(/_/g,' ')}"`;
      await base44.asServiceRole.entities.Notification.create({
        recipient_email: data.assigned_to,
        title: statusTitle,
        message: statusMsg,
        type: 'status_change',
        entity_type: event.entity_name,
        entity_id: event.entity_id,
        action_url: `/RequirementDetail?id=${event.entity_id}`,
        is_read: false
      });
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: data.assigned_to,
        subject: statusTitle,
        body: `${statusMsg}\n\nLog in to view details: https://app.base44.com/RequirementDetail?id=${event.entity_id}`
      });
    }

    // General update notification for assigned user (field changes other than status)
    if (
      event.entity_name === 'ComplianceRequirement' &&
      event.type === 'update' &&
      data.assigned_to &&
      old_data &&
      old_data.status === data.status // don't double-notify if status also changed
    ) {
      const changedFields = old_data ? Object.keys(data).filter(k =>
        !['updated_date', 'created_date', 'id'].includes(k) &&
        JSON.stringify(data[k]) !== JSON.stringify(old_data[k])
      ) : [];

      if (changedFields.length > 0) {
        const updateTitle = `Requirement Updated: ${data.clause_number}`;
        const updateMsg = `"${data.clause_number} – ${data.clause_title}" was updated (fields: ${changedFields.join(', ')}).`;
        await base44.asServiceRole.entities.Notification.create({
          recipient_email: data.assigned_to,
          title: updateTitle,
          message: updateMsg,
          type: 'status_change',
          entity_type: event.entity_name,
          entity_id: event.entity_id,
          action_url: `/RequirementDetail?id=${event.entity_id}`,
          is_read: false
        });
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: data.assigned_to,
          subject: updateTitle,
          body: `${updateMsg}\n\nLog in to view details: https://app.base44.com/RequirementDetail?id=${event.entity_id}`
        });
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error sending notification:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});