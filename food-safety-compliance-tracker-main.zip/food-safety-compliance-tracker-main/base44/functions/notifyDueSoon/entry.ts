import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const today = new Date();
    const threeDaysFromNow = new Date(today);
    threeDaysFromNow.setDate(today.getDate() + 3);

    const todayStr = today.toISOString().split('T')[0];
    const thresholdStr = threeDaysFromNow.toISOString().split('T')[0];

    // Fetch all requirements and action items
    const [requirements, actionItems] = await Promise.all([
      base44.asServiceRole.entities.ComplianceRequirement.list('-due_date', 500),
      base44.asServiceRole.entities.ActionItem.list('-due_date', 500),
    ]);

    const notified = [];

    // Helper: check if due date is within next 3 days (and not already past)
    const isDueSoon = (dueDateStr) => {
      if (!dueDateStr) return false;
      return dueDateStr >= todayStr && dueDateStr <= thresholdStr;
    };

    // Notify for requirements
    for (const req of requirements) {
      if (!isDueSoon(req.due_date)) continue;
      if (!req.assigned_to) continue;
      if (req.status === 'compliant') continue;

      const daysLeft = Math.ceil((new Date(req.due_date) - today) / (1000 * 60 * 60 * 24));

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: req.assigned_to,
        subject: `⚠️ Due Soon: ${req.clause_number} – ${req.clause_title}`,
        body: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #10b981; padding: 20px; border-radius: 8px 8px 0 0;">
              <h2 style="color: white; margin: 0;">Compliance Requirement Due Soon</h2>
            </div>
            <div style="background: #f9fafb; padding: 24px; border: 1px solid #e5e7eb; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #111827;">Hello,</p>
              <p style="color: #374151;">The following compliance requirement is due in <strong>${daysLeft} day${daysLeft !== 1 ? 's' : ''}</strong>:</p>
              <div style="background: white; border: 1px solid #d1fae5; border-left: 4px solid #10b981; border-radius: 6px; padding: 16px; margin: 16px 0;">
                <p style="margin: 0 0 6px; font-weight: bold; color: #065f46;">${req.clause_number} – ${req.clause_title}</p>
                <p style="margin: 0; color: #6b7280; font-size: 14px;">Status: ${req.status?.replace(/_/g, ' ')} | Due: ${req.due_date}</p>
              </div>
              <p style="color: #374151;">Please log in to the compliance tracker to update the status or add evidence.</p>
              <p style="color: #9ca3af; font-size: 12px; margin-top: 24px;">Package Manufacturing Compliance Tracker – automated reminder</p>
            </div>
          </div>
        `
      });

      notified.push({ type: 'requirement', id: req.id, to: req.assigned_to, due: req.due_date });
    }

    // Notify for action items
    for (const item of actionItems) {
      if (!isDueSoon(item.due_date)) continue;
      if (!item.assigned_to) continue;
      if (item.status === 'completed' || item.status === 'cancelled') continue;

      const daysLeft = Math.ceil((new Date(item.due_date) - today) / (1000 * 60 * 60 * 24));

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: item.assigned_to,
        subject: `⚠️ Action Item Due Soon: ${item.title}`,
        body: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: #f59e0b; padding: 20px; border-radius: 8px 8px 0 0;">
              <h2 style="color: white; margin: 0;">Action Item Due Soon</h2>
            </div>
            <div style="background: #f9fafb; padding: 24px; border: 1px solid #e5e7eb; border-radius: 0 0 8px 8px;">
              <p style="font-size: 16px; color: #111827;">Hello,</p>
              <p style="color: #374151;">The following action item is due in <strong>${daysLeft} day${daysLeft !== 1 ? 's' : ''}</strong>:</p>
              <div style="background: white; border: 1px solid #fde68a; border-left: 4px solid #f59e0b; border-radius: 6px; padding: 16px; margin: 16px 0;">
                <p style="margin: 0 0 6px; font-weight: bold; color: #92400e;">${item.title}</p>
                <p style="margin: 0; color: #6b7280; font-size: 14px;">Status: ${item.status?.replace(/_/g, ' ')} | Priority: ${item.priority || 'medium'} | Due: ${item.due_date}</p>
                ${item.description ? `<p style="margin: 8px 0 0; color: #374151; font-size: 14px;">${item.description}</p>` : ''}
              </div>
              <p style="color: #374151;">Please log in to the compliance tracker to update this action item.</p>
              <p style="color: #9ca3af; font-size: 12px; margin-top: 24px;">Package Manufacturing Compliance Tracker – automated reminder</p>
            </div>
          </div>
        `
      });

      notified.push({ type: 'action_item', id: item.id, to: item.assigned_to, due: item.due_date });
    }

    console.log(`Due-soon notifications sent: ${notified.length}`);
    return Response.json({ success: true, notified_count: notified.length, notified });

  } catch (error) {
    console.error('Error in notifyDueSoon:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});