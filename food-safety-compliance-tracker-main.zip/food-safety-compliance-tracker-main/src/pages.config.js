/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import ActionItems from './pages/ActionItems';
import ActivityMonitor from './pages/ActivityMonitor';
import AllergenControl from './pages/AllergenControl';
import Analytics from './pages/Analytics';
import AuditLog from './pages/AuditLog';
import AuditPrep from './pages/AuditPrep';
import CleaningRegisters from './pages/CleaningRegisters';
import ClientHealthDashboard from './pages/ClientHealthDashboard';
import ComplianceAudits from './pages/ComplianceAudits';
import ComplianceImport from './pages/ComplianceImport';
import ConfidentialityAgreement from './pages/ConfidentialityAgreement';
import DailyMonitoring from './pages/DailyMonitoring';
import Dashboard from './pages/Dashboard';
import DocumentRepository from './pages/DocumentRepository';
import DocumentTemplates from './pages/DocumentTemplates';
import FloorDataEntry from './pages/FloorDataEntry';
import FoodBatchRecords from './pages/FoodBatchRecords';
import FoodBatchTraceability from './pages/FoodBatchTraceability';
import HygieneZones from './pages/HygieneZones';
import InternalAudits from './pages/InternalAudits';
import LocationSharing from './pages/LocationSharing';
import MobileActionItems from './pages/MobileActionItems';
import MobileAudit from './pages/MobileAudit';
import ModerationDashboard from './pages/ModerationDashboard';
import MultiTenantAdmin from './pages/MultiTenantAdmin';
import NotificationCenter from './pages/NotificationCenter';
import OrganizationSettings from './pages/OrganizationSettings';

import PrivacyPolicy from './pages/PrivacyPolicy';
import ProprietarySharing from './pages/ProprietarySharing';
import RawMaterialTraceability from './pages/RawMaterialTraceability';
import Reports from './pages/Reports';
import RequestAccess from './pages/RequestAccess';
import RequirementDetail from './pages/RequirementDetail';
import Requirements from './pages/Requirements';
import RetentionSamples from './pages/RetentionSamples';
import RiskPredictions from './pages/RiskPredictions';
import RiskWorkflow from './pages/RiskWorkflow';
import SLADocumentCompletion from './pages/SLADocumentCompletion';
import SelfAssessment from './pages/SelfAssessment';
import Settings from './pages/Settings';
import SiteManufacturingDashboard from './pages/SiteManufacturingDashboard';
import SupplierManagement from './pages/SupplierManagement';
import SupplierPortal from './pages/SupplierPortal';
import SupportTickets from './pages/SupportTickets';
import TermsAndConditions from './pages/TermsAndConditions';
import Training from './pages/Training';
import UserApprovalDashboard from './pages/UserApprovalDashboard';
import UserManagement from './pages/UserManagement';

import __Layout from './Layout.jsx';


export const PAGES = {
    "ActionItems": ActionItems,
    "ActivityMonitor": ActivityMonitor,
    "AllergenControl": AllergenControl,
    "Analytics": Analytics,
    "AuditLog": AuditLog,
    "AuditPrep": AuditPrep,
    "CleaningRegisters": CleaningRegisters,
    "ClientHealthDashboard": ClientHealthDashboard,
    "ComplianceAudits": ComplianceAudits,
    "ComplianceImport": ComplianceImport,
    "ConfidentialityAgreement": ConfidentialityAgreement,
    "DailyMonitoring": DailyMonitoring,
    "Dashboard": Dashboard,
    "DocumentRepository": DocumentRepository,
    "DocumentTemplates": DocumentTemplates,
    "FloorDataEntry": FloorDataEntry,
    "FoodBatchRecords": FoodBatchRecords,
    "FoodBatchTraceability": FoodBatchTraceability,
    "HygieneZones": HygieneZones,
    "InternalAudits": InternalAudits,
    "LocationSharing": LocationSharing,
    "MobileActionItems": MobileActionItems,
    "MobileAudit": MobileAudit,
    "ModerationDashboard": ModerationDashboard,
    "MultiTenantAdmin": MultiTenantAdmin,
    "NotificationCenter": NotificationCenter,
    "OrganizationSettings": OrganizationSettings,

    "PrivacyPolicy": PrivacyPolicy,
    "ProprietarySharing": ProprietarySharing,
    "RawMaterialTraceability": RawMaterialTraceability,
    "Reports": Reports,
    "RequestAccess": RequestAccess,
    "RequirementDetail": RequirementDetail,
    "Requirements": Requirements,
    "RetentionSamples": RetentionSamples,
    "RiskPredictions": RiskPredictions,
    "RiskWorkflow": RiskWorkflow,
    "SLADocumentCompletion": SLADocumentCompletion,
    "SelfAssessment": SelfAssessment,
    "Settings": Settings,
    "SiteManufacturingDashboard": SiteManufacturingDashboard,
    "SupplierManagement": SupplierManagement,
    "SupplierPortal": SupplierPortal,
    "SupportTickets": SupportTickets,
    "TermsAndConditions": TermsAndConditions,
    "Training": Training,
    "UserApprovalDashboard": UserApprovalDashboard,
    "UserManagement": UserManagement,

}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};