import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Upload, X, FileText, Link } from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = [
  { value: "procedure", label: "Standard Operating Procedure (SOP)" },
  { value: "policy", label: "Policy" },
  { value: "training_material", label: "Training Record / Material" },
  { value: "audit_report", label: "Audit Report" },
  { value: "compliance_evidence", label: "Compliance Evidence" },
  { value: "supplier_certificate", label: "Supplier Certificate" },
  { value: "safety_data_sheet", label: "Safety Data Sheet (SDS)" },
  { value: "inspection_report", label: "Inspection Report" },
  { value: "test_report", label: "Test Report" },
  { value: "risk_analysis", label: "Risk Analysis" },
  { value: "specification", label: "Specification" },
  { value: "plan", label: "Plan" },
  { value: "record", label: "Record" },
  { value: "other", label: "Other" },
];

const CONTROL_STATUSES = [
  { value: "uncontrolled", label: "Uncontrolled" },
  { value: "controlled", label: "Controlled" },
  { value: "under_review", label: "Under Review" },
];

export default function DocumentUploadDialog({
  open,
  onOpenChange,
  onDocumentUploaded,
  linkedRequirementIds = [],
  linkedAuditIds = [],
  prefilledTitle = "",
}) {
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState(prefilledTitle);
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState([]);
  const [tagInput, setTagInput] = useState("");
  const [controlStatus, setControlStatus] = useState("uncontrolled");
  const [expiryDate, setExpiryDate] = useState("");
  const [selectedRequirements, setSelectedRequirements] = useState(linkedRequirementIds);
  const [selectedAudits, setSelectedAudits] = useState(linkedAuditIds);
  const [loading, setLoading] = useState(false);
  const [linkTab, setLinkTab] = useState("requirements");

  const { data: requirements = [] } = useQuery({
    queryKey: ["requirements-for-doc"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-clause_number", 500),
    enabled: open,
  });

  const { data: audits = [] } = useQuery({
    queryKey: ["audits-for-doc"],
    queryFn: () => base44.entities.ComplianceAudit.list("-created_date", 100),
    enabled: open,
  });

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (tag) => setTags(tags.filter((t) => t !== tag));

  const handleToggleRequirement = (reqId) => {
    setSelectedRequirements((prev) =>
      prev.includes(reqId) ? prev.filter((id) => id !== reqId) : [...prev, reqId]
    );
  };

  const handleToggleAudit = (auditId) => {
    setSelectedAudits((prev) =>
      prev.includes(auditId) ? prev.filter((id) => id !== auditId) : [...prev, auditId]
    );
  };

  const handleSubmit = async () => {
    if (!file || !category || !title.trim()) {
      toast.error("Please fill in all required fields");
      return;
    }
    setLoading(true);
    try {
      const user = await base44.auth.me();
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      const document = await base44.entities.Document.create({
        file_name: file.name,
        file_url,
        file_size: file.size,
        file_type: file.type,
        title: title.trim(),
        category,
        description: description.trim(),
        tags,
        uploaded_by: user.email,
        organization_id: user.organization_id || null,
        current_version: "1.0",
        version_count: 1,
        control_status: controlStatus,
        expiry_date: expiryDate || undefined,
        linked_requirement_ids: selectedRequirements,
      });

      // Also link to audits if any selected
      if (selectedAudits.length > 0) {
        for (const auditId of selectedAudits) {
          const audit = await base44.entities.ComplianceAudit.filter({ id: auditId });
          if (audit?.[0]) {
            const existing = audit[0].document_ids || [];
            if (!existing.includes(document.id)) {
              await base44.entities.ComplianceAudit.update(auditId, {
                document_ids: [...existing, document.id],
              });
            }
          }
        }
      }

      await base44.entities.DocumentVersion.create({
        document_id: document.id,
        version_number: "1.0",
        file_url,
        file_name: file.name,
        file_size: file.size,
        uploaded_by: user.email,
        version_index: 1,
        is_auto_version: true,
      });

      toast.success("Document uploaded successfully");
      onDocumentUploaded?.(document);
      resetForm();
      onOpenChange(false);
    } catch (error) {
      toast.error("Failed to upload: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFile(null);
    setTitle(prefilledTitle);
    setCategory("");
    setDescription("");
    setTags([]);
    setTagInput("");
    setControlStatus("uncontrolled");
    setExpiryDate("");
    setSelectedRequirements(linkedRequirementIds);
    setSelectedAudits(linkedAuditIds);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Upload Document</DialogTitle>
          <DialogDescription>Upload and categorize compliance documents</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* File Upload */}
          <div>
            <Label className="text-sm font-medium">File *</Label>
            <div
              className="mt-1.5 border-2 border-dashed border-slate-300 rounded-lg p-6 text-center cursor-pointer hover:border-emerald-400 hover:bg-emerald-50/30 transition-colors"
              onClick={() => document.getElementById("doc-file-input").click()}
            >
              {file ? (
                <div className="flex items-center justify-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  <div>
                    <p className="font-medium text-slate-900 text-sm">{file.name}</p>
                    <p className="text-xs text-slate-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); setFile(null); }}
                    className="ml-2 text-slate-400 hover:text-rose-500"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div>
                  <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-700">Click to upload or drag & drop</p>
                  <p className="text-xs text-slate-400 mt-1">PDF, Word, Excel, images supported</p>
                </div>
              )}
              <input
                id="doc-file-input"
                type="file"
                hidden
                accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg,.csv,.txt"
                onChange={(e) => setFile(e.target.files?.[0])}
              />
            </div>
          </div>

          {/* Title + Category row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium">Title *</Label>
              <Input
                className="mt-1.5"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Document title"
              />
            </div>
            <div>
              <Label className="text-sm font-medium">Category *</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Control Status + Expiry row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium">Document Control</Label>
              <Select value={controlStatus} onValueChange={setControlStatus}>
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CONTROL_STATUSES.map((s) => (
                    <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium">Expiry Date</Label>
              <Input
                type="date"
                className="mt-1.5"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <Label className="text-sm font-medium">Description</Label>
            <Textarea
              className="mt-1.5"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add notes or description..."
              rows={2}
            />
          </div>

          {/* Tags */}
          <div>
            <Label className="text-sm font-medium">Tags</Label>
            <div className="flex gap-2 mt-1.5">
              <Input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), handleAddTag())}
                placeholder="Add tag, press Enter"
              />
              <Button type="button" variant="outline" onClick={handleAddTag} size="sm">Add</Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                    {tag}
                    <button onClick={() => handleRemoveTag(tag)} className="hover:text-rose-600 ml-0.5">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Link to Requirements / Audits */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Link className="w-4 h-4 text-slate-400" />
              <Label className="text-sm font-medium">Link to</Label>
              <div className="flex rounded-lg border border-slate-200 overflow-hidden ml-auto text-xs">
                <button
                  onClick={() => setLinkTab("requirements")}
                  className={`px-3 py-1.5 ${linkTab === "requirements" ? "bg-emerald-600 text-white" : "text-slate-600 hover:bg-slate-50"}`}
                >
                  Requirements ({selectedRequirements.length})
                </button>
                <button
                  onClick={() => setLinkTab("audits")}
                  className={`px-3 py-1.5 ${linkTab === "audits" ? "bg-emerald-600 text-white" : "text-slate-600 hover:bg-slate-50"}`}
                >
                  Audits ({selectedAudits.length})
                </button>
              </div>
            </div>

            <div className="max-h-44 overflow-y-auto border border-slate-200 rounded-lg p-2 space-y-1">
              {linkTab === "requirements" ? (
                requirements.length === 0 ? (
                  <p className="text-sm text-slate-400 text-center py-3">No requirements</p>
                ) : (
                  requirements.map((req) => (
                    <label key={req.id} className="flex items-start gap-2 cursor-pointer hover:bg-slate-50 rounded p-1.5">
                      <input
                        type="checkbox"
                        checked={selectedRequirements.includes(req.id)}
                        onChange={() => handleToggleRequirement(req.id)}
                        className="w-4 h-4 mt-0.5 rounded accent-emerald-600"
                      />
                      <span className="text-sm text-slate-800">
                        <span className="font-mono text-xs text-slate-500 mr-1">{req.clause_number}</span>
                        {req.clause_title}
                      </span>
                    </label>
                  ))
                )
              ) : (
                audits.length === 0 ? (
                  <p className="text-sm text-slate-400 text-center py-3">No audits available</p>
                ) : (
                  audits.map((audit) => (
                    <label key={audit.id} className="flex items-start gap-2 cursor-pointer hover:bg-slate-50 rounded p-1.5">
                      <input
                        type="checkbox"
                        checked={selectedAudits.includes(audit.id)}
                        onChange={() => handleToggleAudit(audit.id)}
                        className="w-4 h-4 mt-0.5 rounded accent-emerald-600"
                      />
                      <span className="text-sm text-slate-800">{audit.title || audit.audit_type || audit.id}</span>
                    </label>
                  ))
                )
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-1">
            <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>Cancel</Button>
            <Button
              onClick={handleSubmit}
              disabled={loading || !file || !category || !title.trim()}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {loading ? "Uploading..." : "Upload Document"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}