import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Lock,
  Share2,
  Plus,
  Trash2,
  Copy,
  CheckCircle,
  Clock,
  Mail,
  Link as LinkIcon,
  ExternalLink,
} from "lucide-react";
import { format } from "date-fns";

export default function ProprietaryRecipeShare() {
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [shareEmail, setShareEmail] = useState("");
  const [shareType, setShareType] = useState("internal");
  const [accessLevel, setAccessLevel] = useState("view");
  const [tokenExpiry, setTokenExpiry] = useState("30");
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [copiedToken, setCopiedToken] = useState(null);
  const queryClient = useQueryClient();

  const { data: recipes = [], isLoading } = useQuery({
    queryKey: ["proprietary-recipes"],
    queryFn: () => base44.entities.ProprietaryRecipeShare.list("-created_date", 100),
  });

  const shareMutation = useMutation({
    mutationFn: async (data) => {
      if (!selectedRecipe) return;
      const token = Math.random().toString(36).substring(2, 15);
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + parseInt(tokenExpiry));
      
      await base44.entities.ProprietaryRecipeShare.update(selectedRecipe.id, {
        recipients: [
          ...(selectedRecipe.recipients || []),
          {
            email: shareEmail,
            name: shareEmail.split("@")[0],
            type: shareType,
            access_level: accessLevel,
            shared_date: new Date().toISOString(),
          },
        ],
        ...(shareType === "external" && {
          access_token: token,
          token_expiry: format(expiryDate, "yyyy-MM-dd"),
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["proprietary-recipes"] });
      setShareEmail("");
      setShareType("internal");
      setAccessLevel("view");
      setTokenExpiry("30");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ProprietaryRecipeShare.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["proprietary-recipes"] });
      setDeleteConfirm(null);
    },
  });

  const revokeMutation = useMutation({
    mutationFn: async (recipeId) => {
      const recipe = recipes.find(r => r.id === recipeId);
      if (recipe) {
        await base44.entities.ProprietaryRecipeShare.update(recipeId, {
          status: "revoked",
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["proprietary-recipes"] });
    },
  });

  const handleShare = async () => {
    if (!shareEmail.trim()) return;
    await shareMutation.mutateAsync({});
  };

  const handleCopyToken = (token) => {
    navigator.clipboard.writeText(token);
    setCopiedToken(token);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Lock className="w-5 h-5 text-rose-600" />
          <h3 className="text-lg font-semibold text-slate-900">
            Proprietary Recipe Sharing
          </h3>
          <Badge variant="outline" className="bg-rose-50 text-rose-700 border-rose-200">
            Admin/Auditor Only
          </Badge>
        </div>
        <Button onClick={() => setShowShareDialog(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          New Recipe Share
        </Button>
      </div>

      <div className="grid gap-3">
        {recipes.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-8 text-center">
              <Lock className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-slate-500">
                No proprietary recipes shared yet
              </p>
            </CardContent>
          </Card>
        ) : (
          recipes.map((recipe) => (
            <Card key={recipe.id} className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-slate-900">
                        {recipe.recipe_name}
                      </h4>
                      <Badge
                        className={
                          recipe.status === "active"
                            ? "bg-emerald-100 text-emerald-800"
                            : recipe.status === "archived"
                            ? "bg-slate-100 text-slate-800"
                            : "bg-rose-100 text-rose-800"
                        }
                      >
                        {recipe.status}
                      </Badge>
                    </div>

                    {recipe.description && (
                      <p className="text-sm text-slate-600 mb-3">
                        {recipe.description}
                      </p>
                    )}

                    <div className="space-y-2">
                      <p className="text-xs font-medium text-slate-600">
                        Shared With ({recipe.recipients?.length || 0}):
                      </p>
                      {recipe.recipients?.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {recipe.recipients.map((recipient, idx) => (
                            <div
                              key={idx}
                              className="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-700 flex items-center gap-1"
                            >
                              {recipient.type === "external" ? (
                                <ExternalLink className="w-3 h-3" />
                              ) : (
                                <Mail className="w-3 h-3" />
                              )}
                              <span className="font-medium">
                                {recipient.email}
                              </span>
                              <span className="text-slate-500">
                                ({recipient.access_level})
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-400 italic">
                          Not shared yet
                        </p>
                      )}
                    </div>

                    {recipe.access_token && (
                      <div className="mt-3 p-2 bg-slate-50 rounded-lg border border-slate-200">
                        <p className="text-xs text-slate-600 mb-1">
                          External Access Token:
                        </p>
                        <div className="flex items-center gap-2">
                          <code className="text-xs font-mono text-slate-700 truncate">
                            {recipe.access_token}
                          </code>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 px-2"
                            onClick={() => handleCopyToken(recipe.access_token)}
                          >
                            {copiedToken === recipe.access_token ? (
                              <CheckCircle className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </Button>
                        </div>
                        {recipe.token_expiry && (
                          <p className="text-xs text-slate-500 mt-1">
                            <Clock className="w-3 h-3 inline mr-1" />
                            Expires {format(new Date(recipe.token_expiry), "MMM d, yyyy")}
                          </p>
                        )}
                      </div>
                    )}

                    <div className="text-xs text-slate-500 mt-2">
                      Shared by {recipe.shared_by} •{" "}
                      {format(new Date(recipe.created_date), "MMM d, yyyy")}
                      {recipe.access_count > 0 && (
                        <>
                          • Accessed {recipe.access_count} time
                          {recipe.access_count !== 1 ? "s" : ""}
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-1 shrink-0">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedRecipe(recipe)}
                      className="h-8"
                    >
                      <Share2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => window.open(recipe.file_url, "_blank")}
                      className="h-8"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setDeleteConfirm(recipe.id)}
                      className="h-8 text-rose-600 hover:text-rose-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Share Dialog */}
      <Dialog open={!!selectedRecipe} onOpenChange={(open) => !open && setSelectedRecipe(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Recipe: {selectedRecipe?.recipe_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-slate-700 mb-1 block">
                Share Type
              </label>
              <Select value={shareType} onValueChange={setShareType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="internal">Internal Team Member</SelectItem>
                  <SelectItem value="external">External Party</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 mb-1 block">
                Email Address
              </label>
              <Input
                type="email"
                placeholder="recipient@example.com"
                value={shareEmail}
                onChange={(e) => setShareEmail(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 mb-1 block">
                Access Level
              </label>
              <Select value={accessLevel} onValueChange={setAccessLevel}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="view">View Only</SelectItem>
                  <SelectItem value="download">Download</SelectItem>
                  <SelectItem value="edit">Edit</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {shareType === "external" && (
              <div>
                <label className="text-sm font-medium text-slate-700 mb-1 block">
                  Token Expiry (days)
                </label>
                <Select value={tokenExpiry} onValueChange={setTokenExpiry}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 days</SelectItem>
                    <SelectItem value="30">30 days</SelectItem>
                    <SelectItem value="60">60 days</SelectItem>
                    <SelectItem value="90">90 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="flex gap-2 justify-end pt-4">
              <Button
                variant="outline"
                onClick={() => setSelectedRecipe(null)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleShare}
                disabled={!shareEmail.trim() || shareMutation.isPending}
              >
                {shareMutation.isPending ? "Sharing..." : "Share"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Revoke Recipe Share?</AlertDialogTitle>
            <AlertDialogDescription>
              This will revoke access to the proprietary recipe. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex gap-3 justify-end">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirm && deleteMutation.mutate(deleteConfirm)}
              className="bg-rose-600 hover:bg-rose-700"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}