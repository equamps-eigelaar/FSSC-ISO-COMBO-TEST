import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, CheckCircle2, Info, XCircle } from "lucide-react";
import { format } from "date-fns";

const STATUS_CONFIG = {
  compliant: {
    icon: CheckCircle2,
    color: "text-emerald-600",
    bg: "bg-emerald-50 dark:bg-emerald-900/20",
    label: "Compliant"
  },
  non_compliant: {
    icon: XCircle,
    color: "text-red-600",
    bg: "bg-red-50 dark:bg-red-900/20",
    label: "Non-Compliant"
  },
  requires_review: {
    icon: AlertTriangle,
    color: "text-amber-600",
    bg: "bg-amber-50 dark:bg-amber-900/20",
    label: "Requires Review"
  },
  insufficient_data: {
    icon: Info,
    color: "text-slate-600",
    bg: "bg-slate-50 dark:bg-slate-900/20",
    label: "Insufficient Data"
  }
};

const SEVERITY_CONFIG = {
  critical: { color: "bg-red-600 text-white", label: "Critical" },
  high: { color: "bg-orange-600 text-white", label: "High" },
  medium: { color: "bg-amber-600 text-white", label: "Medium" },
  low: { color: "bg-blue-600 text-white", label: "Low" }
};

export default function DocumentAnalysisDialog({ open, onClose, document }) {
  if (!document?.ai_analysis?.analyzed) {
    return null;
  }

  const analysis = document.ai_analysis;
  const status = STATUS_CONFIG[analysis.compliance_status] || STATUS_CONFIG.insufficient_data;
  const StatusIcon = status.icon;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>AI Document Analysis</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Status */}
          <Card className={`border-0 ${status.bg}`}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <StatusIcon className={`w-6 h-6 ${status.color}`} />
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-900 dark:text-white">
                    {status.label}
                  </h3>
                  {analysis.confidence_score && (
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Confidence: {Math.round(analysis.confidence_score)}%
                    </p>
                  )}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {format(new Date(analysis.analyzed_date), 'MMM d, yyyy HH:mm')}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Summary */}
          {analysis.summary && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm text-slate-900 dark:text-white mb-2">
                  Summary
                </h4>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {analysis.summary}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Extracted Information */}
          {analysis.extracted_data && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm text-slate-900 dark:text-white mb-3">
                  Extracted Information
                </h4>
                <div className="space-y-2">
                  {analysis.extracted_data.issuing_organization && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500 dark:text-slate-400">Issuing Organization:</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {analysis.extracted_data.issuing_organization}
                      </span>
                    </div>
                  )}
                  {analysis.extracted_data.certificate_number && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500 dark:text-slate-400">Certificate Number:</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {analysis.extracted_data.certificate_number}
                      </span>
                    </div>
                  )}
                  {document.expiry_date && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500 dark:text-slate-400">Expiry Date:</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {format(new Date(document.expiry_date), 'MMM d, yyyy')}
                      </span>
                    </div>
                  )}
                  {analysis.extracted_data.scope && (
                    <div className="text-sm">
                      <span className="text-slate-500 dark:text-slate-400 block mb-1">Scope:</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {analysis.extracted_data.scope}
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Regulations Mentioned */}
          {analysis.extracted_data?.regulations_mentioned?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm text-slate-900 dark:text-white mb-3">
                  Regulations &amp; Standards Referenced
                </h4>
                <div className="flex flex-wrap gap-2">
                  {analysis.extracted_data.regulations_mentioned.map((reg, idx) => (
                    <Badge key={idx} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      {reg}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Required Actions */}
          {analysis.extracted_data?.required_actions?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm text-slate-900 dark:text-white mb-3">
                  Required Actions
                </h4>
                <div className="space-y-2">
                  {analysis.extracted_data.required_actions.map((item, idx) => {
                    const color = item.priority === "critical" ? "text-red-700 bg-red-50 border-red-200" :
                      item.priority === "high" ? "text-orange-700 bg-orange-50 border-orange-200" :
                      item.priority === "medium" ? "text-amber-700 bg-amber-50 border-amber-200" :
                      "text-slate-700 bg-slate-50 border-slate-200";
                    return (
                      <div key={idx} className={`p-3 rounded-lg border text-sm ${color}`}>
                        <div className="flex items-start justify-between gap-2">
                          <span>{item.action}</span>
                          {item.deadline_hint && (
                            <span className="text-xs shrink-0 opacity-70">{item.deadline_hint}</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* AI-Suggested Tags - show from document.tags if analysis ran */}
          {document.tags?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm text-slate-900 dark:text-white mb-3">
                  AI-Suggested Tags
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {document.tags.map((tag, idx) => (
                    <span key={idx} className="text-xs px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-100">
                      {tag}
                    </span>
                  ))}
                </div>
                <p className="text-xs text-slate-400 mt-2">Automatically applied to improve searchability.</p>
              </CardContent>
            </Card>
          )}

          {/* Critical Parameters */}
          {analysis.extracted_data?.critical_parameters?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm text-slate-900 dark:text-white mb-3">
                  Critical Parameters
                </h4>
                <div className="space-y-2">
                  {analysis.extracted_data.critical_parameters.map((param, idx) => (
                    <div key={idx} className="flex items-center justify-between text-sm p-2 bg-slate-50 dark:bg-slate-900 rounded">
                      <span className="text-slate-700 dark:text-slate-300">{param.parameter}</span>
                      <span className="font-medium text-slate-900 dark:text-white">
                        {param.value} {param.unit}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Issues Found */}
          {analysis.issues_found?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm text-slate-900 dark:text-white mb-3">
                  Issues Found ({analysis.issues_found.length})
                </h4>
                <div className="space-y-3">
                  {analysis.issues_found.map((issue, idx) => {
                    const severity = SEVERITY_CONFIG[issue.severity] || SEVERITY_CONFIG.medium;
                    return (
                      <div key={idx} className="p-3 border border-slate-200 dark:border-slate-700 rounded-lg">
                        <div className="flex items-start gap-2 mb-2">
                          <Badge className={severity.color}>
                            {severity.label}
                          </Badge>
                          <p className="text-sm font-medium text-slate-900 dark:text-white flex-1">
                            {issue.issue}
                          </p>
                        </div>
                        {issue.recommendation && (
                          <p className="text-xs text-slate-600 dark:text-slate-400 pl-2 border-l-2 border-blue-300 dark:border-blue-700">
                            💡 {issue.recommendation}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* No Issues */}
          {(!analysis.issues_found || analysis.issues_found.length === 0) && analysis.compliance_status === 'compliant' && (
            <Card className="border-0 bg-emerald-50 dark:bg-emerald-900/20">
              <CardContent className="p-4 text-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                <p className="text-sm text-emerald-800 dark:text-emerald-200">
                  No compliance issues found
                </p>
              </CardContent>
            </Card>
          )}

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}