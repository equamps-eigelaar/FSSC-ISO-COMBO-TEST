import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Link as LinkIcon, Unlink } from "lucide-react";
import DocumentUploadDialog from "./DocumentUploadDialog";

export default function LinkedDocumentsSection({ requirementId }) {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);

  useEffect(() => {
    loadDocuments();
  }, [requirementId]);

  const loadDocuments = async () => {
    try {
      const allDocs = await base44.entities.Document.list();
      const linked = (allDocs || []).filter(
        (doc) => doc.linked_requirement_ids?.includes(requirementId)
      );
      setDocuments(linked);
    } catch (error) {
      console.error("Failed to load documents:", error);
    } finally {
      setLoading(false);
    }
  };

  const unlinkDocument = async (docId) => {
    if (!confirm("Remove link from this document?")) return;

    try {
      const doc = await base44.entities.Document.get(docId);
      const updated = (doc.linked_requirement_ids || []).filter(
        (id) => id !== requirementId
      );
      await base44.entities.Document.update(docId, {
        linked_requirement_ids: updated,
      });
      setDocuments(documents.filter((d) => d.id !== docId));
    } catch (error) {
      alert("Failed to unlink document: " + error.message);
    }
  };

  if (loading) {
    return <div className="text-sm text-slate-500">Loading documents...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <LinkIcon className="w-5 h-5 text-slate-400" />
          <h3 className="font-semibold text-slate-900">Linked Documents</h3>
          <span className="text-sm text-slate-500">({documents.length})</span>
        </div>
        <Button
          onClick={() => setUploadDialogOpen(true)}
          size="sm"
          className="gap-1 bg-emerald-600 hover:bg-emerald-700"
        >
          <FileText className="w-4 h-4" />
          Link Document
        </Button>
      </div>

      {documents.length === 0 ? (
        <p className="text-sm text-slate-500 italic">
          No documents linked. Upload or link documents to support this requirement.
        </p>
      ) : (
        <div className="space-y-2">
          {documents.map((doc) => (
            <Card key={doc.id} className="p-3">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <FileText className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <span className="font-medium text-sm text-slate-900 truncate">
                      {doc.title || doc.file_name}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      v{doc.current_version}
                    </Badge>
                  </div>
                  {doc.description && (
                    <p className="text-sm text-slate-600 mb-2">{doc.description}</p>
                  )}
                  <div className="flex flex-wrap gap-1">
                    <Badge variant="secondary" className="text-xs">
                      {doc.category.replace(/_/g, " ")}
                    </Badge>
                    {doc.tags?.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 flex-shrink-0">
                  <a
                    href={doc.file_url}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Download
                    </Button>
                  </a>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => unlinkDocument(doc.id)}
                    className="text-slate-400 hover:text-red-600"
                  >
                    <Unlink className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <DocumentUploadDialog
        open={uploadDialogOpen}
        onOpenChange={setUploadDialogOpen}
        onDocumentUploaded={() => {
          loadDocuments();
          setUploadDialogOpen(false);
        }}
        linkedRequirementIds={[requirementId]}
        prefilledTitle=""
      />
    </div>
  );
}