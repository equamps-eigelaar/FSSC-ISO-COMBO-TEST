import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Download, Upload, Clock, User } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function DocumentVersionHistory({ documentId }) {
  const [versions, setVersions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [newFile, setNewFile] = useState(null);
  const [versionNotes, setVersionNotes] = useState("");
  const [customVersion, setCustomVersion] = useState("");
  const [uploading, setUploading] = useState(false);
  const [user, setUser] = useState(null);
  const [document, setDocument] = useState(null);

  useEffect(() => {
    loadVersions();
    loadUser();
    loadDocument();
  }, [documentId]);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Failed to load user:", error);
    }
  };

  const loadDocument = async () => {
    try {
      const doc = await base44.entities.Document.get(documentId);
      setDocument(doc);
    } catch (error) {
      console.error("Failed to load document:", error);
    }
  };

  const loadVersions = async () => {
    try {
      const allVersions = await base44.entities.DocumentVersion.filter({
        document_id: documentId,
      });
      setVersions((allVersions || []).sort((a, b) => b.version_index - a.version_index));
    } catch (error) {
      console.error("Failed to load versions:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleNewVersion = async () => {
    if (!newFile || !user) {
      alert("Please select a file");
      return;
    }

    setUploading(true);
    try {
      // Upload new file
      const { file_url } = await base44.integrations.Core.UploadFile({
        file: newFile,
      });

      // Calculate new version number
      let newVersionNumber = "1.0";
      if (customVersion.trim()) {
        newVersionNumber = customVersion.trim();
      } else {
        const lastVersion = versions[0];
        if (lastVersion) {
          const parts = lastVersion.version_number.split(".");
          parts[1] = (parseInt(parts[1] || 0) + 1).toString();
          newVersionNumber = parts.join(".");
        }
      }

      // Create version record
      const newVersionRecord = await base44.entities.DocumentVersion.create({
        document_id: documentId,
        version_number: newVersionNumber,
        file_url: file_url,
        file_name: newFile.name,
        file_size: newFile.size,
        uploaded_by: user.email,
        change_notes: versionNotes.trim(),
        version_index: versions.length + 1,
        is_auto_version: !customVersion.trim(),
      });

      // Update document with new version info
      await base44.entities.Document.update(documentId, {
        file_url: file_url,
        current_version: newVersionNumber,
        version_count: versions.length + 1,
      });

      setVersions([newVersionRecord, ...versions]);
      resetUploadForm();
      setUploadDialogOpen(false);
    } catch (error) {
      alert("Failed to upload new version: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const resetUploadForm = () => {
    setNewFile(null);
    setVersionNotes("");
    setCustomVersion("");
  };

  if (loading) {
    return <div className="text-sm text-slate-500">Loading versions...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-slate-400" />
          <h3 className="font-semibold text-slate-900">Version History</h3>
          <span className="text-sm text-slate-500">({versions.length})</span>
        </div>
        <Button
          onClick={() => setUploadDialogOpen(true)}
          size="sm"
          className="gap-1 bg-emerald-600 hover:bg-emerald-700"
        >
          <Upload className="w-4 h-4" />
          New Version
        </Button>
      </div>

      {/* Versions List */}
      <div className="space-y-2">
        {versions.map((version, index) => (
          <Card key={version.id} className="p-3">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant={index === 0 ? "default" : "outline"}>
                    v{version.version_number}
                  </Badge>
                  {version.is_auto_version && (
                    <Badge variant="secondary" className="text-xs">
                      Auto
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-slate-600 mb-1">{version.file_name}</p>
                {version.change_notes && (
                  <p className="text-sm text-slate-700 mb-1">
                    Changes: {version.change_notes}
                  </p>
                )}
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <User className="w-3 h-3" />
                  <span>{version.uploaded_by}</span>
                  <span>•</span>
                  <span>
                    {formatDistanceToNow(new Date(version.created_date), {
                      addSuffix: true,
                    })}
                  </span>
                </div>
              </div>

              <a
                href={version.file_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-shrink-0"
              >
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download
                </Button>
              </a>
            </div>
          </Card>
        ))}
      </div>

      {/* New Version Dialog */}
      <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Upload New Version</DialogTitle>
            <DialogDescription>
              Upload a new version of this document
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* File Upload */}
            <div>
              <label className="block text-sm font-medium text-slate-900 mb-2">
                File *
              </label>
              <div
                className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center cursor-pointer hover:border-slate-400 transition-colors"
                onClick={() => document.getElementById("version-file-input").click()}
              >
                {newFile ? (
                  <div>
                    <p className="font-medium text-slate-900">{newFile.name}</p>
                    <p className="text-xs text-slate-500">
                      {(newFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm font-medium text-slate-900">
                      Click to upload
                    </p>
                  </div>
                )}
                <input
                  id="version-file-input"
                  type="file"
                  hidden
                  onChange={(e) => setNewFile(e.target.files?.[0])}
                />
              </div>
            </div>

            {/* Version Number */}
            <div>
              <label className="block text-sm font-medium text-slate-900 mb-2">
                Version Number (Optional - auto-increment if empty)
              </label>
              <Input
                value={customVersion}
                onChange={(e) => setCustomVersion(e.target.value)}
                placeholder="e.g., 2.0, 1.1"
              />
            </div>

            {/* Change Notes */}
            <div>
              <label className="block text-sm font-medium text-slate-900 mb-2">
                What Changed?
              </label>
              <Textarea
                value={versionNotes}
                onChange={(e) => setVersionNotes(e.target.value)}
                placeholder="Describe the changes in this version"
                rows={3}
              />
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setUploadDialogOpen(false);
                  resetUploadForm();
                }}
                disabled={uploading}
              >
                Cancel
              </Button>
              <Button
                onClick={handleNewVersion}
                disabled={uploading || !newFile}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {uploading ? "Uploading..." : "Upload Version"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}