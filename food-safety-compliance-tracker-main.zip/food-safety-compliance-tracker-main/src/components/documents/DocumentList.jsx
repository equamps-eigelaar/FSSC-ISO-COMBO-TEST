import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  FileText, Download, Trash2, FileSpreadsheet, Image, File,
  Calendar, AlertCircle, Sparkles, GitBranch, Tag, History,
  Eye, Clock, User, ChevronDown, ChevronUp,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import DocumentAnalysisDialog from "./DocumentAnalysisDialog";
import DocumentControlPanel from "./DocumentControlPanel";
import DocumentViewer from "./DocumentViewer";
import { usePermissions } from "@/components/permissions/usePermissions";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const FILE_ICONS = {
  "application/pdf": FileText,
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": FileText,
  "application/msword": FileText,
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": FileSpreadsheet,
  "application/vnd.ms-excel": FileSpreadsheet,
  "image/png": Image,
  "image/jpeg": Image,
  "image/jpg": Image,
};

const CONTROL_COLORS = {
  controlled: "bg-indigo-50 text-indigo-700 border-indigo-200",
  under_review: "bg-amber-50 text-amber-700 border-amber-200",
  uncontrolled: "bg-slate-50 text-slate-600 border-slate-200",
};

function DocumentCard({ doc, onDelete, onAnalyze, isAnalyzing, permissions }) {
  const [expanded, setExpanded] = useState(false);
  const [showControl, setShowControl] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showViewer, setShowViewer] = useState(false);

  const { data: revisions = [] } = useQuery({
    queryKey: ["document-revisions", doc.id],
    queryFn: () => base44.entities.DocumentRevision.filter({ document_id: doc.id }, "-created_date", 50),
    enabled: showHistory || showControl,
  });

  const IconComponent = FILE_ICONS[doc.file_type] || File;
  const expired = doc.expiry_date && new Date(doc.expiry_date) < new Date();
  const expiringSoon = doc.expiry_date && !expired && (() => {
    const days = Math.ceil((new Date(doc.expiry_date) - new Date()) / (1000 * 60 * 60 * 24));
    return days <= 30;
  })();

  return (
    <>
      <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
        <CardContent className="p-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center shrink-0">
              <IconComponent className="w-5 h-5 text-slate-600" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between mb-1 gap-2">
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-slate-900 truncate">{doc.file_name}</h4>
                  <div className="flex flex-wrap items-center gap-1.5 mt-1">
                    <Badge variant="outline" className="text-xs">
                      {doc.document_type?.replace(/_/g, " ")}
                    </Badge>
                    {doc.control_status && (
                      <Badge variant="outline" className={`text-xs ${CONTROL_COLORS[doc.control_status]}`}>
                        {doc.control_status === "controlled" && <GitBranch className="w-3 h-3 mr-1" />}
                        {doc.control_status?.replace(/_/g, " ")}
                        {doc.current_version && doc.control_status === "controlled" ? ` v${doc.current_version}` : ""}
                      </Badge>
                    )}
                    {expired && (
                      <Badge variant="outline" className="text-xs bg-rose-50 text-rose-700 border-rose-200">
                        <AlertCircle className="w-3 h-3 mr-0.5" />Expired
                      </Badge>
                    )}
                    {expiringSoon && !expired && (
                      <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                        <AlertCircle className="w-3 h-3 mr-0.5" />Expiring Soon
                      </Badge>
                    )}
                  </div>
                </div>
                {/* Actions */}
                <div className="flex items-center gap-1 shrink-0">
                  {doc.ai_analysis?.analyzed ? (
                    <Button variant="ghost" size="sm" onClick={() => onAnalyze(doc)} className={`h-8 w-8 p-0 ${doc.ai_analysis.compliance_status === 'compliant' ? 'text-emerald-600 hover:bg-emerald-50' : doc.ai_analysis.compliance_status === 'non_compliant' ? 'text-red-600 hover:bg-red-50' : 'text-amber-600 hover:bg-amber-50'}`} title="View AI Analysis">
                      <Sparkles className="w-4 h-4" />
                    </Button>
                  ) : ['supplier_certificate', 'safety_data_sheet', 'test_report', 'compliance_evidence'].includes(doc.document_type) ? (
                    <Button variant="ghost" size="sm" onClick={() => onAnalyze(doc, true)} disabled={isAnalyzing} className="h-8 w-8 p-0 text-slate-400 hover:text-purple-600 hover:bg-purple-50" title="Analyze with AI">
                      <Sparkles className="w-4 h-4" />
                    </Button>
                  ) : null}
                  <Button variant="ghost" size="sm" onClick={() => setShowViewer(true)} className="h-8 w-8 p-0 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50" title="Preview">
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => setShowControl(true)} className="h-8 w-8 p-0 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50" title="Version Control">
                    <GitBranch className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => setShowHistory(true)} className="h-8 w-8 p-0 text-slate-400 hover:text-slate-600" title="Change History">
                    <History className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => window.open(doc.file_url, "_blank")} className="h-8 w-8 p-0">
                    <Download className="w-4 h-4" />
                  </Button>
                  {permissions.canManageDocuments && (
                    <Button variant="ghost" size="sm" onClick={() => onDelete(doc.id)} className="h-8 w-8 p-0 text-rose-600 hover:text-rose-700 hover:bg-rose-50">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                  <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)} className="h-8 w-8 p-0">
                    {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              {/* Meta row */}
              <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-slate-500">
                {doc.file_size && <span>{(doc.file_size / 1024).toFixed(1)} KB</span>}
                <span className="flex items-center gap-1"><User className="w-3 h-3" />{doc.uploaded_by}</span>
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{format(new Date(doc.created_date), "MMM d, yyyy")}</span>
                {doc.expiry_date && (
                  <span className={`flex items-center gap-1 ${expired ? "text-rose-600" : expiringSoon ? "text-amber-600" : ""}`}>
                    <Calendar className="w-3 h-3" />Expires {format(new Date(doc.expiry_date), "MMM d, yyyy")}
                  </span>
                )}
              </div>

              {/* Tags */}
              {doc.tags?.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-2">
                  <Tag className="w-3 h-3 text-slate-400 mt-0.5" />
                  {doc.tags.map(tag => (
                    <span key={tag} className="text-xs px-1.5 py-0.5 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-100">{tag}</span>
                  ))}
                </div>
              )}

              {/* Expanded description */}
              {expanded && doc.description && (
                <p className="text-xs text-slate-600 mt-2 p-2 bg-slate-50 rounded">{doc.description}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Document Viewer */}
      <DocumentViewer doc={doc} open={showViewer} onClose={() => setShowViewer(false)} />

      {/* Version Control Dialog */}
      <Dialog open={showControl} onOpenChange={setShowControl}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-indigo-600" />
              {doc.file_name}
            </DialogTitle>
          </DialogHeader>
          <DocumentControlPanel document={doc} />
        </DialogContent>
      </Dialog>

      {/* Change History Dialog */}
      <Dialog open={showHistory} onOpenChange={setShowHistory}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="w-4 h-4" />
              Change History — {doc.file_name}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-3">
            {/* Original upload */}
            <div className="border border-slate-100 rounded-lg p-3 bg-slate-50">
              <div className="flex items-center justify-between mb-1">
                <Badge variant="outline" className="font-mono text-xs">Original Upload</Badge>
                <span className="text-xs text-slate-500">{format(new Date(doc.created_date), "MMM d, yyyy h:mm a")}</span>
              </div>
              <p className="text-xs text-slate-600">Uploaded by <strong>{doc.uploaded_by}</strong></p>
            </div>

            {/* Revisions */}
            {revisions.length > 0 ? (
              revisions.map((rev) => (
                <div key={rev.id} className="border border-slate-100 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="font-mono text-xs">v{rev.version}</Badge>
                      <Badge className={`text-xs ${rev.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : rev.status === 'pending_review' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'}`}>
                        {rev.status?.replace(/_/g, " ")}
                      </Badge>
                      {rev.is_current && <Badge className="text-xs bg-indigo-100 text-indigo-800">Current</Badge>}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500">{format(new Date(rev.created_date), "MMM d, yyyy h:mm a")}</span>
                      <Button size="sm" variant="ghost" asChild className="h-6 w-6 p-0">
                        <a href={rev.file_url} target="_blank" rel="noopener noreferrer"><Download className="w-3 h-3" /></a>
                      </Button>
                    </div>
                  </div>
                  {rev.change_summary && <p className="text-xs text-slate-600">{rev.change_summary}</p>}
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500 mt-1">
                    <span>{rev.revision_type} revision</span>
                    {rev.approved_by && <span>• Approved by {rev.approved_by}</span>}
                    {rev.approved_date && <span>on {format(new Date(rev.approved_date), "MMM d, yyyy")}</span>}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-400 text-center py-4">No version revisions recorded yet.</p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default function DocumentList({ entityType, entityId }) {
  const [analyzingDoc, setAnalyzingDoc] = useState(null);
  const [triggerAnalysis, setTriggerAnalysis] = useState(false);
  const { permissions } = usePermissions();
  const queryClient = useQueryClient();

  const analyzeMutation = useMutation({
    mutationFn: (docId) => base44.functions.invoke('analyzeComplianceDocument', { document_id: docId }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['documents'] }); toast.success("Analysis complete"); },
    onError: () => toast.error("Analysis failed"),
  });

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ["documents", entityType, entityId],
    queryFn: () => base44.entities.Document.filter({ linked_entity_type: entityType, linked_entity_id: entityId }, "-created_date", 100),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Document.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["documents"] }); toast.success("Document deleted"); },
    onError: () => toast.error("Failed to delete document"),
  });

  const handleAnalyze = (doc, shouldAnalyze = false) => {
    if (shouldAnalyze) {
      analyzeMutation.mutate(doc.id);
    } else {
      setAnalyzingDoc(doc);
    }
  };

  if (isLoading) return <div className="text-sm text-slate-500">Loading documents...</div>;

  if (documents.length === 0) {
    return (
      <div className="text-center py-8 text-slate-500 text-sm">
        <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
        No documents uploaded yet
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {documents.map((doc) => (
        <DocumentCard
          key={doc.id}
          doc={doc}
          onDelete={(id) => deleteMutation.mutate(id)}
          onAnalyze={handleAnalyze}
          isAnalyzing={analyzeMutation.isPending}
          permissions={permissions}
        />
      ))}

      {analyzingDoc && (
        <DocumentAnalysisDialog
          open={!!analyzingDoc}
          onClose={() => setAnalyzingDoc(null)}
          document={analyzingDoc}
        />
      )}
    </div>
  );
}