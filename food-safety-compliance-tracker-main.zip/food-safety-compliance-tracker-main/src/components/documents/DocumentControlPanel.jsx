import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  FileText, 
  Upload, 
  CheckCircle2, 
  Clock, 
  GitBranch,
  Download,
  Eye,
  History
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

const STATUS_CONFIG = {
  draft: { label: "Draft", color: "bg-slate-100 text-slate-700", icon: FileText },
  pending_review: { label: "Pending Review", color: "bg-yellow-100 text-yellow-800", icon: Clock },
  approved: { label: "Approved", color: "bg-emerald-100 text-emerald-800", icon: CheckCircle2 },
  superseded: { label: "Superseded", color: "bg-slate-100 text-slate-500", icon: History },
  archived: { label: "Archived", color: "bg-slate-100 text-slate-500", icon: History }
};

export default function DocumentControlPanel({ document }) {
  const [showNewVersion, setShowNewVersion] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [newVersion, setNewVersion] = useState({
    file: null,
    change_summary: "",
    revision_type: "minor"
  });
  const queryClient = useQueryClient();

  const { data: revisions = [] } = useQuery({
    queryKey: ['document-revisions', document?.id],
    queryFn: () => base44.entities.DocumentRevision.filter({ document_id: document.id }, '-created_date', 50),
    enabled: !!document
  });

  const { data: currentUser } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });

  const createRevisionMutation = useMutation({
    mutationFn: (data) => base44.entities.DocumentRevision.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['document-revisions'] });
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      setShowNewVersion(false);
      setNewVersion({ file: null, change_summary: "", revision_type: "minor" });
      toast.success("New version uploaded");
    }
  });

  const updateRevisionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.DocumentRevision.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['document-revisions'] });
      toast.success("Revision updated");
    }
  });

  const currentRevision = revisions.find(r => r.is_current);
  const nextVersion = calculateNextVersion(currentRevision?.version || "0.0", newVersion.revision_type);

  function calculateNextVersion(current, type) {
    const parts = current.split('.').map(p => parseInt(p) || 0);
    if (type === 'major') return `${parts[0] + 1}.0`;
    if (type === 'minor') return `${parts[0]}.${parts[1] + 1}`;
    return `${parts[0]}.${parts[1]}.${(parts[2] || 0) + 1}`;
  }

  const handleFileSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setNewVersion({ ...newVersion, file: { url: file_url, name: file.name, size: file.size } });
    } catch (error) {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const handleCreateRevision = async () => {
    if (!newVersion.file) {
      toast.error("Please upload a file");
      return;
    }

    // Mark previous current as superseded
    if (currentRevision) {
      await updateRevisionMutation.mutateAsync({
        id: currentRevision.id,
        data: { is_current: false, status: "superseded" }
      });
    }

    createRevisionMutation.mutate({
      document_id: document.id,
      version: nextVersion,
      file_url: newVersion.file.url,
      file_size: newVersion.file.size,
      change_summary: newVersion.change_summary,
      revision_type: newVersion.revision_type,
      status: "draft",
      is_current: true
    });
  };

  const handleApprove = (revisionId) => {
    updateRevisionMutation.mutate({
      id: revisionId,
      data: {
        status: "approved",
        approved_by: currentUser?.email,
        approved_date: new Date().toISOString()
      }
    });
  };

  const handleRequestReview = (revisionId) => {
    updateRevisionMutation.mutate({
      id: revisionId,
      data: { status: "pending_review" }
    });
  };

  if (!document) return null;

  return (
    <div className="space-y-4">
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-indigo-600" />
              Document Control
            </CardTitle>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => setShowHistory(true)}>
                <History className="w-3 h-3 mr-1" />
                History
              </Button>
              <Button size="sm" onClick={() => setShowNewVersion(true)} className="bg-indigo-600 hover:bg-indigo-700">
                <Upload className="w-3 h-3 mr-1" />
                New Version
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {currentRevision ? (
            <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="font-mono">v{currentRevision.version}</Badge>
                  <Badge className={STATUS_CONFIG[currentRevision.status].color}>
                    {STATUS_CONFIG[currentRevision.status].label}
                  </Badge>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" asChild>
                    <a href={currentRevision.file_url} target="_blank" rel="noopener noreferrer">
                      <Download className="w-3 h-3" />
                    </a>
                  </Button>
                </div>
              </div>
              {currentRevision.change_summary && (
                <p className="text-xs text-slate-600 dark:text-slate-400">{currentRevision.change_summary}</p>
              )}
              <div className="flex gap-4 mt-2 text-xs text-slate-500">
                <span>{format(new Date(currentRevision.created_date), 'MMM d, yyyy')}</span>
                {currentRevision.approved_by && (
                  <span>Approved by {currentRevision.approved_by}</span>
                )}
              </div>
              {currentRevision.status === 'draft' && (
                <Button
                  size="sm"
                  onClick={() => handleRequestReview(currentRevision.id)}
                  className="mt-2 w-full"
                  variant="outline"
                >
                  Request Review
                </Button>
              )}
              {currentRevision.status === 'pending_review' && (
                <Button
                  size="sm"
                  onClick={() => handleApprove(currentRevision.id)}
                  className="mt-2 w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Approve
                </Button>
              )}
            </div>
          ) : (
            <p className="text-xs text-slate-400 text-center py-4">No versions yet</p>
          )}

          <div className="text-xs text-slate-500">
            Total revisions: {revisions.length}
          </div>
        </CardContent>
      </Card>

      {/* New Version Dialog */}
      <Dialog open={showNewVersion} onOpenChange={setShowNewVersion}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Upload New Version</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label className="text-xs">New Version: v{nextVersion}</Label>
              <Select
                value={newVersion.revision_type}
                onValueChange={(v) => setNewVersion({ ...newVersion, revision_type: v })}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="major">Major (Breaking changes)</SelectItem>
                  <SelectItem value="minor">Minor (New features)</SelectItem>
                  <SelectItem value="patch">Patch (Bug fixes)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs">Change Summary</Label>
              <Textarea
                className="mt-1"
                value={newVersion.change_summary}
                onChange={(e) => setNewVersion({ ...newVersion, change_summary: e.target.value })}
                placeholder="Describe what changed in this version..."
                rows={3}
              />
            </div>

            <div>
              <Label className="text-xs">File</Label>
              {newVersion.file ? (
                <div className="mt-1 p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs text-emerald-700 dark:text-emerald-400 flex-1 truncate">
                    {newVersion.file.name}
                  </span>
                </div>
              ) : (
                <label className="mt-1 flex items-center gap-2 px-4 py-3 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer hover:border-indigo-300 hover:bg-indigo-50/30 transition-colors">
                  <Upload className="w-4 h-4 text-slate-400" />
                  <span className="text-xs text-slate-500">
                    {uploading ? "Uploading..." : "Upload file"}
                  </span>
                  <input type="file" className="hidden" onChange={handleFileSelect} disabled={uploading} />
                </label>
              )}
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowNewVersion(false)} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={handleCreateRevision}
                disabled={!newVersion.file || createRevisionMutation.isPending}
                className="flex-1 bg-indigo-600 hover:bg-indigo-700"
              >
                Create Version
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={showHistory} onOpenChange={setShowHistory}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Version History</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-4">
            {revisions.map((revision) => {
              const statusConfig = STATUS_CONFIG[revision.status];
              const StatusIcon = statusConfig.icon;
              return (
                <div
                  key={revision.id}
                  className="border dark:border-slate-700 rounded-lg p-4 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="font-mono">v{revision.version}</Badge>
                      <Badge className={statusConfig.color}>
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {statusConfig.label}
                      </Badge>
                      {revision.is_current && (
                        <Badge className="bg-indigo-100 text-indigo-800">Current</Badge>
                      )}
                    </div>
                    <Button size="sm" variant="ghost" asChild>
                      <a href={revision.file_url} target="_blank" rel="noopener noreferrer">
                        <Download className="w-3 h-3" />
                      </a>
                    </Button>
                  </div>
                  {revision.change_summary && (
                    <p className="text-xs text-slate-600 dark:text-slate-400">{revision.change_summary}</p>
                  )}
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500">
                    <span>{format(new Date(revision.created_date), 'MMM d, yyyy h:mm a')}</span>
                    <span>•</span>
                    <span>{revision.revision_type} revision</span>
                    {revision.approved_by && (
                      <>
                        <span>•</span>
                        <span>Approved by {revision.approved_by}</span>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}