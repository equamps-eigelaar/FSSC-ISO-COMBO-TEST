import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Download, ExternalLink, FileText, File, ZoomIn, ZoomOut,
  RotateCw, Sparkles, Send, Loader2, MessageSquare, X, ChevronDown, ChevronUp
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

function getFileType(doc) {
  const mime = doc.file_type || "";
  const name = doc.file_name?.toLowerCase() || "";
  if (mime === "application/pdf" || name.endsWith(".pdf")) return "pdf";
  if (mime.startsWith("image/") || /\.(png|jpg|jpeg|gif|webp|svg|bmp)$/.test(name)) return "image";
  if (mime.includes("wordprocessingml") || mime === "application/msword" || /\.(docx?|odt)$/.test(name)) return "word";
  if (mime.includes("spreadsheetml") || mime === "application/vnd.ms-excel" || /\.(xlsx?|ods|csv)$/.test(name)) return "spreadsheet";
  return "other";
}

const QUICK_QUESTIONS = [
  "Summarize this document",
  "What regulations are referenced?",
  "What actions are required from me?",
  "When does this expire?",
];

function AIAssistantPanel({ doc }) {
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState([]);

  const ask = async (q) => {
    const text = q || question.trim();
    if (!text) return;
    setMessages(prev => [...prev, { role: "user", text }]);
    setQuestion("");
    setLoading(true);
    try {
      const res = await base44.functions.invoke("askDocumentQuestion", {
        document_id: doc.id,
        question: text,
      });
      setMessages(prev => [...prev, { role: "ai", text: res.data.answer }]);
    } catch (e) {
      toast.error("AI assistant failed");
      setMessages(prev => [...prev, { role: "ai", text: "Sorry, I couldn't answer that. Please try again." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="border border-slate-200 rounded-lg overflow-hidden">
      <div className="bg-gradient-to-r from-purple-50 to-indigo-50 px-4 py-3 flex items-center gap-2 border-b border-slate-200">
        <Sparkles className="w-4 h-4 text-purple-600" />
        <span className="text-sm font-semibold text-slate-800">AI Document Assistant</span>
      </div>

      {/* Quick question chips */}
      <div className="px-4 py-2 flex flex-wrap gap-1.5 border-b border-slate-100 bg-slate-50">
        {QUICK_QUESTIONS.map(q => (
          <button
            key={q}
            onClick={() => ask(q)}
            disabled={loading}
            className="text-xs px-2.5 py-1 rounded-full bg-white border border-slate-200 text-slate-600 hover:border-purple-400 hover:text-purple-700 hover:bg-purple-50 transition-colors disabled:opacity-50"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Messages */}
      {messages.length > 0 && (
        <div className="max-h-48 overflow-y-auto px-4 py-3 space-y-3 bg-white">
          {messages.map((m, i) => (
            <div key={i} className={`flex gap-2 ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              {m.role === "ai" && (
                <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center shrink-0 mt-0.5">
                  <Sparkles className="w-3 h-3 text-purple-600" />
                </div>
              )}
              <div className={`text-xs rounded-lg px-3 py-2 max-w-[85%] leading-relaxed whitespace-pre-wrap ${
                m.role === "user"
                  ? "bg-slate-800 text-white"
                  : "bg-slate-100 text-slate-800"
              }`}>
                {m.text}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex gap-2 justify-start">
              <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center shrink-0">
                <Loader2 className="w-3 h-3 text-purple-600 animate-spin" />
              </div>
              <div className="text-xs bg-slate-100 text-slate-500 rounded-lg px-3 py-2 italic">Thinking…</div>
            </div>
          )}
        </div>
      )}

      {/* Input */}
      <div className="flex gap-2 p-3 bg-white border-t border-slate-100">
        <Textarea
          placeholder="Ask a question about this document…"
          value={question}
          onChange={e => setQuestion(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(); } }}
          rows={2}
          className="text-xs resize-none flex-1"
          disabled={loading}
        />
        <Button size="sm" onClick={() => ask()} disabled={loading || !question.trim()} className="self-end bg-purple-600 hover:bg-purple-700">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </Button>
      </div>
    </div>
  );
}

export default function DocumentViewer({ doc, open, onClose }) {
  const [zoom, setZoom] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [showAI, setShowAI] = useState(false);

  if (!doc) return null;
  const fileType = getFileType(doc);

  const renderPreview = () => {
    if (fileType === "pdf") {
      return (
        <iframe
          src={`${doc.file_url}#toolbar=1`}
          className="w-full rounded border border-slate-200"
          style={{ height: "55vh" }}
          title={doc.file_name}
        />
      );
    }

    if (fileType === "image") {
      return (
        <div className="flex items-center justify-center bg-slate-100 rounded min-h-48 overflow-auto" style={{ maxHeight: "55vh" }}>
          <img
            src={doc.file_url}
            alt={doc.file_name}
            style={{
              maxWidth: `${zoom}%`,
              transform: `rotate(${rotation}deg)`,
              transition: "transform 0.2s, max-width 0.2s",
              borderRadius: 8,
            }}
          />
        </div>
      );
    }

    if (fileType === "word" || fileType === "spreadsheet") {
      return (
        <iframe
          src={`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(doc.file_url)}`}
          className="w-full rounded border border-slate-200"
          style={{ height: "55vh" }}
          title={doc.file_name}
        />
      );
    }

    return (
      <div className="flex flex-col items-center justify-center py-12 text-slate-500 gap-4">
        <File className="w-16 h-16 text-slate-300" />
        <p className="text-sm">Preview not available for this file type.</p>
        <Button asChild>
          <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
            <ExternalLink className="w-4 h-4 mr-2" />
            Open in new tab
          </a>
        </Button>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-sm truncate pr-8">
            <FileText className="w-4 h-4 text-slate-500 shrink-0" />
            {doc.file_name}
          </DialogTitle>
        </DialogHeader>

        {/* Tags from AI */}
        {doc.tags?.length > 0 && (
          <div className="flex flex-wrap gap-1.5 -mt-1">
            {doc.tags.map(tag => (
              <span key={tag} className="text-xs px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-100">{tag}</span>
            ))}
          </div>
        )}

        {/* Image toolbar */}
        {fileType === "image" && (
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Button variant="outline" size="sm" onClick={() => setZoom(z => Math.max(25, z - 25))}><ZoomOut className="w-4 h-4" /></Button>
            <span className="text-xs text-slate-600 w-14 text-center">{zoom}%</span>
            <Button variant="outline" size="sm" onClick={() => setZoom(z => Math.min(200, z + 25))}><ZoomIn className="w-4 h-4" /></Button>
            <Button variant="outline" size="sm" onClick={() => setRotation(r => (r + 90) % 360)}><RotateCw className="w-4 h-4" /></Button>
            <Button variant="outline" size="sm" onClick={() => { setZoom(100); setRotation(0); }}>Reset</Button>
          </div>
        )}

        {/* Preview */}
        <div>{renderPreview()}</div>

        {/* AI Assistant toggle */}
        <button
          onClick={() => setShowAI(v => !v)}
          className="flex items-center gap-2 text-xs font-medium text-purple-700 hover:text-purple-900 transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5" />
          AI Assistant
          {showAI ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>

        {showAI && <AIAssistantPanel doc={doc} />}

        {/* Footer */}
        <div className="flex justify-between items-center pt-3 border-t border-slate-100">
          <span className="text-xs text-slate-400">
            {doc.file_size ? `${(doc.file_size / 1024).toFixed(1)} KB` : ""}
            {doc.document_type ? ` · ${doc.document_type.replace(/_/g, " ")}` : ""}
            {doc.current_version ? ` · v${doc.current_version}` : ""}
            {doc.ai_analysis?.analyzed ? " · ✨ AI analysed" : ""}
          </span>
          <Button size="sm" asChild>
            <a href={doc.file_url} target="_blank" rel="noopener noreferrer" download>
              <Download className="w-4 h-4 mr-2" />
              Download
            </a>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}