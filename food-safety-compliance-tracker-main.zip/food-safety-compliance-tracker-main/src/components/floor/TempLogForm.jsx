import React, { useState } from 'react';
import { ChevronRight, ChevronLeft, Plus, Trash2, CheckCircle2, AlertTriangle } from 'lucide-react';

const PRESET_LOCATIONS = [
  { label: 'Cold Room A', param: 'Cold Room A Temperature', unit: '°C', range: '≤4°C' },
  { label: 'Cold Room B', param: 'Cold Room B Temperature', unit: '°C', range: '≤4°C' },
  { label: 'Freezer 1', param: 'Freezer Temperature', unit: '°C', range: '≤-18°C' },
  { label: 'Chiller Display', param: 'Chiller Display Temperature', unit: '°C', range: '≤5°C' },
  { label: 'Hot Holding', param: 'Hot Holding Temperature', unit: '°C', range: '≥63°C' },
  { label: 'Cook Internal', param: 'Cooking Internal Temp', unit: '°C', range: '≥75°C' },
];

const SHIFTS = [
  { v: 'morning', label: 'Morning', emoji: '🌅' },
  { v: 'afternoon', label: 'Afternoon', emoji: '☀️' },
  { v: 'night', label: 'Night', emoji: '🌙' },
];

const today = () => new Date().toISOString().split('T')[0];
const nowTime = () => new Date().toTimeString().slice(0, 5);
const newReading = () => ({ id: Date.now() + Math.random(), parameter: '', value: '', unit: '°C', acceptable_range: '', status: 'acceptable' });

export default function TempLogForm({ onSubmit, userName }) {
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [customLocation, setCustomLocation] = useState(false);
  const [form, setForm] = useState({
    location: '', shift: '', log_date: today(), reading_time: nowTime(),
    notes: '', corrective_action: '',
  });
  const [readings, setReadings] = useState([newReading()]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const updateReading = (id, k, v) => setReadings(r => r.map(x => x.id === id ? { ...x, [k]: v } : x));
  const removeReading = (id) => setReadings(r => r.filter(x => x.id !== id));

  const hasOutOfSpec = readings.some(r => r.status === 'out_of_spec');
  const step1Valid = form.location && form.shift;
  const step2Valid = readings.some(r => r.value !== '');

  const selectPreset = (loc) => {
    set('location', loc.label);
    setCustomLocation(false);
    setReadings([{ ...newReading(), parameter: loc.param, unit: loc.unit, acceptable_range: loc.range }]);
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    const ok = await onSubmit('temp', {
      log_type: 'temperature',
      log_date: form.log_date,
      shift: form.shift,
      location: form.location,
      status: hasOutOfSpec ? 'requires_review' : 'completed',
      corrective_action: hasOutOfSpec && form.corrective_action ? form.corrective_action : undefined,
      notes: form.notes || undefined,
      readings: readings
        .filter(r => r.value !== '')
        .map(r => ({
          parameter: r.parameter || form.location,
          value: r.value,
          unit: r.unit,
          acceptable_range: r.acceptable_range || '',
          status: r.status,
          timestamp: `${form.log_date}T${form.reading_time}`,
        })),
    });
    setSubmitting(false);
    if (ok) {
      setForm({ location: '', shift: '', log_date: today(), reading_time: nowTime(), notes: '', corrective_action: '' });
      setReadings([newReading()]);
      setStep(1);
      setCustomLocation(false);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Progress */}
      <div className="flex items-center gap-2">
        {[1, 2].map(s => (
          <div key={s} className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${step >= s ? 'bg-blue-500' : 'bg-slate-700'}`} />
        ))}
      </div>

      {step === 1 && (
        <>
          {/* Location */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">📍 Location / Equipment</label>
            <div className="grid grid-cols-2 gap-2 mb-2">
              {PRESET_LOCATIONS.map(loc => (
                <button key={loc.label} onClick={() => selectPreset(loc)}
                  className={`px-4 py-4 rounded-xl text-left text-sm font-medium transition-all border-2 min-h-[56px] ${
                    form.location === loc.label && !customLocation
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                  }`}>
                  🌡️ {loc.label}
                </button>
              ))}
              <button onClick={() => { setCustomLocation(true); set('location', ''); setReadings([newReading()]); }}
                className={`px-4 py-4 rounded-xl text-sm font-medium border-2 border-dashed min-h-[56px] transition-all ${
                  customLocation ? 'border-blue-500 text-blue-400' : 'border-slate-600 text-slate-500 hover:border-blue-600'
                }`}>
                + Other Location
              </button>
            </div>
            {customLocation && (
              <input autoFocus value={form.location} onChange={e => set('location', e.target.value)} placeholder="Enter location name..."
                className="w-full bg-slate-800 border-2 border-slate-700 focus:border-blue-500 text-white rounded-xl px-4 py-4 text-base outline-none" />
            )}
          </div>

          {/* Shift */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">🕐 Shift</label>
            <div className="grid grid-cols-3 gap-3">
              {SHIFTS.map(s => (
                <button key={s.v} onClick={() => set('shift', s.v)}
                  className={`py-5 rounded-xl text-center font-semibold text-sm transition-all border-2 min-h-[80px] ${
                    form.shift === s.v ? 'bg-blue-600 border-blue-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                  }`}>
                  <div className="text-2xl mb-1">{s.emoji}</div>
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">📅 Date</label>
              <input type="date" value={form.log_date} onChange={e => set('log_date', e.target.value)}
                className="w-full bg-slate-800 border-2 border-slate-700 focus:border-blue-500 text-white rounded-xl px-4 py-4 text-base outline-none" />
            </div>
            <div>
              <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">⏱ Time</label>
              <input type="time" value={form.reading_time} onChange={e => set('reading_time', e.target.value)}
                className="w-full bg-slate-800 border-2 border-slate-700 focus:border-blue-500 text-white rounded-xl px-4 py-4 text-base outline-none" />
            </div>
          </div>

          <button disabled={!step1Valid} onClick={() => setStep(2)}
            className="w-full py-5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold text-lg flex items-center justify-center gap-2 transition-all min-h-[64px]">
            Next <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {step === 2 && (
        <>
          {/* Summary */}
          <div className="bg-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center gap-2 text-sm">
            <span className="text-blue-400 font-semibold">{form.location}</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-300 capitalize">{form.shift} shift</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-400">{form.reading_time}</span>
          </div>

          {/* Out of spec warning */}
          {hasOutOfSpec && (
            <div className="bg-red-900/40 border border-red-700 rounded-xl px-4 py-3 flex items-center gap-3 text-red-300">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <span className="text-sm font-medium">Out-of-spec reading – corrective action required</span>
            </div>
          )}

          {/* Readings */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">🌡️ Temperature Readings</label>
            <div className="flex flex-col gap-3">
              {readings.map((r, idx) => (
                <div key={r.id} className={`bg-slate-800 rounded-xl p-4 border-2 transition-colors ${r.status === 'out_of_spec' ? 'border-red-700' : 'border-slate-700'}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <input value={r.parameter} onChange={e => updateReading(r.id, 'parameter', e.target.value)}
                      placeholder={`Reading ${idx + 1} – parameter`}
                      className="flex-1 bg-slate-700 text-white rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500" />
                    {readings.length > 1 && (
                      <button onClick={() => removeReading(r.id)} className="p-2 text-slate-600 hover:text-red-400 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <input type="number" step="0.1" value={r.value} onChange={e => updateReading(r.id, 'value', e.target.value)}
                        placeholder="0.0"
                        className="w-28 bg-slate-700 text-white text-2xl font-bold text-center rounded-xl px-3 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
                      <span className="text-slate-400 text-base font-medium">{r.unit}</span>
                    </div>
                    <div className="flex gap-2 ml-auto">
                      <button onClick={() => updateReading(r.id, 'status', 'acceptable')}
                        className={`px-3 py-3 rounded-xl text-xs font-bold transition-all border-2 flex items-center gap-1 min-h-[48px] ${
                          r.status === 'acceptable' ? 'bg-emerald-600 border-emerald-500 text-white' : 'bg-slate-700 border-slate-600 text-slate-400 hover:border-emerald-600'
                        }`}>
                        <CheckCircle2 className="w-4 h-4" /> OK
                      </button>
                      <button onClick={() => updateReading(r.id, 'status', 'out_of_spec')}
                        className={`px-3 py-3 rounded-xl text-xs font-bold transition-all border-2 flex items-center gap-1 min-h-[48px] ${
                          r.status === 'out_of_spec' ? 'bg-red-600 border-red-500 text-white' : 'bg-slate-700 border-slate-600 text-slate-400 hover:border-red-600'
                        }`}>
                        <AlertTriangle className="w-4 h-4" /> OUT
                      </button>
                    </div>
                  </div>
                  {r.acceptable_range && (
                    <p className="text-slate-500 text-xs mt-2">Target: {r.acceptable_range}</p>
                  )}
                </div>
              ))}

              <button onClick={() => setReadings(r => [...r, newReading()])}
                className="w-full py-4 rounded-xl border-2 border-dashed border-slate-700 text-slate-500 hover:border-blue-600 hover:text-blue-400 flex items-center justify-center gap-2 text-sm font-medium transition-all min-h-[56px]">
                <Plus className="w-4 h-4" /> Add Another Reading
              </button>
            </div>
          </div>

          {/* Corrective action (required if out of spec) */}
          {hasOutOfSpec && (
            <div>
              <label className="block text-red-400 text-xs font-bold uppercase tracking-widest mb-3">⚠️ Corrective Action Taken</label>
              <textarea value={form.corrective_action} onChange={e => set('corrective_action', e.target.value)}
                placeholder="Describe the corrective action taken..." rows={2}
                className="w-full bg-slate-800 border-2 border-red-700 focus:border-red-500 text-white rounded-xl px-4 py-3 text-base outline-none resize-none" />
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">📝 Notes <span className="text-slate-600 normal-case font-normal text-xs">(optional)</span></label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={2}
              className="w-full bg-slate-800 border-2 border-slate-700 focus:border-blue-500 text-white rounded-xl px-4 py-3 text-base outline-none resize-none" />
          </div>

          <div className="flex gap-3">
            <button onClick={() => setStep(1)}
              className="flex-none px-5 py-5 rounded-xl bg-slate-800 border-2 border-slate-700 text-slate-300 hover:text-white flex items-center gap-2 font-medium min-h-[64px]">
              <ChevronLeft className="w-5 h-5" /> Back
            </button>
            <button disabled={!step2Valid || submitting} onClick={handleSubmit}
              className="flex-1 py-5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold text-lg flex items-center justify-center gap-2 transition-all min-h-[64px]">
              {submitting ? 'Saving...' : '✓ Submit Log'}
            </button>
          </div>
        </>
      )}
    </div>
  );
}