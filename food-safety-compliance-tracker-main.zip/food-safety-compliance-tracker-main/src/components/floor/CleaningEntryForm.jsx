import React, { useState } from 'react';
import { ChevronRight, ChevronLeft, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';

const COMMON_AREAS = [
  'Filling Line A', 'Filling Line B', 'Packing Area', 'Cold Room',
  'Raw Material Store', 'Processing Floor', 'Dispatch Area', 'Locker Rooms',
  'Canteen', 'Washrooms', 'Equipment Room', 'Extrusion Line',
];

const METHODS = [
  { value: 'dry_clean', label: 'Dry Clean' },
  { value: 'wet_clean', label: 'Wet Clean' },
  { value: 'chemical_clean', label: 'Chemical' },
  { value: 'sanitize_only', label: 'Sanitize Only' },
  { value: 'full_clean_sanitize', label: 'Full C+S' },
];

const SHIFTS = [
  { v: 'morning', label: 'Morning', emoji: '🌅' },
  { v: 'afternoon', label: 'Afternoon', emoji: '☀️' },
  { v: 'night', label: 'Night', emoji: '🌙' },
];

const today = () => new Date().toISOString().split('T')[0];

export default function CleaningEntryForm({ onSubmit, userName }) {
  const [step, setStep] = useState(1);
  const [customArea, setCustomArea] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    area: '', shift: '', cleaning_date: today(),
    cleaning_method: '', result: '', cleaned_by: userName || '', notes: '',
  });

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const step1Valid = form.area && form.shift;
  const step2Valid = form.result && form.cleaned_by;

  const handleSubmit = async () => {
    setSubmitting(true);
    const ok = await onSubmit('cleaning', {
      area: form.area,
      shift: form.shift,
      cleaning_date: form.cleaning_date,
      cleaning_method: form.cleaning_method || undefined,
      result: form.result,
      cleaned_by: form.cleaned_by,
      notes: form.notes || undefined,
    });
    setSubmitting(false);
    if (ok) {
      setForm({ area: '', shift: '', cleaning_date: today(), cleaning_method: '', result: '', cleaned_by: userName || '', notes: '' });
      setStep(1);
      setCustomArea(false);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Progress bar */}
      <div className="flex items-center gap-2">
        {[1, 2].map(s => (
          <div key={s} className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${step >= s ? 'bg-emerald-500' : 'bg-slate-700'}`} />
        ))}
      </div>

      {step === 1 && (
        <>
          {/* Area */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">📍 Area / Location</label>
            {!customArea ? (
              <div className="grid grid-cols-2 gap-2">
                {COMMON_AREAS.map(a => (
                  <button
                    key={a}
                    onClick={() => set('area', a)}
                    className={`px-4 py-4 rounded-xl text-left text-sm font-medium transition-all border-2 min-h-[56px] ${
                      form.area === a
                        ? 'bg-emerald-600 border-emerald-500 text-white'
                        : 'bg-slate-800 border-slate-700 text-slate-300 active:bg-slate-700 hover:border-slate-600'
                    }`}
                  >
                    {a}
                  </button>
                ))}
                <button
                  onClick={() => { setCustomArea(true); set('area', ''); }}
                  className="px-4 py-4 rounded-xl text-sm font-medium border-2 border-dashed border-slate-600 text-slate-500 hover:border-emerald-600 hover:text-emerald-400 min-h-[56px] transition-all"
                >
                  + Custom Area
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <input
                  autoFocus
                  value={form.area}
                  onChange={e => set('area', e.target.value)}
                  placeholder="Type area name..."
                  className="flex-1 bg-slate-800 border-2 border-slate-700 focus:border-emerald-500 text-white rounded-xl px-4 py-4 text-base outline-none"
                />
                <button onClick={() => { setCustomArea(false); set('area', ''); }}
                  className="px-4 rounded-xl bg-slate-700 text-slate-400 hover:text-white min-h-[56px]">✕</button>
              </div>
            )}
          </div>

          {/* Shift */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">🕐 Shift</label>
            <div className="grid grid-cols-3 gap-3">
              {SHIFTS.map(s => (
                <button
                  key={s.v}
                  onClick={() => set('shift', s.v)}
                  className={`py-5 rounded-xl text-center font-semibold text-sm transition-all border-2 min-h-[80px] ${
                    form.shift === s.v
                      ? 'bg-emerald-600 border-emerald-500 text-white'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <div className="text-2xl mb-1">{s.emoji}</div>
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Date */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">📅 Date</label>
            <input type="date" value={form.cleaning_date} onChange={e => set('cleaning_date', e.target.value)}
              className="w-full bg-slate-800 border-2 border-slate-700 focus:border-emerald-500 text-white rounded-xl px-4 py-4 text-base outline-none" />
          </div>

          <button disabled={!step1Valid} onClick={() => setStep(2)}
            className="w-full py-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold text-lg flex items-center justify-center gap-2 transition-all min-h-[64px]">
            Next <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {step === 2 && (
        <>
          {/* Summary chip */}
          <div className="bg-slate-800 rounded-xl px-4 py-3 flex flex-wrap items-center gap-2 text-sm">
            <span className="text-emerald-400 font-semibold">{form.area}</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-300 capitalize">{form.shift} shift</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-400">{new Date(form.cleaning_date + 'T00:00:00').toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' })}</span>
          </div>

          {/* Method */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">🧹 Cleaning Method</label>
            <div className="flex flex-wrap gap-2">
              {METHODS.map(m => (
                <button key={m.value} onClick={() => set('cleaning_method', m.value)}
                  className={`px-4 py-3 rounded-xl text-sm font-medium transition-all border-2 min-h-[48px] ${
                    form.cleaning_method === m.value
                      ? 'bg-emerald-600 border-emerald-500 text-white'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600'
                  }`}>
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Result – big buttons */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">✅ Result</label>
            <div className="grid grid-cols-3 gap-3">
              <button onClick={() => set('result', 'pass')}
                className={`py-6 rounded-xl font-bold text-base transition-all border-2 flex flex-col items-center gap-2 min-h-[88px] ${
                  form.result === 'pass' ? 'bg-emerald-600 border-emerald-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-emerald-600'
                }`}>
                <CheckCircle2 className="w-7 h-7" />
                PASS
              </button>
              <button onClick={() => set('result', 'fail')}
                className={`py-6 rounded-xl font-bold text-base transition-all border-2 flex flex-col items-center gap-2 min-h-[88px] ${
                  form.result === 'fail' ? 'bg-red-600 border-red-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-red-600'
                }`}>
                <XCircle className="w-7 h-7" />
                FAIL
              </button>
              <button onClick={() => set('result', 'conditional_pass')}
                className={`py-6 rounded-xl font-bold text-xs transition-all border-2 flex flex-col items-center gap-2 min-h-[88px] ${
                  form.result === 'conditional_pass' ? 'bg-amber-500 border-amber-400 text-white' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-amber-500'
                }`}>
                <AlertCircle className="w-7 h-7" />
                CONDITIONAL
              </button>
            </div>
          </div>

          {/* Cleaned By */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">👤 Cleaned By</label>
            <input value={form.cleaned_by} onChange={e => set('cleaned_by', e.target.value)} placeholder="Your name"
              className="w-full bg-slate-800 border-2 border-slate-700 focus:border-emerald-500 text-white rounded-xl px-4 py-4 text-base outline-none" />
          </div>

          {/* Notes */}
          <div>
            <label className="block text-slate-400 text-xs font-bold uppercase tracking-widest mb-3">📝 Notes <span className="text-slate-600 normal-case font-normal text-xs">(optional)</span></label>
            <textarea value={form.notes} onChange={e => set('notes', e.target.value)} placeholder="Any observations or issues..." rows={2}
              className="w-full bg-slate-800 border-2 border-slate-700 focus:border-emerald-500 text-white rounded-xl px-4 py-3 text-base outline-none resize-none" />
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <button onClick={() => setStep(1)}
              className="flex-none px-5 py-5 rounded-xl bg-slate-800 border-2 border-slate-700 text-slate-300 hover:text-white flex items-center gap-2 font-medium min-h-[64px]">
              <ChevronLeft className="w-5 h-5" /> Back
            </button>
            <button disabled={!step2Valid || submitting} onClick={handleSubmit}
              className="flex-1 py-5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold text-lg flex items-center justify-center gap-2 transition-all min-h-[64px]">
              {submitting ? 'Saving...' : '✓ Submit Entry'}
            </button>
          </div>
        </>
      )}
    </div>
  );
}