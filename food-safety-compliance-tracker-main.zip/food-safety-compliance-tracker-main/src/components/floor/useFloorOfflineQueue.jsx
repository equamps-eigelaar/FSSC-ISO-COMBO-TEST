import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const QUEUE_KEY = 'floor_offline_queue';
const HISTORY_KEY = 'floor_entry_history';

const getQueue = () => {
  try { return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]'); }
  catch { return []; }
};

const saveQueue = (q) => localStorage.setItem(QUEUE_KEY, JSON.stringify(q));

const addToHistory = (type, data, status) => {
  try {
    const hist = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    hist.unshift({ id: Date.now() + Math.random(), type, data, status, timestamp: new Date().toISOString() });
    localStorage.setItem(HISTORY_KEY, JSON.stringify(hist.slice(0, 50)));
  } catch {}
};

export function useFloorOfflineQueue() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);

  const refreshCount = useCallback(() => {
    setPendingCount(getQueue().filter(e => !e.synced).length);
  }, []);

  const syncAll = useCallback(async () => {
    if (!navigator.onLine) return;
    const pending = getQueue().filter(e => !e.synced);
    if (!pending.length) return;
    setIsSyncing(true);
    let synced = 0;
    for (const entry of pending) {
      try {
        const entity = entry.type === 'cleaning' ? 'CleaningRegister' : 'MonitoringLog';
        await base44.entities[entity].create(entry.data);
        const q = getQueue();
        const i = q.findIndex(e => e.id === entry.id);
        if (i !== -1) { q[i].synced = true; saveQueue(q); }
        synced++;
      } catch (err) {
        console.error('Sync failed for entry:', err);
      }
    }
    setIsSyncing(false);
    refreshCount();
    if (synced > 0) toast.success(`Synced ${synced} offline ${synced === 1 ? 'entry' : 'entries'}`);
  }, [refreshCount]);

  useEffect(() => {
    refreshCount();
    const onOnline = () => { setIsOnline(true); syncAll(); };
    const onOffline = () => {
      setIsOnline(false);
      toast.info('Working offline – entries will sync automatically when reconnected');
    };
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, [syncAll, refreshCount]);

  const submitEntry = async (type, data) => {
    if (isOnline) {
      try {
        const entity = type === 'cleaning' ? 'CleaningRegister' : 'MonitoringLog';
        await base44.entities[entity].create(data);
        addToHistory(type, data, 'synced');
        toast.success('Entry saved successfully!');
        return true;
      } catch (err) {
        console.error('Online submit failed, queuing offline:', err);
      }
    }
    // Offline queue
    const q = getQueue();
    q.push({ id: Date.now() + Math.random(), type, data, timestamp: new Date().toISOString(), synced: false });
    saveQueue(q);
    addToHistory(type, data, 'pending');
    refreshCount();
    toast.info('Saved offline – will sync when connected');
    return true;
  };

  const getHistory = () => {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); }
    catch { return []; }
  };

  return { isOnline, pendingCount, isSyncing, syncAll, submitEntry, getHistory };
}