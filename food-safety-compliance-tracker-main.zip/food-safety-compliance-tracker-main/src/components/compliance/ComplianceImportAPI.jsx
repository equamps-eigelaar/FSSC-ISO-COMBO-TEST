import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertCircle, Zap, Loader2, Trash2, Edit2, Plus } from "lucide-react";
import { toast } from "sonner";

const API_PROVIDERS = {
  generic: "Generic JSON API",
  iso_registry: "ISO Registry API",
  fssc_database: "FSSC Database",
};

export default function ComplianceImportAPI() {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    provider: "generic",
    apiUrl: "",
    apiKey: "",
    framework: "iso22000",
    syncFrequency: "weekly",
    active: true,
  });
  const [deleteId, setDeleteId] = useState(null);
  const queryClient = useQueryClient();

  const { data: integrations = [], isLoading } = useQuery({
    queryKey: ["compliance-api-integrations"],
    queryFn: () =>
      base44.entities.ComplianceDataImport?.list?.("-created_date", 100) || [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ComplianceDataImport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-api-integrations"] });
      toast.success("API integration created successfully");
      resetForm();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateMutation = useMutation({
    mutationFn: (data) =>
      base44.entities.ComplianceDataImport.update(editingId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-api-integrations"] });
      toast.success("API integration updated successfully");
      resetForm();
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ComplianceDataImport.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-api-integrations"] });
      toast.success("API integration deleted");
      setDeleteId(null);
    },
    onError: (error) => toast.error(error.message),
  });

  const syncMutation = useMutation({
    mutationFn: (id) =>
      base44.functions.invoke("syncComplianceAPI", { integrationId: id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-api-integrations"] });
      toast.success("Sync completed successfully");
    },
    onError: (error) => toast.error("Sync failed: " + error.message),
  });

  const resetForm = () => {
    setFormData({
      name: "",
      provider: "generic",
      apiUrl: "",
      apiKey: "",
      framework: "iso22000",
      syncFrequency: "weekly",
      active: true,
    });
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      integration_type: "api",
      last_sync_date: editingId ? new Date().toISOString() : null,
    };

    if (editingId) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (integration) => {
    setFormData(integration);
    setEditingId(integration.id);
    setShowForm(true);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Info Banner */}
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 flex items-start gap-3">
        <Zap className="w-5 h-5 text-purple-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold text-purple-900">API Integration</p>
          <p className="text-sm text-purple-800 mt-1">
            Connect to external compliance databases for automated data synchronization
          </p>
        </div>
      </div>

      {/* Add Integration Button */}
      {!showForm && (
        <Button
          onClick={() => setShowForm(true)}
          className="bg-emerald-600 hover:bg-emerald-700 w-full sm:w-auto"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add API Integration
        </Button>
      )}

      {/* Form */}
      {showForm && (
        <Card className="border-emerald-200 bg-emerald-50">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="font-semibold">
                    Integration Name
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="e.g., ISO Registry Sync"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="provider" className="font-semibold">
                    API Provider
                  </Label>
                  <Select
                    value={formData.provider}
                    onValueChange={(value) =>
                      setFormData({ ...formData, provider: value })
                    }
                  >
                    <SelectTrigger id="provider">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(API_PROVIDERS).map(([key, label]) => (
                        <SelectItem key={key} value={key}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="apiUrl" className="font-semibold">
                  API Endpoint URL
                </Label>
                <Input
                  id="apiUrl"
                  type="url"
                  value={formData.apiUrl}
                  onChange={(e) =>
                    setFormData({ ...formData, apiUrl: e.target.value })
                  }
                  placeholder="https://api.example.com/compliance/requirements"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="apiKey" className="font-semibold">
                  API Key
                </Label>
                <Input
                  id="apiKey"
                  type="password"
                  value={formData.apiKey}
                  onChange={(e) =>
                    setFormData({ ...formData, apiKey: e.target.value })
                  }
                  placeholder="Enter your API key securely"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="framework" className="font-semibold">
                    Framework
                  </Label>
                  <Select
                    value={formData.framework}
                    onValueChange={(value) =>
                      setFormData({ ...formData, framework: value })
                    }
                  >
                    <SelectTrigger id="framework">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="iso22000">ISO 22000:2018</SelectItem>
                      <SelectItem value="ts22002_4">TS 22002-4:2019</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="syncFrequency" className="font-semibold">
                    Sync Frequency
                  </Label>
                  <Select
                    value={formData.syncFrequency}
                    onValueChange={(value) =>
                      setFormData({ ...formData, syncFrequency: value })
                    }
                  >
                    <SelectTrigger id="syncFrequency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="manual">Manual Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  {createMutation.isPending || updateMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    `${editingId ? "Update" : "Create"} Integration`
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={resetForm}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Integrations List */}
      {integrations.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-slate-900">Active Integrations</h3>
          {integrations.map((integration) => (
            <Card key={integration.id} className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-slate-900">
                      {integration.name}
                    </h4>
                    <div className="mt-2 space-y-1 text-sm text-slate-600">
                      <p>Provider: {API_PROVIDERS[integration.provider]}</p>
                      <p>Framework: {integration.framework.toUpperCase()}</p>
                      <p>Sync: {integration.syncFrequency}</p>
                      {integration.last_sync_date && (
                        <p className="text-xs text-slate-500">
                          Last synced:{" "}
                          {new Date(integration.last_sync_date).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => syncMutation.mutate(integration.id)}
                      disabled={syncMutation.isPending}
                      className="h-8"
                    >
                      {syncMutation.isPending ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Zap className="w-3.5 h-3.5" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(integration)}
                      className="h-8 px-2"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteId(integration.id)}
                      className="h-8 px-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {integrations.length === 0 && !showForm && (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Zap className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 font-medium">No API integrations yet</p>
            <p className="text-sm text-slate-500 mt-1">
              Create your first integration to sync compliance data automatically
            </p>
          </CardContent>
        </Card>
      )}

      {/* Delete Confirmation Dialog */}
      {deleteId && (
        <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
          <AlertDialogContent>
            <AlertDialogTitle>Delete API Integration</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this API integration? This action cannot
              be undone.
            </AlertDialogDescription>
            <div className="flex justify-end gap-2">
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteMutation.mutate(deleteId)}
                disabled={deleteMutation.isPending}
                className="bg-rose-600 hover:bg-rose-700"
              >
                {deleteMutation.isPending ? "Deleting..." : "Delete"}
              </AlertDialogAction>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}