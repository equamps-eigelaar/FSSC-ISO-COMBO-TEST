import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCircle2, XCircle, Clock, Send, AlertCircle, FileText } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export function ApprovalStatusBadge({ template }) {
  const status = template.approval_status || (template.is_published ? 'approved' : 'draft');
  const config = {
    draft:            { label: "Draft",            cls: "bg-slate-100 text-slate-600" },
    pending_approval: { label: "Pending Approval", cls: "bg-amber-100 text-amber-700" },
    approved:         { label: "Published",        cls: "bg-emerald-100 text-emerald-700" },
    rejected:         { label: "Rejected",         cls: "bg-red-100 text-red-700" },
  }[status] || { label: "Draft", cls: "bg-slate-100 text-slate-600" };

  return (
    <span className={`inline-flex items-center text-xs font-medium px-2 py-0.5 rounded-full ${config.cls}`}>
      {config.label}
    </span>
  );
}

export default function ApprovalPanel({ user, isAdmin }) {
  const queryClient = useQueryClient();
  const [rejectingTemplate, setRejectingTemplate] = useState(null);
  const [rejectionReason, setRejectionReason] = useState("");

  const { data: pendingTemplates = [] } = useQuery({
    queryKey: ['templates-pending'],
    queryFn: () => base44.entities.DocumentTemplate.filter({ approval_status: 'pending_approval' }, '-submitted_for_approval_date', 100)
  });

  const { data: mySubmissions = [] } = useQuery({
    queryKey: ['templates-my-submissions', user?.email],
    queryFn: () => base44.entities.DocumentTemplate.filter({ submitted_for_approval_by: user.email }, '-updated_date', 50),
    enabled: !!user?.email
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.DocumentTemplate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['document-templates'] });
      queryClient.invalidateQueries({ queryKey: ['templates-pending'] });
      queryClient.invalidateQueries({ queryKey: ['templates-my-submissions'] });
    }
  });

  const handleApprove = async (template) => {
    await updateMutation.mutateAsync({
      id: template.id,
      data: {
        approval_status: 'approved',
        is_published: true,
        approved_by: user.email,
        approved_date: new Date().toISOString(),
        rejection_reason: null,
      }
    });
    await base44.functions.invoke('documentApprovalNotify', {
      action: 'approved',
      templateName: template.name,
      submitterEmail: template.submitted_for_approval_by,
    });
    toast.success(`"${template.name}" approved and published`);
  };

  const handleReject = async () => {
    await updateMutation.mutateAsync({
      id: rejectingTemplate.id,
      data: {
        approval_status: 'rejected',
        is_published: false,
        approved_by: user.email,
        approved_date: new Date().toISOString(),
        rejection_reason: rejectionReason,
      }
    });
    await base44.functions.invoke('documentApprovalNotify', {
      action: 'rejected',
      templateName: rejectingTemplate.name,
      submitterEmail: rejectingTemplate.submitted_for_approval_by,
      rejectionReason,
    });
    toast.success("Document returned for revision");
    setRejectingTemplate(null);
    setRejectionReason("");
  };

  const submittedItems = mySubmissions.filter(t => t.approval_status && t.approval_status !== 'draft');

  return (
    <div className="space-y-6">
      {/* Pending approvals — admin only */}
      {isAdmin && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="border-b border-slate-100 dark:border-slate-800 py-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-500" />
              Awaiting Approval
              {pendingTemplates.length > 0 && (
                <span className="bg-amber-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {pendingTemplates.length}
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            {pendingTemplates.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle2 className="w-8 h-8 text-emerald-300 mx-auto mb-2" />
                <p className="text-sm text-slate-500">No documents pending approval</p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingTemplates.map(t => (
                  <div key={t.id} className="flex items-start justify-between gap-3 p-3 bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-800 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">{t.name}</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Submitted by <span className="font-medium">{t.submitted_for_approval_by}</span>
                        {t.submitted_for_approval_date && (
                          <> · {format(new Date(t.submitted_for_approval_date), 'dd MMM yyyy')}</>
                        )}
                      </p>
                      {t.description && (
                        <p className="text-xs text-slate-400 mt-1 line-clamp-1">{t.description}</p>
                      )}
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <Button
                        size="sm" variant="outline"
                        className="text-red-600 border-red-200 hover:bg-red-50 dark:hover:bg-red-900/20"
                        onClick={() => { setRejectingTemplate(t); setRejectionReason(""); }}
                      >
                        <XCircle className="w-3.5 h-3.5 mr-1" /> Reject
                      </Button>
                      <Button
                        size="sm"
                        className="bg-emerald-600 hover:bg-emerald-700 text-white"
                        onClick={() => handleApprove(t)}
                        disabled={updateMutation.isPending}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Approve
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* My submissions */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="border-b border-slate-100 dark:border-slate-800 py-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Send className="w-4 h-4 text-slate-400" />
            My Submissions
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          {submittedItems.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-8 h-8 text-slate-200 mx-auto mb-2" />
              <p className="text-sm text-slate-500">No submissions yet</p>
              <p className="text-xs text-slate-400 mt-1">Submit a draft template for approval from the Templates tab</p>
            </div>
          ) : (
            <div className="space-y-3">
              {submittedItems.map(t => (
                <div key={t.id} className="p-3 border border-slate-200 dark:border-slate-800 rounded-lg">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-white">{t.name}</p>
                      {t.approved_date && (
                        <p className="text-xs text-slate-400 mt-0.5">
                          {t.approval_status === 'approved' ? 'Approved' : 'Reviewed'} by {t.approved_by} · {format(new Date(t.approved_date), 'dd MMM yyyy')}
                        </p>
                      )}
                    </div>
                    <ApprovalStatusBadge template={t} />
                  </div>
                  {t.rejection_reason && (
                    <div className="mt-2 flex items-start gap-1.5 text-xs text-red-600 bg-red-50 dark:bg-red-900/20 p-2 rounded">
                      <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                      <span>{t.rejection_reason}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Rejection dialog */}
      <Dialog open={!!rejectingTemplate} onOpenChange={() => setRejectingTemplate(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Return Document for Revision</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Returning: <strong className="text-slate-900 dark:text-white">{rejectingTemplate?.name}</strong>
            </p>
            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 block mb-1.5">
                Reason for rejection <span className="text-red-500">*</span>
              </label>
              <Textarea
                placeholder="Describe what needs to be changed or corrected..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={4}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setRejectingTemplate(null)}>Cancel</Button>
              <Button
                variant="destructive"
                onClick={handleReject}
                disabled={!rejectionReason.trim() || updateMutation.isPending}
              >
                Return for Revision
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}