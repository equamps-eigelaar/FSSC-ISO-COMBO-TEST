import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Save, Loader2, GripVertical } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const FIELD_TYPES = [
  { value: "text", label: "Short Text" },
  { value: "textarea", label: "Long Text / Paragraph" },
  { value: "date", label: "Date" },
  { value: "number", label: "Number" },
  { value: "select", label: "Dropdown" },
  { value: "checkbox", label: "Checkbox" },
];

export default function TemplateFieldEditor({ open, onClose, template, onUpdated }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [fields, setFields] = useState([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (template) {
      setName(template.name || "");
      setDescription(template.description || "");
      setFields(template.fields ? JSON.parse(JSON.stringify(template.fields)) : []);
    }
  }, [template]);

  const addField = () => {
    setFields(prev => [...prev, { name: "", type: "text", placeholder: "", required: false }]);
  };

  const updateField = (idx, key, value) => {
    setFields(prev => prev.map((f, i) => i === idx ? { ...f, [key]: value } : f));
  };

  const removeField = (idx) => {
    setFields(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSave = async () => {
    if (!name.trim()) { toast.error("Template name is required"); return; }
    setSaving(true);
    try {
      const user = await base44.auth.me();
      const changeNote = `Fields updated by ${user?.full_name || user?.email} on ${new Date().toLocaleDateString('en-ZA')}`;
      const updatedTemplate = await base44.entities.DocumentTemplate.update(template.id, {
        name,
        description,
        fields,
        guidance_notes: template.guidance_notes
          ? template.guidance_notes + "\n\n[Change log] " + changeNote
          : "[Change log] " + changeNote,
      });
      toast.success("Template updated successfully");
      onUpdated?.();
      onClose();
    } catch (err) {
      toast.error("Failed to save template");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Template Fields</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-2">
          {/* Basic info */}
          <div className="grid grid-cols-1 gap-3">
            <div>
              <Label>Template Name</Label>
              <Input value={name} onChange={e => setName(e.target.value)} />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} className="resize-none" />
            </div>
          </div>

          {/* Fields */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-sm font-semibold">Document Fields</Label>
              <Button size="sm" variant="outline" onClick={addField}>
                <Plus className="w-3.5 h-3.5 mr-1" /> Add Field
              </Button>
            </div>

            {fields.length === 0 && (
              <Card className="border-dashed border-slate-200">
                <CardContent className="py-6 text-center">
                  <p className="text-xs text-slate-400">No custom fields yet. Click "Add Field" to define the document's fillable fields.</p>
                </CardContent>
              </Card>
            )}

            <div className="space-y-2">
              {fields.map((field, idx) => (
                <Card key={idx} className="border border-slate-200 shadow-none">
                  <CardContent className="p-3">
                    <div className="flex items-start gap-2">
                      <GripVertical className="w-4 h-4 text-slate-300 mt-2 shrink-0" />
                      <div className="flex-1 grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-xs text-slate-500 mb-1 block">Field Name</label>
                          <Input
                            className="h-8 text-xs"
                            placeholder="e.g. Approved By"
                            value={field.name}
                            onChange={e => updateField(idx, "name", e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="text-xs text-slate-500 mb-1 block">Type</label>
                          <Select value={field.type || "text"} onValueChange={v => updateField(idx, "type", v)}>
                            <SelectTrigger className="h-8 text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {FIELD_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <label className="text-xs text-slate-500 mb-1 block">Placeholder / Hint</label>
                          <Input
                            className="h-8 text-xs"
                            placeholder="e.g. Enter approver name"
                            value={field.placeholder || ""}
                            onChange={e => updateField(idx, "placeholder", e.target.value)}
                          />
                        </div>
                        <div className="flex items-end gap-2">
                          <label className="flex items-center gap-2 cursor-pointer mb-1">
                            <input
                              type="checkbox"
                              className="rounded"
                              checked={!!field.required}
                              onChange={e => updateField(idx, "required", e.target.checked)}
                            />
                            <span className="text-xs text-slate-600">Required</span>
                          </label>
                          {field.required && <Badge className="text-xs bg-red-100 text-red-700 mb-1">Required</Badge>}
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-300 hover:text-red-500 shrink-0 mt-1"
                        onClick={() => removeField(idx)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="flex gap-2 pt-2 border-t border-slate-100">
            <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              {saving ? <><Loader2 className="w-4 h-4 mr-1 animate-spin" />Saving…</> : <><Save className="w-4 h-4 mr-1" />Save Changes</>}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}