import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Loader2, Sparkles, CheckCircle2, AlertTriangle, XCircle, ChevronDown, ChevronUp, FileText } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const DOC_TYPES = [
  { value: "prp", label: "PRP Program" },
  { value: "haccp_plan", label: "HACCP Plan" },
  { value: "policy", label: "Policy" },
  { value: "procedure", label: "Procedure" },
  { value: "work_instruction", label: "Work Instruction" },
  { value: "form", label: "Form" },
  { value: "specification", label: "Specification" },
];

const STATUS_CONFIG = {
  compliant:    { label: "Compliant",        color: "text-emerald-700", bg: "bg-emerald-50",  border: "border-emerald-300", icon: CheckCircle2, iconColor: "text-emerald-600" },
  minor_gaps:   { label: "Minor Gaps",       color: "text-amber-700",   bg: "bg-amber-50",    border: "border-amber-300",   icon: AlertTriangle, iconColor: "text-amber-500" },
  major_gaps:   { label: "Major Gaps",       color: "text-orange-700",  bg: "bg-orange-50",   border: "border-orange-300",  icon: AlertTriangle, iconColor: "text-orange-500" },
  non_compliant:{ label: "Non-Compliant",    color: "text-red-700",     bg: "bg-red-50",      border: "border-red-300",     icon: XCircle,       iconColor: "text-red-500" },
};

const SEV_BADGE = { minor: "bg-amber-100 text-amber-800", major: "bg-orange-100 text-orange-800", critical: "bg-red-100 text-red-800" };

export default function DocumentEvaluator() {
  const [file, setFile] = useState(null);
  const [docType, setDocType] = useState("");
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [showGaps, setShowGaps] = useState(true);
  const [showChanges, setShowChanges] = useState(true);

  const handleFile = (f) => {
    setFile(f);
    setResult(null);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };

  const handleEvaluate = async () => {
    if (!file) { toast.error("Please drop or select a document first"); return; }
    setUploading(true);
    setResult(null);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const res = await base44.functions.invoke("evaluateDocumentCompliance", {
        file_url,
        file_name: file.name,
        doc_type: docType,
      });
      setResult(res.data);
      toast.success("Evaluation complete!");
    } catch (err) {
      toast.error("Evaluation failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const statusCfg = result ? (STATUS_CONFIG[result.overall_status] || STATUS_CONFIG.minor_gaps) : null;
  const StatusIcon = statusCfg?.icon;

  return (
    <div className="space-y-4">
      <Card className="border-0 shadow-sm">
        <CardHeader className="py-4 px-5 border-b border-slate-100">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-500" />
            Document Compliance Evaluator
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">Drop an existing document to evaluate it against FSSC 22000 document control requirements and get AI recommendations.</p>
        </CardHeader>
        <CardContent className="p-5 space-y-4">
          {/* Drop zone */}
          <label
            className={`flex flex-col items-center justify-center gap-3 border-2 border-dashed rounded-xl p-8 cursor-pointer transition-colors
              ${dragging ? "border-purple-400 bg-purple-50" : "border-slate-200 hover:border-purple-300 hover:bg-purple-50/50"}`}
            onDragOver={e => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
          >
            {file ? (
              <>
                <FileText className="w-8 h-8 text-purple-500" />
                <span className="text-sm font-medium text-purple-700">{file.name}</span>
                <span className="text-xs text-slate-400">{(file.size / 1024).toFixed(1)} KB — click to change</span>
              </>
            ) : (
              <>
                <Upload className="w-8 h-8 text-slate-400" />
                <span className="text-sm text-slate-600 font-medium">Drop document here or click to browse</span>
                <span className="text-xs text-slate-400">PDF, DOCX, XLSX — PRP, Plan, Policy, Procedure, WI, Form</span>
              </>
            )}
            <input type="file" className="hidden" accept=".pdf,.docx,.doc,.xlsx,.xls" onChange={e => handleFile(e.target.files[0])} />
          </label>

          <div className="flex gap-3">
            <Select value={docType} onValueChange={setDocType}>
              <SelectTrigger className="flex-1 text-sm">
                <SelectValue placeholder="Document type (optional)" />
              </SelectTrigger>
              <SelectContent>
                {DOC_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button onClick={handleEvaluate} disabled={uploading || !file} className="bg-purple-600 hover:bg-purple-700 shrink-0">
              {uploading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Evaluating…</> : <><Sparkles className="w-4 h-4 mr-2" />Evaluate</>}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {result && statusCfg && (
        <div className="space-y-3">
          {/* Score banner */}
          <Card className={`border ${statusCfg.border} ${statusCfg.bg} shadow-sm`}>
            <CardContent className="p-4 flex items-center gap-4">
              <StatusIcon className={`w-8 h-8 ${statusCfg.iconColor} shrink-0`} />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-lg font-bold ${statusCfg.color}`}>{result.overall_score}% Compliance</span>
                  <Badge variant="outline" className={`text-xs ${statusCfg.color} border-current`}>{statusCfg.label}</Badge>
                  {result.doc_type_detected && <Badge variant="secondary" className="text-xs">{result.doc_type_detected}</Badge>}
                  {result.suggested_revision && <Badge className="text-xs bg-slate-700 text-white">{result.suggested_revision}</Badge>}
                </div>
                <p className="text-xs text-slate-700">{result.summary}</p>
              </div>
            </CardContent>
          </Card>

          {/* Missing fields */}
          {result.missing_fields?.length > 0 && (
            <Card className="border-0 shadow-sm border-l-4 border-l-red-400">
              <CardContent className="px-4 py-3">
                <p className="text-xs font-semibold text-red-700 mb-2">Missing Required Fields</p>
                <div className="flex flex-wrap gap-1.5">
                  {result.missing_fields.map((f, i) => (
                    <span key={i} className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full">{f}</span>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Strengths */}
          {result.strengths?.length > 0 && (
            <Card className="border-0 shadow-sm border-l-4 border-l-emerald-400">
              <CardContent className="px-4 py-3">
                <p className="text-xs font-semibold text-emerald-700 mb-2">✓ Strengths</p>
                <ul className="space-y-1">
                  {result.strengths.map((s, i) => <li key={i} className="text-xs text-slate-700 flex items-start gap-1.5"><span className="text-emerald-500 shrink-0">•</span>{s}</li>)}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Gaps */}
          {result.gaps?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-0">
                <button className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-50 transition-colors" onClick={() => setShowGaps(v => !v)}>
                  <span className="text-xs font-semibold text-slate-800">Compliance Gaps ({result.gaps.length})</span>
                  {showGaps ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </button>
                {showGaps && (
                  <div className="px-4 pb-3 border-t border-slate-100 space-y-2">
                    {result.gaps.map((g, i) => (
                      <div key={i} className="flex items-start gap-2 pt-2">
                        <Badge className={`text-xs shrink-0 mt-0.5 ${SEV_BADGE[g.severity] || SEV_BADGE.minor}`}>{g.severity}</Badge>
                        <div>
                          <p className="text-xs text-slate-800">{g.issue}</p>
                          {g.criterion && <p className="text-xs text-slate-400 mt-0.5">Criterion: {g.criterion}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Recommended changes */}
          {result.recommended_changes?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-0">
                <button className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-50 transition-colors" onClick={() => setShowChanges(v => !v)}>
                  <span className="text-xs font-semibold text-slate-800">Recommended Changes ({result.recommended_changes.length})</span>
                  {showChanges ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </button>
                {showChanges && (
                  <div className="px-4 pb-3 border-t border-slate-100">
                    <ol className="space-y-1.5 pt-2">
                      {result.recommended_changes.map((c, i) => (
                        <li key={i} className="text-xs text-slate-700 flex items-start gap-2">
                          <span className="shrink-0 font-semibold text-purple-600">{i + 1}.</span>{c}
                        </li>
                      ))}
                    </ol>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}