import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export function useSectionAccess() {
  const [sectionAssignments, setSectionAssignments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userEmail, setUserEmail] = useState(null);

  useEffect(() => {
    async function init() {
      const me = await base44.auth.me().catch(() => null);
      if (!me) {
        setLoading(false);
        return;
      }
      
      setUserEmail(me.email);
      
      // Fetch section assignments for this user
      const assignments = await base44.entities.SectionAssignment.filter(
        { user_email: me.email },
        "-assigned_date",
        100
      ).catch(() => []);
      
      setSectionAssignments(assignments);
      setLoading(false);
    }
    init();
  }, []);

  // Check if user can edit a requirement in a specific section
  const canEditSection = (section) => {
    const assignment = sectionAssignments.find((a) => a.section === section);
    return assignment?.can_edit ?? false;
  };

  // Check if user can view a requirement in a specific section
  const canViewSection = (section) => {
    const assignment = sectionAssignments.find((a) => a.section === section);
    return assignment?.can_view ?? false;
  };

  // Check if user can approve status changes in a section
  const canApproveSection = (section) => {
    const assignment = sectionAssignments.find((a) => a.section === section);
    return assignment?.can_approve ?? false;
  };

  // Get all sections user has access to
  const getAccessibleSections = (permission = "view") => {
    if (permission === "view") {
      return sectionAssignments.filter((a) => a.can_view).map((a) => a.section);
    }
    if (permission === "edit") {
      return sectionAssignments.filter((a) => a.can_edit).map((a) => a.section);
    }
    if (permission === "approve") {
      return sectionAssignments.filter((a) => a.can_approve).map((a) => a.section);
    }
    return [];
  };

  return {
    sectionAssignments,
    loading,
    userEmail,
    canEditSection,
    canViewSection,
    canApproveSection,
    getAccessibleSections,
  };
}