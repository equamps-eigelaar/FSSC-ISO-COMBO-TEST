import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trash2, Edit2, Plus, CheckCircle2, XCircle, Shield } from "lucide-react";
import { toast } from "sonner";
import RoleFormDialog from "./RoleFormDialog";
import {
  getRoleLabel, getRoleColor, getRoleDescription,
  DEFAULT_ROLE_PERMISSIONS, PERMISSION_LABELS, PERMISSION_GROUPS,
} from "./usePermissions";

const PREDEFINED_ROLES = [
  "compliance_manager", "auditor", "site_manager", "food_safety_manager",
  "production_operator", "user", "viewer",
];

export default function RoleManager() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingRole, setEditingRole] = useState(null);
  const queryClient = useQueryClient();

  const { data: dbRoles = [], isLoading } = useQuery({
    queryKey: ["roles"],
    queryFn: () => base44.entities.RoleConfig.list(),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RoleConfig.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["roles"] });
      toast.success("Custom role deleted");
    },
    onError: () => toast.error("Failed to delete role"),
  });

  // Build merged role list: predefined + any custom roles in DB
  const dbRoleMap = Object.fromEntries(dbRoles.map(r => [r.role, r]));
  const customRoles = dbRoles.filter(r => !PREDEFINED_ROLES.includes(r.role) && r.role !== "admin");

  const openEdit = (role, dbRecord) => {
    setEditingRole(dbRecord || { role, permissions: DEFAULT_ROLE_PERMISSIONS[role] || {} });
    setShowDialog(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">Roles & Permissions</h2>
          <p className="text-sm text-slate-500 mt-0.5">Configure granular permissions for each role. Changes apply to all users with that role.</p>
        </div>
        <Button onClick={() => { setEditingRole(null); setShowDialog(true); }} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
          <Plus className="w-4 h-4" />
          Custom Role
        </Button>
      </div>

      {/* Predefined roles */}
      <div>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Predefined Roles</p>
        <div className="grid gap-3">
          {PREDEFINED_ROLES.map(role => {
            const dbRecord = dbRoleMap[role];
            const perms = dbRecord
              ? { ...DEFAULT_ROLE_PERMISSIONS[role], ...dbRecord.permissions }
              : DEFAULT_ROLE_PERMISSIONS[role] || {};
            const enabledCount = Object.values(perms).filter(Boolean).length;
            const totalCount = Object.keys(PERMISSION_LABELS).length;

            return (
              <Card key={role} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className={getRoleColor(role)}>{getRoleLabel(role)}</Badge>
                        <Badge variant="secondary" className="text-xs">Predefined</Badge>
                        {dbRecord && <Badge className="text-xs bg-amber-50 text-amber-700 border-amber-200">Customised</Badge>}
                      </div>
                      <p className="text-xs text-slate-500 mb-2">{getRoleDescription(role)}</p>
                      <div className="flex flex-wrap gap-x-4 gap-y-1">
                        {Object.entries(PERMISSION_GROUPS).slice(0, 4).map(([group, keys]) => {
                          const on = keys.filter(k => perms[k]).length;
                          return (
                            <span key={group} className="text-xs text-slate-500">
                              <span className="font-medium text-slate-700">{group}:</span> {on}/{keys.length}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-xs text-slate-400">{enabledCount}/{totalCount} perms</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openEdit(role, dbRecord)}
                        className="h-8 gap-1 text-xs"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        Edit
                      </Button>
                      {dbRecord && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => { if (confirm("Reset to default permissions?")) deleteMutation.mutate(dbRecord.id); }}
                          className="h-8 text-xs text-slate-400 hover:text-rose-600"
                          title="Reset to defaults"
                        >
                          Reset
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Custom roles */}
      {customRoles.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Custom Roles</p>
          <div className="grid gap-3">
            {customRoles.map(role => {
              const enabledCount = Object.values(role.permissions || {}).filter(Boolean).length;
              return (
                <Card key={role.id} className="border-0 shadow-sm border-l-2 border-l-emerald-500">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 font-mono text-xs">{role.role}</Badge>
                          <Badge variant="secondary" className="text-xs">Custom</Badge>
                        </div>
                        <p className="text-xs text-slate-400">{enabledCount} permissions enabled</p>
                      </div>
                      <div className="flex gap-2 flex-shrink-0">
                        <Button size="sm" variant="outline" onClick={() => openEdit(role.role, role)} className="h-8 gap-1 text-xs">
                          <Edit2 className="w-3.5 h-3.5" />Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteMutation.mutate(role.id)}
                          className="h-8 w-8 p-0 text-rose-500 hover:bg-rose-50"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {customRoles.length === 0 && (
        <div className="text-center py-6 border-2 border-dashed border-slate-200 rounded-xl">
          <Shield className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-sm text-slate-500 mb-3">No custom roles yet. Create one for specialised access levels.</p>
          <Button size="sm" onClick={() => { setEditingRole(null); setShowDialog(true); }} className="bg-emerald-600 hover:bg-emerald-700 gap-1">
            <Plus className="w-3.5 h-3.5" />Create Custom Role
          </Button>
        </div>
      )}

      <RoleFormDialog
        open={showDialog}
        onOpenChange={(open) => { setShowDialog(open); if (!open) setEditingRole(null); }}
        editingRole={editingRole}
      />
    </div>
  );
}