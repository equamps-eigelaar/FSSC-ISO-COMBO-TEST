import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertTriangle, Plus, Trash2, Edit2 } from "lucide-react";

const SECTIONS = [
  "4 - Context of the Organization",
  "5 - Leadership",
  "6 - Planning",
  "7 - Support",
  "8 - Operation",
  "9 - Performance Evaluation",
  "10 - Improvement",
  "TS 22002-4 - Establishment",
  "TS 22002-4 - Utilities",
  "TS 22002-4 - Equipment",
  "TS 22002-4 - Hygiene",
  "TS 22002-4 - Personnel",
  "TS 22002-4 - Transportation",
  "TS 22002-4 - Product Information",
  "TS 22002-4 - Other Requirements",
];

export default function SectionAssignmentManager() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    user_email: "",
    section: "",
    role: "manager",
    can_edit: true,
    can_approve: false,
    can_view: true,
  });

  const queryClient = useQueryClient();

  const { data: assignments = [], isLoading } = useQuery({
    queryKey: ["section-assignments"],
    queryFn: () => base44.entities.SectionAssignment.list("-assigned_date", 100),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.SectionAssignment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["section-assignments"] });
      resetForm();
      setShowDialog(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SectionAssignment.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["section-assignments"] });
      resetForm();
      setShowDialog(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SectionAssignment.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["section-assignments"] });
    },
  });

  const resetForm = () => {
    setFormData({
      user_email: "",
      section: "",
      role: "manager",
      can_edit: true,
      can_approve: false,
      can_view: true,
    });
    setEditingId(null);
  };

  const handleEdit = (assignment) => {
    setFormData(assignment);
    setEditingId(assignment.id);
    setShowDialog(true);
  };

  const handleSave = () => {
    if (!formData.user_email || !formData.section) {
      alert("Please fill in all required fields");
      return;
    }

    if (editingId) {
      updateMutation.mutate({ id: editingId, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const getRoleColor = (role) => {
    const colors = {
      manager: "bg-emerald-100 text-emerald-700",
      reviewer: "bg-blue-100 text-blue-700",
      contributor: "bg-amber-100 text-amber-700",
    };
    return colors[role] || "bg-slate-100 text-slate-600";
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-40"><div className="animate-spin w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-900">Section Assignments</h2>
        <Button onClick={() => { resetForm(); setShowDialog(true); }} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
          <Plus className="w-4 h-4" />
          Assign Section
        </Button>
      </div>

      <div className="grid gap-4">
        {assignments.length === 0 ? (
          <Card className="border-slate-200 bg-slate-50">
            <CardContent className="pt-8 pb-8 text-center text-slate-600">
              No section assignments yet. Create one to get started.
            </CardContent>
          </Card>
        ) : (
          assignments.map((assignment) => (
            <Card key={assignment.id} className="border-slate-200">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="font-mono text-sm font-bold text-slate-400">{assignment.user_email}</span>
                      <Badge className={getRoleColor(assignment.role)}>{assignment.role}</Badge>
                    </div>
                    <p className="text-sm text-slate-600 mb-3">{assignment.section}</p>
                    <div className="flex gap-3 text-xs text-slate-500">
                      {assignment.can_view && <span className="flex items-center gap-1">✓ View</span>}
                      {assignment.can_edit && <span className="flex items-center gap-1">✓ Edit</span>}
                      {assignment.can_approve && <span className="flex items-center gap-1">✓ Approve</span>}
                    </div>
                    {assignment.notes && <p className="text-xs text-slate-400 mt-2 italic">{assignment.notes}</p>}
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(assignment)}
                      className="h-8 w-8"
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(assignment.id)}
                      className="h-8 w-8 text-rose-600 hover:text-rose-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Assignment" : "Create Section Assignment"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-slate-700 block mb-1.5">User Email *</label>
              <Input
                type="email"
                placeholder="user@example.com"
                value={formData.user_email}
                onChange={(e) => setFormData({ ...formData, user_email: e.target.value })}
                className="min-h-[40px]"
              />
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 block mb-1.5">Section *</label>
              <Select value={formData.section} onValueChange={(value) => setFormData({ ...formData, section: value })}>
                <SelectTrigger className="min-h-[40px]">
                  <SelectValue placeholder="Select section" />
                </SelectTrigger>
                <SelectContent>
                  {SECTIONS.map((section) => (
                    <SelectItem key={section} value={section}>
                      {section}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 block mb-1.5">Role *</label>
              <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                <SelectTrigger className="min-h-[40px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="reviewer">Reviewer</SelectItem>
                  <SelectItem value="contributor">Contributor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Permissions</label>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <Checkbox
                    checked={formData.can_view}
                    onCheckedChange={(checked) => setFormData({ ...formData, can_view: checked })}
                  />
                  <span className="text-sm text-slate-600">Can View</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <Checkbox
                    checked={formData.can_edit}
                    onCheckedChange={(checked) => setFormData({ ...formData, can_edit: checked })}
                  />
                  <span className="text-sm text-slate-600">Can Edit</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <Checkbox
                    checked={formData.can_approve}
                    onCheckedChange={(checked) => setFormData({ ...formData, can_approve: checked })}
                  />
                  <span className="text-sm text-slate-600">Can Approve Status Changes</span>
                </label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">
              {editingId ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}