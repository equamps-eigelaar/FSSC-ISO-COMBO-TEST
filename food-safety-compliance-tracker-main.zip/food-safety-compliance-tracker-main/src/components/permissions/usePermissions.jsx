import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

// ── Full permission keys with labels & groupings ──────────────────────────────

export const PERMISSION_LABELS = {
  // Requirements
  canViewRequirements: "View Requirements",
  canEditRequirements: "Edit Requirements",
  canCreateRequirements: "Create Requirements",
  canDeleteRequirements: "Delete Requirements",
  // Risks
  canViewRisks: "View Risks",
  canEditRisks: "Edit Risks",
  canCreateRisks: "Create Risks",
  canDeleteRisks: "Delete Risks",
  canApproveRisks: "Approve Risks",
  // Documents
  canViewDocuments: "View Documents",
  canUploadDocuments: "Upload Documents",
  canDeleteDocuments: "Delete Documents",
  canApproveDocumentRevisions: "Approve Document Revisions",
  canManageDocuments: "Manage Documents (full)",
  // Audits
  canViewAudits: "View Audits",
  canManageAudits: "Create & Manage Audits",
  canViewAuditLogs: "View Audit Logs",
  // Action Items
  canViewActionItems: "View Action Items",
  canEditActionItems: "Edit Action Items",
  canDeleteActionItems: "Delete Action Items",
  // Batches & Traceability
  canViewBatches: "View Batches",
  canEditBatches: "Edit Batches",
  canCreateBatches: "Create Batches",
  canDeleteBatches: "Delete Batches",
  // Suppliers
  canViewSupplierPortal: "View Supplier Portal",
  canManageSuppliers: "Manage Suppliers",
  // Training
  canViewTraining: "View Training",
  canManageTraining: "Manage Training",
  // Reports
  canViewReports: "View Reports",
  canGenerateReports: "Generate Reports",
  canExportData: "Export Data",
  // Cleaning
  canViewCleaningRegisters: "View Cleaning Registers",
  canManageCleaningRegisters: "Manage Cleaning Registers",
  // Monitoring
  canViewMonitoring: "View Daily Monitoring",
  canManageMonitoring: "Manage Daily Monitoring",
  // Administration
  canManageUsers: "Manage Users",
  canManageSettings: "Manage Settings",
  canManagePricing: "Manage Pricing",
  canViewAllSites: "View All Sites",
  // General
  canComment: "Add Comments",
  canManageOwnActionItems: "Manage Own Action Items",
};

export const PERMISSION_GROUPS = {
  "Requirements": ["canViewRequirements", "canEditRequirements", "canCreateRequirements", "canDeleteRequirements"],
  "Risks & HACCP": ["canViewRisks", "canCreateRisks", "canEditRisks", "canDeleteRisks", "canApproveRisks"],
  "Documents": ["canViewDocuments", "canUploadDocuments", "canDeleteDocuments", "canApproveDocumentRevisions", "canManageDocuments"],
  "Audits": ["canViewAudits", "canManageAudits", "canViewAuditLogs"],
  "Action Items": ["canViewActionItems", "canEditActionItems", "canDeleteActionItems", "canManageOwnActionItems"],
  "Batches & Traceability": ["canViewBatches", "canCreateBatches", "canEditBatches", "canDeleteBatches"],
  "Suppliers": ["canViewSupplierPortal", "canManageSuppliers"],
  "Training": ["canViewTraining", "canManageTraining"],
  "Cleaning & Monitoring": ["canViewCleaningRegisters", "canManageCleaningRegisters", "canViewMonitoring", "canManageMonitoring"],
  "Reports & Export": ["canViewReports", "canGenerateReports", "canExportData"],
  "Administration": ["canManageUsers", "canManageSettings", "canManagePricing", "canViewAllSites"],
  "General": ["canComment"],
};

// ── Default permissions per role ──────────────────────────────────────────────

export const DEFAULT_ROLE_PERMISSIONS = {
  admin: Object.fromEntries(Object.keys(PERMISSION_LABELS).map(k => [k, true])),

  compliance_manager: {
    canViewRequirements: true, canEditRequirements: true, canCreateRequirements: true, canDeleteRequirements: true,
    canViewRisks: true, canEditRisks: true, canCreateRisks: true, canDeleteRisks: true, canApproveRisks: true,
    canViewDocuments: true, canUploadDocuments: true, canDeleteDocuments: true, canApproveDocumentRevisions: true, canManageDocuments: true,
    canViewAudits: true, canManageAudits: true, canViewAuditLogs: true,
    canViewActionItems: true, canEditActionItems: true, canDeleteActionItems: true, canManageOwnActionItems: true,
    canViewBatches: true, canEditBatches: true, canCreateBatches: true, canDeleteBatches: false,
    canViewSupplierPortal: true, canManageSuppliers: true,
    canViewTraining: true, canManageTraining: true,
    canViewCleaningRegisters: true, canManageCleaningRegisters: true,
    canViewMonitoring: true, canManageMonitoring: true,
    canViewReports: true, canGenerateReports: true, canExportData: true,
    canManageUsers: false, canManageSettings: false, canManagePricing: false, canViewAllSites: true,
    canComment: true,
  },

  auditor: {
    canViewRequirements: true, canEditRequirements: false, canCreateRequirements: true, canDeleteRequirements: false,
    canViewRisks: true, canEditRisks: false, canCreateRisks: true, canDeleteRisks: false, canApproveRisks: false,
    canViewDocuments: true, canUploadDocuments: true, canDeleteDocuments: false, canApproveDocumentRevisions: false, canManageDocuments: true,
    canViewAudits: true, canManageAudits: true, canViewAuditLogs: true,
    canViewActionItems: true, canEditActionItems: true, canDeleteActionItems: false, canManageOwnActionItems: true,
    canViewBatches: true, canEditBatches: false, canCreateBatches: false, canDeleteBatches: false,
    canViewSupplierPortal: true, canManageSuppliers: false,
    canViewTraining: true, canManageTraining: false,
    canViewCleaningRegisters: true, canManageCleaningRegisters: false,
    canViewMonitoring: true, canManageMonitoring: false,
    canViewReports: true, canGenerateReports: true, canExportData: true,
    canManageUsers: false, canManageSettings: false, canManagePricing: false, canViewAllSites: true,
    canComment: true,
  },

  site_manager: {
    canViewRequirements: true, canEditRequirements: true, canCreateRequirements: true, canDeleteRequirements: true,
    canViewRisks: true, canEditRisks: true, canCreateRisks: true, canDeleteRisks: true, canApproveRisks: true,
    canViewDocuments: true, canUploadDocuments: true, canDeleteDocuments: true, canApproveDocumentRevisions: true, canManageDocuments: true,
    canViewAudits: true, canManageAudits: true, canViewAuditLogs: true,
    canViewActionItems: true, canEditActionItems: true, canDeleteActionItems: true, canManageOwnActionItems: true,
    canViewBatches: true, canEditBatches: true, canCreateBatches: true, canDeleteBatches: false,
    canViewSupplierPortal: true, canManageSuppliers: true,
    canViewTraining: true, canManageTraining: true,
    canViewCleaningRegisters: true, canManageCleaningRegisters: true,
    canViewMonitoring: true, canManageMonitoring: true,
    canViewReports: true, canGenerateReports: true, canExportData: true,
    canManageUsers: false, canManageSettings: false, canManagePricing: false, canViewAllSites: true,
    canComment: true,
  },

  food_safety_manager: {
    canViewRequirements: true, canEditRequirements: true, canCreateRequirements: true, canDeleteRequirements: true,
    canViewRisks: true, canEditRisks: true, canCreateRisks: true, canDeleteRisks: true, canApproveRisks: true,
    canViewDocuments: true, canUploadDocuments: true, canDeleteDocuments: true, canApproveDocumentRevisions: true, canManageDocuments: true,
    canViewAudits: true, canManageAudits: true, canViewAuditLogs: true,
    canViewActionItems: true, canEditActionItems: true, canDeleteActionItems: true, canManageOwnActionItems: true,
    canViewBatches: true, canEditBatches: true, canCreateBatches: true, canDeleteBatches: false,
    canViewSupplierPortal: true, canManageSuppliers: true,
    canViewTraining: true, canManageTraining: true,
    canViewCleaningRegisters: true, canManageCleaningRegisters: true,
    canViewMonitoring: true, canManageMonitoring: true,
    canViewReports: true, canGenerateReports: true, canExportData: true,
    canManageUsers: false, canManageSettings: false, canManagePricing: false, canViewAllSites: true,
    canComment: true,
  },



  quality_auditor: {
    canViewRequirements: true, canEditRequirements: false, canCreateRequirements: true, canDeleteRequirements: false,
    canViewRisks: true, canEditRisks: false, canCreateRisks: true, canDeleteRisks: false, canApproveRisks: false,
    canViewDocuments: true, canUploadDocuments: true, canDeleteDocuments: false, canApproveDocumentRevisions: false, canManageDocuments: false,
    canViewAudits: true, canManageAudits: true, canViewAuditLogs: true,
    canViewActionItems: true, canEditActionItems: true, canDeleteActionItems: false, canManageOwnActionItems: true,
    canViewBatches: true, canEditBatches: false, canCreateBatches: false, canDeleteBatches: false,
    canViewSupplierPortal: true, canManageSuppliers: false,
    canViewTraining: true, canManageTraining: false,
    canViewCleaningRegisters: true, canManageCleaningRegisters: false,
    canViewMonitoring: true, canManageMonitoring: false,
    canViewReports: true, canGenerateReports: true, canExportData: true,
    canManageUsers: false, canManageSettings: false, canManagePricing: false, canViewAllSites: true,
    canComment: true,
  },

  production_operator: {
    canViewRequirements: true, canEditRequirements: false, canCreateRequirements: false, canDeleteRequirements: false,
    canViewRisks: false, canEditRisks: false, canCreateRisks: false, canDeleteRisks: false, canApproveRisks: false,
    canViewDocuments: true, canUploadDocuments: false, canDeleteDocuments: false, canApproveDocumentRevisions: false, canManageDocuments: false,
    canViewAudits: false, canManageAudits: false, canViewAuditLogs: false,
    canViewActionItems: true, canEditActionItems: true, canDeleteActionItems: false, canManageOwnActionItems: true,
    canViewBatches: true, canEditBatches: true, canCreateBatches: true, canDeleteBatches: false,
    canViewSupplierPortal: false, canManageSuppliers: false,
    canViewTraining: true, canManageTraining: false,
    canViewCleaningRegisters: true, canManageCleaningRegisters: true,
    canViewMonitoring: true, canManageMonitoring: true,
    canViewReports: false, canGenerateReports: false, canExportData: false,
    canManageUsers: false, canManageSettings: false, canManagePricing: false, canViewAllSites: false,
    canComment: true,
  },

  user: {
    canViewRequirements: true, canEditRequirements: true, canCreateRequirements: true, canDeleteRequirements: false,
    canViewRisks: true, canEditRisks: false, canCreateRisks: false, canDeleteRisks: false, canApproveRisks: false,
    canViewDocuments: true, canUploadDocuments: true, canDeleteDocuments: false, canApproveDocumentRevisions: false, canManageDocuments: false,
    canViewAudits: true, canManageAudits: false, canViewAuditLogs: false,
    canViewActionItems: true, canEditActionItems: true, canDeleteActionItems: false, canManageOwnActionItems: true,
    canViewBatches: false, canEditBatches: false, canCreateBatches: false, canDeleteBatches: false,
    canViewSupplierPortal: false, canManageSuppliers: false,
    canViewTraining: true, canManageTraining: false,
    canViewCleaningRegisters: true, canManageCleaningRegisters: false,
    canViewMonitoring: true, canManageMonitoring: false,
    canViewReports: true, canGenerateReports: false, canExportData: false,
    canManageUsers: false, canManageSettings: false, canManagePricing: false, canViewAllSites: false,
    canComment: true,
  },

  viewer: {
    canViewRequirements: true, canEditRequirements: false, canCreateRequirements: false, canDeleteRequirements: false,
    canViewRisks: true, canEditRisks: false, canCreateRisks: false, canDeleteRisks: false, canApproveRisks: false,
    canViewDocuments: true, canUploadDocuments: false, canDeleteDocuments: false, canApproveDocumentRevisions: false, canManageDocuments: false,
    canViewAudits: true, canManageAudits: false, canViewAuditLogs: false,
    canViewActionItems: true, canEditActionItems: false, canDeleteActionItems: false, canManageOwnActionItems: false,
    canViewBatches: true, canEditBatches: false, canCreateBatches: false, canDeleteBatches: false,
    canViewSupplierPortal: false, canManageSuppliers: false,
    canViewTraining: true, canManageTraining: false,
    canViewCleaningRegisters: true, canManageCleaningRegisters: false,
    canViewMonitoring: true, canManageMonitoring: false,
    canViewReports: true, canGenerateReports: false, canExportData: false,
    canManageUsers: false, canManageSettings: false, canManagePricing: false, canViewAllSites: false,
    canComment: false,
  },
};

// ── Cache ─────────────────────────────────────────────────────────────────────

let roleConfigCache = null;
let roleConfigFetchedAt = 0;
const CACHE_TTL_MS = 60_000;

async function loadRoleConfigs() {
  const now = Date.now();
  if (roleConfigCache && now - roleConfigFetchedAt < CACHE_TTL_MS) return roleConfigCache;
  const configs = await base44.entities.RoleConfig.list();
  roleConfigCache = {};
  for (const c of configs) {
    roleConfigCache[c.role] = c.permissions;
  }
  roleConfigFetchedAt = now;
  return roleConfigCache;
}

export function invalidateRoleConfigCache() {
  roleConfigCache = null;
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function usePermissions() {
  const [user, setUser] = useState(null);
  const [permissions, setPermissions] = useState(DEFAULT_ROLE_PERMISSIONS.viewer);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function init() {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      const role = me?.role || "viewer";

      if (role === "admin") {
        setPermissions(DEFAULT_ROLE_PERMISSIONS.admin);
        setLoading(false);
        return;
      }

      const configs = await loadRoleConfigs().catch(() => ({}));
      const dbPerms = configs[role];
      const base = dbPerms
        ? { ...(DEFAULT_ROLE_PERMISSIONS[role] || DEFAULT_ROLE_PERMISSIONS.viewer), ...dbPerms }
        : { ...(DEFAULT_ROLE_PERMISSIONS[role] || DEFAULT_ROLE_PERMISSIONS.viewer) };

      setPermissions(base);
      setLoading(false);
    }
    init();
  }, []);

  const role = user?.role || "viewer";
  const isAdmin = role === "admin";

  return { permissions, user, loading, isAdmin, complianceRole: role };
}

// ── Static helpers ────────────────────────────────────────────────────────────

export function getRoleLabel(role) {
  const labels = {
    admin: "Admin",
    compliance_manager: "Compliance Manager",
    auditor: "Auditor",
    site_manager: "Site Manager",
    user: "User",
    food_safety_manager: "Food Safety Manager",
    production_operator: "Production Operator",
    quality_auditor: "Quality Auditor",
    viewer: "Viewer",
  };
  return labels[role] || role || "Viewer";
}

export function getRoleColor(role) {
  const colors = {
    admin: "bg-purple-50 text-purple-700 border-purple-200",
    compliance_manager: "bg-indigo-50 text-indigo-700 border-indigo-200",
    auditor: "bg-amber-50 text-amber-700 border-amber-200",
    site_manager: "bg-cyan-50 text-cyan-700 border-cyan-200",
    user: "bg-emerald-50 text-emerald-700 border-emerald-200",
    food_safety_manager: "bg-blue-50 text-blue-700 border-blue-200",
    production_operator: "bg-teal-50 text-teal-700 border-teal-200",
    quality_auditor: "bg-violet-50 text-violet-700 border-violet-200",
    viewer: "bg-slate-100 text-slate-600 border-slate-200",
  };
  return colors[role] || "bg-slate-100 text-slate-600 border-slate-200";
}

export function getRoleDescription(role) {
  const descriptions = {
    admin: "Full system access. Manage users, settings, all records, approvals and deletions.",
    compliance_manager: "Full operational access — edit requirements, approve risks, manage documents and suppliers. Cannot manage users or system settings.",
    auditor: "Conduct audits, upload findings, create requirements and risk records, manage documents, and generate reports.",
    site_manager: "Full operational access across all sites. Manages compliance, approves risks, manages documents, suppliers, training, cleaning, monitoring, and generates reports. Cannot manage users or system settings.",
    user: "Standard contributor. Edit assigned requirements and action items, add comments.",
    food_safety_manager: "Full operational access across all sites. Manages compliance, approves risks, manages documents, suppliers, training, cleaning, monitoring, and generates reports. Cannot manage users or system settings.",
    production_operator: "Create batches, manage cleaning and monitoring, add comments.",
    quality_auditor: "Conduct audits, log findings, upload documents, manage own action items, view all sites. Cannot approve risks or manage users.",
    viewer: "Read-only access. Cannot create, edit, or delete anything.",
  };
  return descriptions[role] || "";
}

export function getRolePermissions(role) {
  const perms = DEFAULT_ROLE_PERMISSIONS[role] || DEFAULT_ROLE_PERMISSIONS.viewer;
  return Object.entries(perms)
    .filter(([, v]) => v)
    .map(([k]) => PERMISSION_LABELS[k] || k);
}