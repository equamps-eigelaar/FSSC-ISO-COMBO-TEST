import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Check, X, Save, RotateCcw, Loader2 } from "lucide-react";
import { getRoleLabel, getRoleColor, DEFAULT_ROLE_PERMISSIONS, PERMISSION_LABELS, PERMISSION_GROUPS, invalidateRoleConfigCache } from "./usePermissions";
import { toast } from "sonner";
import { usePermissions } from "./usePermissions";

const ROLES = ["compliance_manager", "auditor", "site_manager", "food_safety_manager", "quality_auditor", "production_operator", "user", "viewer"];

// Descriptions shown in header tooltips
const ROLE_DESCS = {
  compliance_manager: "Oversees full compliance programme",
  auditor: "Conduct audits, read-only on requirements",
  site_manager: "Full site ops, no user management",
  food_safety_manager: "HACCP, risk, docs, suppliers",
  quality_auditor: "Create risks & docs, view audits",
  production_operator: "Batches, cleaning, monitoring",
  user: "Standard contributor",
  viewer: "Read-only",
};

export default function RolePermissionsMatrix() {
  const { isAdmin } = usePermissions();
  const [matrix, setMatrix] = useState(null); // { role: { permKey: bool } }
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const configs = await base44.entities.RoleConfig.list().catch(() => []);
      const m = {};
      for (const role of ROLES) {
        const found = configs.find(c => c.role === role);
        m[role] = found
          ? { ...DEFAULT_ROLE_PERMISSIONS[role], ...found.permissions }
          : { ...DEFAULT_ROLE_PERMISSIONS[role] };
      }
      setMatrix(m);
      setLoading(false);
    }
    load();
  }, []);

  const toggle = (role, perm) => {
    if (!isAdmin) return;
    setMatrix(prev => ({
      ...prev,
      [role]: { ...prev[role], [perm]: !prev[role][perm] },
    }));
  };

  const resetRole = (role) => {
    setMatrix(prev => ({
      ...prev,
      [role]: { ...DEFAULT_ROLE_PERMISSIONS[role] },
    }));
  };

  const saveAll = async () => {
    setSaving(true);
    try {
      const existing = await base44.entities.RoleConfig.list();
      for (const role of ROLES) {
        const found = existing.find(c => c.role === role);
        if (found) {
          await base44.entities.RoleConfig.update(found.id, { permissions: matrix[role] });
        } else {
          await base44.entities.RoleConfig.create({ role, permissions: matrix[role] });
        }
      }
      invalidateRoleConfigCache();
      toast.success("Permissions saved successfully");
    } catch {
      toast.error("Failed to save permissions");
    } finally {
      setSaving(false);
    }
  };

  if (loading || !matrix) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {isAdmin && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-slate-500">
            Toggle permissions per role. Admin always has full access and cannot be modified.
          </p>
          <Button onClick={saveAll} disabled={saving} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Changes
          </Button>
        </div>
      )}

      {Object.entries(PERMISSION_GROUPS).map(([groupName, permKeys]) => (
        <Card key={groupName} className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-slate-700">{groupName}</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead className="w-48 text-xs">Permission</TableHead>
                    {/* Admin column - always full */}
                    <TableHead className="text-center min-w-[110px]">
                      <Badge className={getRoleColor("admin")} variant="outline">Admin</Badge>
                    </TableHead>
                    {ROLES.map(role => (
                      <TableHead key={role} className="text-center min-w-[120px]">
                        <div className="flex flex-col items-center gap-1">
                          <Badge className={getRoleColor(role)} variant="outline">
                            {getRoleLabel(role)}
                          </Badge>
                          {isAdmin && (
                            <button
                              onClick={() => resetRole(role)}
                              className="text-[10px] text-slate-400 hover:text-slate-600 flex items-center gap-0.5"
                              title={`Reset ${getRoleLabel(role)} to defaults`}
                            >
                              <RotateCcw className="w-2.5 h-2.5" /> reset
                            </button>
                          )}
                        </div>
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {permKeys.map(perm => (
                    <TableRow key={perm}>
                      <TableCell className="text-xs font-medium text-slate-700 py-2">
                        {PERMISSION_LABELS[perm] || perm}
                      </TableCell>
                      {/* Admin - always true */}
                      <TableCell className="text-center py-2">
                        <Check className="w-4 h-4 text-emerald-600 mx-auto" />
                      </TableCell>
                      {ROLES.map(role => (
                        <TableCell key={role} className="text-center py-2">
                          {isAdmin ? (
                            <div className="flex justify-center">
                              <Switch
                                checked={!!matrix[role][perm]}
                                onCheckedChange={() => toggle(role, perm)}
                                className="scale-75"
                              />
                            </div>
                          ) : (
                            matrix[role][perm]
                              ? <Check className="w-4 h-4 text-emerald-600 mx-auto" />
                              : <X className="w-4 h-4 text-slate-300 mx-auto" />
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}