import React, { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { PERMISSION_LABELS, PERMISSION_GROUPS, DEFAULT_ROLE_PERMISSIONS } from "./usePermissions";
import { CheckSquare, Square } from "lucide-react";

const PREDEFINED_ROLES = ["admin", "compliance_manager", "auditor", "site_manager", "user", "food_safety_manager", "quality_auditor", "production_operator", "viewer"];

export default function RoleFormDialog({ open, onOpenChange, editingRole }) {
  const [roleName, setRoleName] = useState("");
  const [permissions, setPermissions] = useState({});
  const [activeGroup, setActiveGroup] = useState(Object.keys(PERMISSION_GROUPS)[0]);
  const queryClient = useQueryClient();

  const isPredefined = editingRole && PREDEFINED_ROLES.includes(editingRole.role);

  useEffect(() => {
    if (open) {
      if (editingRole) {
        setRoleName(editingRole.role);
        // Merge DB config over defaults
        const base = DEFAULT_ROLE_PERMISSIONS[editingRole.role] || {};
        setPermissions({ ...base, ...(editingRole.permissions || {}) });
      } else {
        setRoleName("");
        setPermissions(Object.fromEntries(Object.keys(PERMISSION_LABELS).map(k => [k, false])));
      }
      setActiveGroup(Object.keys(PERMISSION_GROUPS)[0]);
    }
  }, [editingRole, open]);

  const saveMutation = useMutation({
    mutationFn: (data) =>
      editingRole
        ? base44.entities.RoleConfig.update(editingRole.id, data)
        : base44.entities.RoleConfig.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["roles"] });
      toast.success(editingRole ? "Role updated" : "Role created");
      onOpenChange(false);
    },
    onError: () => toast.error("Failed to save role"),
  });

  const toggle = (key) => {
    setPermissions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleGroup = (keys) => {
    const allOn = keys.every(k => permissions[k]);
    setPermissions(prev => {
      const next = { ...prev };
      keys.forEach(k => { next[k] = !allOn; });
      return next;
    });
  };

  const handleSave = () => {
    const name = roleName.trim();
    if (!name) return toast.error("Role name is required");
    saveMutation.mutate({ role: name, permissions });
  };

  const groupKeys = PERMISSION_GROUPS[activeGroup] || [];
  const allGroupOn = groupKeys.every(k => permissions[k]);
  const totalEnabled = Object.values(permissions).filter(Boolean).length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[92vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>{editingRole ? (isPredefined ? "Edit Permissions" : "Edit Role") : "Create Custom Role"}</DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4 py-2">
          {/* Role name */}
          <div>
            <Label className="text-sm font-medium">Role Identifier</Label>
            <Input
              value={roleName}
              onChange={(e) => setRoleName(e.target.value.toLowerCase().replace(/\s+/g, "_"))}
              placeholder="e.g., senior_auditor"
              className="mt-1.5 font-mono text-sm"
              disabled={isPredefined}
            />
            {!isPredefined && <p className="text-xs text-slate-400 mt-1">Use lowercase letters and underscores only. This is the role value stored on users.</p>}
          </div>

          {/* Permission summary */}
          <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg">
            <Badge variant="secondary" className="text-xs">{totalEnabled} / {Object.keys(permissions).length} permissions enabled</Badge>
            <button
              onClick={() => setPermissions(Object.fromEntries(Object.keys(PERMISSION_LABELS).map(k => [k, true])))}
              className="text-xs text-emerald-600 hover:underline ml-auto"
            >Enable all</button>
            <button
              onClick={() => setPermissions(Object.fromEntries(Object.keys(PERMISSION_LABELS).map(k => [k, false])))}
              className="text-xs text-rose-500 hover:underline"
            >Disable all</button>
          </div>

          {/* Two-panel: group list + permission switches */}
          <div className="flex gap-4 min-h-0">
            {/* Group sidebar */}
            <div className="w-44 flex-shrink-0 space-y-1">
              {Object.entries(PERMISSION_GROUPS).map(([group, keys]) => {
                const enabledCount = keys.filter(k => permissions[k]).length;
                return (
                  <button
                    key={group}
                    onClick={() => setActiveGroup(group)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-colors ${activeGroup === group ? "bg-emerald-600 text-white" : "text-slate-600 hover:bg-slate-100"}`}
                  >
                    <div className="truncate">{group}</div>
                    <div className={`text-[10px] mt-0.5 ${activeGroup === group ? "text-emerald-100" : "text-slate-400"}`}>
                      {enabledCount}/{keys.length}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Permission switches */}
            <div className="flex-1 border border-slate-200 rounded-xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-2.5 bg-slate-50 border-b border-slate-200">
                <span className="text-sm font-semibold text-slate-800">{activeGroup}</span>
                <button
                  onClick={() => toggleGroup(groupKeys)}
                  className="flex items-center gap-1 text-xs text-slate-500 hover:text-emerald-600 transition-colors"
                >
                  {allGroupOn ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5" />}
                  {allGroupOn ? "Disable all" : "Enable all"}
                </button>
              </div>
              <div className="divide-y divide-slate-100">
                {groupKeys.map(permKey => (
                  <div key={permKey} className="flex items-center justify-between px-4 py-3 hover:bg-slate-50 transition-colors">
                    <div>
                      <p className="text-sm text-slate-800">{PERMISSION_LABELS[permKey]}</p>
                      <p className="text-xs text-slate-400 font-mono">{permKey}</p>
                    </div>
                    <Switch
                      checked={!!permissions[permKey]}
                      onCheckedChange={() => toggle(permKey)}
                      disabled={permKey === "canManageUsers" && editingRole?.role !== "admin"}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="pt-2 border-t border-slate-100">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={handleSave}
            disabled={saveMutation.isPending || !roleName.trim()}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {saveMutation.isPending ? "Saving..." : "Save Permissions"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}