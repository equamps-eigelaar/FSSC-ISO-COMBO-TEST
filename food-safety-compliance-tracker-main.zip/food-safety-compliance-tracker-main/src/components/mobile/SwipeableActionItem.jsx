import React, { useState } from "react";
import { motion, useMotionValue, useTransform } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Trash2, Clock } from "lucide-react";
import { format } from "date-fns";

const PRIORITY_CONFIG = {
  critical: { color: "bg-red-100 text-red-800", label: "Critical" },
  high: { color: "bg-orange-100 text-orange-800", label: "High" },
  medium: { color: "bg-yellow-100 text-yellow-800", label: "Medium" },
  low: { color: "bg-blue-100 text-blue-800", label: "Low" }
};

const STATUS_CONFIG = {
  pending: { color: "bg-slate-100 text-slate-700", label: "Pending" },
  in_progress: { color: "bg-blue-100 text-blue-700", label: "In Progress" },
  completed: { color: "bg-emerald-100 text-emerald-700", label: "Completed" },
  blocked: { color: "bg-red-100 text-red-700", label: "Blocked" }
};

export default function SwipeableActionItem({ action, onComplete, onDelete, onClick }) {
  const [isDragging, setIsDragging] = useState(false);
  const x = useMotionValue(0);
  const background = useTransform(
    x,
    [-100, 0, 100],
    ["rgb(239 68 68)", "rgb(255 255 255)", "rgb(34 197 94)"]
  );

  const handleDragEnd = (event, info) => {
    setIsDragging(false);
    if (info.offset.x > 100) {
      onComplete?.(action.id);
    } else if (info.offset.x < -100) {
      onDelete?.(action.id);
    }
  };

  const priorityConfig = PRIORITY_CONFIG[action.priority] || PRIORITY_CONFIG.medium;
  const statusConfig = STATUS_CONFIG[action.status] || STATUS_CONFIG.pending;
  const isOverdue = action.due_date && new Date(action.due_date) < new Date() && action.status !== 'completed';

  return (
    <div className="relative overflow-hidden rounded-lg">
      {/* Background Actions */}
      <div className="absolute inset-0 flex items-center justify-between px-6">
        <div className="flex items-center gap-2 text-red-600">
          <Trash2 className="w-5 h-5" />
          <span className="text-sm font-medium">Delete</span>
        </div>
        <div className="flex items-center gap-2 text-emerald-600">
          <span className="text-sm font-medium">Complete</span>
          <CheckCircle2 className="w-5 h-5" />
        </div>
      </div>

      {/* Swipeable Card */}
      <motion.div
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.2}
        onDragStart={() => setIsDragging(true)}
        onDragEnd={handleDragEnd}
        style={{ x, background }}
        className={`relative bg-white dark:bg-slate-800 rounded-lg p-4 shadow-sm cursor-pointer ${
          isDragging ? 'cursor-grabbing' : 'cursor-grab'
        }`}
        onClick={() => !isDragging && onClick?.(action)}
      >
        <div className="flex items-start justify-between gap-3 mb-2">
          <h4 className="font-medium text-slate-900 dark:text-white text-sm flex-1 line-clamp-2">
            {action.title}
          </h4>
          <Badge className={priorityConfig.color}>
            {priorityConfig.label}
          </Badge>
        </div>

        {action.description && (
          <p className="text-xs text-slate-600 dark:text-slate-400 mb-3 line-clamp-2">
            {action.description}
          </p>
        )}

        <div className="flex items-center justify-between text-xs">
          <Badge variant="outline" className={statusConfig.color}>
            {statusConfig.label}
          </Badge>
          
          {action.due_date && (
            <div className={`flex items-center gap-1 ${isOverdue ? 'text-red-600' : 'text-slate-500'}`}>
              <Clock className="w-3 h-3" />
              <span>{format(new Date(action.due_date), 'MMM d')}</span>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}