import React, { useState, useRef } from 'react';
import { motion, useMotionValue, useTransform, animate } from 'framer-motion';
import { RefreshCw } from 'lucide-react';

export default function PullToRefresh({ onRefresh, children }) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const containerRef = useRef(null);
  const y = useMotionValue(0);
  const opacity = useTransform(y, [0, 80], [0, 1]);
  const rotate = useTransform(y, [0, 80], [0, 180]);

  const handleDragEnd = async (event, info) => {
    if (info.offset.y > 80 && !isRefreshing) {
      setIsRefreshing(true);
      await onRefresh();
      setIsRefreshing(false);
    }
    animate(y, 0, { type: 'spring', stiffness: 300, damping: 30 });
  };

  return (
    <div ref={containerRef} className="relative overflow-hidden">
      <motion.div
        className="absolute top-0 left-0 right-0 flex items-center justify-center h-20 pointer-events-none"
        style={{ y: useTransform(y, (v) => v - 80), opacity }}
      >
        <motion.div style={{ rotate }} className={isRefreshing ? 'animate-spin' : ''}>
          <RefreshCw className="w-5 h-5 text-emerald-600" />
        </motion.div>
      </motion.div>
      <motion.div
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0.5, bottom: 0 }}
        onDragEnd={handleDragEnd}
        style={{ y }}
        className="touch-pan-y"
      >
        {children}
      </motion.div>
    </div>
  );
}