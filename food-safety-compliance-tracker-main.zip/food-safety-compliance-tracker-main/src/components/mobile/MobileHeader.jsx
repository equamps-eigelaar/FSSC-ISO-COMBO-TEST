import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ChevronLeft, ShieldCheck, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';

// Pages that are "tab roots" — back should go to Dashboard, not browser history
const ROOT_PAGES = ['Dashboard', 'Requirements', 'RiskWorkflow', 'RawMaterialTraceability', 'ActionItems', 'RiskPredictions', 'MobileAudit', 'MobileActionItems', 'DailyMonitoring', 'DocumentRepository', 'Analytics', 'Settings', 'Training', 'Reports'];

const NAV_ITEMS = [
  { name: "Dashboard", page: "Dashboard" },
  { name: "Audit Prep", page: "AuditPrep" },
  { name: "Field Audits", page: "MobileAudit" },
  { name: "Daily Monitoring", page: "DailyMonitoring" },
  { name: "Requirements", page: "Requirements" },
  { name: "Risk Workflow", page: "RiskWorkflow" },
  { name: "Action Items", page: "ActionItems" },
  { name: "Approved Supplier Questionnaire", page: "SelfAssessment" },
  { name: "Supplier Portal", page: "SupplierPortal" },
  { name: "Templates", page: "DocumentTemplates" },
  { name: "Documents", page: "DocumentRepository" },
  { name: "Audit Trail", page: "ActivityMonitor" },
  { name: "Training", page: "Training" },
  { name: "Batch Traceability", page: "FoodBatchTraceability" },
  { name: "Raw Materials", page: "RawMaterialTraceability" },
  { name: "AI Audits", page: "ComplianceAudits" },
  { name: "Customer Complaints", page: "SupportTickets" },
  { name: "Analytics", page: "Analytics" },
  { name: "Settings", page: "Settings" },
];

export default function MobileHeader({ currentPageName }) {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [orgName, setOrgName] = useState("");

  useEffect(() => {
    base44.auth.me().then(user => {
      if (!user) return;
      // Fast path: org name stored directly on user record
      if (user.organization_name) { setOrgName(user.organization_name); return; }
      base44.entities.OrganizationMember.filter({ user_email: user.email }, "-created_date", 1)
        .then(members => {
          if (members?.[0]?.organization_name) { setOrgName(members[0].organization_name); return; }
          base44.entities.Organization.filter({ owner_email: user.email }, "-created_date", 1)
            .then(orgs => { if (orgs?.[0]?.name) setOrgName(orgs[0].name); })
            .catch(() => {});
        }).catch(() => {});
    }).catch(() => {});
  }, []);
  
  const isRootPage = ROOT_PAGES.includes(currentPageName);
  
  return (
    <>
      <div 
        className="lg:hidden fixed top-0 left-0 right-0 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 z-40 select-none"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="h-14 px-4 flex items-center justify-between">
          {!isRootPage ? (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl('Dashboard'))}
              className="min-h-[44px] min-w-[44px]"
            >
              <ChevronLeft className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            </Button>
          ) : (
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center">
                <ShieldCheck className="w-3.5 h-3.5 text-white" />
              </div>
              <div>
                <span className="text-sm font-bold text-slate-900 dark:text-white">ISO 22000:2018v2</span>
                {orgName && <p className="text-xs text-slate-400 dark:text-slate-500 font-medium tracking-wide">{orgName}</p>}
              </div>
            </div>
          )}
          <div className="text-sm font-semibold text-slate-900 dark:text-white">
            {currentPageName === 'SelfAssessment' ? 'Approved Supplier Questionnaire' : currentPageName.replace(/([A-Z])/g, ' $1').trim()}
          </div>
          <Button
            variant="ghost"
            size="icon"
            className={`min-h-[64px] min-w-[64px] h-16 w-16 ${menuOpen ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400' : ''}`}
            onClick={() => setMenuOpen(v => !v)}
          >
            {menuOpen ? <X className="w-6 h-6 text-emerald-600 dark:text-emerald-400" /> : <Menu className="w-6 h-6 text-slate-600 dark:text-slate-300" />}
          </Button>
        </div>
      </div>

      {/* Full-screen dropdown nav */}
      {menuOpen && (
        <div
          className="lg:hidden fixed top-0 left-0 right-0 bottom-0 z-50 bg-white dark:bg-slate-900 overflow-y-auto"
          style={{ paddingTop: 'calc(3.5rem + env(safe-area-inset-top, 0px))', paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
        >
          <div className="absolute top-0 left-0 right-0 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 z-10 flex items-center justify-between px-4 h-14"
            style={{ paddingTop: 'env(safe-area-inset-top)' }}>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center">
                <ShieldCheck className="w-3.5 h-3.5 text-white" />
              </div>
              <div>
                <span className="text-sm font-bold text-slate-900 dark:text-white">ISO 22000:2018v2</span>
                {orgName && <p className="text-xs text-slate-400 dark:text-slate-500 font-medium tracking-wide">{orgName}</p>}
              </div>
            </div>
            <Button variant="ghost" size="icon" className="min-h-[44px] min-w-[44px]" onClick={() => setMenuOpen(false)}>
              <X className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            </Button>
          </div>
          <nav className="p-4 space-y-1">
            {NAV_ITEMS.map(item => {
              const active = currentPageName === item.page;
              return (
                <Link
                  key={item.page}
                  to={createPageUrl(item.page)}
                  onClick={() => setMenuOpen(false)}
                  className={`flex items-center px-5 py-4 rounded-xl text-base font-medium transition-colors min-h-[60px]
                    ${active
                      ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                >
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
      )}
    </>
  );
}