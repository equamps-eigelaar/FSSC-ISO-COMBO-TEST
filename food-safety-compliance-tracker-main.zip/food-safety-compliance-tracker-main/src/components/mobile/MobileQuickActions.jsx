import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Plus, 
  ClipboardCheck, 
  AlertTriangle, 
  FileText,
  Camera,
  CheckCircle2
} from "lucide-react";

const QUICK_ACTIONS = [
  { 
    icon: ClipboardCheck, 
    label: "Quick Check", 
    color: "bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400",
    page: "Requirements" 
  },
  { 
    icon: AlertTriangle, 
    label: "Log Risk", 
    color: "bg-orange-50 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400",
    page: "RiskWorkflow" 
  },
  { 
    icon: CheckCircle2, 
    label: "Actions", 
    color: "bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400",
    page: "ActionItems" 
  },
  { 
    icon: FileText, 
    label: "Documents", 
    color: "bg-purple-50 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400",
    page: "DocumentRepository" 
  },
];

export default function MobileQuickActions() {
  return (
    <Card className="border-0 shadow-sm lg:hidden">
      <CardContent className="p-4">
        <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-3">Quick Actions</h3>
        <div className="grid grid-cols-4 gap-3">
          {QUICK_ACTIONS.map((action) => (
            <Link
              key={action.page}
              to={createPageUrl(action.page)}
              className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors active:scale-95"
            >
              <div className={`w-12 h-12 rounded-xl ${action.color} flex items-center justify-center`}>
                <action.icon className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium text-slate-700 dark:text-slate-300 text-center">
                {action.label}
              </span>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}