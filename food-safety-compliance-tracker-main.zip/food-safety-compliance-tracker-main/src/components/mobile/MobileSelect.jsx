import React, { useState } from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

export default function MobileSelect({ children, value, onValueChange, placeholder, triggerClassName, label }) {
  const [open, setOpen] = useState(false);
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 1024;

  // Extract options from children
  const options = React.Children.toArray(children).filter(
    child => child.type === SelectItem
  );

  if (!isMobile) {
    return (
      <Select value={value} onValueChange={onValueChange}>
        <SelectTrigger className={triggerClassName}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>{children}</SelectContent>
      </Select>
    );
  }

  const selectedLabel = options.find(opt => opt.props.value === value)?.props.children || placeholder;

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        <Button variant="outline" className={`justify-between ${triggerClassName}`}>
          {selectedLabel}
        </Button>
      </DrawerTrigger>
      <DrawerContent className="dark:bg-slate-900">
        <DrawerHeader>
          <DrawerTitle className="dark:text-white">{label || placeholder}</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 pb-8 space-y-1">
          {options.map(option => (
            <button
              key={option.props.value}
              onClick={() => {
                onValueChange(option.props.value);
                setOpen(false);
              }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-lg text-left transition-colors min-h-[44px] ${
                value === option.props.value
                  ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400'
                  : 'hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <span className="text-sm dark:text-white">{option.props.children}</span>
              {value === option.props.value && (
                <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              )}
            </button>
          ))}
        </div>
      </DrawerContent>
    </Drawer>
  );
}