import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { LayoutDashboard, ClipboardList, ShieldCheck, CheckCircle2 } from 'lucide-react';

const TABS = [
  { name: 'Dashboard', icon: LayoutDashboard, page: 'Dashboard' },
  { name: 'Audits', icon: ClipboardList, page: 'MobileAudit' },
  { name: 'Actions', icon: CheckCircle2, page: 'MobileActionItems' },
  { name: 'Requirements', icon: ClipboardList, page: 'Requirements' },
];

export default function BottomTabBar({ currentPageName }) {
  const navigate = useNavigate();

  const handleTabClick = (e, tab) => {
    if (currentPageName === tab.page) {
      e.preventDefault();
      navigate(createPageUrl(tab.page), { replace: true });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div 
      className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 z-40 select-none"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="grid grid-cols-4 h-20">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentPageName === tab.page;
          return (
            <Link
              key={tab.page}
              to={createPageUrl(tab.page)}
              onClick={(e) => handleTabClick(e, tab)}
              className="flex flex-col items-center justify-center gap-1.5 min-h-[56px] active:bg-slate-50 dark:active:bg-slate-800 transition-colors"
            >
              <Icon className={`w-7 h-7 ${isActive ? 'text-emerald-600' : 'text-slate-400 dark:text-slate-500'}`} />
              <span className={`text-xs font-medium ${isActive ? 'text-emerald-600' : 'text-slate-500 dark:text-slate-400'}`}>
                {tab.name}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}