import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { addDays, format } from "date-fns";

export default function InviteMemberDialog({ open, onClose, organization, onInvited }) {
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("viewer");
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleSend = async () => {
    if (!email.includes("@")) { setError("Enter a valid email address"); return; }
    setSaving(true);
    setError("");
    try {
      const user = await base44.auth.me();
      const expiresAt = format(addDays(new Date(), 7), "yyyy-MM-dd");

      await base44.entities.OrganizationInvitation.create({
        organization_id: organization.id,
        organization_name: organization.name,
        invited_email: email.toLowerCase().trim(),
        invited_by: user.email,
        role,
        message,
        status: "pending",
        expires_at: expiresAt,
      });

      // Send email invitation
      await base44.integrations.Core.SendEmail({
        to: email.toLowerCase().trim(),
        subject: `You've been invited to join ${organization.name} on Compliance Tracker`,
        body: `
          <h2>You're invited!</h2>
          <p>${user.full_name || user.email} has invited you to join <strong>${organization.name}</strong> on the Compliance Monitoring Platform.</p>
          ${message ? `<p><em>"${message}"</em></p>` : ""}
          <p>Your role will be: <strong>${role.replace("_", " ")}</strong></p>
          <p>Please log in or register to accept this invitation. This invite expires in 7 days.</p>
        `,
      });

      setEmail(""); setRole("viewer"); setMessage("");
      onInvited();
      onClose();
    } catch (e) {
      setError(e.message);
    }
    setSaving(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Invite Member to {organization?.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>Email Address</Label>
            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="user@company.com" type="email" />
          </div>
          <div className="space-y-1.5">
            <Label>Role</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="org_admin">Org Admin</SelectItem>
                <SelectItem value="compliance_manager">Compliance Manager</SelectItem>
                <SelectItem value="auditor">Auditor</SelectItem>
                <SelectItem value="viewer">Viewer</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Personal Message (optional)</Label>
            <Textarea value={message} onChange={e => setMessage(e.target.value)} placeholder="Add a welcome message..." rows={2} />
          </div>
          {error && <p className="text-xs text-red-600">{error}</p>}
        </div>
        <div className="flex justify-end gap-2 pt-2 border-t">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSend} disabled={saving || !email} className="bg-emerald-600 hover:bg-emerald-700">
            {saving ? "Sending..." : "Send Invitation"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}