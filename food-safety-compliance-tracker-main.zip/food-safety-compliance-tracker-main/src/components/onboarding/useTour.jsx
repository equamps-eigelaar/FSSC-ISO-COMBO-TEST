import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const SIGNIN_COUNT_KEY = (email) => `onboarding_signin_count_${email}`;
const COMPLETED_KEY = (email) => `onboarding_completed_${email}`;
const MAX_SHOW_COUNT = 10;

export function useTour() {
  const [showTour, setShowTour] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [tourCompleted, setTourCompleted] = useState(false);
  const [userEmail, setUserEmail] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function init() {
      try {
        const user = await base44.auth.me();
        if (!user?.email || cancelled) return;
        const email = user.email;
        setUserEmail(email);

        const completed = localStorage.getItem(COMPLETED_KEY(email)) === "true";
        if (completed) {
          setTourCompleted(true);
          return;
        }

        const currentCount = parseInt(localStorage.getItem(SIGNIN_COUNT_KEY(email)) || "0", 10);
        const newCount = currentCount + 1;
        localStorage.setItem(SIGNIN_COUNT_KEY(email), String(newCount));

        if (newCount <= MAX_SHOW_COUNT) {
          setShowTour(true);
        }
      } catch (e) {
        // unauthenticated
      }
    }
    init();
    return () => { cancelled = true; };
  }, []);

  const completeTour = () => {
    if (userEmail) localStorage.setItem(COMPLETED_KEY(userEmail), "true");
    setTourCompleted(true);
    setShowTour(false);
  };

  const skipTour = () => {
    setShowTour(false);
  };

  const nextStep = () => setCurrentStep((prev) => prev + 1);

  const resetTour = () => {
    if (userEmail) {
      localStorage.removeItem(COMPLETED_KEY(userEmail));
      localStorage.removeItem(SIGNIN_COUNT_KEY(userEmail));
    }
    setTourCompleted(false);
    setShowTour(true);
    setCurrentStep(0);
  };

  const signInCount = userEmail
    ? parseInt(localStorage.getItem(SIGNIN_COUNT_KEY(userEmail)) || "0", 10)
    : 0;
  const remainingShows = Math.max(0, MAX_SHOW_COUNT - signInCount);

  return {
    showTour,
    currentStep,
    tourCompleted,
    completeTour,
    skipTour,
    nextStep,
    setCurrentStep,
    resetTour,
    signInCount,
    remainingShows,
  };
}