import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, ChevronDown, ChevronUp, ArrowRight, ShieldCheck, ClipboardList, FileText, BarChart3, Users, X } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { useTour } from "./useTour";

const CHECKLIST = [
  { id: "view_dashboard",  icon: ShieldCheck,   title: "View your Dashboard",      page: "Dashboard",          desc: "Get an overview of your compliance score." },
  { id: "browse_reqs",     icon: ClipboardList, title: "Browse Requirements",       page: "Requirements",       desc: "Explore ISO 22000 requirements." },
  { id: "upload_doc",      icon: FileText,      title: "Upload a Document",         page: "DocumentRepository", desc: "Add your first compliance document." },
  { id: "create_risk",     icon: BarChart3,     title: "Create a Risk Assessment",  page: "RiskWorkflow",       desc: "Log a HACCP hazard and controls." },
  { id: "invite_team",     icon: Users,         title: "Invite a Team Member",      page: "UserManagement",     desc: "Add a colleague and assign their role." },
];

const STORAGE_KEY = (email) => `onboarding_checklist_${email}`;

export function useOnboardingChecklist(userEmail) {
  const key = STORAGE_KEY(userEmail);
  const [completed, setCompleted] = useState(() => {
    try { return JSON.parse(localStorage.getItem(key) || "[]"); } catch { return []; }
  });

  const markDone = (id) => {
    const updated = completed.includes(id) ? completed : [...completed, id];
    setCompleted(updated);
    try { localStorage.setItem(key, JSON.stringify(updated)); } catch {}
  };

  const progress = CHECKLIST.filter(c => completed.includes(c.id)).length;
  const isDismissed = () => { try { return localStorage.getItem(`${key}_dismissed`) === "true"; } catch { return false; } };
  const dismiss = () => { try { localStorage.setItem(`${key}_dismissed`, "true"); } catch {} };

  return { completed, markDone, progress, total: CHECKLIST.length, isDismissed, dismiss };
}

export default function OnboardingChecklist({ userEmail }) {
  const { completed, markDone, progress, total, isDismissed, dismiss } = useOnboardingChecklist(userEmail);
  const [expanded, setExpanded] = useState(true);
  const [dismissed, setDismissed] = useState(() => isDismissed());
  const { resetTour } = useTour();

  if (dismissed || progress === total) return null;

  const handleDismiss = () => {
    dismiss();
    setDismissed(true);
  };

  return (
    <div className="bg-white border border-emerald-200 rounded-xl shadow-sm overflow-hidden mb-6">
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 py-3 cursor-pointer bg-emerald-50 hover:bg-emerald-100/60 transition-colors"
        onClick={() => setExpanded(e => !e)}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center flex-shrink-0">
            <ShieldCheck className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-sm font-semibold text-emerald-900">Getting Started Checklist</p>
            <p className="text-xs text-emerald-600">{progress} of {total} steps complete</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Progress ring */}
          <div className="relative w-8 h-8">
            <svg viewBox="0 0 32 32" className="w-8 h-8 -rotate-90">
              <circle cx="16" cy="16" r="12" fill="none" stroke="#d1fae5" strokeWidth="3" />
              <circle cx="16" cy="16" r="12" fill="none" stroke="#059669" strokeWidth="3"
                strokeDasharray={`${(progress / total) * 75.4} 75.4`}
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-emerald-700">
              {Math.round((progress / total) * 100)}%
            </span>
          </div>
          {expanded ? <ChevronUp className="w-4 h-4 text-emerald-600" /> : <ChevronDown className="w-4 h-4 text-emerald-600" />}
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 py-3 space-y-2">
              {CHECKLIST.map(item => {
                const done = completed.includes(item.id);
                return (
                  <div key={item.id} className={`flex items-center gap-3 p-2.5 rounded-lg border transition-colors ${done ? "border-emerald-100 bg-emerald-50/50" : "border-slate-100 hover:border-slate-200 bg-white"}`}>
                    <button
                      onClick={() => markDone(item.id)}
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${done ? "bg-emerald-500 border-emerald-500" : "border-slate-300 hover:border-emerald-400"}`}
                    >
                      {done && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                    </button>
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${done ? "bg-emerald-100" : "bg-slate-100"}`}>
                      <item.icon className={`w-3.5 h-3.5 ${done ? "text-emerald-600" : "text-slate-500"}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium ${done ? "line-through text-slate-400" : "text-slate-700"}`}>{item.title}</p>
                      <p className="text-xs text-slate-400 truncate">{item.desc}</p>
                    </div>
                    {!done && (
                      <Link
                        to={createPageUrl(item.page)}
                        onClick={() => markDone(item.id)}
                        className="flex items-center gap-1 text-[11px] font-medium text-emerald-600 hover:text-emerald-700 flex-shrink-0"
                      >
                        Go <ArrowRight className="w-3 h-3" />
                      </Link>
                    )}
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-between px-4 pb-3 pt-1">
              <button
                onClick={() => { resetTour(); }}
                className="text-xs text-slate-400 hover:text-emerald-600 transition-colors underline underline-offset-2"
              >
                Replay setup guide
              </button>
              <button onClick={handleDismiss} className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-600 transition-colors">
                <X className="w-3 h-3" /> Dismiss
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}