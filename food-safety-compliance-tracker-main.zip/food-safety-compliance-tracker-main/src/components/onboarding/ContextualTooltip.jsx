import React, { useState } from "react";
import { HelpCircle, X } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

/**
 * ContextualTooltip — a small help icon that shows a tooltip/popover on click.
 *
 * Usage:
 *   <ContextualTooltip title="What is a CCP?" side="right">
 *     A Critical Control Point (CCP) is a step in the process where a control
 *     measure can be applied to prevent, eliminate, or reduce a food safety hazard.
 *   </ContextualTooltip>
 */
export default function ContextualTooltip({ title, children, side = "top", className = "" }) {
  const [open, setOpen] = useState(false);

  const positionClasses = {
    top:    "bottom-full left-1/2 -translate-x-1/2 mb-2",
    bottom: "top-full left-1/2 -translate-x-1/2 mt-2",
    left:   "right-full top-1/2 -translate-y-1/2 mr-2",
    right:  "left-full top-1/2 -translate-y-1/2 ml-2",
  };

  const arrowClasses = {
    top:    "top-full left-1/2 -translate-x-1/2 border-l-transparent border-r-transparent border-b-transparent border-t-slate-700",
    bottom: "bottom-full left-1/2 -translate-x-1/2 border-l-transparent border-r-transparent border-t-transparent border-b-slate-700",
    left:   "left-full top-1/2 -translate-y-1/2 border-t-transparent border-b-transparent border-r-transparent border-l-slate-700",
    right:  "right-full top-1/2 -translate-y-1/2 border-t-transparent border-b-transparent border-l-transparent border-r-slate-700",
  };

  return (
    <span className={`relative inline-flex items-center ${className}`}>
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="text-slate-400 hover:text-slate-600 transition-colors focus:outline-none"
        aria-label="Help"
      >
        <HelpCircle className="w-3.5 h-3.5" />
      </button>

      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop to close */}
            <span className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className={`absolute z-50 w-64 bg-slate-800 text-white rounded-xl shadow-xl p-3.5 text-left ${positionClasses[side]}`}
            >
              <div className={`absolute w-0 h-0 border-4 ${arrowClasses[side]}`} />
              {title && (
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-xs font-semibold text-white">{title}</p>
                  <button onClick={() => setOpen(false)} className="text-slate-400 hover:text-white ml-2 flex-shrink-0">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
              <p className="text-xs text-slate-300 leading-relaxed">{children}</p>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </span>
  );
}