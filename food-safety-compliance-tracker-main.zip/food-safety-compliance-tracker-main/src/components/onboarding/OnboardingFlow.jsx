import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import {
  ChevronRight, ChevronLeft, X, ShieldCheck, ClipboardList,
  FileText, BarChart3, Users, Zap, CheckCircle2, ArrowRight,
  Building2, Globe, Factory, Star,
} from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

const STEPS = [
  { id: "welcome",  title: "Welcome" },
  { id: "profile",  title: "Your Profile" },
  { id: "features", title: "Key Features" },
  { id: "checklist",title: "Setup Checklist" },
];

const FEATURES = [
  { icon: ShieldCheck, color: "bg-emerald-100 text-emerald-700", title: "Compliance Tracking", desc: "Manage all ISO 22000 & TS 22002-4 requirements. Track progress, assign owners, and upload evidence." },
  { icon: ClipboardList, color: "bg-blue-100 text-blue-700", title: "Audit Preparation", desc: "Run field audits, checklists, and HACCP plans. Generate audit-ready reports with one click." },
  { icon: FileText, color: "bg-violet-100 text-violet-700", title: "Document Repository", desc: "Store, version, and link compliance documents to requirements. AI-powered analysis flags gaps automatically." },
  { icon: BarChart3, color: "bg-amber-100 text-amber-700", title: "Risk Management", desc: "Identify hazards, assess likelihood and severity, create HACCP CCPs, and track mitigation progress." },
  { icon: Users, color: "bg-rose-100 text-rose-700", title: "Team Collaboration", desc: "Assign sections to team members, manage approvals, and communicate via comments and tasks." },
  { icon: Zap, color: "bg-cyan-100 text-cyan-700", title: "AI-Powered Insights", desc: "Get AI-generated compliance summaries, risk recommendations, and audit prep suggestions." },
];

const ROLE_LABELS = {
  admin: "Administrator", compliance_manager: "Compliance Manager", auditor: "Auditor",
  food_safety_manager: "Food Safety Manager", site_manager: "Site Manager",
  production_operator: "Production Operator", quality_auditor: "Quality Auditor", user: "Team Member",
};

const CHECKLIST_BY_ROLE = {
  admin: [
    { id: "invite_users",    icon: Users,        title: "Invite Your Team",         desc: "Add team members and assign roles.", page: "UserManagement",   tip: "Go to User Management → Invite User. Assign roles like Compliance Manager or Auditor." },
    { id: "view_reqs",       icon: ClipboardList, title: "Review Requirements",      desc: "Browse ISO 22000 requirement sections.", page: "Requirements", tip: "Requirements are grouped by ISO 22000 sections 4–10. Start with Section 4 to set context." },
    { id: "upload_doc",      icon: FileText,      title: "Upload a Document",        desc: "Add your first compliance document.", page: "DocumentRepository", tip: "Upload SOPs, policies, or certificates. AI will analyse compliance gaps automatically." },
    { id: "explore_risks",   icon: BarChart3,     title: "Start Risk Assessment",    desc: "Create your first HACCP hazard.", page: "RiskWorkflow",       tip: "Use the HACCP decision tree to classify hazards as CCPs or OPRPs." },
    { id: "check_dashboard", icon: ShieldCheck,   title: "Review the Dashboard",     desc: "See your compliance overview.", page: "Dashboard",            tip: "The dashboard shows your overall compliance score, outstanding actions, and risk alerts." },
  ],
  compliance_manager: [
    { id: "view_reqs",     icon: ClipboardList, title: "Review Requirements",     desc: "Browse and update requirement statuses.", page: "Requirements",     tip: "Filter by status: Not Started, In Progress, or Compliant. Assign owners per section." },
    { id: "create_risk",   icon: BarChart3,     title: "Create a Risk Record",    desc: "Log a HACCP hazard and controls.", page: "RiskWorkflow",           tip: "Complete the HACCP decision tree to determine if a hazard is a CCP or OPRP." },
    { id: "upload_doc",    icon: FileText,      title: "Upload Evidence",         desc: "Link documents to requirements.", page: "DocumentRepository",       tip: "Tag documents with categories and link them directly to compliance requirements." },
    { id: "gen_report",    icon: Zap,           title: "Generate a Report",       desc: "Create your first compliance report.", page: "Reports",            tip: "AI-powered reports summarise your compliance score and highlight critical gaps." },
  ],
  auditor: [
    { id: "audit_prep",   icon: ShieldCheck,   title: "Audit Preparation",      desc: "Set up your first audit checklist.", page: "AuditPrep",             tip: "Use Audit Prep to create a pre-audit checklist and assign evidence requirements." },
    { id: "field_audit",  icon: ClipboardList, title: "Run a Field Audit",       desc: "Conduct a mobile on-site audit.", page: "MobileAudit",             tip: "Field Audits work offline — sync when you reconnect." },
    { id: "upload_doc",   icon: FileText,      title: "Upload Findings",         desc: "Upload audit evidence documents.", page: "DocumentRepository",      tip: "Tag findings as Audit Reports for easy filtering and retrieval." },
  ],
  default: [
    { id: "view_reqs",     icon: ClipboardList, title: "Browse Requirements",     desc: "Explore the ISO 22000 requirements.", page: "Requirements",       tip: "Find your assigned sections and update progress as you complete tasks." },
    { id: "view_dash",     icon: ShieldCheck,   title: "Check the Dashboard",     desc: "See your site's compliance status.", page: "Dashboard",            tip: "The dashboard shows key compliance metrics, upcoming due dates, and recent activity." },
    { id: "upload_doc",    icon: FileText,      title: "Upload a Document",       desc: "Contribute compliance evidence.", page: "DocumentRepository",       tip: "Upload certificates, procedures, or inspection records." },
  ],
};

export default function OnboardingFlow({ onComplete, onSkip }) {
  const [stepIndex, setStepIndex] = useState(0);
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState({ company: "", industry: "", sites: "1", framework: "iso22000" });
  const [completedItems, setCompletedItems] = useState([]);
  const navigate = useNavigate();
  const currentStep = STEPS[stepIndex];
  const isFirst = stepIndex === 0;
  const isLast = stepIndex === STEPS.length - 1;

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      if (u?.full_name) setProfile(p => ({ ...p, company: p.company }));
    }).catch(() => {});
  }, []);

  const checklist = CHECKLIST_BY_ROLE[user?.role] || CHECKLIST_BY_ROLE.default;
  const userName = user?.full_name?.split(" ")[0] || "there";

  const goNext = () => { if (!isLast) setStepIndex(i => i + 1); };
  const goPrev = () => { if (!isFirst) setStepIndex(i => i - 1); };

  const handleNavigate = (page) => {
    onComplete();
    navigate(createPageUrl(page));
  };

  const saveProfileAndContinue = async () => {
    try {
      if (profile.company) {
        await base44.auth.updateMe({ onboarding_profile: profile });
      }
    } catch (_) {}
    goNext();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep.id}
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -24 }}
          transition={{ duration: 0.25 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto relative"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 pt-5 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-semibold text-slate-700">ISO 22000:2018 - 6 version 2 Compliance Setup</span>
            </div>
            <button onClick={onSkip} className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors" title="Skip onboarding">
              <X className="w-4 h-4 text-slate-400" />
            </button>
          </div>

          {/* Step tabs */}
          <div className="flex border-b border-slate-100">
            {STEPS.map((s, i) => (
              <div
                key={s.id}
                className={`flex-1 text-center text-xs py-2.5 font-medium transition-colors ${
                  i === stepIndex ? "text-emerald-700 border-b-2 border-emerald-600 bg-emerald-50/40"
                  : i < stepIndex ? "text-emerald-500 cursor-pointer hover:bg-slate-50"
                  : "text-slate-400"
                }`}
                onClick={() => i < stepIndex && setStepIndex(i)}
              >
                {i < stepIndex ? <span className="mr-1">✓</span> : <span className="mr-1">{i + 1}.</span>}
                {s.title}
              </div>
            ))}
          </div>

          {/* Content */}
          <div className="px-6 py-6">
            {currentStep.id === "welcome"   && <WelcomeStep   userName={userName} userRole={user?.role} />}
            {currentStep.id === "profile"   && <ProfileStep   profile={profile} setProfile={setProfile} />}
            {currentStep.id === "features"  && <FeaturesStep  userRole={user?.role} />}
            {currentStep.id === "checklist" && <ChecklistStep checklist={checklist} completedItems={completedItems} setCompletedItems={setCompletedItems} userRole={user?.role} onNavigate={handleNavigate} onComplete={onComplete} />}
          </div>

          {/* Nav footer */}
          {currentStep.id !== "checklist" && (
            <div className="flex items-center justify-between px-6 pb-5">
              <Button variant="ghost" size="sm" onClick={goPrev} disabled={isFirst} className="text-slate-500 gap-1">
                <ChevronLeft className="w-4 h-4" />Back
              </Button>
              <Button
                size="sm"
                onClick={currentStep.id === "profile" ? saveProfileAndContinue : goNext}
                className="bg-emerald-600 hover:bg-emerald-700 gap-1"
              >
                {stepIndex === STEPS.length - 2 ? "See Setup Checklist" : "Next"}
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function WelcomeStep({ userName, userRole }) {
  return (
    <div className="text-center py-4">
      <div className="text-6xl mb-4">🏭</div>
      <h1 className="text-2xl font-bold text-slate-900 mb-2">
        Welcome{userName !== "there" ? `, ${userName}` : ""}!
      </h1>
      {userRole && ROLE_LABELS[userRole] && (
        <div className="mb-3">
          <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 text-xs">
            {ROLE_LABELS[userRole]}
          </Badge>
        </div>
      )}
      <p className="text-slate-500 leading-relaxed max-w-md mx-auto mb-6">
        This short guide will help you set up your compliance profile, understand key features, and complete your initial configuration — tailored to your role.
      </p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-w-md mx-auto">
        {[
          { icon: "⏱️", text: "5 min setup" },
          { icon: "🎯", text: "Role-tailored" },
          { icon: "💡", text: "Guided tips" },
          { icon: "✅", text: "Checklist" },
        ].map(item => (
          <div key={item.text} className="bg-slate-50 rounded-xl p-3 text-center">
            <div className="text-xl mb-1">{item.icon}</div>
            <p className="text-xs text-slate-600 font-medium">{item.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProfileStep({ profile, setProfile }) {
  return (
    <div>
      <div className="text-center mb-6">
        <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mx-auto mb-3">
          <Building2 className="w-6 h-6 text-blue-600" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Set Up Your Compliance Profile</h2>
        <p className="text-sm text-slate-500 mt-1">Help us personalise your experience</p>
      </div>
      <div className="space-y-4 max-w-md mx-auto">
        <div>
          <Label htmlFor="company" className="text-sm font-medium text-slate-700 flex items-center gap-1.5 mb-1.5">
            <Building2 className="w-3.5 h-3.5 text-slate-400" /> Company / Organisation Name
          </Label>
          <Input
            id="company"
            placeholder="e.g. Acme Packaging Ltd"
            value={profile.company}
            onChange={e => setProfile(p => ({ ...p, company: e.target.value }))}
          />
        </div>
        <div>
          <Label className="text-sm font-medium text-slate-700 flex items-center gap-1.5 mb-1.5">
            <Factory className="w-3.5 h-3.5 text-slate-400" /> Industry / Product Type
          </Label>
          <Select value={profile.industry} onValueChange={v => setProfile(p => ({ ...p, industry: v }))}>
            <SelectTrigger><SelectValue placeholder="Select your industry…" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="food_packaging">Food Packaging</SelectItem>
              <SelectItem value="beverage_packaging">Beverage Packaging</SelectItem>
              <SelectItem value="flexible_packaging">Flexible Packaging</SelectItem>
              <SelectItem value="rigid_packaging">Rigid Packaging (PET/HDPE)</SelectItem>
              <SelectItem value="paper_board">Paper & Paperboard</SelectItem>
              <SelectItem value="metal_cans">Metal Cans & Closures</SelectItem>
              <SelectItem value="glass">Glass Containers</SelectItem>
              <SelectItem value="labels_printing">Labels & Printing</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-sm font-medium text-slate-700 flex items-center gap-1.5 mb-1.5">
            <Globe className="w-3.5 h-3.5 text-slate-400" /> Number of Sites
          </Label>
          <Select value={profile.sites} onValueChange={v => setProfile(p => ({ ...p, sites: v }))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 site</SelectItem>
              <SelectItem value="2-5">2–5 sites</SelectItem>
              <SelectItem value="6-20">6–20 sites</SelectItem>
              <SelectItem value="20+">20+ sites</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-sm font-medium text-slate-700 flex items-center gap-1.5 mb-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" /> Primary Compliance Framework
          </Label>
          <Select value={profile.framework} onValueChange={v => setProfile(p => ({ ...p, framework: v }))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="iso22000">ISO 22000:2018</SelectItem>
              <SelectItem value="fssc22000">ISO 22000:2018 - 6 version 2</SelectItem>
              <SelectItem value="ts22002_4">TS 22002-4 (Packaging)</SelectItem>
              <SelectItem value="haccp_only">HACCP only</SelectItem>
              <SelectItem value="multiple">Multiple frameworks</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <p className="text-xs text-slate-400 text-center pt-1">This information is used to personalise your experience. You can update it anytime in Settings.</p>
      </div>
    </div>
  );
}

function FeaturesStep({ userRole }) {
  const roleFeatureOrder = {
    admin: ["Compliance Tracking", "Team Collaboration", "AI-Powered Insights", "Document Repository", "Audit Preparation", "Risk Management"],
    compliance_manager: ["Compliance Tracking", "Risk Management", "AI-Powered Insights", "Document Repository", "Audit Preparation", "Team Collaboration"],
    auditor: ["Audit Preparation", "Document Repository", "Compliance Tracking", "Risk Management", "AI-Powered Insights", "Team Collaboration"],
    food_safety_manager: ["Risk Management", "Compliance Tracking", "AI-Powered Insights", "Document Repository", "Audit Preparation", "Team Collaboration"],
    production_operator: ["Compliance Tracking", "Document Repository", "Team Collaboration", "Audit Preparation", "Risk Management", "AI-Powered Insights"],
  };
  const order = roleFeatureOrder[userRole];
  const orderedFeatures = order
    ? [...FEATURES].sort((a, b) => {
        const ai = order.indexOf(a.title), bi = order.indexOf(b.title);
        return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
      })
    : FEATURES;

  return (
    <div>
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-slate-900">Everything you need in one platform</h2>
        <p className="text-sm text-slate-500 mt-1">
          {order ? "Key modules for your role — highlighted first" : "Core modules available to your team"}
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {orderedFeatures.map((f, idx) => (
          <div key={f.title} className={`flex gap-3 p-3 rounded-xl border transition-colors ${idx === 0 && order ? "border-emerald-200 bg-emerald-50/50" : "border-slate-100 hover:border-slate-200"}`}>
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${f.color}`}>
              <f.icon className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <p className="text-sm font-semibold text-slate-800">{f.title}</p>
                {idx === 0 && order && <Badge className="text-[10px] px-1.5 py-0 bg-emerald-100 text-emerald-700 border-0">Top Pick</Badge>}
              </div>
              <p className="text-xs text-slate-500 leading-relaxed mt-0.5">{f.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ChecklistStep({ checklist, completedItems, setCompletedItems, userRole, onNavigate, onComplete }) {
  const [activeTip, setActiveTip] = useState(null);
  const done = completedItems.length;
  const total = checklist.length;
  const allDone = done === total;

  const toggle = (id) => setCompletedItems(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  return (
    <div>
      <div className="text-center mb-5">
        <div className="text-4xl mb-2">🚀</div>
        <h2 className="text-xl font-bold text-slate-900">Your Setup Checklist</h2>
        <p className="text-sm text-slate-500 mt-1">
          {userRole && ROLE_LABELS[userRole] ? `Recommended first steps for a ${ROLE_LABELS[userRole]}` : "Recommended first steps"}
        </p>
      </div>

      {/* Progress bar */}
      <div className="mb-5">
        <div className="flex justify-between text-xs text-slate-500 mb-1.5">
          <span>{done} of {total} completed</span>
          <span>{Math.round((done / total) * 100)}%</span>
        </div>
        <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
          <motion.div
            className="h-full bg-emerald-500 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${(done / total) * 100}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>

      <div className="space-y-2.5 mb-4">
        {checklist.map((item) => {
          const isDone = completedItems.includes(item.id);
          const isTipOpen = activeTip === item.id;
          return (
            <div key={item.id} className={`rounded-xl border transition-all ${isDone ? "border-emerald-200 bg-emerald-50/50" : "border-slate-200 bg-white"}`}>
              <div className="flex items-center gap-3 p-3">
                <button
                  onClick={() => toggle(item.id)}
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${isDone ? "bg-emerald-500 border-emerald-500" : "border-slate-300 hover:border-emerald-400"}`}
                >
                  {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                </button>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${isDone ? "bg-emerald-100" : "bg-slate-100"}`}>
                  <item.icon className={`w-4 h-4 ${isDone ? "text-emerald-600" : "text-slate-500"}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-semibold ${isDone ? "line-through text-slate-400" : "text-slate-800"}`}>{item.title}</p>
                  <p className="text-xs text-slate-500 truncate">{item.desc}</p>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <button
                    onClick={() => setActiveTip(isTipOpen ? null : item.id)}
                    className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 hover:bg-amber-200 transition-colors"
                    title="Show tip"
                  >
                    💡 Tip
                  </button>
                  <button
                    onClick={() => onNavigate(item.page)}
                    className="flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
                  >
                    Go <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
              <AnimatePresence>
                {isTipOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-3 pt-1 ml-8 border-t border-amber-100">
                      <p className="text-xs text-amber-800 bg-amber-50 rounded-lg p-2.5 leading-relaxed">
                        💡 <strong>Tip:</strong> {item.tip}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {allDone ? (
        <div className="text-center">
          <div className="text-3xl mb-2">🎉</div>
          <p className="text-sm font-semibold text-emerald-700 mb-3">All steps complete — you're all set!</p>
          <Button onClick={onComplete} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
            Go to Dashboard <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      ) : (
        <div className="text-center">
          <Button onClick={onComplete} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
            Go to Dashboard <ArrowRight className="w-4 h-4" />
          </Button>
          <p className="text-xs text-slate-400 mt-2">You can revisit this checklist anytime from the Dashboard.</p>
        </div>
      )}
    </div>
  );
}