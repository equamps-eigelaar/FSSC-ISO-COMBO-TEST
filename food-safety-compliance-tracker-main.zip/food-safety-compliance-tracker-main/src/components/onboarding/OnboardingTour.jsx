import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight, X, SkipForward } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

const TOUR_STEPS = [
  {
    title: "Welcome to Package Manufacturing Compliance!",
    description: "This guided tour will help you understand the key features. Let's get started!",
    icon: "🎯",
    highlight: null,
    action: "next",
  },
  {
    title: "Dashboard Overview",
    description: "The dashboard shows your compliance status, upcoming actions, and key metrics at a glance. This is your command center.",
    icon: "📊",
    highlight: null,
    action: "next",
  },
  {
    title: "Requirements Page",
    description: "Manage all compliance requirements organized by ISO-22000-2018 and FSSC 22000 V6 sections. Track status, update progress, and upload evidence documents.",
    icon: "✓",
    page: "Requirements",
    highlight: "nav-requirements",
    action: "navigate",
  },
  {
    title: "Section Assignments",
    description: "Configure role-based access control. Assign users to specific sections with granular permissions like View, Edit, and Approve.",
    icon: "👥",
    page: "Settings",
    highlight: null,
    action: "navigate",
  },
  {
    title: "Permission System",
    description: "The permission system lets admins control who can edit, approve, and view requirements based on their section assignments and role.",
    icon: "🔐",
    highlight: null,
    action: "next",
  },
  {
    title: "Risk Management",
    description: "Identify and manage risks, create HACCP plans, and link them to requirements. Track mitigation strategies and residual risk levels.",
    icon: "⚠️",
    page: "RiskWorkflow",
    highlight: null,
    action: "navigate",
  },
  {
    title: "Documents & Evidence",
    description: "Upload and organize compliance evidence, certificates, and audit reports. Link documents to specific requirements.",
    icon: "📄",
    page: "DocumentRepository",
    highlight: null,
    action: "navigate",
  },
  {
    title: "You're All Set!",
    description: "You now understand the core features. Start by exploring the Requirements page and setting up section assignments for your team.",
    icon: "🚀",
    highlight: null,
    action: "complete",
  },
];

export default function OnboardingTour({ show, currentStep, onNext, onSkip, onComplete }) {
  if (!show) return null;

  const step = TOUR_STEPS[currentStep] || TOUR_STEPS[0];
  const totalSteps = TOUR_STEPS.length;
  const isLastStep = currentStep === totalSteps - 1;
  const navigateToPage = step.page ? createPageUrl(step.page) : null;

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={currentStep}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
      >
        <Card className="w-full max-w-md border-slate-200 shadow-2xl">
          <CardContent className="pt-6">
            {/* Close button */}
            <button
              onClick={onSkip}
              className="absolute right-4 top-4 p-1 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5 text-slate-400" />
            </button>

            {/* Icon */}
            <div className="text-5xl mb-4">{step.icon}</div>

            {/* Title */}
            <h2 className="text-xl font-bold text-slate-900 mb-2">{step.title}</h2>

            {/* Description */}
            <p className="text-sm text-slate-600 mb-6 leading-relaxed">{step.description}</p>

            {/* Progress */}
            <div className="mb-6">
              <div className="flex gap-1 mb-2">
                {Array.from({ length: totalSteps }).map((_, i) => (
                  <div
                    key={i}
                    className={`h-1 flex-1 rounded-full transition-colors ${
                      i <= currentStep ? "bg-emerald-600" : "bg-slate-200"
                    }`}
                  />
                ))}
              </div>
              <p className="text-xs text-slate-400">
                Step {currentStep + 1} of {totalSteps}
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={onSkip}
                className="gap-1 text-slate-600 hover:text-slate-700"
              >
                <SkipForward className="w-4 h-4" />
                Skip Tour
              </Button>
              {navigateToPage ? (
                <Link to={navigateToPage} className="flex-1">
                  <Button onClick={onNext} className="w-full bg-emerald-600 hover:bg-emerald-700 gap-1">
                    Go to {step.page}
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </Link>
              ) : isLastStep ? (
                <Button onClick={onComplete} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
                  Get Started
                </Button>
              ) : (
                <Button onClick={onNext} className="flex-1 bg-emerald-600 hover:bg-emerald-700 gap-1">
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}