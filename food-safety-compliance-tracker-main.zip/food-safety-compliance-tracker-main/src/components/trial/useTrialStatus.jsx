import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { differenceInDays, parseISO, isAfter } from "date-fns";

export function useTrialStatus() {
  const [trialStatus, setTrialStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function checkTrial() {
      try {
        const user = await base44.auth.me();
        if (!user) { setLoading(false); return; }

        // Look for existing subscription record for this user
        const subs = await base44.entities.Subscription.filter({ user_email: user.email });
        const sub = subs?.[0];

        if (!sub) {
          // First time user — create a 7-day trial record
          const today = new Date();
          const trialEnd = new Date(today);
          trialEnd.setDate(trialEnd.getDate() + 7);

          const newSub = await base44.entities.Subscription.create({
            user_email: user.email,
            status: "trialing",
            trial_start_date: today.toISOString().split("T")[0],
            trial_end_date: trialEnd.toISOString().split("T")[0],
          });
          setTrialStatus({
            status: "trialing",
            daysLeft: 7,
            trialEndDate: trialEnd,
            subscription: newSub,
          });
        } else if (sub.status === "trialing") {
          const trialEnd = parseISO(sub.trial_end_date);
          const now = new Date();
          const daysLeft = differenceInDays(trialEnd, now);

          if (daysLeft < 0) {
            // Trial has expired — update status
            await base44.entities.Subscription.update(sub.id, { status: "trial_expired" });
            setTrialStatus({ status: "trial_expired", daysLeft: 0, trialEndDate: trialEnd, subscription: sub });
          } else {
            setTrialStatus({ status: "trialing", daysLeft, trialEndDate: trialEnd, subscription: sub });
          }
        } else {
          setTrialStatus({ status: sub.status, daysLeft: 0, subscription: sub });
        }
      } catch (e) {
        console.error("Trial check error:", e);
      } finally {
        setLoading(false);
      }
    }
    checkTrial();
  }, []);

  return { trialStatus, loading };
}