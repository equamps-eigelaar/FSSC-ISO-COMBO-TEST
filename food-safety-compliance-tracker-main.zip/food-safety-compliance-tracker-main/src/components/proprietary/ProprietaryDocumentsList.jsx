import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { FileText, Download, Share2, Trash2, Eye, Lock, Loader2 } from "lucide-react";
import { format } from "date-fns";
import ProprietaryShareDialog from "./ProprietaryShareDialog";

export default function ProprietaryDocumentsList({ onDelete }) {
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [shareDoc, setShareDoc] = useState(null);

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ["proprietary-documents"],
    queryFn: () =>
      base44.entities.Document.filter(
        { 
          control_status: "controlled",
          document_type: ["recipe", "raw_material", "manufacturing_process", "specification", "other"]
        },
        "-created_date",
        100
      ),
  });

  const classificationColors = {
    recipe: "bg-purple-100 text-purple-800",
    raw_material: "bg-blue-100 text-blue-800",
    manufacturing_process: "bg-indigo-100 text-indigo-800",
    specification: "bg-green-100 text-green-800",
    other: "bg-slate-100 text-slate-800",
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
      </div>
    );
  }

  if (documents.length === 0) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="p-12 text-center">
          <Lock className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-600 font-medium">No proprietary documents yet</p>
          <p className="text-sm text-slate-500 mt-1">Upload your first secure document to get started</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="grid gap-4">
        {documents.map((doc) => (
          <Card key={doc.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                    <h3 className="font-semibold text-slate-900 truncate">{doc.file_name}</h3>
                    <Badge className={classificationColors[doc.document_type]}>
                      {doc.document_type?.replace(/_/g, " ")}
                    </Badge>
                  </div>

                  {doc.description && (
                    <p className="text-sm text-slate-600 mb-2">{doc.description}</p>
                  )}

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
                    <span>{(doc.file_size / 1024).toFixed(1)} KB</span>
                    <span>•</span>
                    <span>Uploaded {format(new Date(doc.created_date), "MMM d, yyyy")}</span>
                    <span>•</span>
                    <span>by {doc.uploaded_by}</span>
                  </div>

                  {doc.tags?.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {doc.tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-xs px-2 py-1 bg-slate-100 text-slate-700 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedDoc(doc)}
                    className="h-8 px-2"
                    title="View Details"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => window.open(doc.file_url, "_blank")}
                    className="h-8 px-2"
                    title="Download"
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShareDoc(doc)}
                    className="h-8 px-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                    title="Share Access"
                  >
                    <Share2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDelete(doc)}
                    className="h-8 px-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Document Details Dialog */}
      {selectedDoc && (
        <Dialog open={!!selectedDoc} onOpenChange={(open) => !open && setSelectedDoc(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-slate-600" />
                {selectedDoc.file_name}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <h4 className="text-xs font-semibold text-slate-600 uppercase mb-1">Classification</h4>
                <Badge className={classificationColors[selectedDoc.document_type]}>
                  {selectedDoc.document_type?.replace(/_/g, " ")}
                </Badge>
              </div>

              {selectedDoc.description && (
                <div>
                  <h4 className="text-xs font-semibold text-slate-600 uppercase mb-1">Description</h4>
                  <p className="text-sm text-slate-700">{selectedDoc.description}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-xs font-semibold text-slate-600 uppercase mb-1">File Size</h4>
                  <p className="text-sm text-slate-700">{(selectedDoc.file_size / 1024).toFixed(1)} KB</p>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-600 uppercase mb-1">Upload Date</h4>
                  <p className="text-sm text-slate-700">
                    {format(new Date(selectedDoc.created_date), "MMM d, yyyy h:mm a")}
                  </p>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-600 uppercase mb-1">Uploaded By</h4>
                  <p className="text-sm text-slate-700">{selectedDoc.uploaded_by}</p>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-600 uppercase mb-1">Control Status</h4>
                  <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-indigo-200">
                    {selectedDoc.control_status}
                  </Badge>
                </div>
              </div>

              {selectedDoc.tags?.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold text-slate-600 uppercase mb-2">Tags</h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedDoc.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs px-2 py-1 bg-slate-100 text-slate-700 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <p className="text-xs text-amber-800">
                  <strong>Security:</strong> This document is encrypted and access is restricted to authorized personnel only.
                  All access is logged for audit purposes.
                </p>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Share Dialog */}
      {shareDoc && (
        <ProprietaryShareDialog 
          document={shareDoc} 
          open={!!shareDoc} 
          onClose={() => setShareDoc(null)} 
        />
      )}
    </>
  );
}