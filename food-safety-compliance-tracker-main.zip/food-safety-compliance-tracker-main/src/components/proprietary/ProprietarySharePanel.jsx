import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lock, Share2, Trash2, Eye, Download, XCircle, Calendar } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ProprietarySharePanel() {
  const [expandedShare, setExpandedShare] = useState(null);
  const queryClient = useQueryClient();

  const { data: shares = [], isLoading } = useQuery({
    queryKey: ["proprietary-shares"],
    queryFn: () => base44.entities.ProprietaryShare.list("-share_date", 100),
  });

  const { mutate: revokeShare } = useMutation({
    mutationFn: async (shareId) => {
      await base44.entities.ProprietaryShare.update(shareId, { status: "revoked" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["proprietary-shares"] });
      toast.success("Share revoked");
    },
    onError: () => {
      toast.error("Failed to revoke share");
    }
  });

  const activeShares = shares.filter(s => s.status === "active");
  const revokedShares = shares.filter(s => s.status === "revoked");

  if (isLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="p-8 text-center">
          <div className="w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Active Shares */}
      <div>
        <h3 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
          <Share2 className="w-4 h-4 text-emerald-600" />
          Active Shares ({activeShares.length})
        </h3>

        {activeShares.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-6 text-center">
              <Lock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-sm text-slate-500">No active proprietary shares</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {activeShares.map(share => (
              <Card key={share.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="text-sm font-semibold text-slate-900 truncate">
                          {share.document_name}
                        </h4>
                        <Badge className="bg-emerald-100 text-emerald-800 text-xs">
                          {share.share_type}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {share.recipients?.length || 0} recipient{share.recipients?.length !== 1 ? "s" : ""}
                        </Badge>
                      </div>

                      <div className="text-xs text-slate-500 space-y-1">
                        <p>Shared by <span className="font-medium">{share.shared_by}</span></p>
                        <p className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(share.share_date), "MMM d, yyyy h:mm a")}
                        </p>
                        {share.notes && (
                          <p className="text-slate-600 mt-2 italic">{share.notes}</p>
                        )}
                      </div>

                      {/* Recipients Preview */}
                      {share.recipients?.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-slate-200">
                          <p className="text-xs font-medium text-slate-700 mb-2">Recipients:</p>
                          <div className="flex flex-wrap gap-2">
                            {share.recipients.slice(0, 3).map((r, idx) => (
                              <div key={idx} className="text-xs px-2 py-1 bg-slate-50 rounded border border-slate-200">
                                <div className="font-mono text-slate-700">{r.recipient_email}</div>
                                <div className="text-slate-500">{r.recipient_type} • {r.access_level}</div>
                              </div>
                            ))}
                            {share.recipients.length > 3 && (
                              <div className="text-xs px-2 py-1 bg-slate-50 rounded border border-slate-200">
                                +{share.recipients.length - 3} more
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Download/Access Stats */}
                      {(share.download_count > 0 || share.last_accessed) && (
                        <div className="mt-3 pt-3 border-t border-slate-200">
                          <p className="text-xs text-slate-600">
                            {share.download_count} downloads
                            {share.last_accessed && ` • Last accessed ${format(new Date(share.last_accessed), "MMM d")}`}
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setExpandedShare(expandedShare === share.id ? null : share.id)}
                        className="h-8 px-2"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => revokeShare(share.id)}
                        className="h-8 px-2 text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {expandedShare === share.id && (
                    <div className="mt-4 pt-4 border-t border-slate-200">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        {share.recipients?.map((r, idx) => (
                          <div key={idx} className="bg-slate-50 p-2 rounded">
                            <div className="font-medium text-slate-900">{r.recipient_email}</div>
                            <div className="text-slate-600 mt-1">
                              <p>Type: <span className="font-mono">{r.recipient_type}</span></p>
                              <p>Access: <span className="font-mono">{r.access_level}</span></p>
                              {r.expiry_date && (
                                <p>Expires: {format(new Date(r.expiry_date), "MMM d, yyyy")}</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                      {share.link_expires_at && (
                        <div className="mt-3 p-2 bg-amber-50 border border-amber-200 rounded text-xs">
                          <p className="text-amber-700">Link expires: {format(new Date(share.link_expires_at), "MMM d, yyyy")}</p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Revoked Shares */}
      {revokedShares.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
            <XCircle className="w-4 h-4 text-slate-400" />
            Revoked Shares ({revokedShares.length})
          </h3>
          <div className="space-y-2">
            {revokedShares.map(share => (
              <Card key={share.id} className="border-0 shadow-sm opacity-60">
                <CardContent className="p-3">
                  <div className="text-xs">
                    <p className="font-medium text-slate-600">{share.document_name}</p>
                    <p className="text-slate-500 mt-1">Revoked on {format(new Date(share.created_date), "MMM d, yyyy")}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}