import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Plus, Copy, Check, Lock } from "lucide-react";
import { toast } from "sonner";

export default function ProprietaryShareDialog({ document, open, onClose }) {
  const [recipients, setRecipients] = useState([]);
  const [newRecipient, setNewRecipient] = useState({ email: "", type: "internal", access_level: "view_only" });
  const [notes, setNotes] = useState("");
  const [linkExpireDays, setLinkExpireDays] = useState("30");
  const [copiedToken, setCopiedToken] = useState(null);

  const queryClient = useQueryClient();

  const { mutate: createShare, isPending } = useMutation({
    mutationFn: async () => {
      if (recipients.length === 0) {
        throw new Error("Add at least one recipient");
      }
      const result = await base44.functions.invoke("createProprietaryShare", {
        document_id: document.id,
        document_name: document.file_name,
        share_type: document.document_type === "specification" ? "recipe" : "raw_material",
        recipients,
        notes,
        link_expires_days: parseInt(linkExpireDays)
      });
      return result.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["proprietary-shares"] });
      toast.success("Proprietary share created successfully");
      setTimeout(() => {
        onClose();
        resetForm();
      }, 1000);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create share");
    }
  });

  const resetForm = () => {
    setRecipients([]);
    setNewRecipient({ email: "", type: "internal", access_level: "view_only" });
    setNotes("");
    setLinkExpireDays("30");
    setCopiedToken(null);
  };

  const addRecipient = () => {
    if (!newRecipient.email) {
      toast.error("Enter email address");
      return;
    }
    setRecipients([...recipients, { ...newRecipient, id: Math.random() }]);
    setNewRecipient({ email: "", type: "internal", access_level: "view_only" });
  };

  const removeRecipient = (id) => {
    setRecipients(recipients.filter(r => r.id !== id));
  };

  const copyToClipboard = (token) => {
    navigator.clipboard.writeText(token);
    setCopiedToken(token);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  if (!document) return null;

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-600" />
            Share Proprietary Information
          </DialogTitle>
          <DialogDescription>
            {document.file_name} - Restricted to Admin/Auditors
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Document Info */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <p className="text-xs text-amber-800 font-medium mb-1">⚠️ Proprietary Content</p>
            <p className="text-xs text-amber-700">This document contains sensitive proprietary information about recipes or raw materials.</p>
          </div>

          {/* Recipients */}
          <div>
            <label className="text-sm font-semibold text-slate-900 mb-3 block">Recipients</label>
            
            {/* Add Recipient */}
            <div className="space-y-3 mb-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <Input
                  placeholder="Email address"
                  value={newRecipient.email}
                  onChange={(e) => setNewRecipient({ ...newRecipient, email: e.target.value })}
                  className="text-xs"
                />
                <Select value={newRecipient.type} onValueChange={(type) => setNewRecipient({ ...newRecipient, type })}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="internal">Internal</SelectItem>
                    <SelectItem value="external">External</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={newRecipient.access_level} onValueChange={(access_level) => setNewRecipient({ ...newRecipient, access_level })}>
                  <SelectTrigger className="text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="view_only">View Only</SelectItem>
                    <SelectItem value="download">Download</SelectItem>
                    <SelectItem value="full_access">Full Access</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button size="sm" onClick={addRecipient} className="w-full" variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Recipient
              </Button>
            </div>

            {/* Recipients List */}
            {recipients.length > 0 && (
              <div className="space-y-2">
                {recipients.map(r => (
                  <div key={r.id} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg text-xs">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-slate-900 truncate">{r.email}</div>
                      <div className="flex gap-1.5 mt-1">
                        <Badge variant="secondary" className="text-xs">{r.type}</Badge>
                        <Badge variant="outline" className="text-xs">{r.access_level}</Badge>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeRecipient(r.id)}
                      className="h-6 w-6 p-0 shrink-0"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Link Expiry */}
          <div>
            <label className="text-sm font-semibold text-slate-900 mb-2 block">Link Expiration</label>
            <Select value={linkExpireDays} onValueChange={setLinkExpireDays}>
              <SelectTrigger className="text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">7 days</SelectItem>
                <SelectItem value="30">30 days</SelectItem>
                <SelectItem value="90">90 days</SelectItem>
                <SelectItem value="365">1 year</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Notes */}
          <div>
            <label className="text-sm font-semibold text-slate-900 mb-2 block">Notes (optional)</label>
            <Textarea
              placeholder="Reason for sharing, restrictions, or special instructions..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="text-xs"
              rows={3}
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2 border-t pt-4">
          <Button variant="outline" onClick={onClose} disabled={isPending}>
            Cancel
          </Button>
          <Button onClick={() => createShare()} disabled={isPending || recipients.length === 0}>
            {isPending ? "Creating share..." : "Create Share"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}