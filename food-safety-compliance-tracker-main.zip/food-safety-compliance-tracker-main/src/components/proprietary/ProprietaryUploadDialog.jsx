import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Upload, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function ProprietaryUploadDialog({ open, onClose }) {
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState("");
  const [description, setDescription] = useState("");
  const [classification, setClassification] = useState("recipe");
  const [tags, setTags] = useState("");
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("No file selected");

      // Upload file to get URL
      const uploadRes = await base44.integrations.Core.UploadFile({ file });
      const fileUrl = uploadRes.file_url;

      // Create document record
      const doc = await base44.entities.Document.create({
        file_name: fileName || file.name,
        file_url: fileUrl,
        file_size: file.size,
        file_type: file.type,
        document_type: classification,
        linked_entity_type: "Document",
        description: description,
        uploaded_by: (await base44.auth.me()).email,
        tags: tags.split(",").map(t => t.trim()).filter(t => t),
        control_status: "controlled",
      });

      // Log activity
      await base44.functions.invoke('logActivity', {
        activity_type: 'document_uploaded',
        entity_type: 'Document',
        entity_id: doc.id,
        entity_label: doc.file_name,
        description: `Proprietary document "${doc.file_name}" uploaded - Classification: ${classification}`
      });

      return doc;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proprietary-documents'] });
      toast.success("Document uploaded successfully");
      resetForm();
      onClose();
    },
    onError: (error) => {
      toast.error("Failed to upload document: " + error.message);
    },
  });

  const resetForm = () => {
    setFile(null);
    setFileName("");
    setDescription("");
    setClassification("recipe");
    setTags("");
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // Limit to 50MB
      if (selectedFile.size > 50 * 1024 * 1024) {
        toast.error("File size must be less than 50MB");
        return;
      }
      setFile(selectedFile);
      setFileName(selectedFile.name);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (!isOpen) {
        resetForm();
        onClose();
      }
    }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-emerald-600" />
            Upload Proprietary Document
          </DialogTitle>
          <DialogDescription>
            Upload sensitive documents with secure access controls
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* File Upload */}
          <div className="space-y-2">
            <Label className="font-medium">Document File</Label>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center cursor-pointer hover:border-emerald-500 hover:bg-emerald-50 transition-colors">
              <input
                type="file"
                onChange={handleFileChange}
                className="hidden"
                id="file-input"
                accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.png,.jpg,.jpeg"
              />
              <label htmlFor="file-input" className="cursor-pointer block">
                {file ? (
                  <div className="text-sm">
                    <p className="font-medium text-emerald-600">{file.name}</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {(file.size / 1024).toFixed(0)} KB
                    </p>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-5 h-5 mx-auto text-slate-400 mb-2" />
                    <p className="text-sm font-medium text-slate-700">Click to upload</p>
                    <p className="text-xs text-slate-500 mt-1">or drag and drop</p>
                  </div>
                )}
              </label>
            </div>
          </div>

          {/* File Name */}
          <div className="space-y-2">
            <Label htmlFor="fileName" className="font-medium">Document Name</Label>
            <Input
              id="fileName"
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              placeholder="e.g., Secret Recipe v2.1"
              className="border-slate-200"
            />
          </div>

          {/* Classification */}
          <div className="space-y-2">
            <Label htmlFor="classification" className="font-medium">Classification</Label>
            <Select value={classification} onValueChange={setClassification}>
              <SelectTrigger id="classification" className="border-slate-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recipe">Recipe/Formula</SelectItem>
                <SelectItem value="raw_material">Raw Material Spec</SelectItem>
                <SelectItem value="manufacturing_process">Manufacturing Process</SelectItem>
                <SelectItem value="specification">Product Specification</SelectItem>
                <SelectItem value="other">Other Proprietary Data</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="font-medium">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add context about this document..."
              className="border-slate-200 resize-none h-24"
            />
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <Label htmlFor="tags" className="font-medium">Tags (comma-separated)</Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="e.g., confidential, v2, chocolate"
              className="border-slate-200"
            />
          </div>

          {/* Security Notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <div className="flex gap-2 text-xs text-amber-800">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>This document will be encrypted and access will be restricted to authorized personnel only.</span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => {
            resetForm();
            onClose();
          }} disabled={uploadMutation.isPending}>
            Cancel
          </Button>
          <Button
            onClick={() => uploadMutation.mutate()}
            disabled={!file || uploadMutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {uploadMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Upload Document
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}