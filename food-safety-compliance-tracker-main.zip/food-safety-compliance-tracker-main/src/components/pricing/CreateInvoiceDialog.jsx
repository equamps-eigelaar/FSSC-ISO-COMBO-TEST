import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { FileText, Sparkles, Loader2 } from "lucide-react";

export default function CreateInvoiceDialog({ open, onClose, plan }) {
  const [form, setForm] = useState({ customerName: "", customerEmail: "", billingCycle: "monthly", accountCode: "" });
  const [loading, setLoading] = useState(false);
  const [accounts, setAccounts] = useState([]);
  const [loadingAccounts, setLoadingAccounts] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [suggestingCode, setSuggestingCode] = useState(false);

  useEffect(() => {
    if (open) fetchAccounts();
  }, [open]);

  const fetchAccounts = async () => {
    setLoadingAccounts(true);
    try {
      const res = await base44.functions.invoke("xeroSync", { action: "get_chart_of_accounts" });
      if (res.data?.accounts) setAccounts(res.data.accounts);
    } catch {
      // silently fail — Xero may not be connected yet
    } finally {
      setLoadingAccounts(false);
    }
  };

  const handleSuggestCode = async () => {
    if (!plan) return;
    setSuggestingCode(true);
    try {
      const res = await base44.functions.invoke("xeroSync", {
        action: "suggest_account_code",
        billingRecord: {
          billable_type: "subscription",
          entity_name: plan.name + " Plan",
          description: plan.tagline || "",
          customer_type: "business",
          total_cost: form.billingCycle === "annual"
            ? (plan.price_annual || Math.round(plan.price_monthly * 0.85))
            : plan.price_monthly,
          currency: plan.currency || "ZAR",
        },
      });
      const s = res.data?.suggestion;
      if (s) {
        setAiSuggestion(s);
        setForm((f) => ({ ...f, accountCode: s.account_code }));
      }
    } catch {
      toast.error("Could not get AI suggestion");
    } finally {
      setSuggestingCode(false);
    }
  };

  const handleSubmit = async () => {
    if (!form.customerName) {
      toast.error("Customer name is required");
      return;
    }
    setLoading(true);
    try {
      const res = await base44.functions.invoke("createSubscriptionInvoice", {
        customerName: form.customerName,
        customerEmail: form.customerEmail,
        planId: plan.id,
        billingCycle: form.billingCycle,
        accountCode: form.accountCode || undefined,
      });
      if (res.data?.error) {
        const msg = res.data.error;
        if (msg.includes("not connected") || msg.includes("Xero not connected")) {
          toast.error("Xero is not connected. Go to Billing → Xero Integration and reconnect.");
        } else {
          toast.error("Xero error: " + msg);
        }
        return;
      }
      toast.success(res.data?.message || "Invoice created in Xero and billing record saved");
      onClose();
    } catch (error) {
      toast.error("Failed to create invoice: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  if (!plan) return null;

  const price = form.billingCycle === "annual"
    ? (plan.price_annual || Math.round(plan.price_monthly * 0.85))
    : plan.price_monthly;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Create Xero Invoice — {plan.name} Plan
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          <div>
            <Label>Customer Name *</Label>
            <Input
              value={form.customerName}
              onChange={(e) => setForm({ ...form, customerName: e.target.value })}
              placeholder="Company or contact name"
            />
          </div>
          <div>
            <Label>Customer Email</Label>
            <Input
              type="email"
              value={form.customerEmail}
              onChange={(e) => setForm({ ...form, customerEmail: e.target.value })}
              placeholder="customer@example.com"
            />
          </div>
          <div>
            <Label>Billing Cycle</Label>
            <Select value={form.billingCycle} onValueChange={(v) => setForm({ ...form, billingCycle: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="monthly">Monthly — R{plan.price_monthly?.toLocaleString()}/mo</SelectItem>
                <SelectItem value="annual">Annual — R{(plan.price_annual || Math.round(plan.price_monthly * 0.85))?.toLocaleString()}/mo</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Account Code */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <Label>Account Code</Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="text-xs text-purple-600 h-auto py-0 px-1"
                onClick={handleSuggestCode}
                disabled={suggestingCode}
              >
                {suggestingCode ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <Sparkles className="w-3 h-3 mr-1" />}
                AI Suggest
              </Button>
            </div>
            {accounts.length > 0 ? (
              <Select value={form.accountCode} onValueChange={(v) => setForm({ ...form, accountCode: v })}>
                <SelectTrigger>
                  <SelectValue placeholder={loadingAccounts ? "Loading accounts…" : "Select account code"} />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((a) => (
                    <SelectItem key={a.code} value={a.code}>
                      {a.code} — {a.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input
                value={form.accountCode}
                onChange={(e) => setForm({ ...form, accountCode: e.target.value })}
                placeholder={loadingAccounts ? "Loading from Xero…" : "e.g. 200"}
              />
            )}
            {aiSuggestion && (
              <p className="text-xs text-purple-600 mt-1">
                AI suggests <strong>{aiSuggestion.account_code} – {aiSuggestion.account_name}</strong>: {aiSuggestion.reasoning}
              </p>
            )}
          </div>

          <div className="bg-slate-50 rounded-lg p-3 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Invoice Amount</span>
              <span className="font-bold text-slate-900">R{price?.toLocaleString()} ZAR</span>
            </div>
            <div className="flex justify-between mt-1">
              <span className="text-slate-600">Plan</span>
              <span className="text-slate-700">{plan.name}</span>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
            <p className="text-xs font-semibold text-blue-800 flex items-center gap-1">🔗 How Xero-linked activation works</p>
            <ol className="text-xs text-blue-700 space-y-1 list-decimal list-inside">
              <li>An <strong>authorised invoice</strong> is created in Xero and emailed to the customer.</li>
              <li>Customer's account is set to <strong>Payment Pending</strong> — access is locked.</li>
              <li>Once the customer pays in Xero, run <strong>"Grant Access on Payment"</strong> from the Billing → Xero panel.</li>
              <li>The system checks Xero for paid invoices and <strong>automatically activates</strong> the matching account.</li>
            </ol>
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
            <Button onClick={handleSubmit} disabled={loading} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              {loading ? "Creating..." : "Push to Xero & Lock Access"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}