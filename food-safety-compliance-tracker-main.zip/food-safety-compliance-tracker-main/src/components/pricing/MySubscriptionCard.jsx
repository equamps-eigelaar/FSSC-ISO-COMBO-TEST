import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Clock, AlertTriangle, ArrowUpCircle, Settings2, CreditCard } from "lucide-react";
import { differenceInDays, format, parseISO } from "date-fns";
import SubscriptionManagementDialog from "./SubscriptionManagementDialog";

function statusBadge(status) {
  const map = {
    trialing:     { label: "Free Trial", className: "bg-blue-100 text-blue-700" },
    active:       { label: "Active", className: "bg-emerald-100 text-emerald-700" },
    past_due:     { label: "Past Due", className: "bg-orange-100 text-orange-700" },
    cancelled:    { label: "Cancelled", className: "bg-red-100 text-red-700" },
    trial_expired:{ label: "Trial Expired", className: "bg-slate-100 text-slate-600" },
  };
  const s = map[status] || { label: status, className: "bg-slate-100 text-slate-500" };
  return <Badge className={s.className}>{s.label}</Badge>;
}

export default function MySubscriptionCard({ user, plans = [] }) {
  const [showManage, setShowManage] = useState(false);
  const queryClient = useQueryClient();

  const { data: subscriptions = [] } = useQuery({
    queryKey: ["my-subscription", user?.email],
    queryFn: () => base44.entities.Subscription.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });

  const sub = subscriptions[0] || null;
  const currentPlan = plans.find((p) => p.id === sub?.plan_id) || null;

  const trialDaysLeft = sub?.status === "trialing" && sub.trial_end_date
    ? differenceInDays(parseISO(sub.trial_end_date), new Date())
    : null;

  const nextBillingLabel = sub?.next_billing_date
    ? format(parseISO(sub.next_billing_date), "d MMM yyyy")
    : null;

  return (
    <>
      <Card className="border-slate-200 bg-white shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-600" />
              My Subscription
            </CardTitle>
            {sub && statusBadge(sub.status)}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {!sub ? (
            <div className="text-center py-4">
              <p className="text-slate-500 text-sm mb-3">No active subscription found.</p>
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => setShowManage(true)}>
                <ArrowUpCircle className="w-4 h-4 mr-1" /> Choose a Plan
              </Button>
            </div>
          ) : (
            <>
              {/* Plan Info */}
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-slate-900">
                    {sub.plan_name || currentPlan?.name || "No plan selected"}
                  </p>
                  <p className="text-xs text-slate-500 capitalize mt-0.5">
                    {sub.billing_cycle || "monthly"} billing · {sub.currency || "ZAR"}
                    {sub.amount ? ` · R${sub.amount.toLocaleString()}/cycle` : ""}
                  </p>
                </div>
                {currentPlan?.is_popular && (
                  <Badge className="bg-emerald-100 text-emerald-700 text-xs">Most Popular</Badge>
                )}
              </div>

              {/* Trial warning */}
              {sub.status === "trialing" && trialDaysLeft !== null && (
                <div className={`flex items-center gap-2 text-sm p-2.5 rounded-lg ${trialDaysLeft <= 2 ? "bg-red-50 text-red-700" : "bg-blue-50 text-blue-700"}`}>
                  {trialDaysLeft <= 2 ? <AlertTriangle className="w-4 h-4 shrink-0" /> : <Clock className="w-4 h-4 shrink-0" />}
                  {trialDaysLeft <= 0
                    ? "Your trial has expired. Please upgrade to continue."
                    : `Free trial ends in ${trialDaysLeft} day${trialDaysLeft !== 1 ? "s" : ""} (${format(parseISO(sub.trial_end_date), "d MMM")}).`}
                </div>
              )}

              {/* Past due warning */}
              {sub.status === "past_due" && (
                <div className="flex items-center gap-2 text-sm p-2.5 rounded-lg bg-orange-50 text-orange-700">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  Your payment is overdue. Please update your billing details.
                </div>
              )}

              {/* Next billing */}
              {nextBillingLabel && sub.status === "active" && (
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  Next invoice: <span className="font-medium text-slate-700">{nextBillingLabel}</span>
                </div>
              )}

              {/* Features preview */}
              {(currentPlan?.features || []).slice(0, 3).length > 0 && (
                <div className="space-y-1">
                  {(currentPlan.features).slice(0, 3).map((f, i) => (
                    <p key={i} className="text-xs text-slate-500 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" /> {f}
                    </p>
                  ))}
                  {currentPlan.features.length > 3 && (
                    <p className="text-xs text-slate-400">+{currentPlan.features.length - 3} more features</p>
                  )}
                </div>
              )}

              <div className="flex gap-2 pt-1">
                <Button size="sm" variant="outline" className="flex-1 gap-1" onClick={() => setShowManage(true)}>
                  <Settings2 className="w-3.5 h-3.5" /> Manage Plan
                </Button>
                {(sub.status === "trialing" || sub.status === "trial_expired") && (
                  <Button size="sm" className="flex-1 gap-1 bg-emerald-600 hover:bg-emerald-700" onClick={() => setShowManage(true)}>
                    <ArrowUpCircle className="w-3.5 h-3.5" /> Upgrade Now
                  </Button>
                )}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <SubscriptionManagementDialog
        open={showManage}
        onClose={() => setShowManage(false)}
        user={user}
        subscription={sub}
        plans={plans}
        onDone={() => {
          queryClient.invalidateQueries({ queryKey: ["my-subscription"] });
          setShowManage(false);
        }}
      />
    </>
  );
}