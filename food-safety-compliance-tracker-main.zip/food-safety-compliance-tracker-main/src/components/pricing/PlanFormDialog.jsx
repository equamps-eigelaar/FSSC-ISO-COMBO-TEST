import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

const DEFAULT_PLAN = {
  name: "",
  tier: "base",
  tagline: "",
  price_monthly: 0,
  price_annual: 0,
  currency: "ZAR",
  max_users: 5,
  features: [],
  is_active: true,
  is_popular: false,
  xero_item_code: "",
  xero_account_code: "200",
  sort_order: 0,
};

export default function PlanFormDialog({ open, onClose, plan, onSaved }) {
  const [form, setForm] = useState(DEFAULT_PLAN);
  const [featuresText, setFeaturesText] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (plan) {
      setForm({ ...DEFAULT_PLAN, ...plan });
      setFeaturesText((plan.features || []).join("\n"));
    } else {
      setForm(DEFAULT_PLAN);
      setFeaturesText("");
    }
  }, [plan, open]);

  const handleSave = async () => {
    if (!form.name || !form.tier) {
      toast.error("Name and tier are required");
      return;
    }
    setSaving(true);
    try {
      const data = {
        ...form,
        features: featuresText.split("\n").map((f) => f.trim()).filter(Boolean),
        price_monthly: Number(form.price_monthly),
        price_annual: Number(form.price_annual),
        max_users: Number(form.max_users),
        sort_order: Number(form.sort_order),
      };

      if (plan?.id) {
        await base44.entities.PricePlan.update(plan.id, data);
        toast.success("Plan updated");
      } else {
        await base44.entities.PricePlan.create(data);
        toast.success("Plan created");
      }
      onSaved();
      onClose();
    } catch (error) {
      toast.error("Failed to save plan");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{plan?.id ? "Edit Plan" : "New Price Plan"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Plan Name *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Base" />
            </div>
            <div>
              <Label>Tier *</Label>
              <Select value={form.tier} onValueChange={(v) => setForm({ ...form, tier: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="base">Base</SelectItem>
                  <SelectItem value="pro">Pro</SelectItem>
                  <SelectItem value="enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Tagline</Label>
            <Input value={form.tagline} onChange={(e) => setForm({ ...form, tagline: e.target.value })} placeholder="Short description" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Monthly Price (ZAR)</Label>
              <Input type="number" value={form.price_monthly} onChange={(e) => setForm({ ...form, price_monthly: e.target.value })} />
            </div>
            <div>
              <Label>Annual Price/mo (ZAR)</Label>
              <Input type="number" value={form.price_annual} onChange={(e) => setForm({ ...form, price_annual: e.target.value })} placeholder="Leave 0 for auto (15% off)" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Max Users (0 = unlimited)</Label>
              <Input type="number" value={form.max_users} onChange={(e) => setForm({ ...form, max_users: e.target.value })} />
            </div>
            <div>
              <Label>Display Order</Label>
              <Input type="number" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: e.target.value })} />
            </div>
          </div>

          <div>
            <Label>Features (one per line)</Label>
            <Textarea
              value={featuresText}
              onChange={(e) => setFeaturesText(e.target.value)}
              rows={8}
              placeholder="Digital GMP & hygiene checklists&#10;Non-conformance logging&#10;CAPA tracking&#10;..."
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Xero Item Code</Label>
              <Input value={form.xero_item_code} onChange={(e) => setForm({ ...form, xero_item_code: e.target.value })} placeholder="SUB-BASE" />
            </div>
            <div>
              <Label>Xero Account Code</Label>
              <Input value={form.xero_account_code} onChange={(e) => setForm({ ...form, xero_account_code: e.target.value })} placeholder="200" />
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
              <Label>Active (visible)</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.is_popular} onCheckedChange={(v) => setForm({ ...form, is_popular: v })} />
              <Label>Most Popular</Label>
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              {saving ? "Saving..." : "Save Plan"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}