import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, ArrowUpCircle, ArrowDownCircle, Loader2, CreditCard, User, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

const TIER_ORDER = ["base", "basic", "compliance", "pro", "enterprise"];

function tierRank(tier) {
  return TIER_ORDER.indexOf(tier ?? "base");
}

export default function SubscriptionManagementDialog({ open, onClose, user, subscription, plans = [], onDone }) {
  const [tab, setTab] = useState("plan");
  const [billingCycle, setBillingCycle] = useState(subscription?.billing_cycle || "monthly");
  const [selectedPlanId, setSelectedPlanId] = useState(subscription?.plan_id || "");
  const [billingDetails, setBillingDetails] = useState({
    customerName: user?.full_name || "",
    customerEmail: user?.email || "",
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const currentPlan = plans.find((p) => p.id === subscription?.plan_id);
  const selectedPlan = plans.find((p) => p.id === selectedPlanId);

  const activePlans = plans.filter((p) => p.is_active).sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));

  function getChangeType(plan) {
    if (!currentPlan) return "new";
    const curr = tierRank(currentPlan.tier);
    const next = tierRank(plan.tier);
    if (next > curr) return "upgrade";
    if (next < curr) return "downgrade";
    return "same";
  }

  const handleSubscribe = async () => {
    if (!selectedPlanId) { toast.error("Please select a plan"); return; }
    if (!billingDetails.customerName) { toast.error("Customer name is required"); return; }
    setLoading(true);
    try {
      const res = await base44.functions.invoke("manageSubscription", {
        action: "subscribe",
        planId: selectedPlanId,
        billingCycle,
        customerName: billingDetails.customerName,
        customerEmail: billingDetails.customerEmail || user?.email,
      });
      if (res.data?.success) {
        setSuccess(true);
        toast.success(res.data.message || "Subscription updated successfully");
        setTimeout(() => { setSuccess(false); onDone?.(); }, 1500);
      } else {
        toast.error(res.data?.error || "Failed to update subscription");
      }
    } catch (e) {
      toast.error("Something went wrong: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async () => {
    if (!subscription?.id) return;
    if (!window.confirm("Are you sure you want to cancel your subscription? You'll lose access at the end of the billing period.")) return;
    setLoading(true);
    try {
      const res = await base44.functions.invoke("manageSubscription", {
        action: "cancel",
        subscriptionId: subscription.id,
      });
      if (res.data?.success) {
        toast.success("Subscription cancelled.");
        onDone?.();
      } else {
        toast.error(res.data?.error || "Failed to cancel");
      }
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  const price = selectedPlan
    ? billingCycle === "annual"
      ? (selectedPlan.price_annual || Math.round(selectedPlan.price_monthly * 0.85))
      : selectedPlan.price_monthly
    : null;

  if (success) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-sm text-center py-12">
          <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-900 mb-2">Subscription Updated!</h2>
          <p className="text-slate-500 text-sm">Your plan has been updated and an invoice has been created in Xero.</p>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-600" />
            Manage Subscription
          </DialogTitle>
        </DialogHeader>

        <Tabs value={tab} onValueChange={setTab} className="mt-2">
          <TabsList className="w-full grid grid-cols-2">
            <TabsTrigger value="plan">Choose Plan</TabsTrigger>
            <TabsTrigger value="billing">Billing Details</TabsTrigger>
          </TabsList>

          {/* Plan Selection Tab */}
          <TabsContent value="plan" className="space-y-4 pt-3">
            {/* Current plan banner */}
            {subscription?.plan_name && (
              <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm text-slate-600">
                Current plan: <strong>{subscription.plan_name}</strong>
                {subscription.billing_cycle && <span className="ml-1 capitalize">({subscription.billing_cycle})</span>}
              </div>
            )}

            {/* Billing cycle toggle */}
            <div>
              <Label className="text-xs text-slate-500 uppercase tracking-wide">Billing Cycle</Label>
              <div className="flex gap-2 mt-1">
                <Button
                  size="sm"
                  variant={billingCycle === "monthly" ? "default" : "outline"}
                  onClick={() => setBillingCycle("monthly")}
                  className={billingCycle === "monthly" ? "bg-emerald-600 hover:bg-emerald-700" : ""}
                >
                  Monthly
                </Button>
                <Button
                  size="sm"
                  variant={billingCycle === "annual" ? "default" : "outline"}
                  onClick={() => setBillingCycle("annual")}
                  className={billingCycle === "annual" ? "bg-emerald-600 hover:bg-emerald-700" : ""}
                >
                  Annual <Badge className="ml-1 bg-emerald-100 text-emerald-700 text-[10px]">Save 15%</Badge>
                </Button>
              </div>
            </div>

            {/* Plan cards */}
            <div className="space-y-2">
              {activePlans.map((plan) => {
                const p = billingCycle === "annual"
                  ? (plan.price_annual || Math.round(plan.price_monthly * 0.85))
                  : plan.price_monthly;
                const change = getChangeType(plan);
                const isSelected = selectedPlanId === plan.id;
                const isCurrent = subscription?.plan_id === plan.id && subscription?.billing_cycle === billingCycle;

                return (
                  <div
                    key={plan.id}
                    onClick={() => setSelectedPlanId(plan.id)}
                    className={`relative border rounded-xl p-4 cursor-pointer transition-all ${
                      isSelected
                        ? "border-emerald-500 bg-emerald-50 ring-2 ring-emerald-500"
                        : "border-slate-200 bg-white hover:border-slate-300"
                    }`}
                  >
                    {plan.is_popular && !isCurrent && (
                      <div className="absolute -top-2.5 right-3">
                        <Badge className="bg-emerald-600 text-white text-[10px] px-2">Popular</Badge>
                      </div>
                    )}
                    {isCurrent && (
                      <div className="absolute -top-2.5 right-3">
                        <Badge className="bg-blue-600 text-white text-[10px] px-2">Current Plan</Badge>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${isSelected ? "border-emerald-500 bg-emerald-500" : "border-slate-300"}`}>
                          {isSelected && <Check className="w-3 h-3 text-white" />}
                        </div>
                        <div>
                          <p className="font-semibold text-slate-900 text-sm">{plan.name}</p>
                          <p className="text-xs text-slate-500">{plan.tagline}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-slate-900">
                          {plan.price_monthly === 0 ? "Custom" : `R${p.toLocaleString()}`}
                        </p>
                        {plan.price_monthly > 0 && (
                          <p className="text-xs text-slate-400">/mo</p>
                        )}
                      </div>
                    </div>

                    {isSelected && !isCurrent && change !== "same" && (
                      <div className={`mt-2 flex items-center gap-1 text-xs font-medium ${change === "upgrade" ? "text-emerald-600" : "text-orange-500"}`}>
                        {change === "upgrade"
                          ? <ArrowUpCircle className="w-3.5 h-3.5" />
                          : <ArrowDownCircle className="w-3.5 h-3.5" />}
                        {change === "upgrade" ? "Upgrade" : "Downgrade"} from {currentPlan?.name || "current plan"}
                      </div>
                    )}

                    {isSelected && (
                      <ul className="mt-3 space-y-1">
                        {(plan.features || []).slice(0, 4).map((f, i) => (
                          <li key={i} className="text-xs text-slate-600 flex items-center gap-1.5">
                            <Check className="w-3 h-3 text-emerald-500 shrink-0" /> {f}
                          </li>
                        ))}
                        {(plan.features || []).length > 4 && (
                          <li className="text-xs text-slate-400">+{plan.features.length - 4} more</li>
                        )}
                      </ul>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Price summary */}
            {selectedPlan && price !== null && (
              <div className="bg-slate-50 rounded-lg p-3 text-sm border border-slate-200">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">
                    {billingCycle === "annual" ? "Annual total" : "Monthly amount"}
                  </span>
                  <span className="font-bold text-slate-900">
                    R{(billingCycle === "annual" ? price * 12 : price).toLocaleString()} ZAR
                    {billingCycle === "annual" && <span className="text-xs text-slate-500 font-normal ml-1">(R{price.toLocaleString()}/mo)</span>}
                  </span>
                </div>
              </div>
            )}

            <Button
              className="w-full bg-emerald-600 hover:bg-emerald-700"
              disabled={!selectedPlanId || loading}
              onClick={() => setTab("billing")}
            >
              Continue to Billing Details →
            </Button>
          </TabsContent>

          {/* Billing Details Tab */}
          <TabsContent value="billing" className="space-y-4 pt-3">
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-sm">
              <p className="font-medium text-emerald-800">{selectedPlan?.name || "No plan selected"}</p>
              <p className="text-emerald-600 text-xs capitalize">{billingCycle} billing · R{price?.toLocaleString()}/mo</p>
            </div>

            <div>
              <Label className="flex items-center gap-1"><User className="w-3 h-3" /> Full Name *</Label>
              <Input
                className="mt-1"
                value={billingDetails.customerName}
                onChange={(e) => setBillingDetails((d) => ({ ...d, customerName: e.target.value }))}
                placeholder="Company or contact name"
              />
            </div>
            <div>
              <Label className="flex items-center gap-1"><CreditCard className="w-3 h-3" /> Billing Email</Label>
              <Input
                className="mt-1"
                type="email"
                value={billingDetails.customerEmail}
                onChange={(e) => setBillingDetails((d) => ({ ...d, customerEmail: e.target.value }))}
                placeholder="billing@company.com"
              />
              <p className="text-xs text-slate-400 mt-1">Invoices will be sent to this email via Xero.</p>
            </div>

            <div className="bg-slate-50 rounded-lg p-3 space-y-1.5 text-sm border border-slate-200">
              <div className="flex justify-between text-slate-600">
                <span>Plan</span><span className="font-medium text-slate-800">{selectedPlan?.name}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Cycle</span><span className="font-medium text-slate-800 capitalize">{billingCycle}</span>
              </div>
              <div className="flex justify-between text-slate-600 border-t border-slate-200 pt-1.5 mt-1.5">
                <span>Total</span>
                <span className="font-bold text-slate-900">
                  R{(billingCycle === "annual" ? (price ?? 0) * 12 : (price ?? 0)).toLocaleString()} ZAR
                </span>
              </div>
              <p className="text-xs text-slate-400">A Xero invoice will be created for approval. VAT may apply.</p>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setTab("plan")}>← Back</Button>
              <Button
                className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                disabled={loading || !selectedPlanId}
                onClick={handleSubscribe}
              >
                {loading ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Processing…</> : "Confirm & Subscribe"}
              </Button>
            </div>

            {/* Cancel option */}
            {subscription?.status === "active" && (
              <div className="pt-2 border-t border-slate-100">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full text-red-500 hover:text-red-600 hover:bg-red-50 text-xs"
                  onClick={handleCancel}
                  disabled={loading}
                >
                  Cancel Subscription
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}