import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3 } from "lucide-react";

export default function SectionProgressChart({ requirements, sections }) {
  const sectionData = sections.map(section => {
    const items = requirements.filter(r => r.section === section);
    const compliant = items.filter(r => r.status === "compliant").length;
    const total = items.length;
    const pct = total > 0 ? Math.round((compliant / total) * 100) : 0;
    return { section, compliant, total, pct, label: section.split(" - ")[1] || section };
  });

  const maxTotal = Math.max(...sectionData.map(d => d.total), 1);

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-slate-400" />
          Compliance by Section
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-4">
          {sectionData.map((d, i) => (
            <div key={i}>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-medium text-slate-600 truncate pr-4">
                  {d.section}
                </span>
                <span className="text-xs text-slate-400 font-mono shrink-0">
                  {d.compliant}/{d.total}
                </span>
              </div>
              <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-700 ease-out"
                  style={{ width: `${d.pct}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}