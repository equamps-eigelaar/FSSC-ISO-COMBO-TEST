import React, { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, X, FileText, ShieldCheck } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const STATUS_COLORS = {
  compliant: "bg-emerald-100 text-emerald-700",
  in_progress: "bg-blue-100 text-blue-700",
  partial: "bg-amber-100 text-amber-700",
  not_started: "bg-slate-100 text-slate-500",
  non_compliant: "bg-rose-100 text-rose-700",
};

export default function GlobalSearch({ requirements = [], risks = [] }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  const q = query.trim().toLowerCase();

  const matchedRequirements = q.length < 2 ? [] : requirements.filter(r =>
    r.clause_number?.toLowerCase().includes(q) ||
    r.clause_title?.toLowerCase().includes(q) ||
    r.description?.toLowerCase().includes(q) ||
    r.section?.toLowerCase().includes(q) ||
    r.corrective_actions?.toLowerCase().includes(q) ||
    r.evidence_notes?.toLowerCase().includes(q) ||
    r.findings?.toLowerCase().includes(q)
  ).slice(0, 8);

  const matchedRisks = q.length < 2 ? [] : risks.filter(r =>
    r.hazard_description?.toLowerCase().includes(q) ||
    r.hazard_type?.toLowerCase().includes(q) ||
    r.mitigation_strategy?.toLowerCase().includes(q)
  ).slice(0, 4);

  const hasResults = matchedRequirements.length > 0 || matchedRisks.length > 0;

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const highlight = (text, q) => {
    if (!text || !q) return text;
    const idx = text.toLowerCase().indexOf(q);
    if (idx === -1) return text;
    return (
      <>
        {text.slice(0, idx)}
        <mark className="bg-yellow-200 text-yellow-900 rounded px-0.5">{text.slice(idx, idx + q.length)}</mark>
        {text.slice(idx + q.length)}
      </>
    );
  };

  return (
    <div ref={ref} className="relative w-full max-w-xl">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
        <Input
          value={query}
          onChange={e => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="Search clauses, procedures, hazards..."
          className="pl-9 pr-9 bg-white border-slate-200 focus:border-emerald-400 h-9 text-sm"
        />
        {query && (
          <button
            onClick={() => { setQuery(""); setOpen(false); }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {open && q.length >= 2 && (
        <div className="absolute z-50 top-full mt-1 w-full bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden">
          {!hasResults ? (
            <p className="text-sm text-slate-400 px-4 py-3">No results found for "{query}"</p>
          ) : (
            <div className="max-h-96 overflow-y-auto divide-y divide-slate-100">
              {matchedRequirements.length > 0 && (
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-4 pt-3 pb-1 flex items-center gap-1.5">
                    <FileText className="w-3 h-3" /> Clause References & Procedures
                  </p>
                  {matchedRequirements.map(r => (
                    <Link
                      key={r.id}
                      to={createPageUrl("RequirementDetail") + `?id=${r.id}`}
                      onClick={() => { setOpen(false); setQuery(""); }}
                      className="flex items-start gap-3 px-4 py-2.5 hover:bg-slate-50 transition-colors"
                    >
                      <span className="text-xs font-mono font-bold text-slate-400 shrink-0 mt-0.5 min-w-[3rem]">
                        {r.clause_number}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-slate-800 font-medium truncate">
                          {highlight(r.clause_title, q)}
                        </p>
                        {r.description && (
                          <p className="text-xs text-slate-500 truncate mt-0.5">
                            {highlight(r.description, q)}
                          </p>
                        )}
                        <p className="text-[10px] text-slate-400 mt-0.5">{r.section}</p>
                      </div>
                      <Badge className={`text-[10px] shrink-0 ${STATUS_COLORS[r.status] || "bg-slate-100 text-slate-500"}`}>
                        {r.status?.replace("_", " ")}
                      </Badge>
                    </Link>
                  ))}
                </div>
              )}

              {matchedRisks.length > 0 && (
                <div>
                  <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-4 pt-3 pb-1 flex items-center gap-1.5">
                    <ShieldCheck className="w-3 h-3" /> Risk Assessments
                  </p>
                  {matchedRisks.map(r => (
                    <Link
                      key={r.id}
                      to={createPageUrl("RiskWorkflow")}
                      onClick={() => { setOpen(false); setQuery(""); }}
                      className="flex items-start gap-3 px-4 py-2.5 hover:bg-slate-50 transition-colors"
                    >
                      <span className={`text-[10px] font-semibold uppercase shrink-0 mt-0.5 px-1.5 py-0.5 rounded ${
                        r.risk_level === "critical" ? "bg-rose-100 text-rose-700" :
                        r.risk_level === "high" ? "bg-orange-100 text-orange-700" :
                        r.risk_level === "medium" ? "bg-amber-100 text-amber-700" :
                        "bg-slate-100 text-slate-500"
                      }`}>
                        {r.risk_level}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-slate-800 font-medium truncate">
                          {highlight(r.hazard_description, q)}
                        </p>
                        <p className="text-xs text-slate-500 capitalize mt-0.5">{r.hazard_type?.replace("_", " ")}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}