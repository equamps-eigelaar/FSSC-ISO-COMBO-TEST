import React from "react";

export default function ComplianceScoreRing({ score, progressScore, total, compliant }) {
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;
  const progressOffset = circumference - (progressScore / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        <svg width="180" height="180" viewBox="0 0 180 180">
          <circle
            cx="90" cy="90" r={radius}
            fill="none" stroke="#f1f5f9" strokeWidth="12"
          />
          <circle
            cx="90" cy="90" r={radius}
            fill="none" stroke="#d1fae5" strokeWidth="12"
            strokeDasharray={circumference}
            strokeDashoffset={progressOffset}
            strokeLinecap="round"
            transform="rotate(-90 90 90)"
            className="transition-all duration-1000 ease-out"
          />
          <circle
            cx="90" cy="90" r={radius}
            fill="none" stroke="#059669" strokeWidth="12"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            transform="rotate(-90 90 90)"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-4xl font-bold text-slate-900">{score}%</span>
          <span className="text-xs text-slate-400 font-medium">Compliant</span>
        </div>
      </div>
      <div className="text-center">
        <p className="text-sm text-slate-500">
          <span className="font-semibold text-emerald-600">{compliant}</span> of{" "}
          <span className="font-semibold text-slate-700">{total}</span> requirements met
        </p>
        <p className="text-xs text-slate-400 mt-1">Overall progress: {progressScore}%</p>
      </div>
    </div>
  );
}