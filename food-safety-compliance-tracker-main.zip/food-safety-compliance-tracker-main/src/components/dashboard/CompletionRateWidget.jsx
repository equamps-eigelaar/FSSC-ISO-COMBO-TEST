import React, { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";

const SECTION_SHORT = {
  "4 - Context of the Organization": "§4 Context",
  "5 - Leadership": "§5 Leadership",
  "6 - Planning": "§6 Planning",
  "7 - Support": "§7 Support",
  "8 - Operation": "§8 Operation",
  "9 - Performance Evaluation": "§9 Performance",
  "10 - Improvement": "§10 Improvement",
  "TS 22002-4 - Establishment": "TS Establishment",
  "TS 22002-4 - Utilities": "TS Utilities",
  "TS 22002-4 - Equipment": "TS Equipment",
  "TS 22002-4 - Hygiene": "TS Hygiene",
  "TS 22002-4 - Personnel": "TS Personnel",
  "TS 22002-4 - Transportation": "TS Transport",
  "TS 22002-4 - Product Information": "TS Product Info",
  "TS 22002-4 - Other Requirements": "TS Other",
};

function getColor(pct) {
  if (pct >= 80) return { bar: "bg-emerald-500", text: "text-emerald-700", bg: "bg-emerald-50" };
  if (pct >= 50) return { bar: "bg-amber-400", text: "text-amber-700", bg: "bg-amber-50" };
  return { bar: "bg-rose-400", text: "text-rose-700", bg: "bg-rose-50" };
}

export default function CompletionRateWidget({ requirements = [] }) {
  const { overall, bySection } = useMemo(() => {
    if (!requirements.length) return { overall: 0, bySection: [] };

    // Overall average completion_percentage
    const overall = Math.round(
      requirements.reduce((sum, r) => sum + (r.completion_percentage || 0), 0) / requirements.length
    );

    // Group by section
    const map = {};
    requirements.forEach(r => {
      if (!r.section) return;
      if (!map[r.section]) map[r.section] = { total: 0, count: 0, compliant: 0 };
      map[r.section].total += r.completion_percentage || 0;
      map[r.section].count += 1;
      if (r.status === "compliant") map[r.section].compliant += 1;
    });

    const bySection = Object.entries(map)
      .map(([section, d]) => ({
        section,
        short: SECTION_SHORT[section] || section,
        pct: Math.round(d.total / d.count),
        count: d.count,
        compliant: d.compliant,
      }))
      .sort((a, b) => a.pct - b.pct); // lowest first to highlight gaps

    return { overall, bySection };
  }, [requirements]);

  const overallColor = getColor(overall);

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-600" />
          Completion Rate by Section
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        {/* Overall bar */}
        <div className={`rounded-lg p-3 mb-4 ${overallColor.bg}`}>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-slate-700">Overall Avg Completion</span>
            <span className={`text-sm font-bold ${overallColor.text}`}>{overall}%</span>
          </div>
          <div className="w-full bg-white/60 rounded-full h-2.5">
            <div
              className={`h-2.5 rounded-full transition-all ${overallColor.bar}`}
              style={{ width: `${overall}%` }}
            />
          </div>
        </div>

        {/* Per-section bars */}
        <div className="space-y-2.5">
          {bySection.map(({ section, short, pct, count, compliant }) => {
            const c = getColor(pct);
            return (
              <div key={section}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-slate-600 truncate pr-2">{short}</span>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] text-slate-400">{compliant}/{count}</span>
                    <span className={`text-xs font-semibold ${c.text} w-8 text-right`}>{pct}%</span>
                  </div>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5">
                  <div
                    className={`h-1.5 rounded-full transition-all ${c.bar}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {requirements.length === 0 && (
          <p className="text-xs text-slate-400 text-center py-4">No requirements loaded</p>
        )}
      </CardContent>
    </Card>
  );
}