import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle2, Clock, FileX, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";

export default function ComplianceAlertsWidget() {
  const [lastCheckTime, setLastCheckTime] = useState(null);

  const { data: checkResults, isLoading, refetch } = useQuery({
    queryKey: ["compliance-check"],
    queryFn: async () => {
      try {
        const response = await base44.functions.invoke("runComplianceCheck", {});
        setLastCheckTime(new Date());
        return response;
      } catch (error) {
        toast.error("Failed to run compliance check");
        return null;
      }
    },
    enabled: false, // Only run on-demand
  });

  const handleRunCheck = () => {
    refetch();
  };

  if (!checkResults) {
    return (
      <Card className="border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-600" />
              Compliance Status
            </CardTitle>
            <Button
              size="sm"
              onClick={handleRunCheck}
              disabled={isLoading}
              className="gap-2"
            >
              {isLoading && <RefreshCw className="w-4 h-4 animate-spin" />}
              Run Check
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-600">
            Click "Run Check" to scan for compliance issues.
          </p>
        </CardContent>
      </Card>
    );
  }

  const { summary = {}, alerts = {}, check_date } = checkResults;
  const { past_due_count = 0, non_compliant_count = 0, missing_evidence_count = 0 } = summary;
  const total = past_due_count + non_compliant_count + missing_evidence_count;

  const getStatusColor = () => {
    if (total === 0) return "emerald";
    if (total <= 3) return "amber";
    return "rose";
  };

  const color = getStatusColor();
  const colorMap = {
    emerald: "bg-emerald-50 border-emerald-200",
    amber: "bg-amber-50 border-amber-200",
    rose: "bg-rose-50 border-rose-200",
  };

  return (
    <Card className={`border-2 ${colorMap[color]}`}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {color === "emerald" && <CheckCircle2 className="w-6 h-6 text-emerald-600" />}
            {color === "amber" && <AlertCircle className="w-6 h-6 text-amber-600" />}
            {color === "rose" && <AlertCircle className="w-6 h-6 text-rose-600" />}
            <div>
              <CardTitle>Compliance Status</CardTitle>
              <p className="text-xs text-slate-500 mt-1">
                Last checked: {new Date(check_date).toLocaleString()}
              </p>
            </div>
          </div>
          <Button
            size="sm"
            onClick={handleRunCheck}
            disabled={isLoading}
            className="gap-2"
          >
            {isLoading && <RefreshCw className="w-4 h-4 animate-spin" />}
            Re-check
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Past Due */}
            <div className="bg-white rounded-lg p-3 border border-slate-200">
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-rose-500 mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs text-slate-600 font-medium">Past Due</p>
                  <p className="text-lg font-bold text-rose-700">{past_due_count}</p>
                </div>
              </div>
            </div>

            {/* Non-Compliant */}
            <div className="bg-white rounded-lg p-3 border border-slate-200">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs text-slate-600 font-medium">Non-Compliant</p>
                  <p className="text-lg font-bold text-rose-700">{non_compliant_count}</p>
                </div>
              </div>
            </div>

            {/* Missing Evidence */}
            <div className="bg-white rounded-lg p-3 border border-slate-200">
              <div className="flex items-start gap-2">
                <FileX className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs text-slate-600 font-medium">Missing Evidence</p>
                  <p className="text-lg font-bold text-amber-700">{missing_evidence_count}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Alerts Details */}
          {total > 0 && (
            <div className="space-y-3 mt-4 pt-4 border-t border-slate-200">
              {past_due_count > 0 && (
                <div className="text-sm">
                  <p className="font-semibold text-rose-700 mb-1">
                    ⏰ {past_due_count} Past Due Requirement{past_due_count !== 1 ? "s" : ""}
                  </p>
                  <div className="space-y-1">
                    {alerts.pastDue?.slice(0, 3).map((item) => (
                      <p key={item.id} className="text-xs text-slate-600">
                        {item.clause_number} - {item.days_overdue} days overdue
                      </p>
                    ))}
                    {past_due_count > 3 && (
                      <p className="text-xs text-slate-500 italic">+{past_due_count - 3} more</p>
                    )}
                  </div>
                </div>
              )}

              {non_compliant_count > 0 && (
                <div className="text-sm">
                  <p className="font-semibold text-rose-700 mb-1">
                    ✗ {non_compliant_count} Non-Compliant Requirement{non_compliant_count !== 1 ? "s" : ""}
                  </p>
                  <div className="space-y-1">
                    {alerts.nonCompliant?.slice(0, 3).map((item) => (
                      <p key={item.id} className="text-xs text-slate-600">
                        {item.clause_number} - {item.completion_percentage}% complete
                      </p>
                    ))}
                    {non_compliant_count > 3 && (
                      <p className="text-xs text-slate-500 italic">+{non_compliant_count - 3} more</p>
                    )}
                  </div>
                </div>
              )}

              {missing_evidence_count > 0 && (
                <div className="text-sm">
                  <p className="font-semibold text-amber-700 mb-1">
                    📄 {missing_evidence_count} Missing Evidence File{missing_evidence_count !== 1 ? "s" : ""}
                  </p>
                  <div className="space-y-1">
                    {alerts.missingEvidence?.slice(0, 3).map((item) => (
                      <p key={item.id} className="text-xs text-slate-600">
                        {item.clause_number} - needs documentation
                      </p>
                    ))}
                    {missing_evidence_count > 3 && (
                      <p className="text-xs text-slate-500 italic">+{missing_evidence_count - 3} more</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {total === 0 && (
            <div className="text-center py-4">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-emerald-700">All requirements compliant</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}