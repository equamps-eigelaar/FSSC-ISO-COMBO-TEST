import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Clock } from "lucide-react";

export default function OutstandingActions({ risks }) {
  const overdueRisks = React.useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return risks.filter(r => {
      if (!r.review_date) return false;
      const reviewDate = new Date(r.review_date);
      return reviewDate < today;
    }).sort((a, b) => new Date(a.review_date) - new Date(b.review_date));
  }, [risks]);

  const requiresAction = risks.filter(r => r.status === 'requires_action');
  const highRisks = risks.filter(r => r.risk_level === 'critical' || r.risk_level === 'high');

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600" />
          Outstanding Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center p-3 bg-rose-50 rounded-lg">
            <div className="text-2xl font-bold text-rose-700">{overdueRisks.length}</div>
            <div className="text-xs text-rose-600 font-medium">Overdue Reviews</div>
          </div>
          <div className="text-center p-3 bg-amber-50 rounded-lg">
            <div className="text-2xl font-bold text-amber-700">{requiresAction.length}</div>
            <div className="text-xs text-amber-600 font-medium">Require Action</div>
          </div>
          <div className="text-center p-3 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-700">{highRisks.length}</div>
            <div className="text-xs text-orange-600 font-medium">High/Critical</div>
          </div>
        </div>

        {overdueRisks.length > 0 && (
          <div className="pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2 mb-3">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-xs font-semibold text-slate-600">Overdue Risk Reviews</span>
            </div>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {overdueRisks.slice(0, 5).map(risk => {
                const daysOverdue = Math.floor((new Date() - new Date(risk.review_date)) / (1000 * 60 * 60 * 24));
                return (
                  <div key={risk.id} className="flex items-start justify-between gap-2 p-2 bg-slate-50 rounded text-xs">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-slate-700 truncate capitalize">
                        {risk.hazard_type} Hazard
                      </p>
                      <p className="text-slate-500 text-[10px] truncate">{risk.hazard_description}</p>
                    </div>
                    <Badge className="bg-rose-100 text-rose-700 text-[10px] shrink-0">
                      {daysOverdue}d overdue
                    </Badge>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}