import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { FileText } from "lucide-react";

const STATUS_CONFIG = [
  { key: "compliant", label: "Compliant", color: "#059669" },
  { key: "in_progress", label: "In Progress", color: "#3b82f6" },
  { key: "partial", label: "Partial", color: "#f59e0b" },
  { key: "not_started", label: "Not Started", color: "#cbd5e1" },
  { key: "non_compliant", label: "Non-Compliant", color: "#e11d48" },
];

export default function StatusBreakdown({ requirements }) {
  const data = STATUS_CONFIG.map(s => ({
    name: s.label,
    value: requirements.filter(r => r.status === s.key).length,
    color: s.color,
  })).filter(d => d.value > 0);

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
          <FileText className="w-4 h-4 text-slate-400" />
          Status Distribution
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        {data.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-8">No data available</p>
        ) : (
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={85}
                paddingAngle={3}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={index} fill={entry.color} stroke="none" />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  background: "#fff",
                  border: "none",
                  borderRadius: "8px",
                  boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1)",
                  fontSize: "12px",
                }}
              />
              <Legend
                verticalAlign="bottom"
                iconType="circle"
                iconSize={8}
                formatter={(value) => (
                  <span className="text-xs text-slate-600">{value}</span>
                )}
              />
            </PieChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}