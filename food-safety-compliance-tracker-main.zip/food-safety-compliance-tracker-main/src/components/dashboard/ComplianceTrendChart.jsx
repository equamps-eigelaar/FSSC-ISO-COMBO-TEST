import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { TrendingUp } from "lucide-react";

export default function ComplianceTrendChart({ requirements }) {
  // Group by month and calculate compliance percentage
  const trendData = React.useMemo(() => {
    const monthMap = {};
    
    requirements.forEach(req => {
      const date = new Date(req.updated_date || req.created_date);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!monthMap[monthKey]) {
        monthMap[monthKey] = { compliant: 0, total: 0 };
      }
      
      monthMap[monthKey].total++;
      if (req.status === 'compliant') {
        monthMap[monthKey].compliant++;
      }
    });
    
    return Object.entries(monthMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-6)
      .map(([month, data]) => ({
        month: new Date(month + "-01").toLocaleDateString('en', { month: 'short', year: '2-digit' }),
        compliance: Math.round((data.compliant / data.total) * 100),
        total: data.total,
      }));
  }, [requirements]);

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-600" />
          Compliance Trend
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#94a3b8" />
            <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" domain={[0, 100]} />
            <Tooltip 
              contentStyle={{ borderRadius: "8px", border: "1px solid #e2e8f0" }}
              formatter={(value) => [`${value}%`, "Compliance"]}
            />
            <Line 
              type="monotone" 
              dataKey="compliance" 
              stroke="#10b981" 
              strokeWidth={2}
              dot={{ fill: "#10b981", r: 4 }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}