import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, ArrowRight } from "lucide-react";
import { format, isPast, differenceInDays } from "date-fns";

export default function RecentActivity({ requirements }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-blue-500" />
          Upcoming Deadlines
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        {requirements.length === 0 ? (
          <p className="text-sm text-slate-400 py-4 text-center">No upcoming deadlines</p>
        ) : (
          <div className="space-y-2">
            {requirements.map(item => {
              const dueDate = new Date(item.due_date);
              const overdue = isPast(dueDate);
              const daysLeft = differenceInDays(dueDate, new Date());

              return (
                <Link
                  key={item.id}
                  to={createPageUrl("RequirementDetail") + `?id=${item.id}`}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 transition-colors group"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-mono font-bold text-slate-400">{item.clause_number}</span>
                      <span className="text-sm text-slate-700 truncate">{item.clause_title}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs ${overdue ? "text-rose-500 font-medium" : "text-slate-400"}`}>
                        {overdue ? "Overdue" : `${daysLeft}d left`}
                      </span>
                      <span className="text-xs text-slate-300">•</span>
                      <span className="text-xs text-slate-400">{format(dueDate, "MMM d, yyyy")}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 shrink-0 ml-2" />
                </Link>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}