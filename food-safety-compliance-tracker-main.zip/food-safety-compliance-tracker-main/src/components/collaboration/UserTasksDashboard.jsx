import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle2, Circle, AlertCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const priorityColors = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-red-100 text-red-800",
  critical: "bg-red-900 text-red-50",
};

export default function UserTasksDashboard() {
  const [tasks, setTasks] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const userTasks = await base44.entities.Task.filter({
        assigned_to: currentUser.email,
      });
      setTasks(userTasks || []);
    } catch (error) {
      console.error("Failed to load tasks:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateTaskStatus = async (taskId, newStatus) => {
    try {
      const updatedTask = await base44.entities.Task.update(taskId, {
        status: newStatus,
        completed_date:
          newStatus === "completed" ? new Date().toISOString() : null,
      });
      setTasks(tasks.map((t) => (t.id === taskId ? updatedTask : t)));
    } catch (error) {
      alert("Failed to update task: " + error.message);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-slate-500">Loading tasks...</p>
        </CardContent>
      </Card>
    );
  }

  const pendingTasks = tasks.filter((t) => t.status === "pending");
  const inProgressTasks = tasks.filter((t) => t.status === "in_progress");
  const completedTasks = tasks.filter((t) => t.status === "completed");

  const stats = [
    { label: "Pending", count: pendingTasks.length, icon: Circle, color: "text-slate-400" },
    { label: "In Progress", count: inProgressTasks.length, icon: AlertCircle, color: "text-blue-500" },
    { label: "Completed", count: completedTasks.length, icon: CheckCircle2, color: "text-green-600" },
  ];

  const renderTaskCard = (task) => (
    <Card key={task.id} className="p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <h4 className="font-medium text-slate-900 mb-1">{task.title}</h4>
          {task.description && (
            <p className="text-sm text-slate-600 mb-3">{task.description}</p>
          )}
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className={priorityColors[task.priority]}>
              {task.priority}
            </Badge>
            <span className="text-xs text-slate-500">{task.entity_type}</span>
            {task.due_date && (
              <span className="text-xs text-slate-600">
                Due: {formatDistanceToNow(new Date(task.due_date), { addSuffix: true })}
              </span>
            )}
          </div>
        </div>
        <div className="flex gap-2 flex-shrink-0">
          {task.status !== "completed" && (
            <Button
              size="sm"
              variant="outline"
              onClick={() =>
                updateTaskStatus(
                  task.id,
                  task.status === "in_progress" ? "completed" : "in_progress"
                )
              }
            >
              {task.status === "pending" ? "Start" : "Complete"}
            </Button>
          )}
        </div>
      </div>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="p-4">
              <div className="flex items-center gap-3">
                <Icon className={`w-6 h-6 ${stat.color}`} />
                <div>
                  <p className="text-xs text-slate-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {stat.count}
                  </p>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Tasks by Status */}
      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pending">Pending ({pendingTasks.length})</TabsTrigger>
          <TabsTrigger value="inProgress">In Progress ({inProgressTasks.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completedTasks.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-4">
          {pendingTasks.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-8">
              No pending tasks
            </p>
          ) : (
            <div className="space-y-3">
              {pendingTasks.map(renderTaskCard)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="inProgress" className="mt-4">
          {inProgressTasks.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-8">
              No tasks in progress
            </p>
          ) : (
            <div className="space-y-3">
              {inProgressTasks.map(renderTaskCard)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed" className="mt-4">
          {completedTasks.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-8">
              No completed tasks
            </p>
          ) : (
            <div className="space-y-3">
              {completedTasks.map(renderTaskCard)}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}