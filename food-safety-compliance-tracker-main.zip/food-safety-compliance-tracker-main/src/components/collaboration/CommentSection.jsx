import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { MessageSquare, Send, AtSign, Reply } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function CommentSection({ entityType, entityId }) {
  const [newComment, setNewComment] = useState("");
  const [replyingTo, setReplyingTo] = useState(null);
  const [user, setUser] = useState(null);
  const [showMentionMenu, setShowMentionMenu] = useState(false);
  const [mentionSearch, setMentionSearch] = useState("");
  const [cursorPosition, setCursorPosition] = useState(0);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  useEffect(() => {
    const unsubscribe = base44.entities.Comment.subscribe((event) => {
      if (event.data?.entity_type === entityType && event.data?.entity_id === entityId) {
        queryClient.invalidateQueries({ queryKey: ["comments", entityType, entityId] });
      }
    });
    return unsubscribe;
  }, [entityType, entityId, queryClient]);

  const { data: comments = [], isLoading } = useQuery({
    queryKey: ["comments", entityType, entityId],
    queryFn: () => base44.entities.Comment.filter({ 
      entity_type: entityType, 
      entity_id: entityId 
    }, "-created_date", 100),
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users-for-mentions"],
    queryFn: () => base44.entities.User.list("-created_date", 100),
  });

  const createCommentMutation = useMutation({
    mutationFn: async (commentData) => {
      const comment = await base44.entities.Comment.create(commentData);
      
      if (commentData.mentioned_users?.length > 0) {
        await base44.functions.invoke("notifyCommentMention", {
          comment_id: comment.id,
          entity_type: entityType,
          entity_id: entityId,
          mentioned_users: commentData.mentioned_users,
          commenter_name: user.full_name || user.email,
        });
      }
      
      return comment;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["comments", entityType, entityId] });
      setNewComment("");
      setReplyingTo(null);
      toast.success("Comment posted");
    },
  });

  const extractMentions = (text) => {
    const mentionRegex = /@(\S+)/g;
    const mentions = [];
    let match;
    while ((match = mentionRegex.exec(text)) !== null) {
      const mentionedUser = users.find(u => 
        u.email.toLowerCase().includes(match[1].toLowerCase()) ||
        u.full_name?.toLowerCase().includes(match[1].toLowerCase())
      );
      if (mentionedUser && !mentions.includes(mentionedUser.email)) {
        mentions.push(mentionedUser.email);
      }
    }
    return mentions;
  };

  const handleTextChange = (e) => {
    const text = e.target.value;
    setNewComment(text);
    setCursorPosition(e.target.selectionStart);
    
    const lastAtSymbol = text.lastIndexOf("@", e.target.selectionStart - 1);
    if (lastAtSymbol !== -1) {
      const textAfterAt = text.substring(lastAtSymbol + 1, e.target.selectionStart);
      if (!textAfterAt.includes(" ") && textAfterAt.length >= 0) {
        setMentionSearch(textAfterAt);
        setShowMentionMenu(true);
      } else {
        setShowMentionMenu(false);
      }
    } else {
      setShowMentionMenu(false);
    }
  };

  const insertMention = (userEmail) => {
    const lastAtSymbol = newComment.lastIndexOf("@", cursorPosition - 1);
    const beforeMention = newComment.substring(0, lastAtSymbol);
    const afterMention = newComment.substring(cursorPosition);
    setNewComment(`${beforeMention}@${userEmail} ${afterMention}`);
    setShowMentionMenu(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;

    const mentionedUsers = extractMentions(newComment);

    createCommentMutation.mutate({
      entity_type: entityType,
      entity_id: entityId,
      comment_text: newComment,
      user_email: user.email,
      user_name: user.full_name,
      mentioned_users: mentionedUsers,
      parent_comment_id: replyingTo?.id || null,
    });
  };

  const filteredUsers = users.filter(u => 
    mentionSearch === "" ||
    u.email.toLowerCase().includes(mentionSearch.toLowerCase()) ||
    u.full_name?.toLowerCase().includes(mentionSearch.toLowerCase())
  ).slice(0, 5);

  const renderCommentText = (text) => {
    const parts = text.split(/(@\S+)/g);
    return parts.map((part, idx) => {
      if (part.startsWith("@")) {
        const email = part.substring(1);
        return (
          <span key={idx} className="bg-emerald-100 text-emerald-700 px-1 rounded font-medium">
            {part}
          </span>
        );
      }
      return <span key={idx}>{part}</span>;
    });
  };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-emerald-600" />
          Discussion ({comments.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Comment List */}
        <div className="space-y-3 max-h-[500px] overflow-y-auto">
          {comments.map((comment) => (
            <div key={comment.id} className={`rounded-lg p-3 ${
              comment.parent_comment_id ? "ml-8 bg-slate-50 border-l-2 border-emerald-200" : "bg-slate-50"
            }`}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-slate-900">
                      {comment.user_name || comment.user_email}
                    </span>
                    <span className="text-xs text-slate-400">
                      {format(new Date(comment.created_date), "MMM d, h:mm a")}
                    </span>
                    {comment.mentioned_users?.length > 0 && (
                      <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200">
                        <AtSign className="w-3 h-3 mr-0.5" />
                        {comment.mentioned_users.length}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-700 whitespace-pre-wrap">
                    {renderCommentText(comment.comment_text)}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setReplyingTo(comment)}
                  className="h-7 px-2"
                >
                  <Reply className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))}
          
          {comments.length === 0 && (
            <p className="text-sm text-slate-400 text-center py-4">
              No comments yet. Start the discussion!
            </p>
          )}
        </div>

        {/* New Comment Form */}
        {replyingTo && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 flex items-center justify-between">
            <span className="text-xs text-blue-700">
              Replying to {replyingTo.user_name || replyingTo.user_email}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setReplyingTo(null)}
              className="h-6 text-xs"
            >
              Cancel
            </Button>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="relative">
            <Textarea
              placeholder="Add a comment... Type @ to mention someone"
              value={newComment}
              onChange={handleTextChange}
              className="min-h-20"
            />
            {showMentionMenu && filteredUsers.length > 0 && (
              <div className="absolute bottom-full left-0 mb-1 w-full bg-white border border-slate-200 rounded-lg shadow-lg z-10 max-h-48 overflow-y-auto">
                {filteredUsers.map(u => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => insertMention(u.email)}
                    className="w-full px-3 py-2 text-left hover:bg-slate-50 flex items-center gap-2"
                  >
                    <AtSign className="w-3 h-3 text-slate-400" />
                    <div>
                      <div className="text-sm font-medium text-slate-900">
                        {u.full_name || u.email}
                      </div>
                      <div className="text-xs text-slate-500">{u.email}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">
              Tip: Use @ to mention users
            </span>
            <Button 
              type="submit" 
              disabled={!newComment.trim() || createCommentMutation.isPending}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Send className="w-4 h-4 mr-2" />
              {createCommentMutation.isPending ? "Posting..." : "Post Comment"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}