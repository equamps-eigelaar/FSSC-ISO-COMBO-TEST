import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Send, MessageCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function CommentThread({ entityType, entityId }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
    loadComments();
  }, [entityType, entityId]);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Failed to load user:", error);
    }
  };

  const loadComments = async () => {
    try {
      const allComments = await base44.entities.Comment.filter({
        entity_type: entityType,
        entity_id: entityId,
      });
      setComments(allComments || []);
    } catch (error) {
      console.error("Failed to load comments:", error);
    }
  };

  const extractMentions = (text) => {
    const mentionRegex = /@(\S+)/g;
    const mentions = [];
    let match;
    while ((match = mentionRegex.exec(text)) !== null) {
      mentions.push(match[1]);
    }
    return mentions;
  };

  const handleSubmit = async () => {
    if (!newComment.trim() || !user) return;

    setLoading(true);
    try {
      const mentions = extractMentions(newComment);

      const comment = await base44.entities.Comment.create({
        entity_type: entityType,
        entity_id: entityId,
        author_email: user.email,
        author_name: user.full_name,
        content: newComment,
        mentions: mentions,
      });

      // Notify mentioned users
      if (mentions.length > 0) {
        await base44.functions.invoke('notifyCommentMention', {
          comment_id: comment.id,
          mentioned_emails: mentions,
          author_email: user.email,
          entity_type: entityType,
          excerpt: newComment.substring(0, 100),
        });
      }

      setComments([...comments, comment]);
      setNewComment("");
    } catch (error) {
      alert("Failed to post comment: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="border-t border-slate-200 pt-6">
      <div className="flex items-center gap-2 mb-4">
        <MessageCircle className="w-5 h-5 text-slate-400" />
        <h3 className="font-semibold text-slate-900">Discussion</h3>
        <span className="text-sm text-slate-500">({comments.length})</span>
      </div>

      {/* Comment List */}
      <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
        {comments.length === 0 ? (
          <p className="text-sm text-slate-500 italic">
            No comments yet. Start the discussion!
          </p>
        ) : (
          comments.map((comment) => (
            <div key={comment.id} className="flex gap-3">
              <Avatar className="w-8 h-8 flex-shrink-0">
                <AvatarFallback className="text-xs">
                  {comment.author_name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm text-slate-900">
                    {comment.author_name}
                  </span>
                  <span className="text-xs text-slate-500">
                    {formatDistanceToNow(new Date(comment.created_date), {
                      addSuffix: true,
                    })}
                  </span>
                </div>
                <p className="text-sm text-slate-700 mt-1 break-words">
                  {comment.content}
                </p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Comment Input */}
      <div className="space-y-2">
        <Textarea
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder="Add a comment... (use @email to mention someone)"
          rows={3}
          className="resize-none"
        />
        <div className="flex justify-between items-center">
          <p className="text-xs text-slate-500">
            Mention users with @email (e.g., @john@example.com)
          </p>
          <Button
            onClick={handleSubmit}
            disabled={!newComment.trim() || loading}
            size="sm"
            className="gap-1 bg-emerald-600 hover:bg-emerald-700"
          >
            <Send className="w-3.5 h-3.5" />
            Post
          </Button>
        </div>
      </div>
    </div>
  );
}