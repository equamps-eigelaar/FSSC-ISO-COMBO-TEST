import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CheckCircle2, Circle, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const priorityColors = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-red-100 text-red-800",
  critical: "bg-red-900 text-red-50",
};

const statusIcons = {
  pending: <Circle className="w-4 h-4 text-slate-400" />,
  in_progress: <Circle className="w-4 h-4 text-blue-500 fill-blue-500" />,
  completed: <CheckCircle2 className="w-4 h-4 text-green-600" />,
  cancelled: <Circle className="w-4 h-4 text-slate-300" />,
};

export default function TaskList({ entityType, entityId, onTasksUpdated }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTasks();
  }, [entityType, entityId]);

  const loadTasks = async () => {
    try {
      const allTasks = await base44.entities.Task.filter({
        entity_type: entityType,
        entity_id: entityId,
      });
      setTasks(allTasks || []);
    } catch (error) {
      console.error("Failed to load tasks:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateTaskStatus = async (taskId, newStatus) => {
    try {
      const updatedTask = await base44.entities.Task.update(taskId, {
        status: newStatus,
        completed_date:
          newStatus === "completed" ? new Date().toISOString() : null,
      });
      setTasks(tasks.map((t) => (t.id === taskId ? updatedTask : t)));
      onTasksUpdated?.();
    } catch (error) {
      alert("Failed to update task: " + error.message);
    }
  };

  const deleteTask = async (taskId) => {
    if (!confirm("Delete this task?")) return;
    try {
      await base44.entities.Task.delete(taskId);
      setTasks(tasks.filter((t) => t.id !== taskId));
      onTasksUpdated?.();
    } catch (error) {
      alert("Failed to delete task: " + error.message);
    }
  };

  if (loading) {
    return <div className="text-sm text-slate-500">Loading tasks...</div>;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <h4 className="font-medium text-slate-900">Assigned Tasks</h4>
        <span className="text-sm text-slate-500">({tasks.length})</span>
      </div>

      {tasks.length === 0 ? (
        <p className="text-sm text-slate-500 italic">
          No tasks assigned. Create one to delegate work.
        </p>
      ) : (
        <div className="space-y-2">
          {tasks.map((task) => (
            <Card key={task.id} className="p-3">
              <div className="flex items-start gap-3">
                <button
                  onClick={() =>
                    updateTaskStatus(
                      task.id,
                      task.status === "completed" ? "pending" : "completed"
                    )
                  }
                  className="mt-1 cursor-pointer hover:opacity-70 flex-shrink-0"
                >
                  {statusIcons[task.status]}
                </button>

                <div className="flex-1 min-w-0">
                  <p
                    className={`text-sm font-medium ${
                      task.status === "completed"
                        ? "line-through text-slate-400"
                        : "text-slate-900"
                    }`}
                  >
                    {task.title}
                  </p>
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <Badge className={priorityColors[task.priority]}>
                      {task.priority}
                    </Badge>
                    {task.assigned_to && (
                      <span className="text-xs text-slate-600">
                        To: {task.assigned_to}
                      </span>
                    )}
                    {task.due_date && (
                      <span className="text-xs text-slate-600">
                        Due:{" "}
                        {formatDistanceToNow(new Date(task.due_date), {
                          addSuffix: true,
                        })}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <Select value={task.status} onValueChange={(s) => updateTaskStatus(task.id, s)}>
                    <SelectTrigger className="w-24 h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteTask(task.id)}
                    className="w-8 h-8 text-slate-400 hover:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}