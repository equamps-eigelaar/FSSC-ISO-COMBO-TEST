import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { MessageCircle, CheckSquare, Plus } from "lucide-react";
import TaskAssignmentDialog from "./TaskAssignmentDialog";
import TaskList from "./TaskList";
import CommentThread from "./CommentThread";

export default function CollaborationPanel({
  entityType,
  entityId,
  showTasks = true,
  showComments = true,
}) {
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [tasksRefresh, setTasksRefresh] = useState(0);

  if (!showTasks && !showComments) {
    return null;
  }

  return (
    <div className="mt-8 border-t border-slate-200 pt-6">
      <Tabs defaultValue={showComments ? "comments" : "tasks"} className="w-full">
        <TabsList className="grid w-full gap-0" style={{ gridTemplateColumns: `repeat(${(showTasks ? 1 : 0) + (showComments ? 1 : 0)}, 1fr)` }}>
          {showComments && (
            <TabsTrigger value="comments" className="gap-2">
              <MessageCircle className="w-4 h-4" />
              Discussion
            </TabsTrigger>
          )}
          {showTasks && (
            <TabsTrigger value="tasks" className="gap-2">
              <CheckSquare className="w-4 h-4" />
              Tasks
            </TabsTrigger>
          )}
        </TabsList>

        {showComments && (
          <TabsContent value="comments" className="mt-6">
            <CommentThread entityType={entityType} entityId={entityId} />
          </TabsContent>
        )}

        {showTasks && (
          <TabsContent value="tasks" className="mt-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <TaskList
                  entityType={entityType}
                  entityId={entityId}
                  onTasksUpdated={() => setTasksRefresh((p) => p + 1)}
                />
                <Button
                  onClick={() => setTaskDialogOpen(true)}
                  size="sm"
                  className="gap-1 bg-emerald-600 hover:bg-emerald-700"
                >
                  <Plus className="w-4 h-4" />
                  Assign Task
                </Button>
              </div>
            </div>

            <TaskAssignmentDialog
              open={taskDialogOpen}
              onOpenChange={setTaskDialogOpen}
              entityType={entityType}
              entityId={entityId}
              onTaskCreated={() => setTasksRefresh((p) => p + 1)}
            />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}