import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Camera, Trash2, CheckCircle2, XCircle } from "lucide-react";
import AIAuditAssistant from "./AIAuditAssistant";
import AICorrectiveActions from "./AICorrectiveActions";
import { toast } from "sonner";

export default function AuditFindingCard({ item, onUpdate, onClose, auditScope }) {
  const [finding, setFinding] = useState(item.finding || "");
  const [severity, setSeverity] = useState(item.severity || "minor");
  const [notes, setNotes] = useState(item.notes || "");
  const [photos, setPhotos] = useState(item.photos || []);
  const [uploading, setUploading] = useState(false);

  const handlePhotoCapture = async (e) => {
    const files = Array.from(e.target.files);
    setUploading(true);
    try {
      const uploads = await Promise.all(
        files.map(file => base44.integrations.Core.UploadFile({ file }))
      );
      const newPhotos = [...photos, ...uploads.map(u => u.file_url)];
      setPhotos(newPhotos);
      toast.success(`${files.length} photo(s) uploaded`);
    } catch (error) {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const removePhoto = (index) => {
    setPhotos(photos.filter((_, i) => i !== index));
  };

  const applyCorrectiveActions = (text) => {
    setNotes(prev => prev ? `${prev}\n\n${text}` : text);
  };

  const saveAndClose = () => {
    onUpdate({
      finding: finding.trim() || null,
      severity: finding.trim() ? severity : null,
      notes: notes.trim(),
      photos,
      completed: true
    });
    toast.success("Finding saved");
    onClose();
  };

  const markAsPass = () => {
    onUpdate({
      finding: null,
      severity: null,
      notes: notes.trim(),
      photos,
      completed: true
    });
    toast.success("Marked as passed");
    onClose();
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="px-4 py-3">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onClose}
              className="min-h-[44px] min-w-[44px]"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h2 className="font-semibold text-slate-900 dark:text-white text-sm">
                {item.clause_number}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                {item.title}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 pb-24">
        {/* AI Compliance Check */}
        <AIAuditAssistant
          item={item}
          auditScope={auditScope}
          finding={finding}
        />

        {/* Finding Input */}
        <Card className="border-0 shadow-sm mb-4 mt-3">
          <CardHeader>
            <CardTitle className="text-sm font-semibold">Finding Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 block">
                Issue or Non-Conformance
              </label>
              <Textarea
                value={finding}
                onChange={(e) => setFinding(e.target.value)}
                placeholder="Describe the finding... (leave empty if no issues)"
                className="min-h-[120px] text-base"
              />
            </div>

            {finding.trim() && (
              <div>
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 block">
                  Severity
                </label>
                <Select value={severity} onValueChange={setSeverity}>
                  <SelectTrigger className="min-h-[48px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="minor">🟡 Minor</SelectItem>
                    <SelectItem value="major">🟠 Major</SelectItem>
                    <SelectItem value="critical">🔴 Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* AI Corrective Actions (only shown when a finding exists) */}
            {finding.trim() && (
              <AICorrectiveActions
                finding={finding}
                clauseNumber={item.clause_number}
                clauseTitle={item.title}
                severity={severity}
                onApply={applyCorrectiveActions}
              />
            )}
          </CardContent>
        </Card>

        {/* Photo Evidence */}
        <Card className="border-0 shadow-sm mb-4">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold">Photo Evidence</CardTitle>
              <Button 
                variant="outline" 
                size="sm" 
                disabled={uploading}
                className="min-h-[44px]"
                asChild
              >
                <label className="cursor-pointer">
                  <Camera className="w-4 h-4 mr-2" />
                  {uploading ? "Uploading..." : "Add Photo"}
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    capture="environment"
                    onChange={handlePhotoCapture}
                    className="hidden"
                  />
                </label>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {photos.length > 0 ? (
              <div className="grid grid-cols-2 gap-3">
                {photos.map((photo, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={photo}
                      alt={`Evidence ${index + 1}`}
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <button
                      onClick={() => removePhoto(index)}
                      className="absolute top-2 right-2 p-2 bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity min-h-[44px] min-w-[44px]"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500 dark:text-slate-400 text-sm">
                No photos added yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notes */}
        <Card className="border-0 shadow-sm mb-6">
          <CardHeader>
            <CardTitle className="text-sm font-semibold">Additional Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Any additional observations or context..."
              className="min-h-[100px] text-base"
            />
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button 
            className="w-full min-h-[56px] text-base"
            size="lg"
            onClick={saveAndClose}
            disabled={!finding.trim() && photos.length === 0}
          >
            <CheckCircle2 className="w-5 h-5 mr-2" />
            Save Finding
          </Button>
          
          <Button 
            className="w-full min-h-[56px] text-base"
            size="lg"
            variant="outline"
            onClick={markAsPass}
          >
            <CheckCircle2 className="w-5 h-5 mr-2" />
            Mark as Passed (No Issues)
          </Button>
        </div>

        {/* Offline Notice */}
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <div className="flex items-center gap-2 text-xs text-blue-800 dark:text-blue-200">
            <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
            Changes auto-save and sync when online
          </div>
        </div>
      </div>
    </div>
  );
}