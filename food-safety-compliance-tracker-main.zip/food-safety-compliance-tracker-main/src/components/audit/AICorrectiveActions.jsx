import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Loader2, Copy, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

/**
 * AICorrectiveActions – suggests corrective actions for a specific finding.
 * Accepts: finding (string), clauseNumber, clauseTitle, severity, onApply (optional callback)
 */
export default function AICorrectiveActions({ finding, clauseNumber, clauseTitle, severity, onApply }) {
  const [actions, setActions] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(null);

  if (!finding?.trim()) return null;

  const getSuggestions = async () => {
    setLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an ISO 22000 / FSSC 22000 corrective action specialist for packaging manufacturing.

A ${severity || "minor"} non-conformance was found during an audit:
Clause: ${clauseNumber} — ${clauseTitle}
Finding: "${finding}"

Suggest 3 practical corrective actions in JSON. Each should be specific, actionable, and implementable within a packaging facility. Include:
- immediate_action: What to do right now (containment)
- root_cause_actions: 2–3 root cause corrective actions
- timeline: Recommended timeline (e.g. "Immediate", "Within 7 days", "30 days")
- verification: How to verify the corrective action was effective`,
        response_json_schema: {
          type: "object",
          properties: {
            immediate_action: { type: "string" },
            root_cause_actions: { type: "array", items: { type: "string" } },
            timeline: { type: "string" },
            verification: { type: "string" }
          }
        }
      });
      setActions(result);
    } catch (e) {
      toast.error("Could not generate corrective actions");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text, idx) => {
    navigator.clipboard.writeText(text);
    setCopied(idx);
    setTimeout(() => setCopied(null), 2000);
    toast.success("Copied to clipboard");
  };

  const applyAll = () => {
    if (!actions || !onApply) return;
    const combined = [
      `Immediate: ${actions.immediate_action}`,
      ...(actions.root_cause_actions || []).map(a => `• ${a}`),
      `Timeline: ${actions.timeline}`,
      `Verification: ${actions.verification}`
    ].join("\n");
    onApply(combined);
    toast.success("Corrective actions applied");
  };

  return (
    <div className="mt-3">
      {!actions ? (
        <Button
          variant="outline"
          size="sm"
          className="w-full min-h-[44px] border-emerald-200 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-800 dark:text-emerald-400 dark:hover:bg-emerald-900/20"
          onClick={getSuggestions}
          disabled={loading}
        >
          {loading ? (
            <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Generating actions...</>
          ) : (
            <><Sparkles className="w-4 h-4 mr-2" />AI Corrective Actions</>
          )}
        </Button>
      ) : (
        <Card className="border border-emerald-100 dark:border-emerald-900 bg-emerald-50/50 dark:bg-emerald-900/10 shadow-none">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> AI Corrective Action Suggestions
              </p>
              <Badge variant="outline" className="text-xs">{actions.timeline}</Badge>
            </div>

            {/* Immediate action */}
            <div className="bg-white dark:bg-slate-900 rounded-lg p-3 border border-emerald-100 dark:border-emerald-800">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-xs font-semibold text-red-600 mb-1">⚡ Immediate Action</p>
                  <p className="text-xs text-slate-700 dark:text-slate-300">{actions.immediate_action}</p>
                </div>
                <button
                  onClick={() => copyToClipboard(actions.immediate_action, 'imm')}
                  className="flex-shrink-0 p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                >
                  {copied === 'imm' ? <CheckCircle2 className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-400" />}
                </button>
              </div>
            </div>

            {/* Root cause actions */}
            {actions.root_cause_actions?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">Root Cause Corrective Actions</p>
                <ul className="space-y-1.5">
                  {actions.root_cause_actions.map((a, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 rounded p-2 border border-slate-100 dark:border-slate-800">
                      <span className="text-emerald-500 mt-0.5 flex-shrink-0">•</span>
                      <span className="flex-1">{a}</span>
                      <button
                        onClick={() => copyToClipboard(a, i)}
                        className="flex-shrink-0 p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                      >
                        {copied === i ? <CheckCircle2 className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-300" />}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Verification */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded p-2">
              <p className="text-xs font-semibold text-blue-700 dark:text-blue-300 mb-0.5">Verification Method</p>
              <p className="text-xs text-slate-700 dark:text-slate-300">{actions.verification}</p>
            </div>

            {/* Apply button */}
            {onApply && (
              <Button size="sm" className="w-full min-h-[44px]" onClick={applyAll}>
                <CheckCircle2 className="w-4 h-4 mr-2" /> Apply to Notes
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}