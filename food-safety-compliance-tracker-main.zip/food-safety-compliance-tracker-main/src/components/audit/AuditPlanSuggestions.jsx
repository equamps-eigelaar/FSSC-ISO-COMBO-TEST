import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, 
  Loader2, 
  Calendar, 
  Clock, 
  Target, 
  CheckCircle2,
  AlertCircle,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

const PRIORITY_CONFIG = {
  critical: { color: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400", label: "Critical" },
  high: { color: "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400", label: "High" },
  medium: { color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400", label: "Medium" },
  low: { color: "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400", label: "Low" }
};

const AUDIT_TYPE_CONFIG = {
  internal: { color: "bg-purple-100 text-purple-800", label: "Internal" },
  external: { color: "bg-indigo-100 text-indigo-800", label: "External" },
  supplier: { color: "bg-cyan-100 text-cyan-800", label: "Supplier" },
  management_review: { color: "bg-emerald-100 text-emerald-800", label: "Management Review" },
  certification: { color: "bg-rose-100 text-rose-800", label: "Certification" }
};

export default function AuditPlanSuggestions() {
  const [generating, setGenerating] = useState(false);
  const [expandedPlan, setExpandedPlan] = useState(null);
  const queryClient = useQueryClient();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ['audit-plans'],
    queryFn: () => base44.entities.AuditPlan.filter({ status: "suggested" }, '-created_date', 10)
  });

  const updatePlanMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AuditPlan.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['audit-plans'] });
      toast.success('Audit plan updated');
    }
  });

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const response = await base44.functions.invoke('generateAuditPlan', {});
      queryClient.invalidateQueries({ queryKey: ['audit-plans'] });
      toast.success(`Generated ${response.data.plans.length} audit plan suggestions`);
    } catch (error) {
      toast.error('Failed to generate audit plans');
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  const handleApprove = (planId) => {
    updatePlanMutation.mutate({
      id: planId,
      data: { status: "approved" }
    });
  };

  const handleSchedule = (planId) => {
    updatePlanMutation.mutate({
      id: planId,
      data: { status: "scheduled" }
    });
  };

  if (isLoading) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="py-8 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
        </CardContent>
      </Card>
    );
  }

  if (plans.length === 0) {
    return (
      <Card className="border-0 shadow-sm bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/20 dark:to-purple-950/20">
        <CardHeader>
          <CardTitle className="text-sm font-semibold text-indigo-900 dark:text-indigo-100">
            AI Audit Planning
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <Calendar className="w-12 h-12 text-indigo-300 dark:text-indigo-700 mx-auto mb-3" />
            <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">
              Generate AI-powered audit plans based on your compliance gaps and risks
            </p>
            <Button
              onClick={handleGenerate}
              disabled={generating}
              className="bg-indigo-600 hover:bg-indigo-700 min-h-[44px]"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating Plans...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Audit Plans
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            Suggested Audit Plans
          </CardTitle>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleGenerate}
            disabled={generating}
            className="text-indigo-600 hover:text-indigo-700"
          >
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {plans.map(plan => {
          const isExpanded = expandedPlan === plan.id;
          const priorityConfig = PRIORITY_CONFIG[plan.priority] || PRIORITY_CONFIG.medium;
          const typeConfig = AUDIT_TYPE_CONFIG[plan.audit_type] || {};

          return (
            <div
              key={plan.id}
              className="bg-white dark:bg-slate-800 border dark:border-slate-700 rounded-lg p-4 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-semibold text-slate-900 dark:text-white text-sm">
                      {plan.title}
                    </h4>
                    <Badge className={priorityConfig.color}>
                      {priorityConfig.label}
                    </Badge>
                    <Badge variant="outline" className={typeConfig.color}>
                      {typeConfig.label}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500 dark:text-slate-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {format(new Date(plan.suggested_date), 'MMM d, yyyy')}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {plan.estimated_duration_hours}h
                    </span>
                    {plan.confidence_score && (
                      <span className="flex items-center gap-1">
                        <Target className="w-3 h-3" />
                        {plan.confidence_score}% confidence
                      </span>
                    )}
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setExpandedPlan(isExpanded ? null : plan.id)}
                  className="shrink-0"
                >
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </Button>
              </div>

              {isExpanded && (
                <div className="space-y-3 pt-3 border-t dark:border-slate-700">
                  <div>
                    <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Scope:</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">{plan.scope}</p>
                  </div>

                  <div>
                    <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Rationale:</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">{plan.rationale}</p>
                  </div>

                  {plan.focus_areas && plan.focus_areas.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Focus Areas:</p>
                      <div className="flex flex-wrap gap-1">
                        {plan.focus_areas.map((area, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {area}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {plan.recommended_auditors && plan.recommended_auditors.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Recommended Auditors:</p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        {plan.recommended_auditors.join(', ')}
                      </p>
                    </div>
                  )}

                  {plan.checklist && plan.checklist.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Checklist ({plan.checklist.length} items):
                      </p>
                      <div className="space-y-1 max-h-32 overflow-y-auto">
                        {plan.checklist.slice(0, 5).map((item, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-400">
                            <AlertCircle className="w-3 h-3 mt-0.5 shrink-0" />
                            <span>{item.item}</span>
                          </div>
                        ))}
                        {plan.checklist.length > 5 && (
                          <p className="text-xs text-slate-400 italic">
                            +{plan.checklist.length - 5} more items
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleApprove(plan.id)}
                  disabled={updatePlanMutation.isPending}
                  className="flex-1 min-h-[44px]"
                >
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Approve
                </Button>
                <Button
                  size="sm"
                  onClick={() => handleSchedule(plan.id)}
                  disabled={updatePlanMutation.isPending}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 min-h-[44px]"
                >
                  <Calendar className="w-3 h-3 mr-1" />
                  Schedule
                </Button>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}