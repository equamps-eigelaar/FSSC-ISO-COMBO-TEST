import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, AlertTriangle, CheckCircle2, Loader2, ChevronDown, ChevronUp, Lightbulb } from "lucide-react";
import { toast } from "sonner";

/**
 * AIAuditAssistant – shows real-time compliance suggestions for a single checklist item.
 * Accepts: item (checklist item), auditScope, finding text
 */
export default function AIAuditAssistant({ item, auditScope, finding }) {
  const [suggestions, setSuggestions] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const getSuggestions = async () => {
    setLoading(true);
    setExpanded(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an ISO 22000 / FSSC 22000 compliance expert conducting a packaging manufacturing audit.

Clause: ${item.clause_number} — ${item.title}
Section: ${item.category || "General"}
Audit scope: ${auditScope || "FSSC 22000 packaging manufacturing site"}
Auditor's recorded finding: "${finding || "(none yet)"}"

Provide concise, practical guidance in JSON format:
1. key_requirements: Up to 3 bullet points the auditor should verify for this clause.
2. red_flags: Up to 3 specific non-conformance red flags to watch for.
3. evidence_to_request: Up to 3 types of evidence the auditor should ask for.
4. compliance_check: A short verdict on the finding provided (e.g. "Potential major non-conformance" or "Appears compliant — verify evidence").`,
        response_json_schema: {
          type: "object",
          properties: {
            key_requirements: { type: "array", items: { type: "string" } },
            red_flags: { type: "array", items: { type: "string" } },
            evidence_to_request: { type: "array", items: { type: "string" } },
            compliance_check: { type: "string" }
          }
        }
      });
      setSuggestions(result);
    } catch (e) {
      toast.error("AI suggestions unavailable");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-3">
      <Button
        variant="outline"
        size="sm"
        className="w-full min-h-[44px] border-violet-200 text-violet-700 hover:bg-violet-50 dark:border-violet-800 dark:text-violet-400 dark:hover:bg-violet-900/20"
        onClick={suggestions ? () => setExpanded(!expanded) : getSuggestions}
        disabled={loading}
      >
        {loading ? (
          <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Getting AI suggestions...</>
        ) : (
          <>
            <Sparkles className="w-4 h-4 mr-2" />
            AI Compliance Check
            {suggestions && (expanded ? <ChevronUp className="w-3 h-3 ml-auto" /> : <ChevronDown className="w-3 h-3 ml-auto" />)}
          </>
        )}
      </Button>

      {suggestions && expanded && (
        <Card className="mt-2 border border-violet-100 dark:border-violet-900 bg-violet-50/50 dark:bg-violet-900/10 shadow-none">
          <CardContent className="p-4 space-y-3">
            {/* Compliance verdict */}
            <div className="flex items-start gap-2 p-2 bg-white dark:bg-slate-900 rounded-lg border border-violet-100 dark:border-violet-800">
              <Sparkles className="w-4 h-4 text-violet-600 mt-0.5 flex-shrink-0" />
              <p className="text-xs font-medium text-slate-800 dark:text-slate-200">{suggestions.compliance_check}</p>
            </div>

            {/* Key requirements */}
            {suggestions.key_requirements?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Verify these requirements
                </p>
                <ul className="space-y-1">
                  {suggestions.key_requirements.map((r, i) => (
                    <li key={i} className="text-xs text-slate-700 dark:text-slate-300 flex items-start gap-1.5">
                      <span className="text-emerald-500 mt-0.5">•</span>{r}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Red flags */}
            {suggestions.red_flags?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-amber-600" /> Non-conformance red flags
                </p>
                <ul className="space-y-1">
                  {suggestions.red_flags.map((f, i) => (
                    <li key={i} className="text-xs text-slate-700 dark:text-slate-300 flex items-start gap-1.5">
                      <span className="text-amber-500 mt-0.5">•</span>{f}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Evidence */}
            {suggestions.evidence_to_request?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 flex items-center gap-1">
                  <Lightbulb className="w-3 h-3 text-blue-600" /> Evidence to request
                </p>
                <ul className="space-y-1">
                  {suggestions.evidence_to_request.map((e, i) => (
                    <li key={i} className="text-xs text-slate-700 dark:text-slate-300 flex items-start gap-1.5">
                      <span className="text-blue-500 mt-0.5">•</span>{e}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}