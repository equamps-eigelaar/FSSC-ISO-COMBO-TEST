import { base44 } from "@/api/base44Client";

/**
 * Hook to log user actions to the audit trail
 * Handles login, data modifications, report generation, and setting changes
 */
export const useAuditLog = () => {
  const logAction = async (actionType, description, metadata = {}) => {
    try {
      const response = await base44.functions.invoke('logUserAction', {
        action_type: actionType,
        description,
        entity_type: metadata.entity_type,
        entity_id: metadata.entity_id,
        entity_label: metadata.entity_label,
        context: metadata.context,
        details: metadata.details,
        field_changes: metadata.field_changes
      });
      return response.data;
    } catch (error) {
      console.error('Failed to log action:', error);
      // Fail silently - don't disrupt user experience
      return null;
    }
  };

  const logLogin = async (method = 'email') => {
    return logAction('user_login', `User logged in via ${method}`, {
      entity_type: 'System',
      context: { login_method: method }
    });
  };

  const logDataModification = async (entityType, operation, entityLabel, fieldChanges = null) => {
    const actionTypeMap = {
      create: 'requirement_created',
      update: 'requirement_updated',
      delete: 'requirement_deleted'
    };
    
    return logAction(
      actionTypeMap[operation] || `${entityType}_${operation}`,
      `${operation.charAt(0).toUpperCase() + operation.slice(1)} ${entityType}: ${entityLabel}`,
      {
        entity_type: entityType,
        entity_label: entityLabel,
        context: { operation },
        field_changes: fieldChanges
      }
    );
  };

  const logReportGeneration = async (reportType, reportName) => {
    return logAction('report_generated', `Generated ${reportType} report: ${reportName}`, {
      entity_type: 'Report',
      entity_label: reportName,
      context: { report_type: reportType }
    });
  };

  const logSettingChange = async (settingName, oldValue, newValue) => {
    return logAction('settings_changed', `Setting changed: ${settingName}`, {
      entity_type: 'Settings',
      entity_label: settingName,
      context: { setting_name: settingName },
      field_changes: [{
        field: settingName,
        old_value: oldValue,
        new_value: newValue
      }]
    });
  };

  const logBugReport = async (ticketNumber, title) => {
    return logAction('bug_reported', `Bug report submitted: ${ticketNumber} - ${title}`, {
      entity_type: 'SupportTicket',
      entity_label: ticketNumber,
      context: { ticket_number: ticketNumber }
    });
  };

  const logAccessControl = async (action, resource) => {
    return logAction('access_control_event', `${action}: ${resource}`, {
      entity_type: 'AccessControl',
      entity_label: resource,
      context: { action, resource }
    });
  };

  const logBatchOperation = async (batchNumber, operation, status) => {
    return logAction('batch_operation', `${operation} batch: ${batchNumber} (${status})`, {
      entity_type: 'FoodBatchRecord',
      entity_label: batchNumber,
      context: { operation, status }
    });
  };

  const logAuditAction = async (auditType, auditName, result) => {
    return logAction('audit_completed', `${auditType} audit: ${auditName} - ${result}`, {
      entity_type: 'ComplianceAudit',
      entity_label: auditName,
      context: { audit_type: auditType, result }
    });
  };

  return {
    logAction,
    logLogin,
    logDataModification,
    logReportGeneration,
    logSettingChange,
    logBugReport,
    logAccessControl,
    logBatchOperation,
    logAuditAction
  };
};