# Audit Trail System Documentation

## Overview
The robust audit trail feature logs all significant user actions within the application to enhance accountability and traceability for compliance purposes.

## Features

### 1. **Comprehensive Action Logging**
- **User Logins**: Track all user login events with login method
- **Data Modifications**: Log all create, update, and delete operations on compliance data
- **Report Generation**: Track all reports generated, with type and timestamp
- **Setting Changes**: Monitor configuration and settings modifications with before/after values
- **Bug Reports**: Log support ticket submissions
- **Access Control**: Track access-related events
- **Batch Operations**: Monitor food batch and material batch operations
- **Audit Activities**: Log compliance audit completions

### 2. **Available Logging Functions**

#### `useAuditLog()` Hook
Located in `components/audit/useAuditLog.js`, provides these functions:

```javascript
import { useAuditLog } from '@/components/audit/useAuditLog';

const { 
  logAction,
  logLogin,
  logDataModification,
  logReportGeneration,
  logSettingChange,
  logBugReport,
  logAccessControl,
  logBatchOperation,
  logAuditAction
} = useAuditLog();
```

#### Usage Examples

**Log a Login Event:**
```javascript
await logLogin('email');
```

**Log Data Modification:**
```javascript
await logDataModification(
  'ComplianceRequirement',
  'update',
  'Section 4.1 - Food Safety Policy',
  fieldChanges // optional array of field changes
);
```

**Log Report Generation:**
```javascript
await logReportGeneration('compliance', 'Monthly Compliance Report - Feb 2026');
```

**Log Settings Change:**
```javascript
await logSettingChange('audit_frequency', 'monthly', 'weekly');
```

**Log Bug Report:**
```javascript
await logBugReport('TKT-001234', 'Dashboard not loading');
```

### 3. **Activity Logging Function**
Backend function: `functions/logActivity.js`
- Automatically captures entity-level changes
- Triggered on entity create/update/delete events
- Extracts field-level differences
- Identifies workflow status changes

### 4. **User Action Logging Function**
Backend function: `functions/logUserAction.js`
- Logs custom user actions (logins, report generation, etc.)
- Requires authentication
- Returns timestamp of logged action

## Activity Types

| Activity Type | Description | Icon |
|---|---|---|
| `user_login` | User login event | User |
| `requirement_created` | New compliance requirement | FileText |
| `requirement_updated` | Updated requirement | FileText |
| `status_changed` | Status change on requirement | CheckCircle2 |
| `risk_added` | New risk assessment | AlertTriangle |
| `risk_updated` | Updated risk assessment | AlertTriangle |
| `report_generated` | Report generated | FileText |
| `settings_changed` | Settings configuration changed | Shield |
| `bug_reported` | Support ticket submitted | AlertTriangle |
| `batch_operation` | Batch record operation | Package |
| `audit_completed` | Audit completed | CheckCircle2 |

## Audit Trail Page

Located at `/ActivityMonitor`, the audit trail page provides:

### Features
- **Real-time Activity Feed**: Live updates as actions are logged
- **Advanced Filtering**:
  - Search by description, user, or entity
  - Filter by event type
  - Filter by module (Requirements, Risks, Documents, etc.)
  - Filter by user
  - Filter by date range (24h, 7 days, 30 days, 90 days, all time)

### Field Change Tracking
- Expandable rows showing detailed field-level changes
- Old and new values clearly displayed
- Supports all data types (text, numbers, objects, arrays)

### Export
- Export filtered audit trail to CSV
- Includes timestamp, user, action type, and field changes
- Useful for compliance documentation and audits

### Statistics
- Total events count
- Today's activity
- Number of active users
- Filtered results count

## Integration Points

### Required Changes to Existing Components

1. **Dashboard & Report Generation**:
   ```javascript
   const { logReportGeneration } = useAuditLog();
   // After report is generated
   await logReportGeneration('compliance', reportName);
   ```

2. **Settings Page**:
   ```javascript
   const { logSettingChange } = useAuditLog();
   // When settings are updated
   await logSettingChange(settingName, oldValue, newValue);
   ```

3. **Bug Report Dialog**:
   ```javascript
   const { logBugReport } = useAuditLog();
   // After ticket is created
   await logBugReport(ticketNumber, title);
   ```

## Data Retention

- All activities are logged to the `ActivityLog` entity
- No automatic purging - suitable for compliance requirements
- Recommended: Review and archive logs quarterly for optimal performance

## Compliance Benefits

1. **User Accountability**: Track who made what changes and when
2. **Data Integrity**: Verify all modifications with field-level changes
3. **Audit Trail**: Complete history for independent audits
4. **Non-Repudiation**: Users cannot deny their actions
5. **Incident Investigation**: Quickly identify problematic changes
6. **Regulatory Compliance**: Meets FSSC 22000 documentation requirements

## Performance Considerations

- Logging is asynchronous and non-blocking
- Failed logging attempts don't interrupt user workflows
- Efficient filtering on the audit page with 500-entry pagination
- Real-time subscriptions for live updates