import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Play, Factory, Package, FlaskConical, Truck, Wrench, Snowflake, ShieldCheck, Users, Inbox, LayoutGrid } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

const DEPARTMENTS = [
  { id: "receiving", label: "Receiving & Intake", icon: Inbox, color: "bg-blue-50 border-blue-200 text-blue-700", iconColor: "text-blue-600" },
  { id: "production", label: "Production / Processing", icon: Factory, color: "bg-orange-50 border-orange-200 text-orange-700", iconColor: "text-orange-600" },
  { id: "packaging", label: "Packaging", icon: Package, color: "bg-purple-50 border-purple-200 text-purple-700", iconColor: "text-purple-600" },
  { id: "warehouse", label: "Warehouse / Storage", icon: LayoutGrid, color: "bg-yellow-50 border-yellow-200 text-yellow-700", iconColor: "text-yellow-600" },
  { id: "cold_chain", label: "Cold Chain / Cold Store", icon: Snowflake, color: "bg-cyan-50 border-cyan-200 text-cyan-700", iconColor: "text-cyan-600" },
  { id: "qc_lab", label: "Quality Control Lab", icon: FlaskConical, color: "bg-green-50 border-green-200 text-green-700", iconColor: "text-green-600" },
  { id: "maintenance", label: "Maintenance & Engineering", icon: Wrench, color: "bg-slate-50 border-slate-200 text-slate-700", iconColor: "text-slate-600" },
  { id: "hygiene", label: "Hygiene & Sanitation", icon: ShieldCheck, color: "bg-teal-50 border-teal-200 text-teal-700", iconColor: "text-teal-600" },
  { id: "dispatch", label: "Dispatch / Distribution", icon: Truck, color: "bg-rose-50 border-rose-200 text-rose-700", iconColor: "text-rose-600" },
  { id: "personnel", label: "Personnel Facilities", icon: Users, color: "bg-indigo-50 border-indigo-200 text-indigo-700", iconColor: "text-indigo-600" },
];

export default function StartDepartmentAuditDialog({ open, onOpenChange, onAuditStarted }) {
  const [selected, setSelected] = useState(null);
  const [customDept, setCustomDept] = useState("");
  const [loading, setLoading] = useState(false);

  const handleStart = async () => {
    const deptLabel = selected === "custom"
      ? customDept.trim()
      : DEPARTMENTS.find(d => d.id === selected)?.label;

    if (!deptLabel) return;

    setLoading(true);
    const audit = await base44.entities.AuditPlan.create({
      title: `Field Audit – ${deptLabel}`,
      audit_type: "internal",
      scope: deptLabel,
      suggested_date: new Date().toISOString().split("T")[0],
      status: "in_progress",
      priority: "medium",
      focus_areas: [deptLabel],
      checklist: [],
    });
    toast.success(`Audit started for ${deptLabel}`);
    setLoading(false);
    setSelected(null);
    setCustomDept("");
    onOpenChange(false);
    onAuditStarted(audit);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Start Field Audit by Department</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-2 mt-2">
          {DEPARTMENTS.map(dept => {
            const Icon = dept.icon;
            const isSelected = selected === dept.id;
            return (
              <button
                key={dept.id}
                onClick={() => setSelected(dept.id)}
                className={`flex items-center gap-3 p-3 rounded-lg border-2 text-left transition-all
                  ${isSelected ? `${dept.color} border-current scale-[1.02] shadow` : "bg-white border-slate-200 hover:border-slate-300"}`}
              >
                <Icon className={`w-5 h-5 flex-shrink-0 ${isSelected ? dept.iconColor : "text-slate-400"}`} />
                <span className={`text-sm font-medium leading-tight ${isSelected ? "" : "text-slate-700"}`}>
                  {dept.label}
                </span>
              </button>
            );
          })}

          {/* Custom */}
          <button
            onClick={() => setSelected("custom")}
            className={`flex items-center gap-3 p-3 rounded-lg border-2 text-left transition-all col-span-2
              ${selected === "custom" ? "bg-emerald-50 border-emerald-400 text-emerald-700 scale-[1.01] shadow" : "bg-white border-dashed border-slate-300 hover:border-slate-400"}`}
          >
            <span className="text-sm font-medium text-slate-500">+ Other / Custom Department</span>
          </button>
        </div>

        {selected === "custom" && (
          <Input
            placeholder="Enter department name…"
            value={customDept}
            onChange={e => setCustomDept(e.target.value)}
            className="mt-2"
            autoFocus
          />
        )}

        <div className="flex gap-2 mt-4">
          <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="flex-1 bg-emerald-600 hover:bg-emerald-700 gap-2"
            disabled={!selected || (selected === "custom" && !customDept.trim()) || loading}
            onClick={handleStart}
          >
            <Play className="w-4 h-4" />
            {loading ? "Starting…" : "Start Audit"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}