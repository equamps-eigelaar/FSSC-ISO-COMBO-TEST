import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Sparkles, Loader2, History, Lightbulb, AlertTriangle,
  CheckCircle2, Zap, TrendingUp, ChevronDown, ChevronUp, BookOpen
} from "lucide-react";
import { toast } from "sonner";

const PRIORITY_CONFIG = {
  critical: { color: "bg-rose-100 text-rose-800", label: "Critical" },
  high:     { color: "bg-orange-100 text-orange-800", label: "High" },
  medium:   { color: "bg-yellow-100 text-yellow-800", label: "Medium" },
  low:      { color: "bg-slate-100 text-slate-600", label: "Low" },
};

const EFFECTIVENESS_CONFIG = {
  high:   { color: "bg-emerald-100 text-emerald-800", label: "High Impact" },
  medium: { color: "bg-blue-100 text-blue-800", label: "Med Impact" },
  low:    { color: "bg-slate-100 text-slate-600", label: "Low Impact" },
};

function calculateDueDate(timeline) {
  const now = new Date();
  const match = timeline?.match(/(\d+)\s*(day|week|month)s?/i);
  if (!match) { now.setMonth(now.getMonth() + 1); return now.toISOString().split('T')[0]; }
  const amount = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  if (unit === 'day') now.setDate(now.getDate() + amount);
  else if (unit === 'week') now.setDate(now.getDate() + amount * 7);
  else if (unit === 'month') now.setMonth(now.getMonth() + amount);
  return now.toISOString().split('T')[0];
}

export default function AuditFindingsAnalyzer({ requirement, findings, onApplied }) {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [selectedActions, setSelectedActions] = useState(new Set());
  const [showPatterns, setShowPatterns] = useState(false);
  const [applyingActions, setApplyingActions] = useState(false);
  const queryClient = useQueryClient();

  const hasFindings = findings && findings.trim().length > 0;

  const handleAnalyze = async () => {
    if (!hasFindings) {
      toast.error("Please enter audit findings before analyzing");
      return;
    }
    setLoading(true);
    setAnalysis(null);
    setSelectedActions(new Set());
    try {
      const res = await base44.functions.invoke('analyzeAuditFindings', {
        requirementId: requirement.id,
        findings,
        clause_number: requirement.clause_number,
        clause_title: requirement.clause_title,
        section: requirement.section,
        description: requirement.description,
      });
      setAnalysis(res.data);
      // Auto-select high/critical actions
      const autoSelect = new Set();
      (res.data.corrective_actions || []).forEach((a, i) => {
        if (a.priority === 'critical' || a.priority === 'high') autoSelect.add(i);
      });
      setSelectedActions(autoSelect);
      toast.success(`Analysis complete — ${res.data.historical_records_analyzed || 0} historical records compared`);
    } catch {
      toast.error("Failed to analyze findings");
    } finally {
      setLoading(false);
    }
  };

  const toggleAction = (idx) => {
    const next = new Set(selectedActions);
    next.has(idx) ? next.delete(idx) : next.add(idx);
    setSelectedActions(next);
  };

  const handleApplySelected = async () => {
    if (selectedActions.size === 0) { toast.error("Select at least one action"); return; }
    setApplyingActions(true);
    try {
      const actions = Array.from(selectedActions).map(i => analysis.corrective_actions[i]);
      for (const action of actions) {
        await base44.entities.ActionItem.create({
          title: action.title,
          description: `${action.description}${action.historical_context ? `\n\n📚 Historical context: ${action.historical_context}` : ''}`,
          source_type: "compliance_audit",
          source_id: requirement.id,
          clause_reference: requirement.clause_number,
          related_requirement_id: requirement.id,
          priority: action.priority,
          status: "pending",
          due_date: calculateDueDate(action.timeline),
        });
      }
      queryClient.invalidateQueries({ queryKey: ['action-items'] });
      toast.success(`Created ${actions.length} action item${actions.length > 1 ? 's' : ''}`);
      setSelectedActions(new Set());
      if (onApplied) onApplied();
    } catch {
      toast.error("Failed to create action items");
    } finally {
      setApplyingActions(false);
    }
  };

  if (!analysis && !loading) {
    return (
      <Card className="border-0 shadow-sm bg-gradient-to-br from-indigo-50 to-violet-50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2 text-indigo-900">
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            AI Findings Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-slate-600 mb-3">
            Automatically compare findings against historical data and existing controls to get specific mitigation strategies.
          </p>
          <Button
            onClick={handleAnalyze}
            disabled={!hasFindings}
            className="w-full bg-indigo-600 hover:bg-indigo-700 min-h-[44px]"
            size="sm"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            {hasFindings ? "Analyze Findings & Suggest Actions" : "Add findings above first"}
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="border-0 shadow-sm bg-gradient-to-br from-indigo-50 to-violet-50">
        <CardContent className="py-8 text-center">
          <Loader2 className="w-7 h-7 text-indigo-500 animate-spin mx-auto mb-3" />
          <p className="text-sm font-medium text-slate-700">Analyzing findings against historical data…</p>
          <p className="text-xs text-slate-400 mt-1">Comparing past audits, controls and action outcomes</p>
        </CardContent>
      </Card>
    );
  }

  const { pattern_analysis, root_causes = [], corrective_actions = [], preventive_measures = [], quick_wins = [], overall_recommendation, historical_records_analyzed, past_actions_analyzed } = analysis;

  return (
    <Card className="border-0 shadow-sm bg-gradient-to-br from-indigo-50 to-violet-50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold flex items-center gap-2 text-indigo-900">
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            AI Findings Analysis
          </CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-400">{historical_records_analyzed} records compared</span>
            <Button
              size="sm" variant="ghost"
              onClick={handleAnalyze}
              disabled={loading || !hasFindings}
              className="h-7 w-7 p-0 text-indigo-500 hover:text-indigo-700 hover:bg-indigo-100"
            >
              <Sparkles className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Overall Recommendation */}
        {overall_recommendation && (
          <div className="bg-white/70 rounded-lg p-3 border border-indigo-100">
            <p className="text-xs font-semibold text-indigo-800 mb-1 flex items-center gap-1">
              <Lightbulb className="w-3.5 h-3.5" /> Strategic Recommendation
            </p>
            <p className="text-xs text-slate-700">{overall_recommendation}</p>
          </div>
        )}

        {/* Pattern Analysis Toggle */}
        {pattern_analysis && (
          <div className="bg-white/70 rounded-lg border border-indigo-100 overflow-hidden">
            <button
              className="w-full flex items-center justify-between px-3 py-2 text-left"
              onClick={() => setShowPatterns(p => !p)}
            >
              <span className="text-xs font-semibold text-indigo-800 flex items-center gap-1.5">
                <History className="w-3.5 h-3.5" /> Historical Pattern Analysis
              </span>
              {showPatterns ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
            </button>
            {showPatterns && (
              <div className="px-3 pb-3">
                <p className="text-xs text-slate-600">{pattern_analysis}</p>
                {root_causes.length > 0 && (
                  <div className="mt-2">
                    <p className="text-xs font-medium text-slate-700 mb-1">Root Causes Identified:</p>
                    <ul className="space-y-0.5">
                      {root_causes.map((rc, i) => (
                        <li key={i} className="text-xs text-slate-600 flex items-start gap-1.5">
                          <AlertTriangle className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                          {rc}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Quick Wins */}
        {quick_wins.length > 0 && (
          <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-100">
            <p className="text-xs font-semibold text-emerald-800 mb-1.5 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" /> Quick Wins
            </p>
            <ul className="space-y-1">
              {quick_wins.map((qw, i) => (
                <li key={i} className="text-xs text-emerald-700 flex items-start gap-1.5">
                  <CheckCircle2 className="w-3 h-3 mt-0.5 flex-shrink-0" />
                  {qw}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Corrective Actions */}
        {corrective_actions.length > 0 && (
          <div>
            <p className="text-xs font-semibold text-slate-700 mb-2">
              Corrective Actions ({corrective_actions.length})
              <span className="ml-1 font-normal text-slate-400">— select to create action items</span>
            </p>
            <div className="space-y-2">
              {corrective_actions.map((action, idx) => (
                <div
                  key={idx}
                  className={`bg-white rounded-lg p-3 border cursor-pointer transition-all ${
                    selectedActions.has(idx) ? 'border-indigo-300 shadow-sm' : 'border-slate-100 hover:border-indigo-200'
                  }`}
                  onClick={() => toggleAction(idx)}
                >
                  <div className="flex items-start gap-2.5">
                    <Checkbox
                      checked={selectedActions.has(idx)}
                      onCheckedChange={() => toggleAction(idx)}
                      className="mt-0.5"
                      onClick={e => e.stopPropagation()}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-start gap-1.5 mb-1">
                        <span className="text-xs font-semibold text-slate-800">{action.title}</span>
                        <Badge className={`text-[10px] px-1.5 py-0 ${PRIORITY_CONFIG[action.priority]?.color}`}>
                          {PRIORITY_CONFIG[action.priority]?.label}
                        </Badge>
                        <Badge className={`text-[10px] px-1.5 py-0 ${EFFECTIVENESS_CONFIG[action.effectiveness]?.color}`}>
                          {EFFECTIVENESS_CONFIG[action.effectiveness]?.label}
                        </Badge>
                        {action.based_on_history && (
                          <Badge className="text-[10px] px-1.5 py-0 bg-indigo-100 text-indigo-700">
                            <BookOpen className="w-2.5 h-2.5 mr-0.5" /> From History
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 mb-1">{action.description}</p>
                      {action.historical_context && (
                        <p className="text-[10px] text-indigo-600 italic">📚 {action.historical_context}</p>
                      )}
                      <p className="text-[10px] text-slate-400 mt-1">Timeline: {action.timeline}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Preventive Measures */}
        {preventive_measures.length > 0 && (
          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
            <p className="text-xs font-semibold text-slate-700 mb-1.5">Preventive Measures</p>
            <ul className="space-y-1">
              {preventive_measures.map((pm, i) => (
                <li key={i} className="text-xs text-slate-600 flex items-start gap-1.5">
                  <span className="text-indigo-400 font-bold flex-shrink-0">·</span>
                  {pm}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Apply Button */}
        {selectedActions.size > 0 && (
          <Button
            onClick={handleApplySelected}
            disabled={applyingActions}
            className="w-full bg-indigo-600 hover:bg-indigo-700 min-h-[44px]"
          >
            {applyingActions ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Creating Actions…</>
            ) : (
              <><CheckCircle2 className="w-4 h-4 mr-2" />Create {selectedActions.size} Action Item{selectedActions.size > 1 ? 's' : ''}</>
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}