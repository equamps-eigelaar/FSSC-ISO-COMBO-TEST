import React, { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Camera, CheckCircle2, XCircle, AlertTriangle, Save, Sparkles } from "lucide-react";
import { toast } from "sonner";
import AuditFindingCard from "./AuditFindingCard";
import AIAuditReportDialog from "./AIAuditReportDialog";
import { useOfflineMutation } from "@/components/offline/useOfflineMutation";

export default function MobileAuditChecklist({ audit, requirements, onClose }) {
  const queryClient = useQueryClient();
  const [checklist, setChecklist] = useState(audit.checklist || []);
  const [selectedItem, setSelectedItem] = useState(null);
  const [autoSaveTimer, setAutoSaveTimer] = useState(null);
  const [showReportDialog, setShowReportDialog] = useState(false);

  // Group requirements by section for the checklist
  const sections = requirements.reduce((acc, req) => {
    const section = req.section || "Other";
    if (!acc[section]) acc[section] = [];
    acc[section].push(req);
    return acc;
  }, {});

  // Initialize checklist from requirements if empty
  useEffect(() => {
    if (checklist.length === 0) {
      const initialChecklist = requirements
        .filter(req => audit.related_requirements?.includes(req.id) || !audit.related_requirements)
        .map(req => ({
          requirement_id: req.id,
          clause_number: req.clause_number,
          title: req.clause_title,
          category: req.section,
          completed: false,
          finding: null,
          severity: null,
          photos: [],
          notes: ""
        }));
      setChecklist(initialChecklist);
    }
  }, []);

  const updateAuditMutation = useOfflineMutation({
    mutationFn: ({ id, data }) => base44.entities.AuditPlan.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-audits'] });
    }
  });

  const autoSave = () => {
    if (autoSaveTimer) clearTimeout(autoSaveTimer);
    const timer = setTimeout(() => {
      updateAuditMutation.mutate({
        id: audit.id,
        data: { checklist, status: 'in_progress' }
      });
    }, 2000);
    setAutoSaveTimer(timer);
  };

  const updateChecklistItem = (index, updates) => {
    const newChecklist = [...checklist];
    newChecklist[index] = { ...newChecklist[index], ...updates };
    setChecklist(newChecklist);
    autoSave();
  };

  const completeAudit = () => {
    updateAuditMutation.mutate({
      id: audit.id,
      data: { 
        checklist, 
        status: 'completed',
      }
    });
    toast.success("Audit completed!");
    onClose();
  };

  const progress = (checklist.filter(item => item.completed).length / checklist.length) * 100;
  const findings = checklist.filter(item => item.finding);

  if (selectedItem !== null) {
    return (
      <AuditFindingCard
        item={checklist[selectedItem]}
        auditScope={audit.scope}
        onUpdate={(updates) => updateChecklistItem(selectedItem, updates)}
        onClose={() => setSelectedItem(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="sticky top-0 z-10 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="px-4 py-3">
          <div className="flex items-center gap-3 mb-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onClose}
              className="min-h-[44px] min-w-[44px]"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h2 className="font-semibold text-slate-900 dark:text-white text-sm">
                {audit.title}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {checklist.filter(i => i.completed).length}/{checklist.length} completed
              </p>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="min-h-[44px] border-violet-200 text-violet-700 hover:bg-violet-50 dark:border-violet-800 dark:text-violet-400"
              onClick={() => setShowReportDialog(true)}
              disabled={findings.length === 0 && checklist.filter(i => i.completed).length === 0}
            >
              <Sparkles className="w-4 h-4 mr-1" />
              Report
            </Button>
            <Button 
              size="sm"
              variant="outline"
              onClick={() => autoSave()}
              className="min-h-[44px]"
            >
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-4 pb-24">
        {/* Summary Cards */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-emerald-600 mb-1">
                {checklist.filter(i => i.completed && !i.finding).length}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Passed</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-amber-600 mb-1">
                {findings.length}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Findings</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-slate-600 dark:text-slate-400 mb-1">
                {checklist.filter(i => !i.completed).length}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">Pending</div>
            </CardContent>
          </Card>
        </div>

        {/* Checklist Items */}
        <div className="space-y-3">
          {checklist.map((item, index) => {
            const hasPhotos = item.photos && item.photos.length > 0;
            const hasFinding = item.finding;

            return (
              <Card 
                key={index}
                className={`border-0 shadow-sm transition-all ${
                  item.completed 
                    ? hasFinding 
                      ? 'ring-2 ring-amber-200 dark:ring-amber-800' 
                      : 'ring-2 ring-emerald-200 dark:ring-emerald-800'
                    : ''
                }`}
                onClick={() => setSelectedItem(index)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    {/* Status Icon */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        updateChecklistItem(index, { 
                          completed: !item.completed,
                          finding: item.completed ? null : item.finding
                        });
                      }}
                      className="flex-shrink-0 mt-0.5 min-h-[44px] min-w-[44px] flex items-center justify-center"
                    >
                      {item.completed ? (
                        hasFinding ? (
                          <AlertTriangle className="w-6 h-6 text-amber-600" />
                        ) : (
                          <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                        )
                      ) : (
                        <div className="w-6 h-6 rounded-full border-2 border-slate-300 dark:border-slate-600" />
                      )}
                    </button>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h4 className="font-medium text-sm text-slate-900 dark:text-white">
                          {item.clause_number} - {item.title}
                        </h4>
                        {hasPhotos && (
                          <Badge variant="secondary" className="flex-shrink-0">
                            <Camera className="w-3 h-3 mr-1" />
                            {item.photos.length}
                          </Badge>
                        )}
                      </div>
                      
                      {item.category && (
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                          {item.category}
                        </p>
                      )}

                      {hasFinding && (
                        <div className="mt-2 p-2 bg-amber-50 dark:bg-amber-900/20 rounded text-xs text-amber-800 dark:text-amber-200">
                          <div className="flex items-center gap-1 font-medium mb-1">
                            <AlertTriangle className="w-3 h-3" />
                            {item.severity && <span className="capitalize">{item.severity} - </span>}
                            Finding
                          </div>
                          <p className="line-clamp-2">{item.finding}</p>
                        </div>
                      )}

                      {item.notes && !hasFinding && (
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 line-clamp-1">
                          📝 {item.notes}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Complete Audit Button */}
        <div className="sticky bottom-20 mt-6 space-y-3">
          <Button
            className="w-full min-h-[48px] bg-violet-600 hover:bg-violet-700"
            size="lg"
            variant="outline"
            onClick={() => setShowReportDialog(true)}
            disabled={checklist.filter(i => i.completed).length === 0}
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Generate AI Draft Report
          </Button>
          <Button 
            className="w-full min-h-[56px] text-base shadow-lg"
            size="lg"
            onClick={completeAudit}
            disabled={checklist.filter(i => i.completed).length === 0}
          >
            Complete Audit
          </Button>
        </div>
      </div>

      <AIAuditReportDialog
        open={showReportDialog}
        onClose={() => setShowReportDialog(false)}
        audit={audit}
        checklist={checklist}
      />
    </div>
  );
}