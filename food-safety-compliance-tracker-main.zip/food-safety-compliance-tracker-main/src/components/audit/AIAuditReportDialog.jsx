import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Loader2, Download, Copy, CheckCircle2, AlertTriangle, XCircle } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

/**
 * AIAuditReportDialog – generates a draft audit report from checklist findings.
 * Accepts: open, onClose, audit, checklist
 */
export default function AIAuditReportDialog({ open, onClose, audit, checklist = [] }) {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const findings = checklist.filter(i => i.finding);
  const passed = checklist.filter(i => i.completed && !i.finding);
  const pending = checklist.filter(i => !i.completed);

  const generateReport = async () => {
    setLoading(true);
    setReport(null);
    try {
      const findingsSummary = findings.map(f =>
        `- Clause ${f.clause_number} (${f.title}): [${(f.severity || "minor").toUpperCase()}] ${f.finding}`
      ).join("\n");

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert ISO 22000 / FSSC 22000 auditor writing a formal draft audit report for a packaging manufacturing facility.

Audit: "${audit?.title || "Field Audit"}"
Type: ${audit?.audit_type || "internal"}
Scope: ${audit?.scope || "FSSC 22000 packaging site"}
Date: ${new Date().toLocaleDateString("en-ZA")}

Summary statistics:
- Total checklist items: ${checklist.length}
- Passed (no findings): ${passed.length}
- Items with findings/non-conformances: ${findings.length}
- Pending / not assessed: ${pending.length}

Findings recorded:
${findingsSummary || "(No findings recorded)"}

Write a professional, well-structured audit report in Markdown with the following sections:
1. **Executive Summary** – brief overview of the audit and overall compliance status
2. **Audit Scope & Objectives** – what was audited and why
3. **Non-Conformances** – list each finding with clause reference, severity, description, and recommended corrective action
4. **Observations & Opportunities for Improvement** – minor observations that aren't NCs
5. **Positive Findings** – areas of strong compliance worth highlighting  
6. **Conclusion & Recommendations** – overall verdict and next steps
7. **Follow-up Actions Required** – table of required actions with suggested deadlines

Be specific, professional, and base the report on the actual findings provided. Do not invent findings not listed above.`,
      });

      setReport(result);
    } catch (e) {
      toast.error("Could not generate report");
    } finally {
      setLoading(false);
    }
  };

  const copyReport = () => {
    navigator.clipboard.writeText(report);
    toast.success("Report copied to clipboard");
  };

  const downloadReport = () => {
    const blob = new Blob([report], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${audit?.title?.replace(/\s+/g, "_") || "audit_report"}_draft.md`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Report downloaded");
  };

  const severityColor = {
    critical: "text-red-600 bg-red-50",
    major: "text-orange-600 bg-orange-50",
    minor: "text-amber-600 bg-amber-50",
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-violet-600" />
            AI Draft Audit Report
          </DialogTitle>
        </DialogHeader>

        {!report && !loading && (
          <div className="space-y-4">
            {/* Findings summary */}
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                <p className="text-2xl font-bold text-emerald-600">{passed.length}</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">Passed</p>
              </div>
              <div className="text-center p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                <p className="text-2xl font-bold text-amber-600">{findings.length}</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">Findings</p>
              </div>
              <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                <p className="text-2xl font-bold text-slate-600">{pending.length}</p>
                <p className="text-xs text-slate-600 dark:text-slate-400">Pending</p>
              </div>
            </div>

            {/* Findings preview */}
            {findings.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">Findings to include:</p>
                {findings.map((f, i) => (
                  <div key={i} className="flex items-start gap-2 p-2 rounded border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
                    <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-medium text-slate-800 dark:text-slate-200">
                        {f.clause_number} — {f.title}
                        <Badge className={`ml-2 text-xs ${severityColor[f.severity] || severityColor.minor}`}>{f.severity || "minor"}</Badge>
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 line-clamp-2">{f.finding}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <Button
              className="w-full min-h-[48px] bg-violet-600 hover:bg-violet-700"
              onClick={generateReport}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Generate Draft Report
            </Button>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center py-16 gap-4">
            <Loader2 className="w-10 h-10 text-violet-600 animate-spin" />
            <p className="text-sm text-slate-600 dark:text-slate-400">Drafting your audit report...</p>
          </div>
        )}

        {report && !loading && (
          <div className="space-y-4">
            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={copyReport}>
                <Copy className="w-4 h-4 mr-1" /> Copy
              </Button>
              <Button variant="outline" size="sm" onClick={downloadReport}>
                <Download className="w-4 h-4 mr-1" /> Download
              </Button>
              <Button variant="outline" size="sm" onClick={generateReport}>
                <Sparkles className="w-4 h-4 mr-1" /> Regenerate
              </Button>
            </div>
            <div className="prose prose-sm dark:prose-invert max-w-none border rounded-lg p-5 bg-white dark:bg-slate-900">
              <ReactMarkdown>{report}</ReactMarkdown>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}