import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, ArrowUp, ArrowDown, Filter, Loader2 } from "lucide-react";
import { format, subDays } from "date-fns";
import ReportToolbar, { exportToCSV, exportToPDF } from "./ReportToolbar";

const ACTIVITY_COLORS = {
  requirement_created: "bg-emerald-50 text-emerald-700",
  requirement_updated: "bg-blue-50 text-blue-700",
  risk_added: "bg-orange-50 text-orange-700",
  status_changed: "bg-purple-50 text-purple-700",
  document_uploaded: "bg-teal-50 text-teal-700",
  comment_added: "bg-slate-100 text-slate-600",
  action_item_created: "bg-amber-50 text-amber-700",
};

export default function UserActivityReportTab() {
  const [activityTypeFilter, setActivityTypeFilter] = useState("all");
  const [userFilter, setUserFilter] = useState("all");
  const [dateRange, setDateRange] = useState("7d");
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState("created_date");
  const [sortDir, setSortDir] = useState("desc");

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["activity-logs-report"],
    queryFn: () => base44.entities.ActivityLog.list("-created_date", 1000),
  });

  const dateFrom = useMemo(() => {
    if (dateRange === "7d") return subDays(new Date(), 7);
    if (dateRange === "30d") return subDays(new Date(), 30);
    if (dateRange === "90d") return subDays(new Date(), 90);
    return null;
  }, [dateRange]);

  const allUsers = useMemo(() => {
    const s = new Set(); logs.forEach(l => { if (l.user_email) s.add(l.user_email); });
    return Array.from(s).sort();
  }, [logs]);

  const allTypes = useMemo(() => {
    const s = new Set(); logs.forEach(l => { if (l.activity_type) s.add(l.activity_type); });
    return Array.from(s).sort();
  }, [logs]);

  const toggleSort = (field) => {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("asc"); }
  };

  const SortIcon = ({ field }) => {
    if (sortField !== field) return <ArrowUpDown className="w-3 h-3 text-slate-400" />;
    return sortDir === "asc" ? <ArrowUp className="w-3 h-3 text-emerald-600" /> : <ArrowDown className="w-3 h-3 text-emerald-600" />;
  };

  const filtered = useMemo(() => {
    let data = logs;
    if (dateFrom) data = data.filter(l => new Date(l.created_date) >= dateFrom);
    if (activityTypeFilter !== "all") data = data.filter(l => l.activity_type === activityTypeFilter);
    if (userFilter !== "all") data = data.filter(l => l.user_email === userFilter);
    if (search) data = data.filter(l =>
      l.description?.toLowerCase().includes(search.toLowerCase()) ||
      l.user_name?.toLowerCase().includes(search.toLowerCase()) ||
      l.user_email?.toLowerCase().includes(search.toLowerCase()) ||
      l.entity_label?.toLowerCase().includes(search.toLowerCase())
    );
    data = [...data].sort((a, b) => {
      let av = a[sortField] ?? ""; let bv = b[sortField] ?? "";
      return sortDir === "asc" ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });
    return data;
  }, [logs, dateFrom, activityTypeFilter, userFilter, search, sortField, sortDir]);

  const headers = ["Date & Time", "User", "Activity Type", "Entity", "Description"];
  const rows = () => filtered.map(l => [
    l.created_date ? format(new Date(l.created_date), "dd MMM yyyy HH:mm") : "—",
    l.user_name || l.user_email || "System",
    l.activity_type?.replace(/_/g, " "),
    l.entity_label || l.entity_type || "—",
    l.description,
  ]);

  if (isLoading) return <div className="flex items-center justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>;

  return (
    <div className="space-y-4">
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <Input placeholder="Search description, user…" value={search} onChange={e => setSearch(e.target.value)} className="w-52 h-9 text-sm" />
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-36 h-9 text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
                <SelectItem value="90d">Last 90 Days</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
            <Select value={activityTypeFilter} onValueChange={setActivityTypeFilter}>
              <SelectTrigger className="w-48 h-9 text-sm"><SelectValue placeholder="Activity Type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Activities</SelectItem>
                {allTypes.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>)}
              </SelectContent>
            </Select>
            {allUsers.length > 0 && (
              <Select value={userFilter} onValueChange={setUserFilter}>
                <SelectTrigger className="w-44 h-9 text-sm"><SelectValue placeholder="User" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Users</SelectItem>
                  {allUsers.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
            {(activityTypeFilter !== "all" || userFilter !== "all" || dateRange !== "7d" || search) && (
              <Button variant="ghost" size="sm" className="text-slate-400 h-9"
                onClick={() => { setActivityTypeFilter("all"); setUserFilter("all"); setDateRange("7d"); setSearch(""); }}>
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <ReportToolbar
        count={filtered.length}
        onExportCSV={() => exportToCSV([headers, ...rows()], `activity-report-${format(new Date(), "yyyy-MM-dd")}.csv`)}
        onExportPDF={() => exportToPDF("User Activity Report", headers, rows(), `activity-report-${format(new Date(), "yyyy-MM-dd")}.pdf`)}
      />

      <Card className="border-0 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                {[["created_date","Date & Time"],["user_name","User"],["activity_type","Activity"],["entity_label","Entity"],["description","Description"]].map(([field, label]) => (
                  <th key={field} onClick={() => toggleSort(field)} className="text-left px-4 py-3 text-xs font-semibold text-slate-600 cursor-pointer hover:text-slate-900 whitespace-nowrap">
                    <span className="flex items-center gap-1">{label}<SortIcon field={field} /></span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-10 text-slate-400">No activity logs match the selected filters.</td></tr>
              ) : filtered.map(l => (
                <tr key={l.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">
                    {l.created_date ? format(new Date(l.created_date), "dd MMM yyyy HH:mm") : "—"}
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <p className="text-xs font-medium text-slate-900">{l.user_name || "System"}</p>
                      {l.user_email && <p className="text-[10px] text-slate-400">{l.user_email}</p>}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <Badge className={`text-[10px] px-1.5 py-0.5 ${ACTIVITY_COLORS[l.activity_type] || "bg-slate-100 text-slate-600"}`}>
                      {l.activity_type?.replace(/_/g, " ")}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-600">{l.entity_label || l.entity_type || "—"}</td>
                  <td className="px-4 py-3 text-xs text-slate-600 max-w-[300px]">
                    <p className="line-clamp-2">{l.description}</p>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}