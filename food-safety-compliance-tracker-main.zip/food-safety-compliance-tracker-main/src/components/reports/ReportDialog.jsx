import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { base44 } from "@/api/base44Client";
import { FileText, Mail, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function ReportDialog({ open, onClose, defaultType = "compliance" }) {
  const [reportType, setReportType] = useState(defaultType);
  const [filters, setFilters] = useState({});
  const [emailRecipient, setEmailRecipient] = useState("");
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const response = await base44.functions.invoke('generateReport', {
        reportType,
        filters,
        includeCharts: true
      });

      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${reportType}-report-${Date.now()}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      toast.success('Report downloaded successfully');
    } catch (error) {
      toast.error('Failed to generate report');
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  const handleEmail = async () => {
    if (!emailRecipient) {
      toast.error('Please enter an email address');
      return;
    }

    setSending(true);
    try {
      await base44.functions.invoke('sendScheduledReport', {
        recipientEmail: emailRecipient,
        reportType,
        reportName: `${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report`,
        filters
      });

      toast.success('Report sent via email');
      setEmailRecipient("");
    } catch (error) {
      toast.error('Failed to send report');
      console.error(error);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-600" />
            Generate Report
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div>
            <Label className="text-xs text-slate-500">Report Type</Label>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="compliance">Compliance Status</SelectItem>
                <SelectItem value="risk">Risk Assessments</SelectItem>
                <SelectItem value="activity">Activity Log</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {reportType === 'compliance' && (
            <>
              <div>
                <Label className="text-xs text-slate-500">Filter by Status</Label>
                <Select value={filters.status || "all"} onValueChange={(v) => setFilters({...filters, status: v === "all" ? null : v})}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="compliant">Compliant</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="non_compliant">Non-Compliant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-slate-500">Filter by Priority</Label>
                <Select value={filters.priority || "all"} onValueChange={(v) => setFilters({...filters, priority: v === "all" ? null : v})}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {reportType === 'risk' && (
            <>
              <div>
                <Label className="text-xs text-slate-500">Filter by Hazard Type</Label>
                <Select value={filters.hazardType || "all"} onValueChange={(v) => setFilters({...filters, hazardType: v === "all" ? null : v})}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="biological">Biological</SelectItem>
                    <SelectItem value="chemical">Chemical</SelectItem>
                    <SelectItem value="physical">Physical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-slate-500">Filter by Risk Level</Label>
                <Select value={filters.riskLevel || "all"} onValueChange={(v) => setFilters({...filters, riskLevel: v === "all" ? null : v})}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {reportType === 'activity' && (
            <>
              <div>
                <Label className="text-xs text-slate-500">Start Date</Label>
                <Input
                  type="date"
                  className="mt-1"
                  value={filters.startDate || ""}
                  onChange={(e) => setFilters({...filters, startDate: e.target.value})}
                />
              </div>
              <div>
                <Label className="text-xs text-slate-500">End Date</Label>
                <Input
                  type="date"
                  className="mt-1"
                  value={filters.endDate || ""}
                  onChange={(e) => setFilters({...filters, endDate: e.target.value})}
                />
              </div>
            </>
          )}

          <div className="border-t pt-4">
            <Label className="text-xs text-slate-500">Send via Email (Optional)</Label>
            <div className="flex gap-2 mt-1">
              <Input
                type="email"
                placeholder="recipient@example.com"
                value={emailRecipient}
                onChange={(e) => setEmailRecipient(e.target.value)}
              />
              <Button
                variant="outline"
                onClick={handleEmail}
                disabled={sending || !emailRecipient}
                className="shrink-0"
              >
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleGenerate}
            disabled={generating}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {generating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}