import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function ScheduleReportDialog({ open, onClose }) {
  const [form, setForm] = useState({
    reportType: "compliance",
    frequency: "weekly",
    dayOfWeek: 1,
    time: "09:00",
    recipientEmail: "",
    reportName: "",
  });

  const queryClient = useQueryClient();

  const createAutomation = useMutation({
    mutationFn: async (data) => {
      const automation = await fetch('/api/automations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      return automation.json();
    },
    onSuccess: () => {
      toast.success('Report schedule created');
      queryClient.invalidateQueries({ queryKey: ['automations'] });
      onClose();
    },
    onError: () => {
      toast.error('Failed to create schedule');
    }
  });

  const handleSubmit = () => {
    if (!form.recipientEmail) {
      toast.error('Please enter recipient email');
      return;
    }

    const automationData = {
      automation_type: "scheduled",
      name: form.reportName || `${form.reportType} Report - ${form.frequency}`,
      function_name: "sendScheduledReport",
      function_args: {
        recipientEmail: form.recipientEmail,
        reportType: form.reportType,
        reportName: form.reportName,
        filters: {}
      },
      schedule_type: "simple",
      repeat_unit: form.frequency === "daily" ? "days" : "weeks",
      repeat_interval: 1,
      ...(form.frequency === "weekly" && { repeat_on_days: [parseInt(form.dayOfWeek)] }),
      start_time: form.time,
    };

    createAutomation.mutate(automationData);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-emerald-600" />
            Schedule Report
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div>
            <Label className="text-xs text-slate-500">Report Name</Label>
            <Input
              className="mt-1"
              placeholder="Weekly Compliance Report"
              value={form.reportName}
              onChange={(e) => setForm({...form, reportName: e.target.value})}
            />
          </div>

          <div>
            <Label className="text-xs text-slate-500">Report Type</Label>
            <Select value={form.reportType} onValueChange={(v) => setForm({...form, reportType: v})}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="compliance">Compliance Status</SelectItem>
                <SelectItem value="risk">Risk Assessments</SelectItem>
                <SelectItem value="activity">Activity Log</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-xs text-slate-500">Frequency</Label>
            <Select value={form.frequency} onValueChange={(v) => setForm({...form, frequency: v})}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {form.frequency === "weekly" && (
            <div>
              <Label className="text-xs text-slate-500">Day of Week</Label>
              <Select value={form.dayOfWeek.toString()} onValueChange={(v) => setForm({...form, dayOfWeek: parseInt(v)})}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Monday</SelectItem>
                  <SelectItem value="2">Tuesday</SelectItem>
                  <SelectItem value="3">Wednesday</SelectItem>
                  <SelectItem value="4">Thursday</SelectItem>
                  <SelectItem value="5">Friday</SelectItem>
                  <SelectItem value="6">Saturday</SelectItem>
                  <SelectItem value="0">Sunday</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label className="text-xs text-slate-500">Time</Label>
            <Input
              type="time"
              className="mt-1"
              value={form.time}
              onChange={(e) => setForm({...form, time: e.target.value})}
            />
          </div>

          <div>
            <Label className="text-xs text-slate-500">Recipient Email *</Label>
            <Input
              type="email"
              className="mt-1"
              placeholder="recipient@example.com"
              value={form.recipientEmail}
              onChange={(e) => setForm({...form, recipientEmail: e.target.value})}
            />
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={createAutomation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {createAutomation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Creating...
              </>
            ) : (
              'Create Schedule'
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}