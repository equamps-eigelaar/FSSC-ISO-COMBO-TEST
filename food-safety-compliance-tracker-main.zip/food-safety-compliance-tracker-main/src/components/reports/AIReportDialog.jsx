import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Download, TrendingDown, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

export default function AIReportDialog({ open, onClose }) {
  const [stakeholderType, setStakeholderType] = useState("executive");
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState(null);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const { data } = await base44.functions.invoke('generateAIComplianceReport', {
        stakeholder_type: stakeholderType
      });
      
      if (data.success) {
        setReport(data.report);
        toast.success("AI report generated successfully");
      } else {
        toast.error("Failed to generate report");
      }
    } catch (error) {
      toast.error("Error generating report");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!report) return;
    
    const content = `
AI-GENERATED COMPLIANCE REPORT
${stakeholderType.toUpperCase()} SUMMARY
Generated: ${new Date(report.generated_date).toLocaleString()}

===========================================

${report.summary}

===========================================

KEY METRICS:
- Total Requirements: ${report.metrics.total}
- Compliant: ${report.metrics.compliant} (${report.metrics.compliance_percentage}%)
- In Progress: ${report.metrics.in_progress}
- Non-Compliant: ${report.metrics.non_compliant}
- Not Started: ${report.metrics.not_started}
- Overdue Items: ${report.overdue_count}

RISK SUMMARY:
- Critical Risks: ${report.risk_summary.critical}
- High Risks: ${report.risk_summary.high}
- Requiring Action: ${report.risk_summary.requires_action}

FOCUS AREAS (Lowest Compliance Scores):
${report.focus_areas.map((area, i) => `${i+1}. ${area.name}: ${area.compliant}/${area.total} (${area.score}%)`).join('\n')}
    `;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ai-report-${stakeholderType}-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-600" />
            AI-Powered Compliance Report
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Configuration */}
          <Card className="border-0 shadow-sm bg-emerald-50">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 mb-2 block">
                    Select Stakeholder Type
                  </label>
                  <Select value={stakeholderType} onValueChange={setStakeholderType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="executive">Executive Summary</SelectItem>
                      <SelectItem value="auditor">Audit Report</SelectItem>
                      <SelectItem value="team_lead">Operational Report</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="text-xs text-slate-600">
                  {stakeholderType === "executive" && "High-level overview with strategic recommendations for leadership"}
                  {stakeholderType === "auditor" && "Detailed compliance analysis with gap identification and corrective actions"}
                  {stakeholderType === "team_lead" && "Action-oriented report with priority tasks and resource recommendations"}
                </div>

                <Button 
                  onClick={handleGenerate}
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  {loading ? "Generating with AI..." : "Generate AI Report"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Report Display */}
          {report && (
            <>
              {/* Metrics Overview */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs text-slate-500">Compliant</span>
                    </div>
                    <div className="text-2xl font-bold text-emerald-700">
                      {report.metrics.compliance_percentage}%
                    </div>
                    <div className="text-xs text-slate-400">
                      {report.metrics.compliant}/{report.metrics.total}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="w-4 h-4 text-blue-600" />
                      <span className="text-xs text-slate-500">In Progress</span>
                    </div>
                    <div className="text-2xl font-bold text-blue-700">
                      {report.metrics.in_progress}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      <span className="text-xs text-slate-500">Critical Risks</span>
                    </div>
                    <div className="text-2xl font-bold text-rose-700">
                      {report.risk_summary.critical}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingDown className="w-4 h-4 text-amber-600" />
                      <span className="text-xs text-slate-500">Overdue</span>
                    </div>
                    <div className="text-2xl font-bold text-amber-700">
                      {report.overdue_count}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* AI Summary */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    AI-Generated Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-sm max-w-none text-slate-700">
                    <ReactMarkdown>{report.summary}</ReactMarkdown>
                  </div>
                </CardContent>
              </Card>

              {/* Focus Areas */}
              <Card className="border-0 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <TrendingDown className="w-4 h-4 text-rose-600" />
                    Priority Focus Areas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {report.focus_areas.map((area, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <Badge variant="outline" className="shrink-0">
                            #{index + 1}
                          </Badge>
                          <span className="text-sm text-slate-700 truncate">{area.name}</span>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <span className="text-xs text-slate-500">
                            {area.compliant}/{area.total}
                          </span>
                          <Badge 
                            className={`${
                              area.score < 50 ? "bg-rose-100 text-rose-700" :
                              area.score < 75 ? "bg-amber-100 text-amber-700" :
                              "bg-emerald-100 text-emerald-700"
                            }`}
                          >
                            {area.score}%
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Actions */}
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  onClick={handleDownload}
                  className="flex-1"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Report
                </Button>
                <Button onClick={onClose} className="flex-1">
                  Close
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}