import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, ArrowUp, ArrowDown, Filter, Loader2 } from "lucide-react";
import { format } from "date-fns";
import ReportToolbar, { exportToCSV, exportToPDF } from "./ReportToolbar";

const RISK_COLORS = {
  critical: "bg-rose-50 text-rose-700 border-rose-200",
  high: "bg-orange-50 text-orange-700 border-orange-200",
  medium: "bg-amber-50 text-amber-700 border-amber-200",
  low: "bg-emerald-50 text-emerald-700 border-emerald-200",
};

const WORKFLOW_COLORS = {
  draft: "bg-slate-100 text-slate-600 border-slate-200",
  pending_review: "bg-amber-50 text-amber-700 border-amber-200",
  approved: "bg-emerald-50 text-emerald-700 border-emerald-200",
  rejected: "bg-rose-50 text-rose-700 border-rose-200",
  revision_required: "bg-orange-50 text-orange-700 border-orange-200",
};

export default function RiskReportTab() {
  const [riskLevelFilter, setRiskLevelFilter] = useState("all");
  const [hazardFilter, setHazardFilter] = useState("all");
  const [workflowFilter, setWorkflowFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState("risk_level");
  const [sortDir, setSortDir] = useState("desc");

  const { data: risks = [], isLoading: rLoading } = useQuery({
    queryKey: ["risks-report"],
    queryFn: () => base44.entities.RiskAssessment.list("-created_date", 1000),
  });
  const { data: requirements = [], isLoading: reqLoading } = useQuery({
    queryKey: ["reqs-for-risks"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-created_date", 1000),
  });

  const reqMap = useMemo(() => {
    const m = {}; requirements.forEach(r => { m[r.id] = r; });
    return m;
  }, [requirements]);

  const toggleSort = (field) => {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("asc"); }
  };

  const SortIcon = ({ field }) => {
    if (sortField !== field) return <ArrowUpDown className="w-3 h-3 text-slate-400" />;
    return sortDir === "asc" ? <ArrowUp className="w-3 h-3 text-emerald-600" /> : <ArrowDown className="w-3 h-3 text-emerald-600" />;
  };

  const RISK_ORDER = { critical: 4, high: 3, medium: 2, low: 1 };

  const filtered = useMemo(() => {
    let data = risks;
    if (riskLevelFilter !== "all") data = data.filter(r => r.risk_level === riskLevelFilter);
    if (hazardFilter !== "all") data = data.filter(r => r.hazard_type === hazardFilter);
    if (workflowFilter !== "all") data = data.filter(r => r.workflow_status === workflowFilter);
    if (search) data = data.filter(r =>
      r.hazard_description?.toLowerCase().includes(search.toLowerCase()) ||
      reqMap[r.requirement_id]?.clause_number?.toLowerCase().includes(search.toLowerCase())
    );
    data = [...data].sort((a, b) => {
      if (sortField === "risk_level") {
        const diff = (RISK_ORDER[b.risk_level] || 0) - (RISK_ORDER[a.risk_level] || 0);
        return sortDir === "desc" ? diff : -diff;
      }
      let av = a[sortField] ?? ""; let bv = b[sortField] ?? "";
      return sortDir === "asc" ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });
    return data;
  }, [risks, riskLevelFilter, hazardFilter, workflowFilter, search, sortField, sortDir, reqMap]);

  const headers = ["Clause #", "Hazard Type", "Description", "Likelihood", "Severity", "Risk Level", "Residual Risk", "Workflow", "Assigned To"];
  const rows = () => filtered.map(r => [
    reqMap[r.requirement_id]?.clause_number || "—",
    r.hazard_type, r.hazard_description,
    r.likelihood, r.severity, r.risk_level, r.residual_risk || "—",
    r.workflow_status?.replace(/_/g, " ") || "—",
    r.assigned_to || "—",
  ]);

  if (rLoading || reqLoading) return <div className="flex items-center justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>;

  return (
    <div className="space-y-4">
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <Input placeholder="Search hazard, clause…" value={search} onChange={e => setSearch(e.target.value)} className="w-52 h-9 text-sm" />
            <Select value={riskLevelFilter} onValueChange={setRiskLevelFilter}>
              <SelectTrigger className="w-36 h-9 text-sm"><SelectValue placeholder="Risk Level" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select value={hazardFilter} onValueChange={setHazardFilter}>
              <SelectTrigger className="w-36 h-9 text-sm"><SelectValue placeholder="Hazard Type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Hazards</SelectItem>
                <SelectItem value="biological">Biological</SelectItem>
                <SelectItem value="chemical">Chemical</SelectItem>
                <SelectItem value="physical">Physical</SelectItem>
              </SelectContent>
            </Select>
            <Select value={workflowFilter} onValueChange={setWorkflowFilter}>
              <SelectTrigger className="w-40 h-9 text-sm"><SelectValue placeholder="Workflow" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Workflows</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="pending_review">Pending Review</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="revision_required">Revision Required</SelectItem>
              </SelectContent>
            </Select>
            {(riskLevelFilter !== "all" || hazardFilter !== "all" || workflowFilter !== "all" || search) && (
              <Button variant="ghost" size="sm" className="text-slate-400 h-9"
                onClick={() => { setRiskLevelFilter("all"); setHazardFilter("all"); setWorkflowFilter("all"); setSearch(""); }}>
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <ReportToolbar
        count={filtered.length}
        onExportCSV={() => exportToCSV([headers, ...rows()], `risk-report-${format(new Date(), "yyyy-MM-dd")}.csv`)}
        onExportPDF={() => exportToPDF("Risk Assessment Report", headers, rows(), `risk-report-${format(new Date(), "yyyy-MM-dd")}.pdf`)}
      />

      <Card className="border-0 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                {[["clause","Clause"],["hazard_type","Hazard"],["hazard_description","Description"],["likelihood","Likelihood"],["severity","Severity"],["risk_level","Risk Level"],["residual_risk","Residual"],["workflow_status","Workflow"]].map(([field, label]) => (
                  <th key={field} onClick={() => toggleSort(field)} className="text-left px-4 py-3 text-xs font-semibold text-slate-600 cursor-pointer hover:text-slate-900 whitespace-nowrap">
                    <span className="flex items-center gap-1">{label}<SortIcon field={field} /></span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-10 text-slate-400">No records match the selected filters.</td></tr>
              ) : filtered.map(r => (
                <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs text-slate-700">{reqMap[r.requirement_id]?.clause_number || "—"}</td>
                  <td className="px-4 py-3 text-xs capitalize text-slate-700">{r.hazard_type}</td>
                  <td className="px-4 py-3 max-w-[200px]"><p className="truncate text-slate-900 text-xs">{r.hazard_description}</p></td>
                  <td className="px-4 py-3 text-xs capitalize text-slate-600">{r.likelihood?.replace(/_/g, " ")}</td>
                  <td className="px-4 py-3 text-xs capitalize text-slate-600">{r.severity}</td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${RISK_COLORS[r.risk_level] || ""}`}>{r.risk_level}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    {r.residual_risk ? <Badge variant="outline" className={`text-xs ${RISK_COLORS[r.residual_risk] || ""}`}>{r.residual_risk}</Badge> : <span className="text-slate-400 text-xs">—</span>}
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${WORKFLOW_COLORS[r.workflow_status] || ""}`}>{r.workflow_status?.replace(/_/g, " ")}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}