import React from "react";
import { Button } from "@/components/ui/button";
import { Download, FileText, Loader2 } from "lucide-react";

export function exportToCSV(rows, filename) {
  const csv = rows.map(r => r.map(cell => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  URL.revokeObjectURL(url);
  a.remove();
}

export function exportToPDF(title, headers, rows, filename) {
  const win = window.open("", "_blank");
  win.document.write(`
    <html><head><title>${title}</title>
    <style>
      body { font-family: sans-serif; padding: 24px; font-size: 12px; color: #1e293b; }
      h1 { font-size: 18px; margin-bottom: 4px; }
      p.sub { color: #64748b; font-size: 11px; margin-bottom: 20px; }
      table { width: 100%; border-collapse: collapse; }
      th { background: #f1f5f9; text-align: left; padding: 8px 10px; border: 1px solid #e2e8f0; font-size: 11px; font-weight: 600; }
      td { padding: 7px 10px; border: 1px solid #e2e8f0; vertical-align: top; font-size: 11px; }
      tr:nth-child(even) td { background: #f8fafc; }
    </style></head><body>
    <h1>${title}</h1>
    <p class="sub">Generated ${new Date().toLocaleString()} — ${rows.length} record(s)</p>
    <table>
      <thead><tr>${headers.map(h => `<th>${h}</th>`).join("")}</tr></thead>
      <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c ?? ""}</td>`).join("")}</tr>`).join("")}</tbody>
    </table>
    </body></html>
  `);
  win.document.close();
  win.print();
}

export default function ReportToolbar({ title, count, onExportCSV, onExportPDF, exporting }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <p className="text-sm text-slate-500">{count} record{count !== 1 ? "s" : ""} shown</p>
      <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={onExportCSV} disabled={exporting} className="gap-1.5 text-xs">
          <Download className="w-3.5 h-3.5" />
          CSV
        </Button>
        <Button variant="outline" size="sm" onClick={onExportPDF} disabled={exporting} className="gap-1.5 text-xs">
          <FileText className="w-3.5 h-3.5" />
          PDF
        </Button>
      </div>
    </div>
  );
}