import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  Download,
  Mail,
  Trash2,
  Eye,
  Calendar,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
} from "lucide-react";
import { format } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

const statusColors = {
  draft: "bg-yellow-100 text-yellow-800",
  finalized: "bg-blue-100 text-blue-800",
  sent: "bg-green-100 text-green-800",
};

const reportTypeColors = {
  weekly: "bg-purple-50 border-purple-200",
  monthly: "bg-blue-50 border-blue-200",
  quarterly: "bg-indigo-50 border-indigo-200",
  annual: "bg-emerald-50 border-emerald-200",
  manual: "bg-slate-50 border-slate-200",
};

export default function GeneratedReportsView() {
  const [selectedReport, setSelectedReport] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [emailRecipients, setEmailRecipients] = useState("");
  const queryClient = useQueryClient();

  const { data: reports = [], isLoading } = useQuery({
    queryKey: ["complianceReports"],
    queryFn: () => base44.entities.ComplianceReport.list("-created_date", 50),
  });

  const deleteMutation = useMutation({
    mutationFn: (reportId) => base44.entities.ComplianceReport.delete(reportId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["complianceReports"] });
      setSelectedReport(null);
      setShowDeleteDialog(false);
    },
  });

  const emailMutation = useMutation({
    mutationFn: ({ reportId, recipients }) =>
      base44.functions.invoke("emailComplianceReport", {
        report_id: reportId,
        recipient_emails: recipients.split(",").map((e) => e.trim()),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["complianceReports"] });
      setShowEmailDialog(false);
      setEmailRecipients("");
    },
  });

  const downloadPDF = async (report) => {
    const element = document.getElementById(`report-${report.id}`);
    if (!element) return;

    const canvas = await html2canvas(element, { scale: 2 });
    const pdf = new jsPDF();
    const imgData = canvas.toDataURL("image/png");
    const imgWidth = 210;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
    pdf.save(`${report.title}.pdf`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Clock className="w-6 h-6 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {reports.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No Reports Generated</h3>
            <p className="text-sm text-slate-500">
              Schedule automated reports to get started with compliance insights.
            </p>
          </CardContent>
        </Card>
      ) : (
        reports.map((report) => (
          <Card
            key={report.id}
            className={`border-2 ${reportTypeColors[report.report_type]}`}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <CardTitle className="text-lg">{report.title}</CardTitle>
                    <Badge className={statusColors[report.status]}>
                      {report.status}
                    </Badge>
                    <Badge variant="outline">{report.report_type}</Badge>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-slate-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {format(new Date(report.report_date), "MMM d, yyyy")}
                    </div>
                    {report.sent_date && (
                      <div className="flex items-center gap-1 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        Sent {format(new Date(report.sent_date), "MMM d")}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedReport(report)}
                    className="min-h-[44px]"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => downloadPDF(report)}
                    className="min-h-[44px]"
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setSelectedReport(report);
                      setShowEmailDialog(true);
                    }}
                    className="min-h-[44px]"
                  >
                    <Mail className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setSelectedReport(report);
                      setShowDeleteDialog(true);
                    }}
                    className="min-h-[44px] text-rose-600 hover:text-rose-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Compliance Score */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="bg-white p-3 rounded-lg border">
                  <div className="text-xs text-slate-500 mb-1">Compliance Score</div>
                  <div className="text-2xl font-bold text-emerald-600">
                    {report.compliance_score}%
                  </div>
                </div>

                <div className="bg-white p-3 rounded-lg border">
                  <div className="text-xs text-slate-500 mb-1">Task Completion</div>
                  <div className="text-2xl font-bold text-blue-600">
                    {report.task_completion_rate}%
                  </div>
                </div>

                <div className="bg-white p-3 rounded-lg border">
                  <div className="text-xs text-slate-500 mb-1">Critical Risks</div>
                  <div className="text-2xl font-bold text-rose-600">
                    {report.risk_stats?.critical || 0}
                  </div>
                </div>

                <div className="bg-white p-3 rounded-lg border">
                  <div className="text-xs text-slate-500 mb-1">Non-Compliant</div>
                  <div className="text-2xl font-bold text-amber-600">
                    {report.compliance_stats?.non_compliant || 0}
                  </div>
                </div>
              </div>

              {/* Executive Summary */}
              {report.executive_summary && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-900 mb-2 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-slate-500" />
                    Executive Summary
                  </h4>
                  <p className="text-sm text-slate-700 bg-white p-3 rounded border">
                    {report.executive_summary}
                  </p>
                </div>
              )}

              {/* Key Findings */}
              {report.key_findings?.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-900 mb-2">Key Findings</h4>
                  <ul className="space-y-2">
                    {report.key_findings.slice(0, 3).map((finding, idx) => (
                      <li key={idx} className="text-sm text-slate-700 flex gap-2">
                        <span className="text-emerald-600 font-bold">•</span>
                        {finding}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Critical Issues */}
              {report.critical_issues?.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold text-slate-900 mb-2 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-500" />
                    Critical Issues
                  </h4>
                  <div className="space-y-2">
                    {report.critical_issues.slice(0, 2).map((issue, idx) => (
                      <div key={idx} className="bg-rose-50 border border-rose-200 p-3 rounded">
                        <div className="font-semibold text-sm text-rose-900">{issue.issue}</div>
                        <div className="text-xs text-rose-700 mt-1">
                          Recommendation: {issue.recommendation}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>

            {/* Hidden PDF export element */}
            <div id={`report-${report.id}`} style={{ display: "none", padding: "20px" }}>
              <h1>{report.title}</h1>
              <p>{report.executive_summary}</p>
            </div>
          </Card>
        ))
      )}

      {/* Delete Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Report</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this report? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogAction
            onClick={() =>
              selectedReport && deleteMutation.mutate(selectedReport.id)
            }
            disabled={deleteMutation.isPending}
            className="bg-rose-600 hover:bg-rose-700"
          >
            {deleteMutation.isPending ? "Deleting..." : "Delete"}
          </AlertDialogAction>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
        </AlertDialogContent>
      </AlertDialog>

      {/* Email Dialog */}
      {showEmailDialog && selectedReport && (
        <Card className="fixed inset-4 z-50 max-w-md mx-auto my-auto">
          <CardHeader>
            <CardTitle>Send Report via Email</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-slate-900 block mb-2">
                Email Recipients (comma-separated)
              </label>
              <textarea
                value={emailRecipients}
                onChange={(e) => setEmailRecipients(e.target.value)}
                placeholder="email1@example.com, email2@example.com"
                className="w-full p-2 border rounded-lg text-sm"
                rows="4"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() =>
                  emailMutation.mutate({
                    reportId: selectedReport.id,
                    recipients: emailRecipients,
                  })
                }
                disabled={emailMutation.isPending || !emailRecipients}
              >
                {emailMutation.isPending ? "Sending..." : "Send"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowEmailDialog(false)}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}