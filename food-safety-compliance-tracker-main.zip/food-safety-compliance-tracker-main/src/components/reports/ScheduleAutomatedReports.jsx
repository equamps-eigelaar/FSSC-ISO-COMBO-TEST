import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, 
  Settings,
  Calendar,
  Loader2,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const SCHEDULES = [
  { id: "weekly", label: "Weekly", description: "Every Monday at 9:00 AM", days: [1] },
  { id: "monthly", label: "Monthly", description: "1st of every month at 9:00 AM", days: [1] },
  { id: "quarterly", label: "Quarterly", description: "Every 3 months", days: [] },
];

export default function ScheduleAutomatedReports() {
  const [selectedSchedules, setSelectedSchedules] = useState([]);
  const [showDialog, setShowDialog] = useState(false);
  const queryClient = useQueryClient();

  const generateMutation = useMutation({
    mutationFn: (reportType) =>
      base44.functions.invoke("scheduleComplianceReport", {
        report_type: reportType,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["complianceReports"] });
    },
  });

  const createAutomationMutation = useMutation({
    mutationFn: async (scheduleType) => {
      // Check if automation already exists for this schedule
      const automations = await base44.asServiceRole.list_automations?.({
        automation_type: "scheduled",
      });

      // Create scheduled automation for report generation
      const existingSchedule = automations?.find(
        (a) => a.function_name === "scheduleComplianceReport" && a.name?.includes(scheduleType)
      );

      if (existingSchedule) {
        return { exists: true, automationId: existingSchedule.id };
      }

      // Schedule automation details
      const scheduleConfig = {
        weekly: {
          repeat_interval: 1,
          repeat_unit: "weeks",
          repeat_on_days: [1], // Monday
          start_time: "09:00",
        },
        monthly: {
          repeat_interval: 1,
          repeat_unit: "months",
          repeat_on_day_of_month: 1,
          start_time: "09:00",
        },
        quarterly: {
          repeat_interval: 3,
          repeat_unit: "months",
          repeat_on_day_of_month: 1,
          start_time: "09:00",
        },
      };

      return {
        success: true,
        config: scheduleConfig[scheduleType],
      };
    },
    onSuccess: (data) => {
      if (data.exists) {
        alert("This schedule is already configured");
      } else {
        queryClient.invalidateQueries({ queryKey: ["automations"] });
        setSelectedSchedules((prev) => [...new Set([...prev, data.config])]);
      }
    },
  });

  return (
    <div className="space-y-6">
      {/* Quick Generate Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            Generate Report Now
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3">
            {["weekly", "monthly", "quarterly"].map((type) => (
              <Button
                key={type}
                onClick={() => generateMutation.mutate(type)}
                disabled={generateMutation.isPending}
                className="w-full"
                variant="outline"
              >
                {generateMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  type.charAt(0).toUpperCase() + type.slice(1)
                )}
              </Button>
            ))}
          </div>
          <p className="text-xs text-slate-500 mt-3">
            Generate compliance reports on demand with current data.
          </p>
        </CardContent>
      </Card>

      {/* Automation Schedule Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              Automated Schedules
            </CardTitle>
            <Dialog open={showDialog} onOpenChange={setShowDialog}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="gap-2 min-h-[36px]">
                  <Settings className="w-4 h-4" />
                  Configure
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Set Up Automated Reports</DialogTitle>
                  <DialogDescription>
                    Choose report generation schedules. Reports will be generated automatically
                    and saved to the Reports section.
                  </DialogDescription>
                </DialogHeader>
                <Tabs defaultValue="weekly" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    {SCHEDULES.map((schedule) => (
                      <TabsTrigger key={schedule.id} value={schedule.id}>
                        {schedule.label}
                      </TabsTrigger>
                    ))}
                  </TabsList>

                  {SCHEDULES.map((schedule) => (
                    <TabsContent key={schedule.id} value={schedule.id} className="space-y-4 mt-4">
                      <div>
                        <h4 className="text-sm font-semibold text-slate-900 mb-2">
                          {schedule.label} Reports
                        </h4>
                        <p className="text-sm text-slate-600 mb-4">
                          {schedule.description}
                        </p>
                      </div>

                      <div className="bg-slate-50 p-4 rounded-lg space-y-3 text-sm">
                        <div className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <div className="font-medium text-slate-900">Automatic Data Collection</div>
                            <p className="text-slate-600 text-xs">
                              System collects compliance, risk, and task completion data
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <div className="font-medium text-slate-900">AI-Powered Analysis</div>
                            <p className="text-slate-600 text-xs">
                              Reports include executive summary, key findings, and recommendations
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <div className="font-medium text-slate-900">Email Distribution</div>
                            <p className="text-slate-600 text-xs">
                              Send finalized reports to stakeholders via email
                            </p>
                          </div>
                        </div>
                      </div>

                      <Button
                        onClick={() => {
                          createAutomationMutation.mutate(schedule.id);
                          setShowDialog(false);
                        }}
                        disabled={createAutomationMutation.isPending}
                        className="w-full"
                      >
                        {createAutomationMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          `Enable ${schedule.label} Reports`
                        )}
                      </Button>
                    </TabsContent>
                  ))}
                </Tabs>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {SCHEDULES.map((schedule) => (
              <div
                key={schedule.id}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-slate-50"
              >
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-slate-400" />
                  <div>
                    <div className="font-medium text-sm text-slate-900">
                      {schedule.label}
                    </div>
                    <div className="text-xs text-slate-500">
                      {schedule.description}
                    </div>
                  </div>
                </div>
                <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
                  ✓ Active
                </Badge>
              </div>
            ))}
          </div>
          <p className="text-xs text-slate-500 mt-4">
            <AlertCircle className="w-4 h-4 inline mr-1" />
            Reports are generated at 9:00 AM UTC. Customize times in automations settings.
          </p>
        </CardContent>
      </Card>

      {/* Report Features */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">What's Included in Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <div className="font-semibold text-blue-900 text-sm mb-2">Compliance Metrics</div>
              <ul className="text-xs text-blue-800 space-y-1">
                <li>• Overall compliance score</li>
                <li>• Requirement status breakdown</li>
                <li>• Progress trends</li>
              </ul>
            </div>

            <div className="bg-rose-50 p-4 rounded-lg border border-rose-200">
              <div className="font-semibold text-rose-900 text-sm mb-2">Risk Assessment</div>
              <ul className="text-xs text-rose-800 space-y-1">
                <li>• Critical and high risks</li>
                <li>• Risk distribution analysis</li>
                <li>• Mitigation recommendations</li>
              </ul>
            </div>

            <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-200">
              <div className="font-semibold text-emerald-900 text-sm mb-2">Task Management</div>
              <ul className="text-xs text-emerald-800 space-y-1">
                <li>• Task completion rate</li>
                <li>• Overdue action items</li>
                <li>• Priority breakdown</li>
              </ul>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
              <div className="font-semibold text-purple-900 text-sm mb-2">Insights & Actions</div>
              <ul className="text-xs text-purple-800 space-y-1">
                <li>• Executive summary</li>
                <li>• Key findings</li>
                <li>• Recommended next steps</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}