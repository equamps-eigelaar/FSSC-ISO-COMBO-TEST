import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, ArrowUp, ArrowDown, Filter, Loader2 } from "lucide-react";
import { format } from "date-fns";
import ReportToolbar, { exportToCSV, exportToPDF } from "./ReportToolbar";

const STATUS_COLORS = {
  compliant: "bg-emerald-50 text-emerald-700 border-emerald-200",
  in_progress: "bg-blue-50 text-blue-700 border-blue-200",
  partial: "bg-amber-50 text-amber-700 border-amber-200",
  non_compliant: "bg-rose-50 text-rose-700 border-rose-200",
  not_started: "bg-slate-100 text-slate-600 border-slate-200",
};

const PRIORITY_COLORS = {
  critical: "bg-rose-50 text-rose-700 border-rose-200",
  high: "bg-orange-50 text-orange-700 border-orange-200",
  medium: "bg-amber-50 text-amber-700 border-amber-200",
  low: "bg-blue-50 text-blue-700 border-blue-200",
};

const SECTIONS = [
  "4 - Context of the Organization", "5 - Leadership", "6 - Planning",
  "7 - Support", "8 - Operation", "9 - Performance Evaluation", "10 - Improvement",
  "TS 22002-4 - Establishment", "TS 22002-4 - Utilities", "TS 22002-4 - Equipment",
  "TS 22002-4 - Hygiene", "TS 22002-4 - Personnel", "TS 22002-4 - Transportation",
  "TS 22002-4 - Product Information", "TS 22002-4 - Other Requirements",
];

export default function ComplianceReportTab() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [sectionFilter, setSectionFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState("clause_number");
  const [sortDir, setSortDir] = useState("asc");

  const { data: requirements = [], isLoading } = useQuery({
    queryKey: ["compliance-requirements-report"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-created_date", 1000),
  });

  const toggleSort = (field) => {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("asc"); }
  };

  const SortIcon = ({ field }) => {
    if (sortField !== field) return <ArrowUpDown className="w-3 h-3 text-slate-400" />;
    return sortDir === "asc" ? <ArrowUp className="w-3 h-3 text-emerald-600" /> : <ArrowDown className="w-3 h-3 text-emerald-600" />;
  };

  const filtered = useMemo(() => {
    let data = requirements;
    if (statusFilter !== "all") data = data.filter(r => r.status === statusFilter);
    if (priorityFilter !== "all") data = data.filter(r => r.priority === priorityFilter);
    if (sectionFilter !== "all") data = data.filter(r => r.section === sectionFilter);
    if (search) data = data.filter(r =>
      r.clause_number?.toLowerCase().includes(search.toLowerCase()) ||
      r.clause_title?.toLowerCase().includes(search.toLowerCase()) ||
      r.responsible_person?.toLowerCase().includes(search.toLowerCase())
    );
    data = [...data].sort((a, b) => {
      let av = a[sortField] ?? ""; let bv = b[sortField] ?? "";
      return sortDir === "asc" ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });
    return data;
  }, [requirements, statusFilter, priorityFilter, sectionFilter, search, sortField, sortDir]);

  const headers = ["Clause #", "Title", "Section", "Status", "Priority", "Responsible", "Due Date", "% Complete"];
  const rows = () => filtered.map(r => [
    r.clause_number, r.clause_title, r.section?.split(" - ")[0], r.status?.replace(/_/g, " "),
    r.priority, r.responsible_person || "—",
    r.due_date ? format(new Date(r.due_date), "dd MMM yyyy") : "—",
    `${r.completion_percentage ?? 0}%`,
  ]);

  if (isLoading) return <div className="flex items-center justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>;

  return (
    <div className="space-y-4">
      {/* Filters */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <Input placeholder="Search clause, title, person…" value={search} onChange={e => setSearch(e.target.value)} className="w-52 h-9 text-sm" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40 h-9 text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="compliant">Compliant</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="partial">Partial</SelectItem>
                <SelectItem value="non_compliant">Non-Compliant</SelectItem>
                <SelectItem value="not_started">Not Started</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-36 h-9 text-sm"><SelectValue placeholder="Priority" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sectionFilter} onValueChange={setSectionFilter}>
              <SelectTrigger className="w-48 h-9 text-sm"><SelectValue placeholder="Section" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sections</SelectItem>
                {SECTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            {(statusFilter !== "all" || priorityFilter !== "all" || sectionFilter !== "all" || search) && (
              <Button variant="ghost" size="sm" className="text-slate-400 h-9"
                onClick={() => { setStatusFilter("all"); setPriorityFilter("all"); setSectionFilter("all"); setSearch(""); }}>
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <ReportToolbar
        count={filtered.length}
        onExportCSV={() => exportToCSV([headers, ...rows()], `compliance-report-${format(new Date(), "yyyy-MM-dd")}.csv`)}
        onExportPDF={() => exportToPDF("Compliance Status Report", headers, rows(), `compliance-report-${format(new Date(), "yyyy-MM-dd")}.pdf`)}
      />

      {/* Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                {[["clause_number","Clause #"],["clause_title","Title"],["section","Section"],["status","Status"],["priority","Priority"],["responsible_person","Responsible"],["due_date","Due Date"],["completion_percentage","% Done"]].map(([field, label]) => (
                  <th key={field} onClick={() => toggleSort(field)} className="text-left px-4 py-3 text-xs font-semibold text-slate-600 cursor-pointer hover:text-slate-900 whitespace-nowrap">
                    <span className="flex items-center gap-1">{label}<SortIcon field={field} /></span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-10 text-slate-400">No records match the selected filters.</td></tr>
              ) : filtered.map(r => (
                <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs text-slate-700">{r.clause_number}</td>
                  <td className="px-4 py-3 text-slate-900 max-w-[200px]">
                    <p className="truncate font-medium">{r.clause_title}</p>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">{r.section?.split(" - ")[0]}</td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${STATUS_COLORS[r.status] || ""}`}>
                      {r.status?.replace(/_/g, " ")}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${PRIORITY_COLORS[r.priority] || ""}`}>
                      {r.priority}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-slate-600 text-xs">{r.responsible_person || "—"}</td>
                  <td className="px-4 py-3 text-slate-600 text-xs whitespace-nowrap">
                    {r.due_date ? format(new Date(r.due_date), "dd MMM yyyy") : "—"}
                  </td>
                  <td className="px-4 py-3 text-xs">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-16 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${r.completion_percentage ?? 0}%` }} />
                      </div>
                      <span className="text-slate-600">{r.completion_percentage ?? 0}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}