import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, ArrowUp, ArrowDown, Filter, AlertTriangle, Loader2 } from "lucide-react";
import { format } from "date-fns";
import ReportToolbar, { exportToCSV, exportToPDF } from "./ReportToolbar";

const PRIORITY_COLORS = {
  critical: "bg-rose-50 text-rose-700 border-rose-200",
  high: "bg-orange-50 text-orange-700 border-orange-200",
  medium: "bg-amber-50 text-amber-700 border-amber-200",
  low: "bg-blue-50 text-blue-700 border-blue-200",
};

const STATUS_COLORS = {
  completed: "bg-emerald-50 text-emerald-700 border-emerald-200",
  in_progress: "bg-blue-50 text-blue-700 border-blue-200",
  blocked: "bg-rose-50 text-rose-700 border-rose-200",
  pending: "bg-amber-50 text-amber-700 border-amber-200",
};

function isOverdue(a) {
  return a.due_date && a.status !== "completed" && new Date(a.due_date) < new Date();
}

export default function ActionItemsReportTab() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [assigneeFilter, setAssigneeFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState("due_date");
  const [sortDir, setSortDir] = useState("asc");

  const { data: actions = [], isLoading } = useQuery({
    queryKey: ["action-items-report"],
    queryFn: () => base44.entities.ActionItem.list("-created_date", 1000),
  });

  const allAssignees = useMemo(() => {
    const s = new Set(); actions.forEach(a => { if (a.assigned_to) s.add(a.assigned_to); });
    return Array.from(s).sort();
  }, [actions]);

  const toggleSort = (field) => {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("asc"); }
  };

  const SortIcon = ({ field }) => {
    if (sortField !== field) return <ArrowUpDown className="w-3 h-3 text-slate-400" />;
    return sortDir === "asc" ? <ArrowUp className="w-3 h-3 text-emerald-600" /> : <ArrowDown className="w-3 h-3 text-emerald-600" />;
  };

  const filtered = useMemo(() => {
    let data = actions;
    if (statusFilter !== "all") data = data.filter(a => a.status === statusFilter);
    if (priorityFilter !== "all") data = data.filter(a => a.priority === priorityFilter);
    if (assigneeFilter !== "all") data = data.filter(a => a.assigned_to === assigneeFilter);
    if (search) data = data.filter(a =>
      a.title?.toLowerCase().includes(search.toLowerCase()) ||
      a.assigned_to?.toLowerCase().includes(search.toLowerCase())
    );
    data = [...data].sort((a, b) => {
      let av = a[sortField] ?? ""; let bv = b[sortField] ?? "";
      return sortDir === "asc" ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });
    return data;
  }, [actions, statusFilter, priorityFilter, assigneeFilter, search, sortField, sortDir]);

  const overdueCount = filtered.filter(isOverdue).length;

  const headers = ["Title", "Status", "Priority", "Assigned To", "Due Date", "Overdue", "Source"];
  const rows = () => filtered.map(a => [
    a.title, a.status?.replace(/_/g, " "), a.priority,
    a.assigned_to || "—",
    a.due_date ? format(new Date(a.due_date), "dd MMM yyyy") : "—",
    isOverdue(a) ? "Yes" : "No",
    a.source_type?.replace(/_/g, " ") || "—",
  ]);

  if (isLoading) return <div className="flex items-center justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>;

  return (
    <div className="space-y-4">
      {overdueCount > 0 && (
        <div className="flex items-center gap-2 px-4 py-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-sm">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <strong>{overdueCount} overdue</strong> action item{overdueCount !== 1 ? "s" : ""} in current filter
        </div>
      )}

      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <Input placeholder="Search title, assignee…" value={search} onChange={e => setSearch(e.target.value)} className="w-52 h-9 text-sm" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 h-9 text-sm"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="blocked">Blocked</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-36 h-9 text-sm"><SelectValue placeholder="Priority" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
            {allAssignees.length > 0 && (
              <Select value={assigneeFilter} onValueChange={setAssigneeFilter}>
                <SelectTrigger className="w-44 h-9 text-sm"><SelectValue placeholder="Assignee" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Assignees</SelectItem>
                  {allAssignees.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
            {(statusFilter !== "all" || priorityFilter !== "all" || assigneeFilter !== "all" || search) && (
              <Button variant="ghost" size="sm" className="text-slate-400 h-9"
                onClick={() => { setStatusFilter("all"); setPriorityFilter("all"); setAssigneeFilter("all"); setSearch(""); }}>
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <ReportToolbar
        count={filtered.length}
        onExportCSV={() => exportToCSV([headers, ...rows()], `action-items-report-${format(new Date(), "yyyy-MM-dd")}.csv`)}
        onExportPDF={() => exportToPDF("Action Items Report", headers, rows(), `action-items-report-${format(new Date(), "yyyy-MM-dd")}.pdf`)}
      />

      <Card className="border-0 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                {[["title","Title"],["status","Status"],["priority","Priority"],["assigned_to","Assigned To"],["due_date","Due Date"]].map(([field, label]) => (
                  <th key={field} onClick={() => toggleSort(field)} className="text-left px-4 py-3 text-xs font-semibold text-slate-600 cursor-pointer hover:text-slate-900 whitespace-nowrap">
                    <span className="flex items-center gap-1">{label}<SortIcon field={field} /></span>
                  </th>
                ))}
                <th className="text-left px-4 py-3 text-xs font-semibold text-slate-600">Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-10 text-slate-400">No records match the selected filters.</td></tr>
              ) : filtered.map(a => (
                <tr key={a.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 max-w-[240px]">
                    <div className="flex items-start gap-1.5">
                      {isOverdue(a) && <AlertTriangle className="w-3.5 h-3.5 text-rose-500 mt-0.5 shrink-0" />}
                      <p className="font-medium text-slate-900 truncate">{a.title}</p>
                    </div>
                    {a.description && <p className="text-xs text-slate-400 truncate mt-0.5">{a.description}</p>}
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${STATUS_COLORS[a.status] || ""}`}>
                      {a.status?.replace(/_/g, " ")}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${PRIORITY_COLORS[a.priority] || ""}`}>
                      {a.priority}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-600">{a.assigned_to || "—"}</td>
                  <td className={`px-4 py-3 text-xs whitespace-nowrap ${isOverdue(a) ? "text-rose-600 font-semibold" : "text-slate-600"}`}>
                    {a.due_date ? format(new Date(a.due_date), "dd MMM yyyy") : "—"}
                    {isOverdue(a) && " ⚠"}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500">{a.source_type?.replace(/_/g, " ") || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}