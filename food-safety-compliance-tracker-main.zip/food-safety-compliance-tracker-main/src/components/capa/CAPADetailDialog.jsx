import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { CheckCircle2, Clock, AlertTriangle, Plus, Trash2, ShieldCheck } from "lucide-react";

const STATUS_STEPS = [
  { key: "open", label: "Open" },
  { key: "root_cause_analysis", label: "RCA" },
  { key: "action_planning", label: "Planning" },
  { key: "implementation", label: "Implementation" },
  { key: "verification", label: "Verification" },
  { key: "pending_signoff", label: "Sign-off" },
  { key: "closed", label: "Closed" },
];

const PRIORITY_COLORS = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
};

export default function CAPADetailDialog({ capa, onClose, currentUser }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({ ...capa });

  const update = useMutation({
    mutationFn: (data) => base44.entities.CAPA.update(capa.id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["capas"] });
      toast.success("CAPA updated");
    },
    onError: () => toast.error("Failed to update CAPA"),
  });

  const set = (field, value) => setForm(f => ({ ...f, [field]: value }));

  const save = (extraFields = {}) => update.mutate({ ...form, ...extraFields });

  const addAction = (type) => {
    const field = type === "corrective" ? "corrective_actions" : "preventive_actions";
    const list = form[field] || [];
    set(field, [...list, { id: `${type}-${Date.now()}`, action: "", assigned_to: "", due_date: "", completed: false }]);
  };

  const updateAction = (type, id, patch) => {
    const field = type === "corrective" ? "corrective_actions" : "preventive_actions";
    set(field, (form[field] || []).map(a => a.id === id ? { ...a, ...patch } : a));
  };

  const removeAction = (type, id) => {
    const field = type === "corrective" ? "corrective_actions" : "preventive_actions";
    set(field, (form[field] || []).filter(a => a.id !== id));
  };

  const handleSignoff = () => {
    save({
      status: "closed",
      signoff_by: currentUser?.email,
      signoff_date: new Date().toISOString(),
      closed_date: new Date().toISOString(),
    });
    toast.success("CAPA signed off and closed");
    onClose();
  };

  const stepIndex = STATUS_STEPS.findIndex(s => s.key === form.status);

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <DialogTitle className="text-base font-bold">{form.capa_number}</DialogTitle>
            <Badge className={PRIORITY_COLORS[form.priority]}>{form.priority}</Badge>
            <Badge variant="outline">{form.capa_type}</Badge>
          </div>
          <p className="text-sm text-slate-500 mt-1">{form.title}</p>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="flex items-center gap-1 py-2 overflow-x-auto">
          {STATUS_STEPS.map((step, i) => (
            <React.Fragment key={step.key}>
              <button
                onClick={() => set("status", step.key)}
                className={`px-2 py-1 rounded text-xs font-medium whitespace-nowrap transition-colors ${
                  i <= stepIndex
                    ? "bg-emerald-600 text-white"
                    : "bg-slate-100 text-slate-500 hover:bg-slate-200"
                }`}
              >
                {step.label}
              </button>
              {i < STATUS_STEPS.length - 1 && (
                <div className={`h-0.5 w-4 shrink-0 ${i < stepIndex ? "bg-emerald-600" : "bg-slate-200"}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        <Tabs defaultValue="details">
          <TabsList className="w-full grid grid-cols-5 text-xs">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="rca">Root Cause</TabsTrigger>
            <TabsTrigger value="actions">Actions</TabsTrigger>
            <TabsTrigger value="verification">Verification</TabsTrigger>
            <TabsTrigger value="signoff">Sign-off</TabsTrigger>
          </TabsList>

          {/* DETAILS TAB */}
          <TabsContent value="details" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Title</Label>
                <Input value={form.title || ""} onChange={e => set("title", e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Priority</Label>
                <Select value={form.priority} onValueChange={v => set("priority", v)}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Assigned To</Label>
                <Input value={form.assigned_to || ""} onChange={e => set("assigned_to", e.target.value)} placeholder="Email" className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Due Date</Label>
                <Input type="date" value={form.due_date || ""} onChange={e => set("due_date", e.target.value)} className="mt-1" />
              </div>
            </div>
            <div>
              <Label className="text-xs">Problem Statement</Label>
              <Textarea value={form.problem_statement || ""} onChange={e => set("problem_statement", e.target.value)} rows={3} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Immediate Containment Action</Label>
              <Textarea value={form.immediate_action || ""} onChange={e => set("immediate_action", e.target.value)} rows={2} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Immediate Action Date</Label>
                <Input type="date" value={form.immediate_action_date || ""} onChange={e => set("immediate_action_date", e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Immediate Action By</Label>
                <Input value={form.immediate_action_by || ""} onChange={e => set("immediate_action_by", e.target.value)} placeholder="Name" className="mt-1" />
              </div>
            </div>
            {form.source_reference && (
              <div className="bg-slate-50 p-3 rounded text-xs text-slate-600">
                <span className="font-medium">Source:</span> {form.source_type?.replace(/_/g, " ")} — {form.source_reference}
              </div>
            )}
          </TabsContent>

          {/* ROOT CAUSE TAB */}
          <TabsContent value="rca" className="space-y-4 pt-4">
            <div>
              <Label className="text-xs">RCA Method</Label>
              <Select value={form.root_cause_method || ""} onValueChange={v => set("root_cause_method", v)}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select method" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="5_whys">5 Whys</SelectItem>
                  <SelectItem value="fishbone">Fishbone (Ishikawa)</SelectItem>
                  <SelectItem value="fault_tree">Fault Tree Analysis</SelectItem>
                  <SelectItem value="pareto">Pareto Analysis</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Root Cause Description</Label>
              <Textarea value={form.root_cause_description || ""} onChange={e => set("root_cause_description", e.target.value)} rows={5} placeholder="Describe the identified root cause..." className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Completed Date</Label>
                <Input type="date" value={form.root_cause_completed_date || ""} onChange={e => set("root_cause_completed_date", e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Completed By</Label>
                <Input value={form.root_cause_completed_by || ""} onChange={e => set("root_cause_completed_by", e.target.value)} className="mt-1" />
              </div>
            </div>
          </TabsContent>

          {/* ACTIONS TAB */}
          <TabsContent value="actions" className="space-y-6 pt-4">
            {/* Corrective Actions */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-xs font-semibold text-slate-700">Corrective Actions</Label>
                <Button size="sm" variant="outline" onClick={() => addAction("corrective")} className="h-7 text-xs gap-1">
                  <Plus className="w-3 h-3" /> Add
                </Button>
              </div>
              <div className="space-y-2">
                {(form.corrective_actions || []).map(a => (
                  <div key={a.id} className="flex items-start gap-2 p-3 bg-slate-50 rounded-lg">
                    <Checkbox checked={a.completed} onCheckedChange={v => updateAction("corrective", a.id, { completed: v, completed_date: v ? new Date().toISOString().split("T")[0] : "" })} className="mt-1" />
                    <div className="flex-1 grid grid-cols-3 gap-2">
                      <Input value={a.action} onChange={e => updateAction("corrective", a.id, { action: e.target.value })} placeholder="Action description" className="col-span-2 h-8 text-xs" />
                      <Input type="date" value={a.due_date} onChange={e => updateAction("corrective", a.id, { due_date: e.target.value })} className="h-8 text-xs" />
                      <Input value={a.assigned_to} onChange={e => updateAction("corrective", a.id, { assigned_to: e.target.value })} placeholder="Assigned to (email)" className="col-span-2 h-8 text-xs" />
                    </div>
                    <Button size="icon" variant="ghost" onClick={() => removeAction("corrective", a.id)} className="h-7 w-7 text-red-400 hover:text-red-600">
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            {/* Preventive Actions */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-xs font-semibold text-slate-700">Preventive Actions</Label>
                <Button size="sm" variant="outline" onClick={() => addAction("preventive")} className="h-7 text-xs gap-1">
                  <Plus className="w-3 h-3" /> Add
                </Button>
              </div>
              <div className="space-y-2">
                {(form.preventive_actions || []).map(a => (
                  <div key={a.id} className="flex items-start gap-2 p-3 bg-slate-50 rounded-lg">
                    <Checkbox checked={a.completed} onCheckedChange={v => updateAction("preventive", a.id, { completed: v })} className="mt-1" />
                    <div className="flex-1 grid grid-cols-3 gap-2">
                      <Input value={a.action} onChange={e => updateAction("preventive", a.id, { action: e.target.value })} placeholder="Preventive action description" className="col-span-2 h-8 text-xs" />
                      <Input type="date" value={a.due_date} onChange={e => updateAction("preventive", a.id, { due_date: e.target.value })} className="h-8 text-xs" />
                      <Input value={a.assigned_to} onChange={e => updateAction("preventive", a.id, { assigned_to: e.target.value })} placeholder="Assigned to (email)" className="col-span-2 h-8 text-xs" />
                    </div>
                    <Button size="icon" variant="ghost" onClick={() => removeAction("preventive", a.id)} className="h-7 w-7 text-red-400 hover:text-red-600">
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* VERIFICATION TAB */}
          <TabsContent value="verification" className="space-y-4 pt-4">
            <div>
              <Label className="text-xs">Verification Method</Label>
              <Textarea value={form.verification_method || ""} onChange={e => set("verification_method", e.target.value)} rows={2} placeholder="How will effectiveness be verified?" className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Verification Date</Label>
                <Input type="date" value={form.verification_date || ""} onChange={e => set("verification_date", e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label className="text-xs">Verified By</Label>
                <Input value={form.verification_by || ""} onChange={e => set("verification_by", e.target.value)} placeholder="Email" className="mt-1" />
              </div>
            </div>
            <div>
              <Label className="text-xs">Verification Result</Label>
              <Select value={form.verification_result || ""} onValueChange={v => set("verification_result", v)}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select result" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="effective">Effective</SelectItem>
                  <SelectItem value="partially_effective">Partially Effective</SelectItem>
                  <SelectItem value="not_effective">Not Effective</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Verification Notes</Label>
              <Textarea value={form.verification_notes || ""} onChange={e => set("verification_notes", e.target.value)} rows={3} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Lessons Learned</Label>
              <Textarea value={form.lessons_learned || ""} onChange={e => set("lessons_learned", e.target.value)} rows={3} placeholder="Key takeaways to prevent recurrence..." className="mt-1" />
            </div>
          </TabsContent>

          {/* SIGNOFF TAB */}
          <TabsContent value="signoff" className="space-y-4 pt-4">
            {form.status === "closed" ? (
              <div className="flex flex-col items-center gap-3 py-6">
                <CheckCircle2 className="w-12 h-12 text-emerald-600" />
                <p className="text-sm font-semibold text-emerald-700">CAPA Closed & Signed Off</p>
                <p className="text-xs text-slate-500">Signed by: {form.signoff_by}</p>
                <p className="text-xs text-slate-500">Date: {form.signoff_date ? new Date(form.signoff_date).toLocaleDateString() : "—"}</p>
                {form.signoff_notes && <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded">{form.signoff_notes}</p>}
              </div>
            ) : (
              <>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-800">
                  <p className="font-semibold flex items-center gap-2"><AlertTriangle className="w-4 h-4" /> Management Sign-off Required</p>
                  <p className="text-xs mt-1">Ensure all corrective and preventive actions are completed and verification is done before signing off.</p>
                </div>
                <div>
                  <Label className="text-xs">Sign-off Notes</Label>
                  <Textarea value={form.signoff_notes || ""} onChange={e => set("signoff_notes", e.target.value)} rows={3} placeholder="Add any final notes or comments..." className="mt-1" />
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Signing off as: <strong>{currentUser?.email}</strong>
                </div>
                <Button onClick={handleSignoff} className="w-full bg-emerald-600 hover:bg-emerald-700 gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Sign Off & Close CAPA
                </Button>
              </>
            )}
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => save()} disabled={update.isPending} className="bg-emerald-600 hover:bg-emerald-700">
            {update.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}