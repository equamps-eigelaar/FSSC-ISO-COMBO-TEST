import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { addDays, format } from "date-fns";

const REASONS = ["routine", "customer_complaint", "regulatory", "shelf_life_study", "internal_investigation", "other"];

export default function RetentionSampleDialog({ open, onClose, onSave, sample }) {
  const isEdit = !!sample;
  const [form, setForm] = useState({
    sample_code: "",
    batch_number: "",
    product_name: "",
    product_code: "",
    sample_date: format(new Date(), "yyyy-MM-dd"),
    quantity: 1,
    unit: "units",
    storage_location: "",
    storage_conditions: "Ambient",
    retention_period_days: 90,
    expiry_date: format(addDays(new Date(), 90), "yyyy-MM-dd"),
    reason_for_retention: "routine",
    status: "active",
    notes: "",
    collected_by: "",
  });

  useEffect(() => {
    if (sample) setForm({ ...form, ...sample });
  }, [sample]);

  // Auto-calculate expiry date
  const handlePeriodChange = (days) => {
    const expiry = form.sample_date
      ? format(addDays(new Date(form.sample_date), parseInt(days) || 0), "yyyy-MM-dd")
      : form.expiry_date;
    setForm((f) => ({ ...f, retention_period_days: days, expiry_date: expiry }));
  };

  const handleDateChange = (val) => {
    const expiry = format(addDays(new Date(val), parseInt(form.retention_period_days) || 90), "yyyy-MM-dd");
    setForm((f) => ({ ...f, sample_date: val, expiry_date: expiry }));
  };

  const set = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target ? e.target.value : e }));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Retention Sample" : "Register Retention Sample"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Sample Code *</Label>
              <Input value={form.sample_code} onChange={set("sample_code")} placeholder="RS-2026-001" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Batch Number *</Label>
              <Input value={form.batch_number} onChange={set("batch_number")} placeholder="BATCH-001" className="mt-1" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Product Name *</Label>
              <Input value={form.product_name} onChange={set("product_name")} placeholder="Product name" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Product Code</Label>
              <Input value={form.product_code} onChange={set("product_code")} placeholder="SKU-001" className="mt-1" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Sample Date *</Label>
              <Input type="date" value={form.sample_date} onChange={(e) => handleDateChange(e.target.value)} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Retention Period (days)</Label>
              <Input type="number" value={form.retention_period_days} onChange={(e) => handlePeriodChange(e.target.value)} className="mt-1" />
            </div>
          </div>
          <div>
            <Label className="text-xs">Expiry Date (auto-calculated)</Label>
            <Input type="date" value={form.expiry_date} onChange={set("expiry_date")} className="mt-1" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Quantity</Label>
              <Input type="number" value={form.quantity} onChange={set("quantity")} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Unit</Label>
              <Input value={form.unit} onChange={set("unit")} placeholder="units / kg / g" className="mt-1" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Storage Location *</Label>
              <Input value={form.storage_location} onChange={set("storage_location")} placeholder="e.g. Cold Room A, Shelf 3" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Storage Conditions</Label>
              <Input value={form.storage_conditions} onChange={set("storage_conditions")} placeholder="e.g. 4°C, Ambient" className="mt-1" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Reason for Retention</Label>
              <Select value={form.reason_for_retention} onValueChange={set("reason_for_retention")}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {REASONS.map((r) => <SelectItem key={r} value={r}>{r.replace(/_/g, " ")}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={set("status")}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="tested">Tested</SelectItem>
                  <SelectItem value="disposed">Disposed</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label className="text-xs">Collected By</Label>
            <Input value={form.collected_by} onChange={set("collected_by")} placeholder="Email" className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Notes</Label>
            <Textarea value={form.notes} onChange={set("notes")} rows={2} className="mt-1" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => onSave(form)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            {isEdit ? "Save Changes" : "Register Sample"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}