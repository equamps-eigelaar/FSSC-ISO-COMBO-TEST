import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { base44 } from "@/api/base44Client";

const TEST_TYPES = ["microbiological", "chemical", "physical", "organoleptic", "allergen", "nutritional", "packaging_integrity", "other"];

export default function SampleTestDialog({ open, onClose, onSave, sample, test }) {
  const isEdit = !!test;
  const [form, setForm] = useState({
    sample_id: sample?.id || "",
    sample_code: sample?.sample_code || "",
    test_type: "microbiological",
    test_name: "",
    test_date: format(new Date(), "yyyy-MM-dd"),
    laboratory: "",
    test_method: "",
    parameters: [],
    overall_result: "pending",
    report_number: "",
    corrective_action: "",
    reviewed_by: "",
    notes: "",
  });
  const [reportFile, setReportFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (test) setForm({ ...form, ...test });
  }, [test]);

  const set = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target ? e.target.value : e }));

  const addParameter = () => {
    setForm((f) => ({
      ...f,
      parameters: [...(f.parameters || []), { parameter: "", result: "", unit: "", specification: "", pass_fail: "pass" }]
    }));
  };

  const updateParam = (idx, field, value) => {
    setForm((f) => {
      const params = [...(f.parameters || [])];
      params[idx] = { ...params[idx], [field]: value };
      return { ...f, parameters: params };
    });
  };

  const removeParam = (idx) => {
    setForm((f) => ({ ...f, parameters: f.parameters.filter((_, i) => i !== idx) }));
  };

  const handleSave = async () => {
    let finalForm = { ...form };
    if (reportFile) {
      setUploading(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file: reportFile });
      finalForm.report_url = file_url;
      setUploading(false);
    }
    onSave(finalForm);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Test Result" : "Record Test Result"} — {form.sample_code}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Test Type *</Label>
              <Select value={form.test_type} onValueChange={set("test_type")}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TEST_TYPES.map((t) => <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Test Name *</Label>
              <Input value={form.test_name} onChange={set("test_name")} placeholder="e.g. Total Plate Count, pH" className="mt-1" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Test Date *</Label>
              <Input type="date" value={form.test_date} onChange={set("test_date")} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Overall Result</Label>
              <Select value={form.overall_result} onValueChange={set("overall_result")}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="pass">Pass</SelectItem>
                  <SelectItem value="fail">Fail</SelectItem>
                  <SelectItem value="inconclusive">Inconclusive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Laboratory / Tester</Label>
              <Input value={form.laboratory} onChange={set("laboratory")} placeholder="Lab name or person" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Test Method</Label>
              <Input value={form.test_method} onChange={set("test_method")} placeholder="e.g. ISO 4833, AOAC" className="mt-1" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Report / Certificate Number</Label>
              <Input value={form.report_number} onChange={set("report_number")} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Upload Report</Label>
              <Input type="file" onChange={(e) => setReportFile(e.target.files[0])} className="mt-1" />
            </div>
          </div>

          {/* Parameters */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-xs font-semibold">Test Parameters</Label>
              <Button size="sm" variant="outline" onClick={addParameter} className="h-7 text-xs gap-1">
                <Plus className="w-3 h-3" /> Add Parameter
              </Button>
            </div>
            {(form.parameters || []).length === 0 && (
              <p className="text-xs text-slate-400 italic">No parameters added yet.</p>
            )}
            <div className="space-y-2">
              {(form.parameters || []).map((p, idx) => (
                <div key={idx} className="grid grid-cols-5 gap-2 items-center bg-slate-50 rounded p-2">
                  <Input value={p.parameter} onChange={(e) => updateParam(idx, "parameter", e.target.value)} placeholder="Parameter" className="text-xs h-7" />
                  <Input value={p.result} onChange={(e) => updateParam(idx, "result", e.target.value)} placeholder="Result" className="text-xs h-7" />
                  <Input value={p.unit} onChange={(e) => updateParam(idx, "unit", e.target.value)} placeholder="Unit" className="text-xs h-7" />
                  <Input value={p.specification} onChange={(e) => updateParam(idx, "specification", e.target.value)} placeholder="Spec" className="text-xs h-7" />
                  <div className="flex items-center gap-1">
                    <Select value={p.pass_fail} onValueChange={(v) => updateParam(idx, "pass_fail", v)}>
                      <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pass">Pass</SelectItem>
                        <SelectItem value="fail">Fail</SelectItem>
                        <SelectItem value="inconclusive">N/A</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button size="icon" variant="ghost" onClick={() => removeParam(idx)} className="h-7 w-7 text-red-400">
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {form.overall_result === "fail" && (
            <div>
              <Label className="text-xs">Corrective Action</Label>
              <Textarea value={form.corrective_action} onChange={set("corrective_action")} rows={2} placeholder="Actions taken due to failed result..." className="mt-1" />
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Reviewed By</Label>
              <Input value={form.reviewed_by} onChange={set("reviewed_by")} placeholder="Email" className="mt-1" />
            </div>
          </div>
          <div>
            <Label className="text-xs">Notes</Label>
            <Textarea value={form.notes} onChange={set("notes")} rows={2} className="mt-1" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={uploading} className="bg-emerald-600 hover:bg-emerald-700 text-white">
            {uploading ? "Uploading..." : isEdit ? "Save Changes" : "Record Test"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}