import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, FlaskConical, FileText, ExternalLink, Trash2 } from "lucide-react";
import SampleTestDialog from "./SampleTestDialog";

const RESULT_COLORS = {
  pass: "bg-emerald-100 text-emerald-700 border-emerald-300",
  fail: "bg-red-100 text-red-700 border-red-300",
  pending: "bg-yellow-100 text-yellow-700 border-yellow-300",
  inconclusive: "bg-slate-100 text-slate-600 border-slate-300",
};

export default function SampleTestsPanel({ sample }) {
  const qc = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [editTest, setEditTest] = useState(null);

  const { data: tests = [] } = useQuery({
    queryKey: ["sample_tests", sample.id],
    queryFn: () => base44.entities.SampleTest.filter({ sample_id: sample.id }),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.SampleTest.create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["sample_tests", sample.id] }); setShowDialog(false); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SampleTest.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["sample_tests", sample.id] }); setEditTest(null); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SampleTest.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sample_tests", sample.id] }),
  });

  const handleSave = (form) => {
    if (editTest) {
      updateMutation.mutate({ id: editTest.id, data: form });
    } else {
      createMutation.mutate(form);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
          <FlaskConical className="w-4 h-4 text-emerald-600" /> Test Results ({tests.length})
        </h4>
        <Button size="sm" onClick={() => setShowDialog(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white h-7 text-xs gap-1">
          <Plus className="w-3 h-3" /> Add Test
        </Button>
      </div>

      {tests.length === 0 ? (
        <p className="text-xs text-slate-400 italic">No tests recorded yet.</p>
      ) : (
        <div className="space-y-2">
          {tests.map((t) => (
            <div key={t.id} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2 border border-slate-200">
              <div>
                <span className="text-xs font-medium text-slate-800">{t.test_name}</span>
                <span className="text-xs text-slate-400 ml-2">({t.test_type?.replace(/_/g, " ")})</span>
                <p className="text-[11px] text-slate-500">{t.test_date} · {t.laboratory || "Internal"}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={`text-[11px] border ${RESULT_COLORS[t.overall_result]}`}>{t.overall_result}</Badge>
                {t.report_url && (
                  <a href={t.report_url} target="_blank" rel="noreferrer">
                    <Button size="icon" variant="ghost" className="h-6 w-6"><FileText className="w-3 h-3" /></Button>
                  </a>
                )}
                <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setEditTest(t)}><ExternalLink className="w-3 h-3" /></Button>
                <Button size="icon" variant="ghost" className="h-6 w-6 text-red-400" onClick={() => deleteMutation.mutate(t.id)}><Trash2 className="w-3 h-3" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {(showDialog || editTest) && (
        <SampleTestDialog
          open={!!(showDialog || editTest)}
          onClose={() => { setShowDialog(false); setEditTest(null); }}
          onSave={handleSave}
          sample={sample}
          test={editTest}
        />
      )}
    </div>
  );
}