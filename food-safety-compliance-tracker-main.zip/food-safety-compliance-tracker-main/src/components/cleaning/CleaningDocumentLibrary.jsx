import React, { useState, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Search, Download, Filter, X, Camera, Sparkles, CheckCircle2,
  XCircle, AlertTriangle, FileImage, ExternalLink, Calendar
} from "lucide-react";
import { format } from "date-fns";

const RESULT_CONFIG = {
  pass: { label: "Pass", icon: CheckCircle2, bg: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  conditional_pass: { label: "Conditional", icon: AlertTriangle, bg: "bg-amber-50 text-amber-700 border-amber-200" },
  fail: { label: "Fail", icon: XCircle, bg: "bg-red-50 text-red-700 border-red-200" },
};

function DocumentCard({ register, photoIndex }) {
  const url = register.photo_urls[photoIndex];
  const cfg = RESULT_CONFIG[register.result] || RESULT_CONFIG.pass;
  const Icon = cfg.icon;
  const score = register.ai_analysis?.compliance_score;

  const handleDownload = () => {
    const a = document.createElement("a");
    a.href = url;
    a.download = `register-${register.area}-${photoIndex + 1}.jpg`;
    a.target = "_blank";
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <Card className="border-0 shadow-sm hover:shadow-md transition-shadow overflow-hidden group">
      <div className="relative">
        <a href={url} target="_blank" rel="noopener noreferrer">
          <img
            src={url}
            alt={`${register.area} photo ${photoIndex + 1}`}
            className="w-full h-40 object-cover group-hover:opacity-90 transition-opacity"
            onError={(e) => {
              e.target.style.display = "none";
              e.target.nextSibling.style.display = "flex";
            }}
          />
          <div className="hidden w-full h-40 bg-slate-100 items-center justify-center">
            <FileImage className="w-10 h-10 text-slate-300" />
          </div>
        </a>
        {/* Overlay actions */}
        <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            size="icon"
            variant="secondary"
            className="h-7 w-7 bg-white/90 hover:bg-white shadow"
            onClick={handleDownload}
            title="Download"
          >
            <Download className="w-3.5 h-3.5 text-slate-700" />
          </Button>
          <a href={url} target="_blank" rel="noopener noreferrer">
            <Button size="icon" variant="secondary" className="h-7 w-7 bg-white/90 hover:bg-white shadow" title="Open">
              <ExternalLink className="w-3.5 h-3.5 text-slate-700" />
            </Button>
          </a>
        </div>
        {/* Photo count indicator */}
        {register.photo_urls.length > 1 && (
          <div className="absolute bottom-2 left-2 bg-black/60 text-white text-xs px-1.5 py-0.5 rounded">
            {photoIndex + 1}/{register.photo_urls.length}
          </div>
        )}
      </div>
      <CardContent className="p-3 space-y-2">
        <div className="flex items-start justify-between gap-1">
          <span className="font-semibold text-sm text-slate-900 dark:text-white truncate">{register.area}</span>
          <Badge className={`text-xs border shrink-0 ${cfg.bg}`}>
            <Icon className="w-3 h-3 mr-1" />
            {cfg.label}
          </Badge>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500 flex-wrap">
          {register.cleaning_date && (
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {format(new Date(register.cleaning_date), "dd MMM yyyy")}
            </span>
          )}
          {register.shift && <span className="capitalize">• {register.shift} shift</span>}
        </div>
        {register.cleaned_by && (
          <p className="text-xs text-slate-500 truncate">By: {register.cleaned_by}</p>
        )}
        {score != null && (
          <div className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-purple-500" />
            <div className="flex-1 bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div
                className={`h-full rounded-full ${score >= 80 ? "bg-emerald-500" : score >= 50 ? "bg-amber-500" : "bg-red-500"}`}
                style={{ width: `${score}%` }}
              />
            </div>
            <span className="text-xs font-medium text-purple-700">{score}%</span>
          </div>
        )}
        <Button
          variant="outline"
          size="sm"
          className="w-full text-xs h-7 gap-1"
          onClick={handleDownload}
        >
          <Download className="w-3 h-3" />
          Download
        </Button>
      </CardContent>
    </Card>
  );
}

function RegisterDocRow({ register, onDownloadAll }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = RESULT_CONFIG[register.result] || RESULT_CONFIG.pass;
  const Icon = cfg.icon;
  const score = register.ai_analysis?.compliance_score;

  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center shrink-0">
            <Camera className="w-5 h-5 text-slate-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-sm text-slate-900 dark:text-white">{register.area}</span>
              <Badge className={`text-xs border shrink-0 ${cfg.bg}`}>
                <Icon className="w-3 h-3 mr-1" />
                {cfg.label}
              </Badge>
              {score != null && (
                <Badge className="bg-purple-100 text-purple-700 border border-purple-200 text-xs gap-1 shrink-0">
                  <Sparkles className="w-3 h-3" />
                  {score}%
                </Badge>
              )}
            </div>
            <div className="text-xs text-slate-500 mt-0.5 flex flex-wrap gap-x-2">
              {register.cleaning_date && <span>{format(new Date(register.cleaning_date), "dd MMM yyyy")}</span>}
              {register.cleaned_by && <span>• {register.cleaned_by}</span>}
              <span className="text-blue-600 font-medium">• {register.photo_urls.length} photo(s)</span>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button variant="outline" size="sm" className="h-8 gap-1 text-xs" onClick={() => onDownloadAll(register)}>
              <Download className="w-3 h-3" />
              All
            </Button>
            <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => setExpanded(!expanded)}>
              {expanded ? "Hide" : "View"} Photos
            </Button>
          </div>
        </div>

        {expanded && (
          <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 border-t border-slate-100 pt-4">
            {register.photo_urls.map((_, i) => (
              <DocumentCard key={i} register={register} photoIndex={i} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function CleaningDocumentLibrary({ registers }) {
  const [search, setSearch] = useState("");
  const [filterResult, setFilterResult] = useState("all");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");
  const [filterScore, setFilterScore] = useState("all");
  const [filterLocation, setFilterLocation] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState("list"); // "list" | "grid"

  // Only registers that have photos
  const withPhotos = useMemo(() => registers.filter((r) => r.photo_urls?.length > 0), [registers]);

  const locations = useMemo(() => [...new Set(withPhotos.map((r) => r.area).filter(Boolean))].sort(), [withPhotos]);

  const filtered = useMemo(() => {
    return withPhotos.filter((r) => {
      if (search && !r.area?.toLowerCase().includes(search.toLowerCase()) && !r.cleaned_by?.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterResult !== "all" && r.result !== filterResult) return false;
      if (filterLocation !== "all" && r.area !== filterLocation) return false;
      if (filterDateFrom && r.cleaning_date && new Date(r.cleaning_date) < new Date(filterDateFrom)) return false;
      if (filterDateTo && r.cleaning_date && new Date(r.cleaning_date) > new Date(filterDateTo)) return false;
      if (filterScore !== "all") {
        const score = r.ai_analysis?.compliance_score;
        if (filterScore === "high" && (score == null || score < 80)) return false;
        if (filterScore === "medium" && (score == null || score < 50 || score >= 80)) return false;
        if (filterScore === "low" && (score == null || score >= 50)) return false;
        if (filterScore === "no_ai" && r.ai_analysis?.analysed) return false;
      }
      return true;
    });
  }, [withPhotos, search, filterResult, filterLocation, filterDateFrom, filterDateTo, filterScore]);

  // All photos in filtered registers (for grid mode)
  const allPhotos = useMemo(() => {
    const photos = [];
    filtered.forEach((r) => {
      r.photo_urls.forEach((_, i) => photos.push({ register: r, photoIndex: i }));
    });
    return photos;
  }, [filtered]);

  const totalPhotos = withPhotos.reduce((s, r) => s + r.photo_urls.length, 0);
  const hasActiveFilters = filterResult !== "all" || filterLocation !== "all" || filterDateFrom || filterDateTo || filterScore !== "all";

  const clearFilters = () => {
    setFilterResult("all");
    setFilterDateFrom("");
    setFilterDateTo("");
    setFilterScore("all");
    setFilterLocation("all");
  };

  const handleDownloadAll = (register) => {
    register.photo_urls.forEach((url, i) => {
      setTimeout(() => {
        const a = document.createElement("a");
        a.href = url;
        a.download = `register-${register.area}-${i + 1}.jpg`;
        a.target = "_blank";
        document.body.appendChild(a);
        a.click();
        a.remove();
      }, i * 200);
    });
  };

  const handleDownloadAllFiltered = () => {
    filtered.forEach((register) => {
      register.photo_urls.forEach((url, i) => {
        const totalIdx = filtered.indexOf(register) * 10 + i;
        setTimeout(() => {
          const a = document.createElement("a");
          a.href = url;
          a.download = `register-${register.area}-${i + 1}.jpg`;
          a.target = "_blank";
          document.body.appendChild(a);
          a.click();
          a.remove();
        }, totalIdx * 150);
      });
    });
  };

  return (
    <div className="space-y-4">
      {/* Stats bar */}
      <div className="flex items-center gap-4 text-sm text-slate-600 flex-wrap">
        <span><strong className="text-slate-900">{withPhotos.length}</strong> registers with documents</span>
        <span>•</span>
        <span><strong className="text-slate-900">{totalPhotos}</strong> total photos</span>
        <span>•</span>
        <span><strong className="text-slate-900">{registers.filter((r) => !r.photo_urls?.length).length}</strong> without photos</span>
      </div>

      {/* Toolbar */}
      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input className="pl-9" placeholder="Search by area or person..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Button
          variant={showFilters ? "default" : "outline"}
          className="gap-2 shrink-0"
          onClick={() => setShowFilters(!showFilters)}
        >
          <Filter className="w-4 h-4" />
          Filters
          {hasActiveFilters && (
            <Badge className="bg-white text-slate-900 text-xs px-1 py-0 min-w-4 h-4">
              {[filterResult !== "all", filterLocation !== "all", filterDateFrom, filterDateTo, filterScore !== "all"].filter(Boolean).length}
            </Badge>
          )}
        </Button>
        <div className="flex border border-slate-200 rounded-md overflow-hidden shrink-0">
          <button
            onClick={() => setViewMode("list")}
            className={`px-3 py-1.5 text-sm font-medium transition-colors ${viewMode === "list" ? "bg-slate-900 text-white" : "bg-white text-slate-600 hover:bg-slate-50"}`}
          >
            List
          </button>
          <button
            onClick={() => setViewMode("grid")}
            className={`px-3 py-1.5 text-sm font-medium transition-colors ${viewMode === "grid" ? "bg-slate-900 text-white" : "bg-white text-slate-600 hover:bg-slate-50"}`}
          >
            Grid
          </button>
        </div>
        {filtered.length > 0 && (
          <Button variant="outline" size="sm" className="gap-1 shrink-0 text-xs" onClick={handleDownloadAllFiltered}>
            <Download className="w-3.5 h-3.5" />
            Download All ({allPhotos.length})
          </Button>
        )}
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <Card className="border border-slate-200 shadow-sm">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <div>
                <label className="text-xs font-medium text-slate-600 mb-1 block">Location</label>
                <Select value={filterLocation} onValueChange={setFilterLocation}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="All locations" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Locations</SelectItem>
                    {locations.map((loc) => (
                      <SelectItem key={loc} value={loc}>{loc}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600 mb-1 block">Status</label>
                <Select value={filterResult} onValueChange={setFilterResult}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="All" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pass">Pass</SelectItem>
                    <SelectItem value="conditional_pass">Conditional Pass</SelectItem>
                    <SelectItem value="fail">Fail</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600 mb-1 block">Date From</label>
                <input type="date" value={filterDateFrom} onChange={(e) => setFilterDateFrom(e.target.value)}
                  className="w-full h-9 px-3 border border-slate-200 rounded-md text-sm bg-background" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600 mb-1 block">Date To</label>
                <input type="date" value={filterDateTo} onChange={(e) => setFilterDateTo(e.target.value)}
                  className="w-full h-9 px-3 border border-slate-200 rounded-md text-sm bg-background" />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600 mb-1 block">AI Score</label>
                <Select value={filterScore} onValueChange={setFilterScore}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="All" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Scores</SelectItem>
                    <SelectItem value="high">High (≥80%)</SelectItem>
                    <SelectItem value="medium">Medium (50–79%)</SelectItem>
                    <SelectItem value="low">Low (&lt;50%)</SelectItem>
                    <SelectItem value="no_ai">No AI Analysis</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {hasActiveFilters && (
              <div className="mt-3 flex justify-end">
                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-xs gap-1 text-slate-500 hover:text-red-600">
                  <X className="w-3 h-3" /> Clear filters
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {(search || hasActiveFilters) && (
        <p className="text-xs text-slate-500">
          Showing <strong>{filtered.length}</strong> of {withPhotos.length} document sets ({allPhotos.length} photos)
        </p>
      )}

      {/* Content */}
      {withPhotos.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-16 text-center">
            <Camera className="w-12 h-12 text-slate-200 mx-auto mb-4" />
            <h3 className="text-base font-medium text-slate-700 mb-1">No documents yet</h3>
            <p className="text-sm text-slate-400">Upload cleaning registers with photos to see them here.</p>
          </CardContent>
        </Card>
      ) : filtered.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <p className="text-sm text-slate-500">No documents match your filters.</p>
            {hasActiveFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters} className="mt-2 text-xs">Clear filters</Button>
            )}
          </CardContent>
        </Card>
      ) : viewMode === "grid" ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {allPhotos.map(({ register, photoIndex }, idx) => (
            <DocumentCard key={`${register.id}-${photoIndex}-${idx}`} register={register} photoIndex={photoIndex} />
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((register) => (
            <RegisterDocRow key={register.id} register={register} onDownloadAll={handleDownloadAll} />
          ))}
        </div>
      )}
    </div>
  );
}