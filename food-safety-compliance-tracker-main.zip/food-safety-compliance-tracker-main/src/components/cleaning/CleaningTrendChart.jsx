import React, { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, ReferenceLine
} from "recharts";
import { format, parseISO, startOfWeek, eachWeekOfInterval, subWeeks, startOfDay } from "date-fns";
import { TrendingUp } from "lucide-react";

function buildWeeklyTrend(registers) {
  if (!registers.length) return [];

  const sorted = [...registers]
    .filter((r) => r.cleaning_date)
    .sort((a, b) => new Date(a.cleaning_date) - new Date(b.cleaning_date));

  if (!sorted.length) return [];

  const earliest = startOfWeek(new Date(sorted[0].cleaning_date), { weekStartsOn: 1 });
  const latest = startOfWeek(new Date(), { weekStartsOn: 1 });

  const weeks = eachWeekOfInterval({ start: earliest, end: latest }, { weekStartsOn: 1 });

  return weeks.map((weekStart) => {
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);

    const weekRegs = sorted.filter((r) => {
      const d = new Date(r.cleaning_date);
      return d >= weekStart && d <= weekEnd;
    });

    const total = weekRegs.length;
    const passes = weekRegs.filter((r) => r.result === "pass").length;
    const fails = weekRegs.filter((r) => r.result === "fail").length;
    const aiRegs = weekRegs.filter((r) => r.ai_analysis?.analysed);
    const avgAI = aiRegs.length > 0
      ? Math.round(aiRegs.reduce((s, r) => s + (r.ai_analysis?.compliance_score || 0), 0) / aiRegs.length)
      : null;

    return {
      week: format(weekStart, "dd MMM"),
      total,
      passRate: total > 0 ? Math.round((passes / total) * 100) : null,
      failRate: total > 0 ? Math.round((fails / total) * 100) : null,
      avgAI,
    };
  }).filter((w) => w.total > 0);
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-lg p-3 text-xs space-y-1">
      <p className="font-semibold text-slate-700 mb-1">Week of {label}</p>
      {payload.map((entry, i) => (
        <div key={i} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-slate-600">{entry.name}:</span>
          <span className="font-medium">{entry.value !== null ? `${entry.value}%` : "—"}</span>
        </div>
      ))}
    </div>
  );
};

export default function CleaningTrendChart({ registers }) {
  const data = useMemo(() => buildWeeklyTrend(registers), [registers]);

  if (data.length < 2) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="p-8 text-center text-sm text-slate-400">
          <TrendingUp className="w-8 h-8 mx-auto mb-2 text-slate-300" />
          Not enough data yet to show trends. Upload more registers over time.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-600" />
          Weekly Compliance Trends
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="week" tick={{ fontSize: 11, fill: "#94a3b8" }} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: "#94a3b8" }} unit="%" />
            <Tooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <ReferenceLine y={80} stroke="#10b981" strokeDasharray="4 4" strokeOpacity={0.5} />
            <Line
              type="monotone"
              dataKey="passRate"
              name="Pass Rate"
              stroke="#10b981"
              strokeWidth={2}
              dot={{ r: 3, fill: "#10b981" }}
              connectNulls
            />
            <Line
              type="monotone"
              dataKey="failRate"
              name="Fail Rate"
              stroke="#ef4444"
              strokeWidth={2}
              dot={{ r: 3, fill: "#ef4444" }}
              connectNulls
            />
            <Line
              type="monotone"
              dataKey="avgAI"
              name="Avg AI Score"
              stroke="#a855f7"
              strokeWidth={2}
              strokeDasharray="5 3"
              dot={{ r: 3, fill: "#a855f7" }}
              connectNulls
            />
          </LineChart>
        </ResponsiveContainer>
        <p className="text-xs text-slate-400 text-center mt-1">Dashed green line = 80% target threshold</p>
      </CardContent>
    </Card>
  );
}