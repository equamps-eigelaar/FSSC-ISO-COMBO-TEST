import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Upload, X, Loader2, Image, Sparkles } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function CleaningRegisterUpload({ open, onClose }) {
  const queryClient = useQueryClient();
  const [form, setForm] = useState({
    area: "",
    cleaning_date: format(new Date(), "yyyy-MM-dd"),
    shift: "morning",
    cleaned_by: "",
    verified_by: "",
    cleaning_method: "full_clean_sanitize",
    chemicals_used: [],
    notes: "",
    result: "pass",
  });
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [analysing, setAnalysing] = useState(false);
  const [aiResult, setAiResult] = useState(null);
  const [chemInput, setChemInput] = useState("");

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploading(true);
    const urls = [];
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      urls.push(file_url);
    }
    setPhotos((prev) => [...prev, ...urls]);
    setUploading(false);
    toast.success(`${files.length} photo(s) uploaded`);
  };

  const handleAnalyse = async () => {
    if (!photos.length) {
      toast.error("Please upload at least one photo first");
      return;
    }
    setAnalysing(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a food safety auditor specialising in packaging manufacturing cleaning compliance.
Analyse the cleaning register photo(s) provided. Assess:
1. Whether the cleaning record appears complete and properly signed off
2. Any visible issues, missed areas, or incomplete entries
3. Chemical usage appropriateness
4. Compliance with good hygiene practices
5. Trends or recurring issues if visible

Area: ${form.area || "General"}
Shift: ${form.shift}
Method: ${form.cleaning_method}
Chemicals: ${form.chemicals_used.join(", ") || "Not specified"}

Provide a structured JSON analysis.`,
        file_urls: photos,
        response_json_schema: {
          type: "object",
          properties: {
            overall_assessment: { type: "string" },
            compliance_score: { type: "number" },
            issues_found: { type: "array", items: { type: "string" } },
            recommendations: { type: "array", items: { type: "string" } },
          },
        },
      });
      setAiResult(result);
      toast.success("AI analysis complete");
    } catch {
      toast.error("Analysis failed, please try again");
    }
    setAnalysing(false);
  };

  const handleSave = async () => {
    if (!form.area || !form.cleaned_by) {
      toast.error("Please fill in Area and Cleaned By fields");
      return;
    }
    const record = {
      ...form,
      photo_urls: photos,
      ...(aiResult
        ? {
            ai_analysis: {
              analysed: true,
              analysed_date: new Date().toISOString(),
              ...aiResult,
            },
          }
        : {}),
    };
    await base44.entities.CleaningRegister.create(record);
    queryClient.invalidateQueries({ queryKey: ["cleaning-registers"] });
    toast.success("Cleaning register saved");
    onClose();
    resetForm();
  };

  const resetForm = () => {
    setForm({
      area: "",
      cleaning_date: format(new Date(), "yyyy-MM-dd"),
      shift: "morning",
      cleaned_by: "",
      verified_by: "",
      cleaning_method: "full_clean_sanitize",
      chemicals_used: [],
      notes: "",
      result: "pass",
    });
    setPhotos([]);
    setAiResult(null);
    setChemInput("");
  };

  const addChem = () => {
    if (chemInput.trim()) {
      setForm((f) => ({ ...f, chemicals_used: [...f.chemicals_used, chemInput.trim()] }));
      setChemInput("");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Upload Cleaning Register</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Area / Equipment *</Label>
              <Input value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} placeholder="e.g. Filling Line A" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Cleaning Date *</Label>
              <Input type="date" value={form.cleaning_date} onChange={(e) => setForm({ ...form, cleaning_date: e.target.value })} className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Shift</Label>
              <Select value={form.shift} onValueChange={(v) => setForm({ ...form, shift: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="morning">Morning</SelectItem>
                  <SelectItem value="afternoon">Afternoon</SelectItem>
                  <SelectItem value="night">Night</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Cleaning Method</Label>
              <Select value={form.cleaning_method} onValueChange={(v) => setForm({ ...form, cleaning_method: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="dry_clean">Dry Clean</SelectItem>
                  <SelectItem value="wet_clean">Wet Clean</SelectItem>
                  <SelectItem value="chemical_clean">Chemical Clean</SelectItem>
                  <SelectItem value="sanitize_only">Sanitize Only</SelectItem>
                  <SelectItem value="full_clean_sanitize">Full Clean + Sanitize</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Cleaned By *</Label>
              <Input value={form.cleaned_by} onChange={(e) => setForm({ ...form, cleaned_by: e.target.value })} placeholder="Name" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Verified By</Label>
              <Input value={form.verified_by} onChange={(e) => setForm({ ...form, verified_by: e.target.value })} placeholder="Supervisor name" className="mt-1" />
            </div>
          </div>

          <div>
            <Label className="text-xs">Result</Label>
            <Select value={form.result} onValueChange={(v) => setForm({ ...form, result: v })}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="pass">✅ Pass</SelectItem>
                <SelectItem value="conditional_pass">⚠️ Conditional Pass</SelectItem>
                <SelectItem value="fail">❌ Fail</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-xs">Chemicals Used</Label>
            <div className="flex gap-2 mt-1">
              <Input value={chemInput} onChange={(e) => setChemInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addChem()} placeholder="Add chemical..." />
              <Button type="button" variant="outline" size="sm" onClick={addChem}>Add</Button>
            </div>
            <div className="flex flex-wrap gap-1 mt-2">
              {form.chemicals_used.map((c, i) => (
                <Badge key={i} variant="secondary" className="gap-1">
                  {c}
                  <X className="w-3 h-3 cursor-pointer" onClick={() => setForm((f) => ({ ...f, chemicals_used: f.chemicals_used.filter((_, j) => j !== i) }))} />
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-xs">Notes</Label>
            <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Observations, deviations..." rows={2} className="mt-1" />
          </div>

          {/* Photo Upload */}
          <div className="border-2 border-dashed border-slate-200 rounded-lg p-4">
            <Label className="text-xs font-semibold text-slate-700 mb-3 block">Register Photos</Label>
            <label className="flex flex-col items-center cursor-pointer gap-2 text-slate-500 hover:text-slate-700 transition-colors">
              <Upload className="w-6 h-6" />
              <span className="text-xs">Click to upload photos of the completed register</span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} disabled={uploading} />
            </label>
            {uploading && <div className="flex items-center justify-center mt-3 gap-2 text-xs text-slate-500"><Loader2 className="w-4 h-4 animate-spin" /> Uploading...</div>}
            {photos.length > 0 && (
              <div className="grid grid-cols-3 gap-2 mt-3">
                {photos.map((url, i) => (
                  <div key={i} className="relative group">
                    <img src={url} alt={`Register ${i + 1}`} className="w-full h-24 object-cover rounded-lg border border-slate-200" />
                    <button
                      onClick={() => setPhotos((prev) => prev.filter((_, j) => j !== i))}
                      className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* AI Analysis */}
          {photos.length > 0 && (
            <Button variant="outline" className="w-full gap-2 border-purple-200 text-purple-700 hover:bg-purple-50" onClick={handleAnalyse} disabled={analysing}>
              {analysing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {analysing ? "Analysing register..." : "AI Analyse Register Photo(s)"}
            </Button>
          )}

          {aiResult && (
            <div className="border border-purple-200 bg-purple-50 rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-purple-800">AI Analysis Result</span>
                <Badge className={aiResult.compliance_score >= 80 ? "bg-emerald-100 text-emerald-800" : aiResult.compliance_score >= 60 ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-800"}>
                  Score: {aiResult.compliance_score}%
                </Badge>
              </div>
              <p className="text-xs text-slate-700">{aiResult.overall_assessment}</p>
              {aiResult.issues_found?.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-red-700 mb-1">Issues Found:</p>
                  <ul className="text-xs text-slate-600 space-y-0.5 list-disc ml-4">
                    {aiResult.issues_found.map((issue, i) => <li key={i}>{issue}</li>)}
                  </ul>
                </div>
              )}
              {aiResult.recommendations?.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-blue-700 mb-1">Recommendations:</p>
                  <ul className="text-xs text-slate-600 space-y-0.5 list-disc ml-4">
                    {aiResult.recommendations.map((r, i) => <li key={i}>{r}</li>)}
                  </ul>
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => { onClose(); resetForm(); }}>Cancel</Button>
            <Button onClick={handleSave}>Save Register</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}