import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle2, XCircle, AlertTriangle, Camera, Sparkles, TrendingUp, Search, ChevronDown, ChevronUp } from "lucide-react";
import { format } from "date-fns";

const RESULT_CONFIG = {
  pass: { label: "Pass", icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  conditional_pass: { label: "Conditional", icon: AlertTriangle, color: "text-amber-600", bg: "bg-amber-50 text-amber-700 border-amber-200" },
  fail: { label: "Fail", icon: XCircle, color: "text-red-600", bg: "bg-red-50 text-red-700 border-red-200" },
};

function RegisterCard({ register }) {
  const [expanded, setExpanded] = useState(false);
  const [showPhotos, setShowPhotos] = useState(false);
  const cfg = RESULT_CONFIG[register.result] || RESULT_CONFIG.pass;
  const Icon = cfg.icon;

  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-sm text-slate-900 dark:text-white">{register.area}</span>
              <Badge className={`text-xs border ${cfg.bg}`}>
                <Icon className="w-3 h-3 mr-1" />
                {cfg.label}
              </Badge>
              {register.photo_urls?.length > 0 && (
                <Badge variant="outline" className="text-xs gap-1">
                  <Camera className="w-3 h-3" />
                  {register.photo_urls.length} photo(s)
                </Badge>
              )}
              {register.ai_analysis?.analysed && (
                <Badge className="bg-purple-100 text-purple-700 border border-purple-200 text-xs gap-1">
                  <Sparkles className="w-3 h-3" />
                  AI: {register.ai_analysis.compliance_score}%
                </Badge>
              )}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {register.cleaning_date && format(new Date(register.cleaning_date), "dd MMM yyyy")}
              {register.shift && <span> • {register.shift}</span>}
              {register.cleaned_by && <span> • By: {register.cleaned_by}</span>}
              {register.verified_by && <span> • Verified: {register.verified_by}</span>}
            </div>
            {register.cleaning_method && (
              <span className="text-xs text-slate-400 capitalize">{register.cleaning_method.replace(/_/g, " ")}</span>
            )}
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setExpanded(!expanded)}>
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
        </div>

        {expanded && (
          <div className="mt-3 space-y-3 border-t border-slate-100 pt-3">
            {register.chemicals_used?.length > 0 && (
              <div>
                <p className="text-xs font-medium text-slate-600 mb-1">Chemicals Used:</p>
                <div className="flex flex-wrap gap-1">
                  {register.chemicals_used.map((c, i) => <Badge key={i} variant="secondary" className="text-xs">{c}</Badge>)}
                </div>
              </div>
            )}
            {register.notes && <p className="text-xs text-slate-600 italic">{register.notes}</p>}

            {register.photo_urls?.length > 0 && (
              <div>
                <Button variant="outline" size="sm" className="text-xs gap-1 mb-2" onClick={() => setShowPhotos(!showPhotos)}>
                  <Camera className="w-3 h-3" />
                  {showPhotos ? "Hide" : "View"} Photos
                </Button>
                {showPhotos && (
                  <div className="grid grid-cols-3 gap-2">
                    {register.photo_urls.map((url, i) => (
                      <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                        <img src={url} alt={`Register ${i + 1}`} className="w-full h-24 object-cover rounded-lg border border-slate-200 hover:opacity-80 transition-opacity" />
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}

            {register.ai_analysis?.analysed && (
              <div className="border border-purple-200 bg-purple-50 rounded-lg p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-3 h-3 text-purple-600" />
                  <span className="text-xs font-semibold text-purple-800">AI Analysis</span>
                  <Badge className="bg-purple-100 text-purple-700 text-xs ml-auto">{register.ai_analysis.compliance_score}%</Badge>
                </div>
                <p className="text-xs text-slate-700">{register.ai_analysis.overall_assessment}</p>
                {register.ai_analysis.issues_found?.length > 0 && (
                  <div>
                    <p className="text-xs font-medium text-red-700">Issues:</p>
                    <ul className="text-xs text-slate-600 ml-4 list-disc">
                      {register.ai_analysis.issues_found.map((issue, i) => <li key={i}>{issue}</li>)}
                    </ul>
                  </div>
                )}
                {register.ai_analysis.recommendations?.length > 0 && (
                  <div>
                    <p className="text-xs font-medium text-blue-700">Recommendations:</p>
                    <ul className="text-xs text-slate-600 ml-4 list-disc">
                      {register.ai_analysis.recommendations.map((r, i) => <li key={i}>{r}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function CleaningRegisterList() {
  const [search, setSearch] = useState("");

  const { data: registers = [], isLoading } = useQuery({
    queryKey: ["cleaning-registers"],
    queryFn: () => base44.entities.CleaningRegister.list("-cleaning_date", 200),
  });

  const filtered = registers.filter((r) =>
    !search || r.area?.toLowerCase().includes(search.toLowerCase()) || r.cleaned_by?.toLowerCase().includes(search.toLowerCase())
  );

  // Trend stats
  const total = registers.length;
  const passRate = total > 0 ? Math.round((registers.filter((r) => r.result === "pass").length / total) * 100) : 0;
  const aiAnalysed = registers.filter((r) => r.ai_analysis?.analysed).length;
  const avgScore = aiAnalysed > 0
    ? Math.round(registers.filter((r) => r.ai_analysis?.analysed).reduce((s, r) => s + (r.ai_analysis?.compliance_score || 0), 0) / aiAnalysed)
    : null;

  return (
    <div className="space-y-4">
      {/* Trend Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-slate-900 dark:text-white">{total}</div>
            <div className="text-xs text-slate-500 mt-1">Total Registers</div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-emerald-600">{passRate}%</div>
            <div className="text-xs text-slate-500 mt-1">Pass Rate</div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-600">
              {registers.filter((r) => r.result === "fail").length}
            </div>
            <div className="text-xs text-slate-500 mt-1">Failures</div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-purple-600">{avgScore !== null ? `${avgScore}%` : "—"}</div>
            <div className="text-xs text-slate-500 mt-1">Avg AI Score</div>
          </CardContent>
        </Card>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input
          className="pl-9"
          placeholder="Search by area or person..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-slate-400 text-sm">Loading registers...</div>
      ) : filtered.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <div className="text-4xl mb-3">🧹</div>
            <p className="text-slate-500 text-sm">No cleaning registers found. Upload your first one.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((r) => <RegisterCard key={r.id} register={r} />)}
        </div>
      )}
    </div>
  );
}