import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronLeft, ChevronRight, Search, CheckCircle2, ClipboardList, Calendar } from "lucide-react";
import { toast } from "sonner";

const SECTIONS = [
  "4 - Context of the Organization", "5 - Leadership", "6 - Planning",
  "7 - Support", "8 - Operation", "9 - Performance Evaluation", "10 - Improvement",
  "TS 22002-4 - Establishment", "TS 22002-4 - Utilities", "TS 22002-4 - Equipment",
  "TS 22002-4 - Hygiene", "TS 22002-4 - Personnel", "TS 22002-4 - Transportation",
  "TS 22002-4 - Product Information", "TS 22002-4 - Other Requirements",
];

const STEPS = ["Select Requirements", "Audit Details", "Review & Schedule"];

export default function ScheduleAuditDialog({ open, onClose, onCreated }) {
  const [step, setStep] = useState(0);
  const [search, setSearch] = useState("");
  const [sectionFilter, setSectionFilter] = useState("all");
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [form, setForm] = useState({
    title: "",
    scope: "",
    assigned_auditor: "",
    suggested_date: "",
    end_date: "",
    recurrence: "none",
    recurrence_end_date: "",
    priority: "medium",
  });

  const queryClient = useQueryClient();

  const { data: requirements = [] } = useQuery({
    queryKey: ["requirements-all"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-clause_number", 500),
    enabled: open,
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list("-created_date", 100),
    enabled: open,
  });

  const filtered = useMemo(() => {
    return requirements.filter(r => {
      const matchSection = sectionFilter === "all" || r.section === sectionFilter;
      const matchSearch = !search || r.clause_number?.includes(search) || r.clause_title?.toLowerCase().includes(search.toLowerCase());
      return matchSection && matchSearch;
    });
  }, [requirements, search, sectionFilter]);

  const selectedReqs = requirements.filter(r => selectedIds.has(r.id));

  const toggleReq = (id) => {
    const next = new Set(selectedIds);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelectedIds(next);
  };

  const toggleAll = () => {
    if (filtered.every(r => selectedIds.has(r.id))) {
      const next = new Set(selectedIds);
      filtered.forEach(r => next.delete(r.id));
      setSelectedIds(next);
    } else {
      const next = new Set(selectedIds);
      filtered.forEach(r => next.add(r.id));
      setSelectedIds(next);
    }
  };

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.AuditPlan.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["audit-plans"] });
      toast.success("Audit scheduled successfully");
      handleClose();
      if (onCreated) onCreated();
    },
  });

  const handleClose = () => {
    setStep(0);
    setSelectedIds(new Set());
    setSearch("");
    setSectionFilter("all");
    setForm({ title: "", scope: "", assigned_auditor: "", suggested_date: "", end_date: "", recurrence: "none", recurrence_end_date: "", priority: "medium" });
    onClose();
  };

  const handleSubmit = () => {
    const checklist = selectedReqs.map(r => ({
      requirement_id: r.id,
      clause_number: r.clause_number,
      clause_title: r.clause_title,
      section: r.section,
      item: `${r.clause_number} – ${r.clause_title}`,
      category: r.section,
      status: "not_checked",
      finding: "",
      notes: "",
      completed: false,
    }));

    createMutation.mutate({
      ...form,
      audit_type: "internal",
      status: "scheduled",
      related_requirements: Array.from(selectedIds),
      recommended_auditors: form.assigned_auditor ? [form.assigned_auditor] : [],
      checklist,
    });
  };

  const canProceed = step === 0
    ? selectedIds.size > 0
    : step === 1
    ? form.title && form.suggested_date && form.assigned_auditor
    : true;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-emerald-600" />
            Schedule Internal Audit
          </DialogTitle>
          {/* Step indicator */}
          <div className="flex items-center gap-2 pt-2">
            {STEPS.map((s, i) => (
              <React.Fragment key={i}>
                <div className={`flex items-center gap-1.5 text-xs font-medium ${i <= step ? "text-emerald-700" : "text-slate-400"}`}>
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${i < step ? "bg-emerald-600 text-white" : i === step ? "bg-emerald-100 text-emerald-700 ring-2 ring-emerald-400" : "bg-slate-100 text-slate-400"}`}>
                    {i < step ? <CheckCircle2 className="w-3 h-3" /> : i + 1}
                  </div>
                  <span className="hidden sm:inline">{s}</span>
                </div>
                {i < STEPS.length - 1 && <div className={`flex-1 h-px ${i < step ? "bg-emerald-300" : "bg-slate-200"}`} />}
              </React.Fragment>
            ))}
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4">
          {/* Step 0 – Select Requirements */}
          {step === 0 && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
                  <Input placeholder="Search clause…" className="pl-8 h-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
                </div>
                <Select value={sectionFilter} onValueChange={setSectionFilter}>
                  <SelectTrigger className="w-48 h-9 text-xs"><SelectValue placeholder="All sections" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All sections</SelectItem>
                    {SECTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between px-1">
                <span className="text-xs text-slate-500">{filtered.length} requirements • {selectedIds.size} selected</span>
                <button className="text-xs text-emerald-600 hover:underline" onClick={toggleAll}>
                  {filtered.every(r => selectedIds.has(r.id)) ? "Deselect all" : "Select all"}
                </button>
              </div>

              <div className="space-y-1 max-h-80 overflow-y-auto pr-1">
                {filtered.map(r => (
                  <div
                    key={r.id}
                    className={`flex items-start gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${selectedIds.has(r.id) ? "border-emerald-300 bg-emerald-50" : "border-transparent hover:bg-slate-50"}`}
                    onClick={() => toggleReq(r.id)}
                  >
                    <Checkbox checked={selectedIds.has(r.id)} onCheckedChange={() => toggleReq(r.id)} onClick={e => e.stopPropagation()} className="mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-mono font-bold text-slate-500">{r.clause_number}</span>
                        <span className="text-xs font-medium text-slate-800 truncate">{r.clause_title}</span>
                        <Badge className={`text-[10px] px-1.5 py-0 ${r.status === "compliant" ? "bg-emerald-100 text-emerald-700" : r.status === "non_compliant" ? "bg-rose-100 text-rose-700" : "bg-slate-100 text-slate-600"}`}>
                          {r.status?.replace("_", " ")}
                        </Badge>
                      </div>
                      <p className="text-[10px] text-slate-400 truncate mt-0.5">{r.section}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Step 1 – Audit Details */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <Label className="text-xs">Audit Title *</Label>
                <Input className="mt-1" placeholder="e.g. Q1 Internal ISO 22000 Audit" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs">Scope / Objectives</Label>
                <Textarea className="mt-1" rows={2} placeholder="What is the objective of this audit?" value={form.scope} onChange={e => setForm(f => ({ ...f, scope: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs">Assigned Auditor *</Label>
                  <Select value={form.assigned_auditor} onValueChange={v => setForm(f => ({ ...f, assigned_auditor: v }))}>
                    <SelectTrigger className="mt-1"><SelectValue placeholder="Select auditor…" /></SelectTrigger>
                    <SelectContent>
                      {users.map(u => <SelectItem key={u.id} value={u.email}>{u.full_name} ({u.email})</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Priority</Label>
                  <Select value={form.priority} onValueChange={v => setForm(f => ({ ...f, priority: v }))}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs">Audit Date *</Label>
                  <Input type="date" className="mt-1" value={form.suggested_date} onChange={e => setForm(f => ({ ...f, suggested_date: e.target.value }))} />
                </div>
                <div>
                  <Label className="text-xs">End Date</Label>
                  <Input type="date" className="mt-1" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs">Recurrence</Label>
                  <Select value={form.recurrence} onValueChange={v => setForm(f => ({ ...f, recurrence: v }))}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">One-time</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="biannual">Bi-annual</SelectItem>
                      <SelectItem value="annual">Annual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {form.recurrence !== "none" && (
                  <div>
                    <Label className="text-xs">Recurrence End Date</Label>
                    <Input type="date" className="mt-1" value={form.recurrence_end_date} onChange={e => setForm(f => ({ ...f, recurrence_end_date: e.target.value }))} />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 2 – Review */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="bg-slate-50 rounded-lg p-4 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-500">Title</span><span className="font-medium">{form.title}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Auditor</span><span className="font-medium">{form.assigned_auditor}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Date</span><span className="font-medium">{form.suggested_date}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Recurrence</span><span className="font-medium capitalize">{form.recurrence}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Priority</span><span className="font-medium capitalize">{form.priority}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Requirements</span><span className="font-medium">{selectedIds.size} selected</span></div>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                  <ClipboardList className="w-3.5 h-3.5" /> Generated Checklist Preview ({selectedReqs.length} items)
                </p>
                <div className="space-y-1 max-h-52 overflow-y-auto">
                  {selectedReqs.map(r => (
                    <div key={r.id} className="flex items-center gap-2 text-xs bg-white border border-slate-100 rounded px-3 py-2">
                      <span className="font-mono font-bold text-slate-400 w-10 shrink-0">{r.clause_number}</span>
                      <span className="text-slate-700">{r.clause_title}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex items-center justify-between gap-2 pt-2 border-t">
          <Button variant="outline" size="sm" onClick={step === 0 ? handleClose : () => setStep(s => s - 1)}>
            {step === 0 ? "Cancel" : <><ChevronLeft className="w-4 h-4 mr-1" />Back</>}
          </Button>
          <Button
            size="sm"
            className="bg-emerald-600 hover:bg-emerald-700"
            disabled={!canProceed || createMutation.isPending}
            onClick={step < 2 ? () => setStep(s => s + 1) : handleSubmit}
          >
            {step < 2 ? <><span>Next</span><ChevronRight className="w-4 h-4 ml-1" /></> : createMutation.isPending ? "Scheduling…" : "Schedule Audit"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}