import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle2, XCircle, Eye, Minus, Save, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";

const STATUS_CONFIG = {
  not_checked: { label: "Not Checked", color: "bg-slate-100 text-slate-500", icon: Minus },
  compliant:    { label: "Compliant",   color: "bg-emerald-100 text-emerald-700", icon: CheckCircle2 },
  non_compliant:{ label: "Non-Compliant",color: "bg-rose-100 text-rose-700",    icon: XCircle },
  observation:  { label: "Observation", color: "bg-amber-100 text-amber-700",   icon: Eye },
};

export default function AuditChecklistPanel({ audit, onSaved }) {
  const [items, setItems] = useState(audit.checklist || []);
  const [expanded, setExpanded] = useState(new Set());
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  const toggleExpand = (idx) => {
    const next = new Set(expanded);
    next.has(idx) ? next.delete(idx) : next.add(idx);
    setExpanded(next);
  };

  const updateItem = (idx, field, value) => {
    setItems(prev => prev.map((item, i) => i === idx ? { ...item, [field]: value, completed: field === "status" ? value !== "not_checked" : item.completed } : item));
  };

  const handleSave = async () => {
    setSaving(true);
    const allDone = items.every(i => i.status !== "not_checked");
    await base44.entities.AuditPlan.update(audit.id, {
      checklist: items,
      status: allDone ? "completed" : "in_progress",
    });
    queryClient.invalidateQueries({ queryKey: ["audit-plans"] });
    toast.success("Checklist saved");
    setSaving(false);
    if (onSaved) onSaved();
  };

  const progress = items.length ? Math.round((items.filter(i => i.status !== "not_checked").length / items.length) * 100) : 0;

  const counts = items.reduce((acc, i) => {
    acc[i.status] = (acc[i.status] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-4">
      {/* Progress bar */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-slate-700">Checklist Progress</span>
            <span className="text-sm font-bold text-slate-900">{progress}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 mb-3">
            <div className="bg-emerald-500 h-2 rounded-full transition-all" style={{ width: `${progress}%` }} />
          </div>
          <div className="flex gap-3 flex-wrap text-xs">
            {Object.entries(STATUS_CONFIG).map(([key, cfg]) => (
              <span key={key} className={`px-2 py-0.5 rounded-full ${cfg.color}`}>
                {counts[key] || 0} {cfg.label}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Checklist items */}
      <div className="space-y-2">
        {items.map((item, idx) => {
          const cfg = STATUS_CONFIG[item.status] || STATUS_CONFIG.not_checked;
          const Icon = cfg.icon;
          const isOpen = expanded.has(idx);

          return (
            <Card key={idx} className={`border shadow-sm transition-colors ${item.status === "non_compliant" ? "border-rose-200" : item.status === "compliant" ? "border-emerald-100" : "border-slate-100"}`}>
              <div className="flex items-center gap-3 p-3 cursor-pointer" onClick={() => toggleExpand(idx)}>
                <Icon className={`w-4 h-4 flex-shrink-0 ${item.status === "compliant" ? "text-emerald-600" : item.status === "non_compliant" ? "text-rose-600" : item.status === "observation" ? "text-amber-500" : "text-slate-400"}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-mono font-bold text-slate-400">{item.clause_number}</span>
                    <span className="text-xs font-medium text-slate-800 truncate">{item.clause_title}</span>
                  </div>
                  {item.finding && <p className="text-[10px] text-slate-500 truncate mt-0.5">{item.finding}</p>}
                </div>
                <Badge className={`text-[10px] px-2 py-0.5 ${cfg.color} shrink-0`}>{cfg.label}</Badge>
                {isOpen ? <ChevronUp className="w-3.5 h-3.5 text-slate-400 shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />}
              </div>

              {isOpen && (
                <CardContent className="pt-0 pb-3 px-3 space-y-3 border-t border-slate-100">
                  <div>
                    <label className="text-xs text-slate-500 block mb-1">Status</label>
                    <Select value={item.status} onValueChange={v => updateItem(idx, "status", v)}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Object.entries(STATUS_CONFIG).map(([k, c]) => (
                          <SelectItem key={k} value={k}><span className={`px-1.5 py-0.5 rounded text-xs ${c.color}`}>{c.label}</span></SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 block mb-1">Finding / Observation</label>
                    <Textarea
                      rows={2}
                      className="text-xs"
                      placeholder="Describe what was found…"
                      value={item.finding || ""}
                      onChange={e => updateItem(idx, "finding", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 block mb-1">Notes</label>
                    <Textarea
                      rows={2}
                      className="text-xs"
                      placeholder="Additional notes…"
                      value={item.notes || ""}
                      onChange={e => updateItem(idx, "notes", e.target.value)}
                    />
                  </div>
                </CardContent>
              )}
            </Card>
          );
        })}
      </div>

      <Button onClick={handleSave} disabled={saving} className="w-full bg-emerald-600 hover:bg-emerald-700 min-h-[44px]">
        <Save className="w-4 h-4 mr-2" />
        {saving ? "Saving…" : "Save Checklist"}
      </Button>
    </div>
  );
}