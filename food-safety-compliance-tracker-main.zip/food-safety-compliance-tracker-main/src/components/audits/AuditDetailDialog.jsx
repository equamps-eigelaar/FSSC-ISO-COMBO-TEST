import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp, 
  FileText,
  Download
} from "lucide-react";
import { format } from "date-fns";

export default function AuditDetailDialog({ open, onClose, audit }) {
  if (!audit) return null;

  const getSeverityColor = (severity) => {
    const colors = {
      critical: "bg-rose-50 text-rose-700 border-rose-200",
      high: "bg-orange-50 text-orange-700 border-orange-200",
      medium: "bg-amber-50 text-amber-700 border-amber-200",
      low: "bg-blue-50 text-blue-700 border-blue-200"
    };
    return colors[severity?.toLowerCase()] || "bg-slate-50 text-slate-700 border-slate-200";
  };

  const handleDownload = () => {
    const content = `
AI COMPLIANCE AUDIT REPORT
Generated: ${format(new Date(audit.audit_date), "MMMM d, yyyy 'at' h:mm a")}
Overall Score: ${audit.overall_score}/100

===========================================
EXECUTIVE SUMMARY
===========================================
${audit.summary}

===========================================
KEY METRICS
===========================================
Total Requirements: ${audit.metrics?.total_requirements || 0}
Compliant: ${audit.metrics?.compliant || 0}
Non-Compliant: ${audit.metrics?.non_compliant || 0}
In Progress: ${audit.metrics?.in_progress || 0}
Missing Evidence: ${audit.metrics?.missing_evidence || 0}
Overdue: ${audit.metrics?.overdue || 0}

RISK SUMMARY:
- Critical: ${audit.risk_summary?.critical || 0}
- High: ${audit.risk_summary?.high || 0}
- Medium: ${audit.risk_summary?.medium || 0}
- Low: ${audit.risk_summary?.low || 0}

===========================================
FINDINGS (${audit.findings?.length || 0})
===========================================
${audit.findings?.map((f, i) => `
${i + 1}. ${f.clause_number || 'N/A'}: ${f.issue_type}
   Severity: ${f.severity}
   Description: ${f.description}
   Recommendation: ${f.recommendation}
`).join('\n') || 'No findings'}

===========================================
DISCREPANCIES (${audit.discrepancies?.length || 0})
===========================================
${audit.discrepancies?.map((d, i) => `
${i + 1}. ${d.type}
   Description: ${d.description}
   Impact: ${d.impact}
`).join('\n') || 'No discrepancies'}

===========================================
RECOMMENDATIONS
===========================================
${audit.recommendations?.map((r, i) => `${i + 1}. ${r}`).join('\n') || 'No recommendations'}
`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-report-${format(new Date(audit.audit_date), "yyyy-MM-dd")}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-purple-600" />
            Audit Report - {format(new Date(audit.audit_date), "MMM d, yyyy")}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Score & Metrics */}
          <div className="grid grid-cols-3 gap-3">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4 text-center">
                <TrendingUp className="w-5 h-5 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-purple-700">{audit.overall_score}</div>
                <div className="text-xs text-slate-500">Overall Score</div>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4 text-center">
                <CheckCircle className="w-5 h-5 text-emerald-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-emerald-700">{audit.metrics?.compliant || 0}</div>
                <div className="text-xs text-slate-500">Compliant</div>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4 text-center">
                <AlertTriangle className="w-5 h-5 text-rose-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-rose-700">{audit.findings?.length || 0}</div>
                <div className="text-xs text-slate-500">Findings</div>
              </CardContent>
            </Card>
          </div>

          {/* Summary */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Executive Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-600">{audit.summary}</p>
            </CardContent>
          </Card>

          {/* Findings */}
          {audit.findings?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-orange-600" />
                  Audit Findings ({audit.findings.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {audit.findings.map((finding, idx) => (
                    <Card key={idx} className="border-l-4 border-l-orange-500">
                      <CardContent className="p-3">
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              {finding.clause_number && (
                                <Badge variant="outline" className="text-xs">
                                  {finding.clause_number}
                                </Badge>
                              )}
                              <span className="text-xs font-medium text-slate-900">
                                {finding.issue_type}
                              </span>
                            </div>
                            <p className="text-xs text-slate-600">{finding.description}</p>
                          </div>
                          <Badge className={getSeverityColor(finding.severity)} variant="outline">
                            {finding.severity}
                          </Badge>
                        </div>
                        <div className="text-xs text-slate-600 bg-slate-50 p-2 rounded">
                          <span className="font-medium">Recommendation: </span>
                          {finding.recommendation}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Discrepancies */}
          {audit.discrepancies?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Identified Discrepancies ({audit.discrepancies.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {audit.discrepancies.map((disc, idx) => (
                    <div key={idx} className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                      <div className="text-xs font-medium text-amber-900 mb-1">{disc.type}</div>
                      <p className="text-xs text-amber-800">{disc.description}</p>
                      <p className="text-xs text-amber-700 mt-1">
                        <span className="font-medium">Impact:</span> {disc.impact}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommendations */}
          {audit.recommendations?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Key Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {audit.recommendations.map((rec, idx) => (
                    <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                      {rec}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          <div className="flex gap-3">
            <Button variant="outline" onClick={handleDownload} className="flex-1">
              <Download className="w-4 h-4 mr-2" />
              Download Report
            </Button>
            <Button onClick={onClose} className="flex-1">Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}