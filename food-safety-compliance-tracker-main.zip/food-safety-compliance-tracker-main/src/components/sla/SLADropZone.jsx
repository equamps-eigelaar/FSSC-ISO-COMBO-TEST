import React, { useRef, useState } from "react";
import { Upload, FileText, CheckCircle2, Loader2, X } from "lucide-react";

const ACCEPTED = [".pdf", ".docx", ".doc", ".xlsx", ".xls"];

export default function SLADropZone({ onFileSelected, uploading, file }) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) onFileSelected(dropped);
  };

  const handleChange = (e) => {
    const selected = e.target.files[0];
    if (selected) onFileSelected(selected);
  };

  if (file && !uploading) {
    return (
      <div className="flex items-center gap-3 p-4 bg-emerald-50 border border-emerald-200 rounded-xl">
        <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-emerald-800 truncate">{file.name}</p>
          <p className="text-xs text-emerald-600">{(file.size / 1024).toFixed(1)} KB · Uploaded successfully</p>
        </div>
        <button onClick={() => onFileSelected(null)} className="text-slate-400 hover:text-slate-600 p-1">
          <X className="w-4 h-4" />
        </button>
      </div>
    );
  }

  if (uploading) {
    return (
      <div className="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-xl">
        <Loader2 className="w-5 h-5 text-blue-600 animate-spin flex-shrink-0" />
        <div>
          <p className="text-sm font-medium text-blue-800">Uploading {file?.name}...</p>
          <p className="text-xs text-blue-600">Please wait</p>
        </div>
      </div>
    );
  }

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      className={`border-2 border-dashed rounded-xl p-10 flex flex-col items-center justify-center cursor-pointer transition-all
        ${dragging ? "border-blue-500 bg-blue-50" : "border-slate-300 bg-slate-50 hover:border-blue-400 hover:bg-blue-50/50"}`}
    >
      <input ref={inputRef} type="file" className="hidden" accept={ACCEPTED.join(",")} onChange={handleChange} />
      <div className="w-12 h-12 rounded-2xl bg-blue-100 flex items-center justify-center mb-4">
        <Upload className="w-6 h-6 text-blue-600" />
      </div>
      <p className="text-sm font-semibold text-slate-700 mb-1">Drop your customer document here</p>
      <p className="text-xs text-slate-500 mb-3">or click to browse</p>
      <div className="flex gap-2 flex-wrap justify-center">
        {[".pdf", ".docx", ".doc", ".xlsx", ".xls"].map(ext => (
          <span key={ext} className="text-[10px] px-2 py-0.5 bg-white border border-slate-200 rounded text-slate-500 font-mono">{ext}</span>
        ))}
      </div>
      <p className="text-[11px] text-slate-400 mt-3 text-center max-w-xs">
        Supports customer SLAs, supplier questionnaires, quality agreements, and audit checklists
      </p>
    </div>
  );
}