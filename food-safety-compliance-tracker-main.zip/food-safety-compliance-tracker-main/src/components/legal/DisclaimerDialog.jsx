import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Lock, Globe } from "lucide-react";

const DISCLAIMER_KEY = "compliance_disclaimer_v3_accepted";

export default function DisclaimerDialog() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [isAccepted, setIsAccepted] = useState(false);
  const [popiaAccepted, setPopiaAccepted] = useState(false);

  useEffect(() => {
    const hasAccepted = localStorage.getItem(DISCLAIMER_KEY) === "true";
    if (!hasAccepted) {
      setIsOpen(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(DISCLAIMER_KEY, "true");
    setIsOpen(false);
    navigate(createPageUrl("Dashboard"));
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="max-w-2xl flex flex-col" style={{maxHeight: 'min(90vh, 600px)'}} onPointerDownOutside={(e) => e.preventDefault()}>
         <DialogHeader className="shrink-0">
           <DialogTitle className="flex items-center gap-2 text-rose-600">
             <AlertTriangle className="w-5 h-5" />
             Legal Disclaimer & Confidentiality Agreement
           </DialogTitle>
         </DialogHeader>

         <div className="space-y-4 overflow-y-auto min-h-0 flex-1">
          <Alert className="border-rose-200 bg-rose-50">
            <AlertTriangle className="h-4 w-4 text-rose-600" />
            <AlertDescription className="text-rose-900 ml-2">
              Please read and accept the terms below before using this application.
            </AlertDescription>
          </Alert>

          <div className="space-y-4 text-sm text-slate-600">

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <h3 className="font-semibold text-amber-900 mb-1 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5" /> Confidentiality & Non-Disclosure
              </h3>
              <p className="text-amber-800 text-xs leading-relaxed">
                By using this platform you agree to treat all information accessible herein — including HACCP plans, 
                risk assessments, compliance records, supplier data, and any platform IP — as strictly confidential. 
                You may not disclose, copy, or distribute any such information to unauthorised parties. Breach of 
                this obligation may result in suspension of access and legal action. Your acceptance below constitutes 
                a binding electronic NDA under the <em>Electronic Communications and Transactions Act (ECTA)</em>.{" "}
                <a href={createPageUrl("ConfidentialityAgreement")} target="_blank" rel="noopener noreferrer"
                  className="underline text-amber-900 font-medium">Read full NDA →</a>
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
              <h3 className="font-semibold text-slate-800 mb-1 text-xs uppercase tracking-wide">Currency & Billing</h3>
              <p className="text-slate-700 text-xs leading-relaxed">
                All services are invoiced in <strong>ZAR or USD</strong> at the prevailing exchange rate on the invoice date. 
                Exchange rate fluctuations are for the account of the client.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-slate-900 mb-2">User Responsibility</h3>
              <p>
                It is the user's responsibility to adhere to all requirements outlined in the compliance clauses and standards referenced in this application. This application is provided as a management tool to assist with compliance tracking and documentation, but does not guarantee compliance with applicable regulations or standards.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Third-Party Audits</h3>
              <p>
                We strongly recommend that both this application and your organization's current compliance level be thoroughly reviewed and validated by an independent third-party auditor before, during, and after any external audit by regulatory bodies or certification auditors. No digital tool can substitute for professional audit verification.
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <h3 className="font-semibold text-blue-900 mb-1 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5" /> POPIA Section 72 — International Data Transfer Consent
              </h3>
              <p className="text-blue-800 text-xs leading-relaxed">
                Your data is stored on servers located in the <strong>United States of America</strong>. 
                The USA does not provide data protection equivalent to South Africa's POPIA. 
                By accepting below, you grant <strong>explicit informed consent</strong> under POPIA Section 72(1)(a) 
                for your personal information to be transferred to and stored in the USA. 
                You may withdraw consent by contacting your system administrator, however this will prevent 
                access to the platform.{" "}
                <a href={createPageUrl("PrivacyPolicy")} target="_blank" rel="noopener noreferrer"
                  className="underline text-blue-900 font-medium">Read full Privacy Policy →</a>
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Limitation of Liability</h3>
              <p>
                While this application strives to provide accurate compliance information, it is provided "as is" without warranties of any kind. Users acknowledge that compliance with regulations is their sole responsibility, and this application should be used in conjunction with professional compliance guidance.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3 py-3 border-t border-slate-200 shrink-0">
          <div className="flex items-start gap-3">
            <Checkbox
              id="accept-disclaimer"
              checked={isAccepted}
              onCheckedChange={setIsAccepted}
              className="mt-1"
            />
            <label
              htmlFor="accept-disclaimer"
              className="text-sm text-slate-600 cursor-pointer flex-1 leading-relaxed"
            >
              I have read and agree to the <strong>Legal Disclaimer</strong>, <strong>Confidentiality & NDA</strong>, and <strong>Privacy Policy</strong>. I accept responsibility for compliance with all applicable requirements and will keep all platform data and IP strictly confidential.
            </label>
          </div>
          <div className="flex items-start gap-3">
            <Checkbox
              id="accept-popia"
              checked={popiaAccepted}
              onCheckedChange={setPopiaAccepted}
              className="mt-1"
            />
            <label
              htmlFor="accept-popia"
              className="text-sm text-blue-700 cursor-pointer flex-1 leading-relaxed"
            >
              <strong>POPIA Section 72 Consent:</strong> I explicitly consent to my personal information being transferred to and stored in the <strong>United States of America</strong> as described above, in accordance with Section 72(1)(a) of the Protection of Personal Information Act.
            </label>
          </div>
        </div>

        <DialogFooter className="shrink-0">
          <Button
            onClick={handleAccept}
            disabled={!isAccepted || !popiaAccepted}
            className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Agree & Continue
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}