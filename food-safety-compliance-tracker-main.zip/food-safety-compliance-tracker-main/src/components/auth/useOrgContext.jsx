/**
 * useOrgContext – Multi-tenant organization context hook
 *
 * Returns the current user's organization_id and a `withOrg` helper
 * that automatically injects organization_id into entity create/update payloads.
 *
 * Usage:
 *   const { organization_id, withOrg } = useOrgContext();
 *   await base44.entities.SomeEntity.create(withOrg({ name: 'foo', ... }));
 */

import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

let _cache = null;

export function useOrgContext() {
  const [ctx, setCtx] = useState(_cache);
  const [loading, setLoading] = useState(!_cache);

  useEffect(() => {
    if (_cache) return;
    base44.auth.me()
      .then(user => {
        const orgCtx = {
          organization_id: user?.organization_id || null,
          organization_name: user?.organization_name || null,
          user_email: user?.email || null,
          user_role: user?.role || null,
        };
        _cache = orgCtx;
        setCtx(orgCtx);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  /**
   * Inject organization_id into a data object before saving.
   * If the user has no organization_id set, data is returned unchanged.
   */
  const withOrg = (data) => {
    if (!ctx?.organization_id) return data;
    return { ...data, organization_id: ctx.organization_id };
  };

  /**
   * Build a filter object scoped to the current org.
   * Usage: base44.entities.Foo.filter(orgFilter({ status: 'active' }))
   */
  const orgFilter = (extraFilters = {}) => {
    if (!ctx?.organization_id) return extraFilters;
    return { ...extraFilters, organization_id: ctx.organization_id };
  };

  return {
    organization_id: ctx?.organization_id || null,
    organization_name: ctx?.organization_name || null,
    user_email: ctx?.user_email || null,
    user_role: ctx?.user_role || null,
    loading,
    withOrg,
    orgFilter,
  };
}

/**
 * Reset the org context cache (call after updating user's organization).
 */
export function resetOrgContextCache() {
  _cache = null;
}