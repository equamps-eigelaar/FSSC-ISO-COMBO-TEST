import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Clock, CreditCard, XCircle, Loader2, RefreshCw, Timer } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

// Statuses that mean the user is fully allowed in
const ALLOWED_STATUSES = ["approved", "trial_active", "active", "trial_expired"];

// Pages that should always be accessible regardless of approval status
const PUBLIC_PAGES = ["PrivacyPolicy", "ConfidentialityAgreement", "TermsAndConditions", "RequestAccess", "Requirements", "RequirementDetail"];

export default function AccessGate({ children, bypass = false, currentPageName }) {
  const [status, setStatus] = useState(null); // null = loading
  const [approvalData, setApprovalData] = useState(null);
  const [checking, setChecking] = useState(false);

  const check = async () => {
    setChecking(true);
    try {
      // Owner/admin: bypass immediately without backend call
      const user = await base44.auth.me();
      if (user?.role === 'admin') {
        setApprovalData({ is_admin: true });
        setStatus('approved');
        setChecking(false);
        return;
      }
      const res = await base44.functions.invoke("checkUserApproval", {});
      setApprovalData(res.data);
      setStatus(res.data?.status || "none");
    } catch {
      setStatus("error");
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    if (!bypass) check();
  }, [bypass]);

  // Bypass for public pages or explicitly public page names
  if (bypass || PUBLIC_PAGES.includes(currentPageName)) return children;

  // Loading
  if (status === null) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex items-center gap-3 text-slate-400">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm">Verifying access...</span>
        </div>
      </div>
    );
  }

  // Allowed through
  if (ALLOWED_STATUSES.includes(status) || approvalData?.is_admin) {
    return children;
  }

  // Blocked — show appropriate holding screen
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-lg p-8 text-center space-y-4">
        <div className="w-14 h-14 rounded-full mx-auto flex items-center justify-center bg-slate-100">
          {status === "pending" && <Clock className="w-7 h-7 text-amber-500" />}
          {status === "payment_pending" && <CreditCard className="w-7 h-7 text-blue-500" />}
          {status === "rejected" && <XCircle className="w-7 h-7 text-rose-500" />}
          {status === "trial_expired" && <Timer className="w-7 h-7 text-orange-500" />}
          {(status === "none" || status === "error") && <ShieldCheck className="w-7 h-7 text-slate-400" />}
        </div>

        {status === "pending" && (
          <>
            <h2 className="text-xl font-bold text-slate-900">Request Pending Review</h2>
            <p className="text-sm text-slate-500">
              Your access request has been submitted and is awaiting admin approval. 
              You'll receive an email once it's reviewed.
            </p>
            <Button variant="outline" size="sm" onClick={check} disabled={checking} className="gap-2">
              <RefreshCw className={`w-3.5 h-3.5 ${checking ? "animate-spin" : ""}`} />
              Check again
            </Button>
          </>
        )}

        {status === "payment_pending" && (
          <>
            <h2 className="text-xl font-bold text-slate-900">Invoice Sent</h2>
            <p className="text-sm text-slate-500">
              Your access has been approved pending payment. An invoice
              {approvalData?.xero_invoice_number ? ` (${approvalData.xero_invoice_number})` : ""} has been sent to your email.
              Your account will be activated once payment is confirmed.
            </p>
            {approvalData?.xero_invoice_url && (
              <a
                href={approvalData.xero_invoice_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700 transition-colors"
              >
                <CreditCard className="w-4 h-4" />
                Pay Invoice Online
              </a>
            )}
            <div>
              <Button variant="outline" size="sm" onClick={check} disabled={checking} className="gap-2">
                <RefreshCw className={`w-3.5 h-3.5 ${checking ? "animate-spin" : ""}`} />
                I've paid — check status
              </Button>
            </div>
          </>
        )}

        {status === "rejected" && (
          <>
            <h2 className="text-xl font-bold text-slate-900">Access Declined</h2>
            <p className="text-sm text-slate-500">
              Unfortunately your access request was not approved.
              {approvalData?.rejection_reason ? ` Reason: ${approvalData.rejection_reason}` : ""}
            </p>
            <p className="text-xs text-slate-400">Contact your system administrator if you believe this is an error.</p>
          </>
        )}

        {(status === "none" || status === "error") && (
          <>
            <h2 className="text-xl font-bold text-slate-900">Access Required</h2>
            <p className="text-sm text-slate-500">
              You need access to use this platform. Please contact your administrator to request access.
            </p>
            <Button variant="outline" size="sm" onClick={check} disabled={checking} className="gap-2">
              <RefreshCw className={`w-3.5 h-3.5 ${checking ? "animate-spin" : ""}`} />
              Check again
            </Button>
          </>
        )}

        <p className="text-xs text-slate-300 pt-2">FSMS Compliance Tracker — Eigelaar Enterprises</p>
      </div>
    </div>
  );
}