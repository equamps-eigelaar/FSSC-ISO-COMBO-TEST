import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useOfflineSync } from './OfflineSyncManager';
import { toast } from 'sonner';

export function useOfflineMutation(entityType, operation, queryKey) {
  const queryClient = useQueryClient();
  const { isOnline, saveOfflineChange } = useOfflineSync();

  return useMutation({
    mutationFn: async ({ entityId, data }) => {
      if (isOnline) {
        // Online: Execute immediately
        if (operation === 'create') {
          return base44.entities[entityType].create(data);
        } else if (operation === 'update') {
          return base44.entities[entityType].update(entityId, data);
        } else if (operation === 'delete') {
          return base44.entities[entityType].delete(entityId);
        }
      } else {
        // Offline: Save for later sync
        await saveOfflineChange(entityType, operation, data, entityId);
        toast.info('Change saved. Will sync when online.');
        
        // Optimistically update the UI
        return { id: entityId || `temp_${Date.now()}`, ...data };
      }
    },
    onMutate: async ({ entityId, data }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey });

      // Snapshot previous value
      const previousData = queryClient.getQueryData(queryKey);

      // Optimistically update
      queryClient.setQueryData(queryKey, (old) => {
        if (!old) return operation === 'create' ? [{ ...data, id: entityId || `temp_${Date.now()}` }] : [];
        
        if (operation === 'create') {
          return [...old, { ...data, id: entityId || `temp_${Date.now()}`, created_date: new Date().toISOString() }];
        } else if (operation === 'update') {
          return old.map((item) => (item.id === entityId ? { ...item, ...data, updated_date: new Date().toISOString() } : item));
        } else if (operation === 'delete') {
          return old.filter((item) => item.id !== entityId);
        }
        return old;
      });

      return { previousData };
    },
    onError: (err, variables, context) => {
      // Rollback on error
      if (context?.previousData) {
        queryClient.setQueryData(queryKey, context.previousData);
      }
      toast.error('Failed to save changes');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
    }
  });
}