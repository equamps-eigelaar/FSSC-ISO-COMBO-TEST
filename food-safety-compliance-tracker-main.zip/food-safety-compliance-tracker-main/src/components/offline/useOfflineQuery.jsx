import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useOfflineSync } from './OfflineSyncManager';

export function useOfflineQuery(queryKey, entityType, queryFn, options = {}) {
  const { isOnline, getOfflineData } = useOfflineSync();

  return useQuery({
    queryKey,
    queryFn: async () => {
      if (isOnline) {
        try {
          return await queryFn();
        } catch (error) {
          // If online query fails, fallback to offline data
          console.warn('Online query failed, using offline data:', error);
          return getOfflineData(entityType);
        }
      } else {
        // Use offline data when offline
        return getOfflineData(entityType);
      }
    },
    ...options,
    staleTime: isOnline ? (options.staleTime || 0) : Infinity,
  });
}