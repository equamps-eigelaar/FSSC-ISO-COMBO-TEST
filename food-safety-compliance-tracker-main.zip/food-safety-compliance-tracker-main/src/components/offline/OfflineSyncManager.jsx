import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const DB_NAME = 'compliance_offline_db';
const DB_VERSION = 1;

class OfflineStorage {
  constructor() {
    this.db = null;
    this.initDB();
  }

  async initDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        if (!db.objectStoreNames.contains('requirements')) {
          db.createObjectStore('requirements', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('risks')) {
          db.createObjectStore('risks', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('actions')) {
          db.createObjectStore('actions', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('pendingChanges')) {
          const store = db.createObjectStore('pendingChanges', { keyPath: 'id', autoIncrement: true });
          store.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
    });
  }

  async saveData(storeName, data) {
    await this.initDB();
    const tx = this.db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    
    for (const item of data) {
      await store.put(item);
    }
    
    return tx.complete;
  }

  async getData(storeName) {
    await this.initDB();
    const tx = this.db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    return store.getAll();
  }

  async savePendingChange(change) {
    await this.initDB();
    const tx = this.db.transaction('pendingChanges', 'readwrite');
    const store = tx.objectStore('pendingChanges');
    await store.add({
      ...change,
      timestamp: Date.now()
    });
  }

  async getPendingChanges() {
    await this.initDB();
    const tx = this.db.transaction('pendingChanges', 'readonly');
    const store = tx.objectStore('pendingChanges');
    return store.getAll();
  }

  async clearPendingChange(id) {
    await this.initDB();
    const tx = this.db.transaction('pendingChanges', 'readwrite');
    const store = tx.objectStore('pendingChanges');
    await store.delete(id);
  }
}

const offlineStorage = new OfflineStorage();

export function useOfflineSync() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      syncPendingChanges();
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      toast.info('You are offline. Changes will sync when reconnected.');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Load pending changes count
    loadPendingCount();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const loadPendingCount = async () => {
    const changes = await offlineStorage.getPendingChanges();
    setPendingCount(changes.length);
  };

  const cacheDataForOffline = async () => {
    try {
      const [requirements, risks, actions] = await Promise.all([
        base44.entities.ComplianceRequirement.list("-updated_date", 500),
        base44.entities.RiskAssessment.list("-updated_date", 500),
        base44.entities.ActionItem.list("-updated_date", 200)
      ]);

      await Promise.all([
        offlineStorage.saveData('requirements', requirements),
        offlineStorage.saveData('risks', risks),
        offlineStorage.saveData('actions', actions)
      ]);

      toast.success('Data cached for offline use');
    } catch (error) {
      console.error('Failed to cache data:', error);
      toast.error('Failed to cache data for offline use');
    }
  };

  const syncPendingChanges = async () => {
    if (!navigator.onLine) return;
    
    setIsSyncing(true);
    const pendingChanges = await offlineStorage.getPendingChanges();
    
    if (!pendingChanges || !Array.isArray(pendingChanges) || pendingChanges.length === 0) {
      setIsSyncing(false);
      return;
    }

    let syncedCount = 0;
    let failedCount = 0;

    for (const change of pendingChanges) {
      try {
        const { entityType, entityId, operation, data } = change;

        if (operation === 'update') {
          await base44.entities[entityType].update(entityId, data);
        } else if (operation === 'create') {
          await base44.entities[entityType].create(data);
        } else if (operation === 'delete') {
          await base44.entities[entityType].delete(entityId);
        }

        await offlineStorage.clearPendingChange(change.id);
        syncedCount++;
      } catch (error) {
        console.error('Failed to sync change:', error);
        failedCount++;
      }
    }

    await loadPendingCount();
    setIsSyncing(false);

    if (syncedCount > 0) {
      toast.success(`Synced ${syncedCount} changes`);
    }
    if (failedCount > 0) {
      toast.error(`Failed to sync ${failedCount} changes`);
    }
  };

  const saveOfflineChange = async (entityType, operation, data, entityId = null) => {
    await offlineStorage.savePendingChange({
      entityType,
      operation,
      data,
      entityId
    });
    await loadPendingCount();
  };

  const getOfflineData = async (entityType) => {
    const storeMap = {
      'ComplianceRequirement': 'requirements',
      'RiskAssessment': 'risks',
      'ActionItem': 'actions'
    };
    const storeName = storeMap[entityType];
    if (!storeName) return [];
    return offlineStorage.getData(storeName);
  };

  return {
    isOnline,
    isSyncing,
    pendingCount,
    cacheDataForOffline,
    syncPendingChanges,
    saveOfflineChange,
    getOfflineData
  };
}

export { offlineStorage };