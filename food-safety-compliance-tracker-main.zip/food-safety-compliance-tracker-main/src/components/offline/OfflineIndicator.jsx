import React from 'react';
import { WifiOff, Wifi, RefreshCw, Download, Cloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useOfflineSync } from './OfflineSyncManager';
import { toast } from 'sonner';

export default function OfflineIndicator() {
  const { isOnline, isSyncing, pendingCount, cacheDataForOffline, syncPendingChanges } = useOfflineSync();

  const handleCacheData = async () => {
    await cacheDataForOffline();
  };

  const handleSync = async () => {
    if (!isOnline) {
      toast.error('You are offline. Please connect to sync.');
      return;
    }
    await syncPendingChanges();
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2">
      {!isOnline && (
        <Badge variant="outline" className="bg-amber-50 text-amber-800 border-amber-300 px-3 py-2">
          <WifiOff className="w-4 h-4 mr-2" />
          Offline Mode
        </Badge>
      )}

      {pendingCount > 0 && (
        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-300 px-3 py-2">
          <Cloud className="w-4 h-4 mr-2" />
          {pendingCount} pending change{pendingCount !== 1 ? 's' : ''}
        </Badge>
      )}

      {isSyncing && (
        <Badge variant="outline" className="bg-emerald-50 text-emerald-800 border-emerald-300 px-3 py-2">
          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
          Syncing...
        </Badge>
      )}

      {isOnline && pendingCount > 0 && (
        <Button
          size="sm"
          onClick={handleSync}
          className="shadow-lg bg-emerald-600 hover:bg-emerald-700"
          disabled={isSyncing}
        >
          <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
        </Button>
      )}
    </div>
  );
}