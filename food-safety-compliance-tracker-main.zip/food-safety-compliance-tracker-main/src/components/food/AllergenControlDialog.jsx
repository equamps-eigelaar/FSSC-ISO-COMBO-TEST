import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { X, Plus } from "lucide-react";

const ALLERGEN_TYPES = [
  "peanuts", "tree_nuts", "milk", "eggs", "fish", "shellfish",
  "soy", "wheat", "sesame", "celery", "mustard", "lupin", "molluscs", "sulphites"
];

const SEGREGATION_METHODS = [
  "physical_barrier", "time_separation", "dedicated_equipment", "dedicated_line", "cleaning_protocol"
];

export default function AllergenControlDialog({ open, onClose, allergen }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState(allergen || {
    allergen_type: "peanuts",
    product_line: "",
    segregation_method: "physical_barrier",
    control_measures: [],
    status: "controlled",
    risk_level: "medium",
    cleaning_procedure: "",
    verification_method: "",
    notes: ""
  });
  const [newMeasure, setNewMeasure] = useState("");

  const mutation = useMutation({
    mutationFn: (data) => allergen 
      ? base44.entities.AllergenControl.update(allergen.id, data)
      : base44.entities.AllergenControl.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allergen-controls"] });
      toast.success(allergen ? "Allergen control updated" : "Allergen control created");
      onClose();
    },
    onError: () => toast.error("Failed to save allergen control")
  });

  const deleteMutation = useMutation({
    mutationFn: () => base44.entities.AllergenControl.delete(allergen.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["allergen-controls"] });
      toast.success("Allergen control deleted");
      onClose();
    },
    onError: () => toast.error("Failed to delete")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate(formData);
  };

  const addMeasure = () => {
    if (newMeasure.trim()) {
      setFormData({
        ...formData,
        control_measures: [...(formData.control_measures || []), newMeasure]
      });
      setNewMeasure("");
    }
  };

  const removeMeasure = (index) => {
    setFormData({
      ...formData,
      control_measures: formData.control_measures.filter((_, i) => i !== index)
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{allergen ? "Edit Allergen Control" : "Add Allergen Control"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Allergen Type</Label>
              <Select value={formData.allergen_type} onValueChange={(v) => setFormData({...formData, allergen_type: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ALLERGEN_TYPES.map(type => (
                    <SelectItem key={type} value={type} className="capitalize">
                      {type.replace(/_/g, " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Product Line</Label>
              <Input
                value={formData.product_line}
                onChange={(e) => setFormData({...formData, product_line: e.target.value})}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Segregation Method</Label>
              <Select value={formData.segregation_method} onValueChange={(v) => setFormData({...formData, segregation_method: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SEGREGATION_METHODS.map(method => (
                    <SelectItem key={method} value={method} className="capitalize">
                      {method.replace(/_/g, " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(v) => setFormData({...formData, status: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="controlled">Controlled</SelectItem>
                  <SelectItem value="under_review">Under Review</SelectItem>
                  <SelectItem value="action_required">Action Required</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Risk Level</Label>
              <Select value={formData.risk_level} onValueChange={(v) => setFormData({...formData, risk_level: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Verification Method</Label>
              <Input
                value={formData.verification_method}
                onChange={(e) => setFormData({...formData, verification_method: e.target.value})}
              />
            </div>
          </div>

          <div>
            <Label>Control Measures</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newMeasure}
                onChange={(e) => setNewMeasure(e.target.value)}
                placeholder="Add control measure"
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addMeasure())}
              />
              <Button type="button" onClick={addMeasure} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {formData.control_measures?.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.control_measures.map((measure, idx) => (
                  <div key={idx} className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded text-sm">
                    {measure}
                    <button type="button" onClick={() => removeMeasure(idx)} className="text-slate-500 hover:text-red-600">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <Label>Cleaning Procedure</Label>
            <Input
              value={formData.cleaning_procedure}
              onChange={(e) => setFormData({...formData, cleaning_procedure: e.target.value})}
            />
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={3}
            />
          </div>

          <div className="flex justify-between pt-4">
            {allergen && (
              <Button
                type="button"
                variant="destructive"
                onClick={() => deleteMutation.mutate()}
                disabled={deleteMutation.isPending}
              >
                Delete
              </Button>
            )}
            <div className="flex gap-2 ml-auto">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? "Saving..." : "Save"}
              </Button>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}