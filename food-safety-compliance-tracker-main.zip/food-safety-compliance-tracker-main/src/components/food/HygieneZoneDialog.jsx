import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { X, Plus } from "lucide-react";

export default function HygieneZoneDialog({ open, onClose, zone }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState(zone || {
    zone_name: "",
    zone_classification: "low_risk",
    location: "",
    cleaning_frequency: "daily",
    cleaning_procedure: "",
    activities: [],
    access_controls: [],
    status: "active",
    responsible_person: ""
  });
  const [newActivity, setNewActivity] = useState("");
  const [newControl, setNewControl] = useState("");

  const mutation = useMutation({
    mutationFn: (data) => zone 
      ? base44.entities.HygieneZone.update(zone.id, data)
      : base44.entities.HygieneZone.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["hygiene-zones"] });
      toast.success(zone ? "Hygiene zone updated" : "Hygiene zone created");
      onClose();
    },
    onError: () => toast.error("Failed to save hygiene zone")
  });

  const deleteMutation = useMutation({
    mutationFn: () => base44.entities.HygieneZone.delete(zone.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["hygiene-zones"] });
      toast.success("Hygiene zone deleted");
      onClose();
    },
    onError: () => toast.error("Failed to delete")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate(formData);
  };

  const addActivity = () => {
    if (newActivity.trim()) {
      setFormData({
        ...formData,
        activities: [...(formData.activities || []), newActivity]
      });
      setNewActivity("");
    }
  };

  const removeActivity = (index) => {
    setFormData({
      ...formData,
      activities: formData.activities.filter((_, i) => i !== index)
    });
  };

  const addControl = () => {
    if (newControl.trim()) {
      setFormData({
        ...formData,
        access_controls: [...(formData.access_controls || []), newControl]
      });
      setNewControl("");
    }
  };

  const removeControl = (index) => {
    setFormData({
      ...formData,
      access_controls: formData.access_controls.filter((_, i) => i !== index)
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{zone ? "Edit Hygiene Zone" : "Add Hygiene Zone"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Zone Name</Label>
            <Input
              value={formData.zone_name}
              onChange={(e) => setFormData({...formData, zone_name: e.target.value})}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Classification</Label>
              <Select value={formData.zone_classification} onValueChange={(v) => setFormData({...formData, zone_classification: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high_care">High Care</SelectItem>
                  <SelectItem value="high_risk">High Risk</SelectItem>
                  <SelectItem value="low_care">Low Care</SelectItem>
                  <SelectItem value="low_risk">Low Risk</SelectItem>
                  <SelectItem value="ambient">Ambient</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(v) => setFormData({...formData, status: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="under_maintenance">Under Maintenance</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Location</Label>
            <Input
              value={formData.location}
              onChange={(e) => setFormData({...formData, location: e.target.value})}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Cleaning Frequency</Label>
              <Select value={formData.cleaning_frequency} onValueChange={(v) => setFormData({...formData, cleaning_frequency: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="continuous">Continuous</SelectItem>
                  <SelectItem value="every_shift">Every Shift</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Cleaning Procedure</Label>
              <Input
                value={formData.cleaning_procedure}
                onChange={(e) => setFormData({...formData, cleaning_procedure: e.target.value})}
              />
            </div>
          </div>

          <div>
            <Label>Activities</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newActivity}
                onChange={(e) => setNewActivity(e.target.value)}
                placeholder="Add activity"
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addActivity())}
              />
              <Button type="button" onClick={addActivity} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {formData.activities?.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.activities.map((activity, idx) => (
                  <div key={idx} className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded text-sm">
                    {activity}
                    <button type="button" onClick={() => removeActivity(idx)} className="text-slate-500 hover:text-red-600">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <Label>Access Controls</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newControl}
                onChange={(e) => setNewControl(e.target.value)}
                placeholder="Add access control"
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addControl())}
              />
              <Button type="button" onClick={addControl} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {formData.access_controls?.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.access_controls.map((control, idx) => (
                  <div key={idx} className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded text-sm">
                    {control}
                    <button type="button" onClick={() => removeControl(idx)} className="text-slate-500 hover:text-red-600">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <Label>Responsible Person</Label>
            <Input
              value={formData.responsible_person}
              onChange={(e) => setFormData({...formData, responsible_person: e.target.value})}
            />
          </div>

          <div className="flex justify-between pt-4">
            {zone && (
              <Button
                type="button"
                variant="destructive"
                onClick={() => deleteMutation.mutate()}
                disabled={deleteMutation.isPending}
              >
                Delete
              </Button>
            )}
            <div className="flex gap-2 ml-auto">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? "Saving..." : "Save"}
              </Button>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}