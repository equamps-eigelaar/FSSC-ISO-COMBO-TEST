import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { FileText, Award, Loader2 } from "lucide-react";

export default function BatchDocumentButtons({ batch }) {
  const [loadingSpec, setLoadingSpec] = useState(false);
  const [loadingCert, setLoadingCert] = useState(false);

  const handleGenerateSpecSheet = async () => {
    try {
      setLoadingSpec(true);
      const response = await base44.functions.invoke('generateTechnicalDataSheet', {
        batch_id: batch.id
      });
      
      if (response.data?.file_url) {
        window.open(response.data.file_url, '_blank');
      }
    } catch (error) {
      console.error('Failed to generate spec sheet:', error);
    } finally {
      setLoadingSpec(false);
    }
  };

  const handleGenerateCertificate = async () => {
    try {
      setLoadingCert(true);
      const response = await base44.functions.invoke('generateCertificateOfCompliance', {
        batch_id: batch.id
      });
      
      if (response.data?.file_url) {
        window.open(response.data.file_url, '_blank');
      }
    } catch (error) {
      console.error('Failed to generate certificate:', error);
    } finally {
      setLoadingCert(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Button
        variant="outline"
        size="sm"
        onClick={handleGenerateSpecSheet}
        disabled={loadingSpec || loadingCert}
        className="gap-2"
      >
        {loadingSpec ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <FileText className="w-4 h-4" />
        )}
        {loadingSpec ? "Generating..." : "Product Spec Sheet"}
      </Button>
      
      <Button
        variant="outline"
        size="sm"
        onClick={handleGenerateCertificate}
        disabled={loadingSpec || loadingCert}
        className="gap-2"
      >
        {loadingCert ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <Award className="w-4 h-4" />
        )}
        {loadingCert ? "Generating..." : "Certificate of Compliance"}
      </Button>
    </div>
  );
}