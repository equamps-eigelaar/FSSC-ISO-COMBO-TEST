import React, { useState, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Sparkles, Package, Loader2 } from "lucide-react";

export default function FoodBatchDialog({ open, onClose, batch }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState(batch || {
    batch_number: "",
    product_name: "",
    product_code: "",
    production_date: new Date().toISOString().split('T')[0],
    production_line: "",
    shift: "morning",
    quantity_produced: 0,
    unit: "",
    raw_material_batches: [],
    status: "in_production",
    supervisor: "",
    notes: ""
  });
  const [selectedMaterials, setSelectedMaterials] = useState(new Set(
    batch?.raw_material_batches?.map(rm => rm.raw_material_batch_id) || []
  ));
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

  // Fetch available raw materials
  const { data: rawMaterials = [] } = useQuery({
    queryKey: ["raw-materials-available"],
    queryFn: () => base44.entities.RawMaterialBatch.filter({
      status: { $in: ['approved', 'in_use'] }
    }),
    enabled: open
  });

  // Get AI suggestions when product name changes
  useEffect(() => {
    const getSuggestions = async () => {
      if (formData.product_name && formData.product_name.length > 3 && !batch) {
        setLoadingSuggestions(true);
        try {
          const response = await base44.functions.invoke('suggestRawMaterials', {
            product_name: formData.product_name,
            product_code: formData.product_code
          });
          setAiSuggestions(response.data.suggestions || []);
        } catch (error) {
          console.error('Failed to get AI suggestions:', error);
        } finally {
          setLoadingSuggestions(false);
        }
      }
    };

    const timer = setTimeout(getSuggestions, 800);
    return () => clearTimeout(timer);
  }, [formData.product_name, formData.product_code, batch]);

  const mutation = useMutation({
    mutationFn: (data) => {
      // Build raw_material_batches array from selected materials
      const rawMaterialBatches = Array.from(selectedMaterials).map(materialId => {
        const material = rawMaterials.find(rm => rm.id === materialId);
        return {
          material_name: material.material_name,
          batch_number: material.batch_number,
          raw_material_batch_id: material.id,
          quantity_used: 0 // Can be updated later
        };
      });

      const dataToSave = {
        ...data,
        raw_material_batches: rawMaterialBatches
      };

      return batch 
        ? base44.entities.FoodBatchRecord.update(batch.id, dataToSave)
        : base44.entities.FoodBatchRecord.create(dataToSave);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["food-batches"] });
      toast.success(batch ? "Batch record updated" : "Batch record created");
      onClose();
    },
    onError: () => toast.error("Failed to save batch record")
  });

  const deleteMutation = useMutation({
    mutationFn: () => base44.entities.FoodBatchRecord.delete(batch.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["food-batches"] });
      toast.success("Batch record deleted");
      onClose();
    },
    onError: () => toast.error("Failed to delete")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate(formData);
  };

  const toggleMaterial = (materialId) => {
    const newSelected = new Set(selectedMaterials);
    if (newSelected.has(materialId)) {
      newSelected.delete(materialId);
    } else {
      newSelected.add(materialId);
    }
    setSelectedMaterials(newSelected);
  };

  const applySuggestion = (suggestion) => {
    setSelectedMaterials(prev => new Set([...prev, suggestion.batch_id]));
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{batch ? "Edit Batch Record" : "New Batch Record"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Batch Number</Label>
              <Input
                value={formData.batch_number}
                onChange={(e) => setFormData({...formData, batch_number: e.target.value})}
                required
              />
            </div>
            <div>
              <Label>Product Code</Label>
              <Input
                value={formData.product_code}
                onChange={(e) => setFormData({...formData, product_code: e.target.value})}
              />
            </div>
          </div>

          <div>
            <Label>Product Name</Label>
            <Input
              value={formData.product_name}
              onChange={(e) => setFormData({...formData, product_name: e.target.value})}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Production Date</Label>
              <Input
                type="date"
                value={formData.production_date}
                onChange={(e) => setFormData({...formData, production_date: e.target.value})}
                required
              />
            </div>
            <div>
              <Label>Shift</Label>
              <Select value={formData.shift} onValueChange={(v) => setFormData({...formData, shift: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="morning">Morning</SelectItem>
                  <SelectItem value="afternoon">Afternoon</SelectItem>
                  <SelectItem value="night">Night</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Production Line</Label>
              <Input
                value={formData.production_line}
                onChange={(e) => setFormData({...formData, production_line: e.target.value})}
              />
            </div>
            <div>
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(v) => setFormData({...formData, status: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in_production">In Production</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="quality_hold">Quality Hold</SelectItem>
                  <SelectItem value="released">Released</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Quantity Produced</Label>
              <Input
                type="number"
                value={formData.quantity_produced}
                onChange={(e) => setFormData({...formData, quantity_produced: Number(e.target.value)})}
                required
              />
            </div>
            <div>
              <Label>Unit</Label>
              <Input
                value={formData.unit}
                onChange={(e) => setFormData({...formData, unit: e.target.value})}
                placeholder="kg, L, units"
              />
            </div>
          </div>

          <div>
            <Label>Supervisor</Label>
            <Input
              value={formData.supervisor}
              onChange={(e) => setFormData({...formData, supervisor: e.target.value})}
            />
          </div>

          <div>
            <Label>Raw Materials Used</Label>
            
            {aiSuggestions.length > 0 && (
              <div className="mb-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <p className="text-sm font-medium text-blue-900">AI Suggestions</p>
                </div>
                <div className="space-y-2">
                  {aiSuggestions.map((suggestion) => (
                    <div key={suggestion.batch_id} className="flex items-center justify-between text-sm">
                      <div className="flex-1">
                        <p className="font-medium text-slate-900">{suggestion.material_name}</p>
                        <p className="text-xs text-slate-600">{suggestion.reason}</p>
                      </div>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => applySuggestion(suggestion)}
                        disabled={selectedMaterials.has(suggestion.batch_id)}
                      >
                        {selectedMaterials.has(suggestion.batch_id) ? "Added" : "Add"}
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {loadingSuggestions && (
              <div className="flex items-center gap-2 text-sm text-slate-500 mb-3">
                <Loader2 className="w-4 h-4 animate-spin" />
                Getting AI suggestions...
              </div>
            )}

            <div className="space-y-2 max-h-48 overflow-y-auto border rounded-lg p-3">
              {rawMaterials.map((material) => (
                <div key={material.id} className="flex items-start gap-2">
                  <Checkbox
                    checked={selectedMaterials.has(material.id)}
                    onCheckedChange={() => toggleMaterial(material.id)}
                    id={`material-${material.id}`}
                  />
                  <label htmlFor={`material-${material.id}`} className="flex-1 cursor-pointer">
                    <div className="flex items-center gap-2">
                      <Package className="w-4 h-4 text-slate-400" />
                      <span className="text-sm font-medium">{material.material_name}</span>
                    </div>
                    <p className="text-xs text-slate-500 ml-6">
                      Batch: {material.batch_number} | Supplier: {material.supplier}
                    </p>
                  </label>
                </div>
              ))}
              {rawMaterials.length === 0 && (
                <p className="text-sm text-slate-500 text-center py-4">
                  No approved raw materials available
                </p>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              {selectedMaterials.size} material{selectedMaterials.size !== 1 ? 's' : ''} selected
            </p>
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={3}
            />
          </div>

          <div className="flex justify-between pt-4">
            {batch && (
              <Button
                type="button"
                variant="destructive"
                onClick={() => deleteMutation.mutate()}
                disabled={deleteMutation.isPending}
              >
                Delete
              </Button>
            )}
            <div className="flex gap-2 ml-auto">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? "Saving..." : "Save"}
              </Button>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}