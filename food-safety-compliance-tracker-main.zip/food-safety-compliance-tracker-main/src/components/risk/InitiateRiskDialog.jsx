import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const LIKELIHOOD_SCORES = { rare: 1, unlikely: 2, possible: 3, likely: 4, almost_certain: 5 };
const SEVERITY_SCORES = { negligible: 1, minor: 2, moderate: 3, major: 4, catastrophic: 5 };

function calculateRiskLevel(likelihood, severity) {
  const score = LIKELIHOOD_SCORES[likelihood] * SEVERITY_SCORES[severity];
  if (score >= 15) return "critical";
  if (score >= 9) return "high";
  if (score >= 4) return "medium";
  return "low";
}

export default function InitiateRiskDialog({ open, onClose }) {
  const [form, setForm] = useState({
    requirement_id: "",
    hazard_type: "chemical",
    hazard_description: "",
    likelihood: "possible",
    severity: "moderate",
    mitigation_strategy: "",
    assigned_to: "",
    priority: "medium",
    workflow_status: "draft",
  });

  const queryClient = useQueryClient();

  const { data: requirements = [] } = useQuery({
    queryKey: ["compliance-requirements"],
    queryFn: () => base44.entities.ComplianceRequirement.list("clause_number", 200),
    enabled: open,
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list("-created_date", 100),
    enabled: open,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.RiskAssessment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["risk-assessments-workflow"] });
      toast.success("Risk assessment initiated");
      onClose();
      setForm({
        requirement_id: "",
        hazard_type: "chemical",
        hazard_description: "",
        likelihood: "possible",
        severity: "moderate",
        mitigation_strategy: "",
        assigned_to: "",
        priority: "medium",
        workflow_status: "draft",
      });
    },
    onError: () => toast.error("Failed to initiate assessment"),
  });

  const handleSubmit = () => {
    const riskLevel = calculateRiskLevel(form.likelihood, form.severity);
    const data = {
      ...form,
      risk_level: riskLevel,
      residual_risk: "medium",
      status: "identified",
    };
    createMutation.mutate(data);
  };

  const riskLevel = calculateRiskLevel(form.likelihood, form.severity);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Initiate Risk Assessment</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div>
            <Label className="text-xs">Compliance Requirement*</Label>
            <Select value={form.requirement_id} onValueChange={(v) => setForm({ ...form, requirement_id: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Select requirement" />
              </SelectTrigger>
              <SelectContent>
                {requirements.map(req => (
                  <SelectItem key={req.id} value={req.id}>
                    {req.clause_number} - {req.clause_title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Hazard Type*</Label>
              <Select value={form.hazard_type} onValueChange={(v) => setForm({ ...form, hazard_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="biological">Biological</SelectItem>
                  <SelectItem value="chemical">Chemical</SelectItem>
                  <SelectItem value="physical">Physical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Priority</Label>
              <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-xs">Hazard Description*</Label>
            <Textarea
              placeholder="Describe the identified hazard..."
              value={form.hazard_description}
              onChange={(e) => setForm({ ...form, hazard_description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Likelihood*</Label>
              <Select value={form.likelihood} onValueChange={(v) => setForm({ ...form, likelihood: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="rare">Rare</SelectItem>
                  <SelectItem value="unlikely">Unlikely</SelectItem>
                  <SelectItem value="possible">Possible</SelectItem>
                  <SelectItem value="likely">Likely</SelectItem>
                  <SelectItem value="almost_certain">Almost Certain</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Severity*</Label>
              <Select value={form.severity} onValueChange={(v) => setForm({ ...form, severity: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="negligible">Negligible</SelectItem>
                  <SelectItem value="minor">Minor</SelectItem>
                  <SelectItem value="moderate">Moderate</SelectItem>
                  <SelectItem value="major">Major</SelectItem>
                  <SelectItem value="catastrophic">Catastrophic</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-lg">
            <Label className="text-xs text-slate-600">Calculated Risk Level</Label>
            <div className={`text-lg font-semibold mt-1 ${
              riskLevel === "critical" ? "text-rose-700" :
              riskLevel === "high" ? "text-orange-700" :
              riskLevel === "medium" ? "text-amber-700" : "text-emerald-700"
            }`}>
              {riskLevel.toUpperCase()}
            </div>
          </div>

          <div>
            <Label className="text-xs">Mitigation Strategy</Label>
            <Textarea
              placeholder="Describe control measures or actions to mitigate the risk..."
              value={form.mitigation_strategy}
              onChange={(e) => setForm({ ...form, mitigation_strategy: e.target.value })}
              rows={3}
            />
          </div>

          <div>
            <Label className="text-xs">Assign To</Label>
            <Select value={form.assigned_to} onValueChange={(v) => setForm({ ...form, assigned_to: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Select user" />
              </SelectTrigger>
              <SelectContent>
                {users.map(user => (
                  <SelectItem key={user.id} value={user.email}>
                    {user.full_name || user.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={handleSubmit}
            disabled={!form.requirement_id || !form.hazard_description || createMutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {createMutation.isPending ? "Initiating..." : "Initiate Assessment"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}