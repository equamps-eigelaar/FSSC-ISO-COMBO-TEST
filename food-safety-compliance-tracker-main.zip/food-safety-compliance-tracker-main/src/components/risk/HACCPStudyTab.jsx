import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Pencil, Trash2, AlertTriangle, ShieldCheck, Info, GitBranch } from "lucide-react";
import HACCPEntryDialog from "./HACCPEntryDialog";
import HACCPDecisionWizard from "./HACCPDecisionWizard";
import CodexHACCPPrinciples from "./CodexHACCPPrinciples";
import PDCAProcessControl from "./PDCAProcessControl";

const RISK_COLORS = {
  low: "bg-emerald-100 text-emerald-800 border-emerald-300",
  medium: "bg-yellow-100 text-yellow-800 border-yellow-300",
  high: "bg-orange-100 text-orange-800 border-orange-300",
  critical: "bg-red-100 text-red-800 border-red-300",
};

const RISK_LABEL = { low: "L – Low", medium: "M – Medium", high: "H – High", critical: "E – Extreme" };

const HAZARD_TYPE_LABELS = {
  biological: "B – Biological",
  chemical: "C – Chemical",
  physical: "P – Physical",
  allergen: "A – Allergen",
  radiological: "M – Migration",
};

export default function HACCPStudyTab() {
  const [showDialog, setShowDialog] = useState(false);
  const [showWizard, setShowWizard] = useState(false);
  const [editEntry, setEditEntry] = useState(null);
  const queryClient = useQueryClient();

  const { data: allRisks = [], isLoading } = useQuery({
    queryKey: ["haccp-study-risks"],
    queryFn: () => base44.entities.RiskAssessment.filter({ requirement_id: "haccp_study" }, "-created_date", 200),
  });

  const handleSaved = () => queryClient.invalidateQueries({ queryKey: ["haccp-study-risks"] });
  const handleEdit = (entry) => { setEditEntry(entry); setShowDialog(true); };
  const handleDelete = async (id) => {
    if (window.confirm("Delete this HACCP entry?")) {
      await base44.entities.RiskAssessment.delete(id);
      handleSaved();
    }
  };

  const ccps = allRisks.filter(r => r.is_ccp);
  const oprps = allRisks.filter(r => r.is_oprp);
  const significantRisks = allRisks.filter(r => r.risk_level === "high" || r.risk_level === "critical");

  if (isLoading) return <div className="p-8 text-center text-slate-500">Loading HACCP study...</div>;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-800">HACCP / TACCP / VACCP Hazard Analysis Study</h2>
          <p className="text-sm text-slate-500 mt-0.5">Based on ISO 22000:2018 – Principles 1–7 | HACCP Decision Tree</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowWizard(true)} className="border-blue-300 text-blue-700 hover:bg-blue-50">
            <GitBranch className="w-4 h-4 mr-2" />
            Decision Tree Wizard
          </Button>
          <Button onClick={() => { setEditEntry(null); setShowDialog(true); }} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Hazard Entry
          </Button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <SummaryCard label="Total Entries" count={allRisks.length} color="slate" icon={Info} />
        <SummaryCard label="Significant Risks" count={significantRisks.length} color="orange" icon={AlertTriangle} />
        <SummaryCard label="CCPs Identified" count={ccps.length} color="red" icon={ShieldCheck} />
        <SummaryCard label="OPRPs Identified" count={oprps.length} color="blue" icon={ShieldCheck} />
      </div>

      <Tabs defaultValue="hara">
        <TabsList className="bg-white border border-slate-200">
          <TabsTrigger value="hara">Hazard Analysis Table</TabsTrigger>
          <TabsTrigger value="ccp">CCP / OPRP Register</TabsTrigger>
          <TabsTrigger value="matrix">Risk Matrix</TabsTrigger>
          <TabsTrigger value="codex">CODEX Principles</TabsTrigger>
          <TabsTrigger value="pdca">PDCA Process Control</TabsTrigger>
        </TabsList>

        {/* HARA Table */}
        <TabsContent value="hara">
          {allRisks.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <AlertTriangle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500 mb-2">No HACCP entries yet</p>
                <p className="text-xs text-slate-400">Click "Add Hazard Entry" to begin your HACCP study</p>
              </CardContent>
            </Card>
          ) : (
            <div className="rounded-lg border border-slate-200 overflow-x-auto bg-white shadow-sm">
              <table className="min-w-full text-xs">
                <thead className="bg-slate-700 text-white">
                  <tr>
                    <th className="px-3 py-2.5 text-left font-medium w-8">#</th>
                    <th className="px-3 py-2.5 text-left font-medium min-w-[140px]">Process Step</th>
                    <th className="px-3 py-2.5 text-left font-medium">Hazard Type</th>
                    <th className="px-3 py-2.5 text-left font-medium min-w-[180px]">Hazards Identified</th>
                    <th className="px-3 py-2.5 text-center font-medium">Source</th>
                    <th className="px-3 py-2.5 text-left font-medium min-w-[160px]">Control Measures</th>
                    <th className="px-3 py-2.5 text-center font-medium">L</th>
                    <th className="px-3 py-2.5 text-center font-medium">S</th>
                    <th className="px-3 py-2.5 text-center font-medium">Score</th>
                    <th className="px-3 py-2.5 text-center font-medium">Risk Level</th>
                    <th className="px-3 py-2.5 text-center font-medium">Significant</th>
                    <th className="px-3 py-2.5 text-center font-medium">CCP/OPRP</th>
                    <th className="px-3 py-2.5 text-left font-medium">Documentation</th>
                    <th className="px-3 py-2.5 text-center font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {allRisks.map((entry, idx) => {
                    const processStep = entry.notes?.split("||")[0] || "-";
                    const source = entry.notes?.split("||")[1] || "-";
                    const lScore = { rare: 1, unlikely: 2, possible: 3, likely: 4, almost_certain: 5 }[entry.likelihood] || "-";
                    const sScore = { negligible: 1, minor: 2, moderate: 3, major: 4, catastrophic: 5 }[entry.severity] || "-";
                    const totalScore = (typeof lScore === "number" && typeof sScore === "number") ? lScore * sScore : "-";
                    const isSignificant = entry.risk_level === "high" || entry.risk_level === "critical";
                    const ccpOprp = entry.is_ccp ? "CCP" : entry.is_oprp ? "OPRP" : "—";
                    const rowBg = entry.risk_level === "critical" ? "bg-red-50" : entry.risk_level === "high" ? "bg-orange-50" : idx % 2 === 0 ? "bg-white" : "bg-slate-50";

                    return (
                      <tr key={entry.id} className={`${rowBg} border-b border-slate-100 hover:bg-slate-100 transition-colors`}>
                        <td className="px-3 py-2 text-slate-500">{idx + 1}</td>
                        <td className="px-3 py-2 font-medium text-slate-800">{processStep}</td>
                        <td className="px-3 py-2">
                          <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-700">
                            {HAZARD_TYPE_LABELS[entry.hazard_type] || entry.hazard_type}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-slate-600 max-w-[200px]">
                          <p className="line-clamp-2">{entry.hazard_description}</p>
                        </td>
                        <td className="px-3 py-2 text-center">
                          <span className="font-bold text-slate-700">{source}</span>
                        </td>
                        <td className="px-3 py-2 text-slate-600 max-w-[180px]">
                          <p className="line-clamp-2">{entry.mitigation_strategy || "—"}</p>
                        </td>
                        <td className="px-3 py-2 text-center font-semibold">{lScore}</td>
                        <td className="px-3 py-2 text-center font-semibold">{sScore}</td>
                        <td className="px-3 py-2 text-center font-bold text-slate-800">{totalScore}</td>
                        <td className="px-3 py-2 text-center">
                          <Badge className={`text-[10px] ${RISK_COLORS[entry.risk_level] || "bg-slate-100"}`}>
                            {RISK_LABEL[entry.risk_level] || entry.risk_level}
                          </Badge>
                        </td>
                        <td className="px-3 py-2 text-center">
                          {isSignificant ? (
                            <span className="text-rose-600 font-bold">YES</span>
                          ) : (
                            <span className="text-slate-400">No</span>
                          )}
                        </td>
                        <td className="px-3 py-2 text-center">
                          <Badge className={
                            ccpOprp === "CCP" ? "bg-red-100 text-red-800 text-[10px]" :
                            ccpOprp === "OPRP" ? "bg-orange-100 text-orange-800 text-[10px]" :
                            "bg-slate-100 text-slate-500 text-[10px]"
                          }>
                            {ccpOprp}
                          </Badge>
                        </td>
                        <td className="px-3 py-2 text-slate-500 max-w-[140px]">
                          <p className="line-clamp-1 text-[11px]">{entry.approval_notes || "—"}</p>
                        </td>
                        <td className="px-3 py-2">
                          <div className="flex gap-1 justify-center">
                            <button onClick={() => handleEdit(entry)} className="p-1 rounded hover:bg-slate-200 text-slate-500">
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button onClick={() => handleDelete(entry.id)} className="p-1 rounded hover:bg-rose-100 text-slate-400 hover:text-rose-600">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </TabsContent>

        {/* CCP / OPRP Register */}
        <TabsContent value="ccp">
          <div className="space-y-4">
            {ccps.length === 0 && oprps.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-10 text-center">
                  <ShieldCheck className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500">No CCPs or OPRPs identified yet</p>
                </CardContent>
              </Card>
            ) : (
              <>
                {ccps.length > 0 && (
                  <Card className="border border-red-200 shadow-sm">
                    <CardHeader className="bg-red-50 pb-3">
                      <CardTitle className="text-sm text-red-800">Critical Control Points (CCPs) — {ccps.length}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      {ccps.map((ccp, i) => (
                        <CCPRow key={ccp.id} entry={ccp} index={i + 1} type="CCP" onEdit={() => handleEdit(ccp)} />
                      ))}
                    </CardContent>
                  </Card>
                )}
                {oprps.length > 0 && (
                  <Card className="border border-orange-200 shadow-sm">
                    <CardHeader className="bg-orange-50 pb-3">
                      <CardTitle className="text-sm text-orange-800">Operational Prerequisite Programmes (OPRPs) — {oprps.length}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      {oprps.map((oprp, i) => (
                        <CCPRow key={oprp.id} entry={oprp} index={i + 1} type="OPRP" onEdit={() => handleEdit(oprp)} />
                      ))}
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </div>
        </TabsContent>

        {/* Risk Matrix */}
        <TabsContent value="matrix">
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-sm">Risk Matrix — Likelihood × Severity</CardTitle>
              <p className="text-xs text-slate-500">Based on HACCP study risk methodology</p>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="text-xs border-collapse">
                  <thead>
                    <tr>
                      <th className="border border-slate-300 px-3 py-2 bg-slate-100 text-slate-600">Likelihood \ Severity</th>
                      {["Low (1)", "Minor (2)", "Moderate (3)", "Major (4)", "Extreme (5)"].map(s => (
                        <th key={s} className="border border-slate-300 px-3 py-2 bg-slate-100 text-slate-600">{s}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ["Almost Certain (5)", "H","H","E","E","E"],
                      ["Likely (4)",         "M","H","H","E","E"],
                      ["Possible (3)",       "L","M","H","E","E"],
                      ["Unlikely (2)",       "L","L","M","H","E"],
                      ["Rare (1)",           "L","L","L","M","H"],
                    ].map(([label, ...cells]) => (
                      <tr key={label}>
                        <td className="border border-slate-300 px-3 py-2 font-medium bg-slate-50">{label}</td>
                        {cells.map((cell, i) => {
                          const colors = { L: "bg-emerald-100 text-emerald-800", M: "bg-yellow-100 text-yellow-800", H: "bg-orange-200 text-orange-900", E: "bg-red-200 text-red-900" };
                          return (
                            <td key={i} className={`border border-slate-300 px-3 py-2 text-center font-bold ${colors[cell]}`}>
                              {cell === "L" ? "Low" : cell === "M" ? "Medium" : cell === "H" ? "High" : "Extreme"}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex flex-wrap gap-3 mt-4">
                {[
                  { label: "L – Low", cls: "bg-emerald-100 text-emerald-800" },
                  { label: "M – Medium", cls: "bg-yellow-100 text-yellow-800" },
                  { label: "H – High", cls: "bg-orange-200 text-orange-900" },
                  { label: "E – Extreme", cls: "bg-red-200 text-red-900" },
                ].map(({ label, cls }) => (
                  <span key={label} className={`px-3 py-1 rounded text-xs font-medium border ${cls}`}>{label}</span>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* CODEX Principles */}
        <TabsContent value="codex">
          <CodexHACCPPrinciples />
        </TabsContent>

        {/* PDCA Process Control */}
        <TabsContent value="pdca">
          <PDCAProcessControl />
        </TabsContent>
      </Tabs>

      {showWizard && (
        <HACCPDecisionWizard
          open={showWizard}
          onClose={() => setShowWizard(false)}
          onSaved={handleSaved}
        />
      )}

      {showDialog && (
        <HACCPEntryDialog
          open={showDialog}
          onClose={() => { setShowDialog(false); setEditEntry(null); }}
          onSaved={handleSaved}
          entry={editEntry}
        />
      )}
    </div>
  );
}

function CCPRow({ entry, index, type, onEdit }) {
  const processStep = entry.notes?.split("||")[0] || "—";
  return (
    <div className="border-b border-slate-100 last:border-0 p-4 flex items-start justify-between gap-4">
      <div className="flex-1 space-y-1">
        <div className="flex items-center gap-2">
          <Badge className={type === "CCP" ? "bg-red-100 text-red-800 text-[10px]" : "bg-orange-100 text-orange-800 text-[10px]"}>
            {type}-{String(index).padStart(2, "0")}
          </Badge>
          <span className="text-sm font-medium text-slate-800">{processStep}</span>
        </div>
        <p className="text-xs text-slate-600">{entry.hazard_description}</p>
        {entry.critical_limits && <p className="text-xs text-slate-500"><strong>Acceptable Level:</strong> {entry.critical_limits}</p>}
        {entry.monitoring_procedure && <p className="text-xs text-slate-500"><strong>Monitoring:</strong> {entry.monitoring_procedure}</p>}
        {entry.corrective_action_plan && <p className="text-xs text-slate-500"><strong>Corrective Action:</strong> {entry.corrective_action_plan}</p>}
      </div>
      <button onClick={onEdit} className="p-1.5 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-600 flex-shrink-0">
        <Pencil className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

function SummaryCard({ label, count, color, icon: Icon }) {
  const colorMap = {
    slate: "bg-slate-50 text-slate-700",
    orange: "bg-orange-50 text-orange-700",
    red: "bg-red-50 text-red-700",
    blue: "bg-blue-50 text-blue-700",
  };
  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4 flex items-center gap-3">
        <Icon className={`w-8 h-8 p-1.5 rounded-lg ${colorMap[color]}`} />
        <div>
          <div className="text-2xl font-bold text-slate-800">{count}</div>
          <div className="text-xs text-slate-500">{label}</div>
        </div>
      </CardContent>
    </Card>
  );
}