import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Sparkles, Loader2, CheckCircle2, Lightbulb, ArrowRight } from "lucide-react";
import { toast } from "sonner";

const EFFECTIVENESS_CONFIG = {
  high: { color: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-400", label: "High Impact" },
  medium: { color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400", label: "Medium Impact" },
  low: { color: "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400", label: "Low Impact" }
};

export default function RiskMitigationSuggestions({ riskId, onApplied }) {
  const [generating, setGenerating] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [recommendation, setRecommendation] = useState("");
  const [selectedStrategies, setSelectedStrategies] = useState(new Set());
  const queryClient = useQueryClient();

  const createActionMutation = useMutation({
    mutationFn: (actionData) => base44.entities.ActionItem.create(actionData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['action-items'] });
    }
  });

  const updateRiskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RiskAssessment.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['risk-assessments'] });
    }
  });

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const response = await base44.functions.invoke('suggestRiskMitigation', { riskId });
      setSuggestions(response.data.suggestions || []);
      setRecommendation(response.data.recommendation || "");
      toast.success(`Generated ${response.data.suggestions.length} mitigation strategies`);
    } catch (error) {
      toast.error('Failed to generate suggestions');
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  const toggleStrategy = (index) => {
    const newSelected = new Set(selectedStrategies);
    if (newSelected.has(index)) {
      newSelected.delete(index);
    } else {
      newSelected.add(index);
    }
    setSelectedStrategies(newSelected);
  };

  const handleApply = async () => {
    if (selectedStrategies.size === 0) {
      toast.error('Please select at least one strategy');
      return;
    }

    try {
      const selected = Array.from(selectedStrategies).map(idx => suggestions[idx]);
      
      // Combine selected strategies into mitigation text
      const combinedMitigation = selected.map(s => `${s.title}: ${s.description}`).join('\n\n');
      
      // Update risk with mitigation strategy
      await updateRiskMutation.mutateAsync({
        id: riskId,
        data: { mitigation_strategy: combinedMitigation }
      });

      // Create action items for each selected strategy
      for (const strategy of selected) {
        await createActionMutation.mutateAsync({
          title: `Implement: ${strategy.title}`,
          description: `${strategy.description}\n\nImplementation Steps:\n${strategy.implementation_steps.map((step, i) => `${i + 1}. ${step}`).join('\n')}\n\nRequired Resources:\n${strategy.resources_needed.join(', ')}`,
          source_type: "risk_assessment",
          source_id: riskId,
          priority: strategy.effectiveness === 'high' ? 'high' : 'medium',
          status: "pending",
          due_date: calculateDueDate(strategy.timeline)
        });
      }

      toast.success(`Applied ${selected.length} strategies and created action items`);
      setSuggestions([]);
      setSelectedStrategies(new Set());
      if (onApplied) onApplied();
    } catch (error) {
      toast.error('Failed to apply strategies');
      console.error(error);
    }
  };

  const calculateDueDate = (timeline) => {
    const now = new Date();
    const match = timeline.match(/(\d+)\s*(day|week|month)s?/i);
    
    if (!match) {
      now.setMonth(now.getMonth() + 1);
      return now.toISOString().split('T')[0];
    }
    
    const amount = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    
    if (unit === 'day') now.setDate(now.getDate() + amount);
    else if (unit === 'week') now.setDate(now.getDate() + (amount * 7));
    else if (unit === 'month') now.setMonth(now.getMonth() + amount);
    
    return now.toISOString().split('T')[0];
  };

  if (suggestions.length === 0 && !generating) {
    return (
      <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/20 dark:to-indigo-950/20 border-purple-100 dark:border-purple-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-purple-900 dark:text-purple-100 text-sm">
            <Lightbulb className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            AI Mitigation Suggestions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <Sparkles className="w-10 h-10 text-purple-400 dark:text-purple-600 mx-auto mb-2" />
            <p className="text-xs text-slate-600 dark:text-slate-300 mb-3">
              Get AI-powered mitigation strategies for this risk
            </p>
            <Button
              size="sm"
              onClick={handleGenerate}
              disabled={generating}
              className="bg-purple-600 hover:bg-purple-700 min-h-[44px]"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Strategies
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/20 dark:to-indigo-950/20 border-purple-100 dark:border-purple-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-purple-900 dark:text-purple-100 text-sm">
            <Lightbulb className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            AI Mitigation Strategies
          </CardTitle>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleGenerate}
            disabled={generating}
            className="text-purple-600 hover:text-purple-700 hover:bg-purple-100 dark:hover:bg-purple-900/20"
          >
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {recommendation && (
          <div className="bg-white/60 dark:bg-slate-800/60 rounded-lg p-3 mb-3">
            <p className="text-xs text-slate-700 dark:text-slate-300 font-medium mb-1">Overall Recommendation:</p>
            <p className="text-xs text-slate-600 dark:text-slate-400">{recommendation}</p>
          </div>
        )}

        {suggestions.map((strategy, idx) => (
          <div
            key={idx}
            className={`bg-white dark:bg-slate-800 rounded-lg p-3 border transition-all ${
              selectedStrategies.has(idx)
                ? 'border-purple-300 dark:border-purple-600 shadow-sm'
                : 'border-purple-100 dark:border-purple-800'
            }`}
          >
            <div className="flex items-start gap-3 mb-2">
              <Checkbox
                checked={selectedStrategies.has(idx)}
                onCheckedChange={() => toggleStrategy(idx)}
                className="mt-0.5 min-h-[44px] min-w-[44px] flex items-center justify-center"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <h4 className="font-semibold text-slate-900 dark:text-white text-xs">
                    {strategy.title}
                  </h4>
                  <Badge className={EFFECTIVENESS_CONFIG[strategy.effectiveness].color}>
                    {EFFECTIVENESS_CONFIG[strategy.effectiveness].label}
                  </Badge>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mb-2">
                  {strategy.description}
                </p>

                {strategy.implementation_steps && strategy.implementation_steps.length > 0 && (
                  <div className="mb-2">
                    <p className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Steps:</p>
                    <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-0.5 ml-3">
                      {strategy.implementation_steps.slice(0, 2).map((step, i) => (
                        <li key={i} className="flex items-start gap-1">
                          <span className="text-purple-600 dark:text-purple-400">•</span>
                          {step}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex flex-wrap gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span>Timeline: {strategy.timeline}</span>
                </div>
              </div>
            </div>
          </div>
        ))}

        {selectedStrategies.size > 0 && (
          <Button
            onClick={handleApply}
            disabled={createActionMutation.isPending || updateRiskMutation.isPending}
            className="w-full bg-purple-600 hover:bg-purple-700 min-h-[44px]"
          >
            {createActionMutation.isPending || updateRiskMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Applying...
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Apply {selectedStrategies.size} {selectedStrategies.size === 1 ? 'Strategy' : 'Strategies'}
              </>
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}