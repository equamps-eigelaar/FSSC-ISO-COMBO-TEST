import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Loader2, CheckCircle, Target, Activity } from "lucide-react";
import { toast } from "sonner";

export default function AIRiskRecommendations({ hazardType, hazardDescription, likelihood, severity, requirementId, onApply }) {
  const [loading, setLoading] = useState(false);
  const [recommendations, setRecommendations] = useState(null);

  const fetchRecommendations = async () => {
    setLoading(true);
    try {
      const response = await base44.functions.invoke('getRiskMitigationRecommendations', {
        hazard_type: hazardType,
        hazard_description: hazardDescription,
        likelihood,
        severity,
        requirement_id: requirementId
      });

      setRecommendations(response.data);
      toast.success("AI recommendations generated");
    } catch (error) {
      toast.error("Failed to get recommendations");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleApplyRecommendations = () => {
    if (recommendations?.recommendations) {
      const strategy = [
        ...recommendations.recommendations.immediate_controls,
        ...recommendations.recommendations.long_term_strategies
      ].join('\n\n');
      
      if (onApply) {
        onApply(strategy);
      }
    }
  };

  if (!recommendations) {
    return (
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-white">
        <CardContent className="p-6 text-center">
          <Sparkles className="w-12 h-12 text-purple-400 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-slate-900 mb-2">
            AI-Powered Risk Mitigation
          </h3>
          <p className="text-xs text-slate-600 mb-4">
            Get intelligent recommendations based on industry best practices and historical data
          </p>
          <Button
            onClick={fetchRecommendations}
            disabled={loading || !hazardDescription}
            className="bg-purple-600 hover:bg-purple-700"
            size="sm"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Get AI Recommendations
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  const rec = recommendations.recommendations;

  return (
    <div className="space-y-4">
      <Card className="border-purple-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-600" />
            AI-Driven Recommendations
            <div className="ml-auto flex items-center gap-2">
              {recommendations.compliance_gaps_identified > 0 && (
                <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700">
                  {recommendations.compliance_gaps_identified} gaps addressed
                </Badge>
              )}
              <Badge variant="outline" className="text-xs">
                {recommendations.similar_cases_analyzed} historical cases
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Immediate Controls */}
          <div>
            <h4 className="text-xs font-semibold text-slate-900 mb-2 flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-rose-600" />
              Immediate Control Measures
            </h4>
            <ul className="space-y-1.5">
              {rec.immediate_controls?.map((control, idx) => (
                <li key={idx} className="text-xs text-slate-600 flex items-start gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  {control}
                </li>
              ))}
            </ul>
          </div>

          {/* Long-term Strategies */}
          <div>
            <h4 className="text-xs font-semibold text-slate-900 mb-2 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-blue-600" />
              Long-term Strategies
            </h4>
            <ul className="space-y-1.5">
              {rec.long_term_strategies?.map((strategy, idx) => (
                <li key={idx} className="text-xs text-slate-600 flex items-start gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-blue-600 mt-0.5 shrink-0" />
                  {strategy}
                </li>
              ))}
            </ul>
          </div>

          {/* Expected Residual Risk */}
          {rec.expected_residual_risk && (
            <div className="p-3 bg-slate-50 rounded-lg">
              <span className="text-xs font-medium text-slate-700">Expected Residual Risk: </span>
              <span className="text-xs text-emerald-700 font-semibold">
                {rec.expected_residual_risk}
              </span>
            </div>
          )}

          {/* Compliance Gap Benefits */}
          {rec.compliance_gap_benefits?.length > 0 && (
            <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
              <h4 className="text-xs font-semibold text-amber-900 mb-2">Compliance Benefits</h4>
              <ul className="space-y-1">
                {rec.compliance_gap_benefits.map((benefit, idx) => (
                  <li key={idx} className="text-xs text-amber-800 flex items-start gap-2">
                    <CheckCircle className="w-3 h-3 text-amber-600 mt-0.5 shrink-0" />
                    {benefit}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* ISO Clauses */}
          {rec.iso_clauses?.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-slate-900 mb-2">Relevant ISO Clauses</h4>
              <div className="flex flex-wrap gap-1.5">
                {rec.iso_clauses.map((clause, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs">
                    {clause}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <Button
            onClick={handleApplyRecommendations}
            variant="outline"
            size="sm"
            className="w-full"
          >
            Apply to Mitigation Strategy
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}