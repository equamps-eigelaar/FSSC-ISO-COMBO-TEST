import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Trash2, ShieldAlert } from "lucide-react";

const HAZARD_ICONS = {
  biological: { icon: "🦠", color: "text-rose-600" },
  chemical: { icon: "⚗️", color: "text-orange-600" },
  physical: { icon: "🔩", color: "text-slate-600" },
  radiological: { icon: "☢️", color: "text-purple-600" },
  allergen: { icon: "⚠️", color: "text-amber-600" },
};

const RISK_COLORS = {
  low: "bg-green-50 text-green-700 border-green-200",
  medium: "bg-yellow-50 text-yellow-700 border-yellow-200",
  high: "bg-orange-50 text-orange-700 border-orange-200",
  critical: "bg-rose-50 text-rose-700 border-rose-200",
};

const STATUS_COLORS = {
  identified: "bg-blue-50 text-blue-700",
  under_control: "bg-emerald-50 text-emerald-700",
  requires_action: "bg-rose-50 text-rose-700",
};

const LIKELIHOOD_LABELS = {
  rare: "Rare",
  unlikely: "Unlikely",
  possible: "Possible",
  likely: "Likely",
  almost_certain: "Almost Certain",
};

const SEVERITY_LABELS = {
  negligible: "Negligible",
  minor: "Minor",
  moderate: "Moderate",
  major: "Major",
  catastrophic: "Catastrophic",
};

export default function RiskAssessmentCard({ assessment, onEdit, onDelete }) {
  const hazardConfig = HAZARD_ICONS[assessment.hazard_type];

  return (
    <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{hazardConfig.icon}</span>
            <div>
              <p className="font-medium text-sm text-slate-900 capitalize">{assessment.hazard_type} Hazard</p>
              <p className="text-xs text-slate-500 mt-0.5">{assessment.hazard_description}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-slate-400 hover:text-rose-600"
            onClick={onDelete}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-3">
          <div>
            <p className="text-xs text-slate-400 mb-1">Likelihood</p>
            <Badge variant="outline" className="text-xs border-slate-200 text-slate-600">
              {LIKELIHOOD_LABELS[assessment.likelihood]}
            </Badge>
          </div>
          <div>
            <p className="text-xs text-slate-400 mb-1">Severity</p>
            <Badge variant="outline" className="text-xs border-slate-200 text-slate-600">
              {SEVERITY_LABELS[assessment.severity]}
            </Badge>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <AlertTriangle className={`w-3.5 h-3.5 ${assessment.risk_level === 'critical' || assessment.risk_level === 'high' ? 'text-rose-500' : 'text-slate-400'}`} />
          <Badge className={`${RISK_COLORS[assessment.risk_level]} text-xs border`}>
            {assessment.risk_level.toUpperCase()} Risk
          </Badge>
          {assessment.residual_risk && (
            <>
              <span className="text-xs text-slate-300">→</span>
              <Badge className={`${RISK_COLORS[assessment.residual_risk]} text-xs border`}>
                After: {assessment.residual_risk.toUpperCase()}
              </Badge>
            </>
          )}
          {assessment.is_ccp && (
            <Badge className="bg-amber-100 text-amber-800 border border-amber-300 text-xs gap-1">
              <ShieldAlert className="w-2.5 h-2.5" />
              CCP {assessment.ccp_number ? `· ${assessment.ccp_number}` : ""}
            </Badge>
          )}
          {assessment.is_oprp && (
            <Badge className="bg-blue-100 text-blue-800 border border-blue-300 text-xs gap-1">
              <ShieldAlert className="w-2.5 h-2.5" />
              OPRP {assessment.ccp_number ? `· ${assessment.ccp_number}` : ""}
            </Badge>
          )}
        </div>

        {assessment.is_ccp && assessment.critical_limits && (
          <div className="mb-2">
            <p className="text-xs text-slate-400 mb-1">Critical Limits</p>
            <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 p-2 rounded">{assessment.critical_limits}</p>
          </div>
        )}

        {assessment.mitigation_strategy && (
          <div className="mb-3">
            <p className="text-xs text-slate-400 mb-1">Mitigation Strategy</p>
            <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded">{assessment.mitigation_strategy}</p>
          </div>
        )}

        <div className="flex items-center justify-between">
          <Badge className={`${STATUS_COLORS[assessment.status]} text-xs`}>
            {assessment.status.replace(/_/g, ' ')}
          </Badge>
          <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={onEdit}>
            Edit
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}