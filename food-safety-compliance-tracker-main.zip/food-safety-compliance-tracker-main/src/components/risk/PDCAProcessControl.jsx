import React, { useState } from "react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { ArrowRight, ArrowLeft, ArrowDown, ArrowUp, ExternalLink, ChevronDown, ChevronRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";

/* ─── Colour palette for PDCA phases ───────────────────────────── */
const PHASE = {
  plan:  { bg: "bg-slate-100",  border: "border-slate-400",  label: "bg-slate-600  text-white", text: "text-slate-800" },
  do:    { bg: "bg-blue-50",    border: "border-blue-400",   label: "bg-blue-600   text-white", text: "text-blue-900"  },
  check: { bg: "bg-amber-50",   border: "border-amber-400",  label: "bg-amber-600  text-white", text: "text-amber-900" },
  act:   { bg: "bg-emerald-50", border: "border-emerald-400",label: "bg-emerald-600 text-white",text: "text-emerald-900"},
};

/* ─── Org-level PDCA boxes ──────────────────────────────────────── */
const ORG_PHASES = [
  {
    phase: "plan",
    label: "PLAN (FSMS)",
    clauses: [
      { num: "4", title: "Context of the Organization" },
      { num: "5", title: "Leadership" },
      { num: "6", title: "Planning" },
      { num: "7", title: "Support (incl. control of externally provided processes, products or services)" },
    ],
  },
  {
    phase: "do",
    label: "DO (FSMS)",
    clauses: [{ num: "8", title: "Operation" }],
  },
  {
    phase: "check",
    label: "CHECK (FSMS)",
    clauses: [{ num: "9", title: "Performance Evaluation" }],
  },
  {
    phase: "act",
    label: "ACT (FSMS)",
    clauses: [{ num: "10", title: "Improvement" }],
  },
];

/* ─── Operational PDCA detail ───────────────────────────────────── */
const OP_PLAN_FOUNDATIONS = [
  { label: "PRPs (Prerequisite Programmes)", page: "Requirements", iso: "§8.2" },
  { label: "Traceability System", page: "FoodBatchTraceability", iso: "§8.3" },
  { label: "Emergency Preparedness & Response", page: "ActionItems", iso: "§8.4" },
];

const OP_PLAN_FLOW = [
  { label: "Hazard Analysis", page: "RiskWorkflow", iso: "§8.5.2" },
  { label: "Validation of Control Measures", page: "RiskWorkflow", iso: "§8.5.3" },
  { label: "Hazard Control Plan (HACCP/OPRP)", page: "RiskWorkflow", iso: "§8.5.4" },
  { label: "Verification Planning", page: "InternalAudits", iso: "§8.8.1" },
];

const OP_DO = [
  { label: "Implementation of the PLAN (food safety)", page: "RiskWorkflow", iso: "§8.5" },
  { label: "Control of Monitoring and Measuring", page: "DailyMonitoring", iso: "§8.7" },
  { label: "Control of Product and Process Nonconformities", page: "ActionItems", iso: "§8.9" },
];

const OP_CHECK = [
  { label: "Verification Activities", page: "InternalAudits", iso: "§8.8.2" },
  { label: "Analysis of Results of Verification Activities", page: "ComplianceAudits", iso: "§8.8.2" },
];

const OP_ACT = [
  { label: "Updating of Preliminary Information & Documents specifying the PRPs and the Hazard Control Plan", page: "DocumentRepository", iso: "§8.5 / §8.8" },
];

/* ─── Sub-components ────────────────────────────────────────────── */
function PhaseLabel({ phase, label }) {
  const c = PHASE[phase];
  return (
    <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${c.label}`}>{label}</span>
  );
}

function AppLink({ page, children }) {
  return (
    <Link
      to={createPageUrl(page)}
      className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-800 hover:underline text-[11px] font-medium"
    >
      {children}
      <ExternalLink className="w-2.5 h-2.5" />
    </Link>
  );
}

function FlowItem({ item, showArrow }) {
  return (
    <div className="flex items-center gap-1">
      <div className="bg-white border border-slate-300 rounded px-2 py-1.5 text-center shadow-sm min-w-[110px]">
        <p className="text-[11px] font-semibold text-slate-800 leading-tight">{item.label}</p>
        <div className="flex items-center justify-between mt-1">
          <span className="text-[9px] font-mono text-slate-400">{item.iso}</span>
          <AppLink page={item.page}><span className="text-[9px]">Open</span></AppLink>
        </div>
      </div>
      {showArrow && <ArrowRight className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />}
    </div>
  );
}

function FoundationItem({ item }) {
  return (
    <div className="bg-white border border-slate-300 rounded px-2 py-1.5 flex items-center justify-between gap-2">
      <div>
        <p className="text-[11px] font-semibold text-slate-800">{item.label}</p>
        <span className="text-[9px] font-mono text-slate-400">{item.iso}</span>
      </div>
      <AppLink page={item.page}><span className="text-[9px]">Open</span></AppLink>
    </div>
  );
}

function OperationalItem({ item }) {
  return (
    <div className="bg-white border border-slate-200 rounded px-2.5 py-1.5 flex items-start justify-between gap-2">
      <div className="flex-1">
        <p className="text-[11px] text-slate-700 leading-tight">{item.label}</p>
        <span className="text-[9px] font-mono text-slate-400">{item.iso}</span>
      </div>
      <AppLink page={item.page}><span className="text-[9px]">Open</span></AppLink>
    </div>
  );
}

/* ─── Main component ────────────────────────────────────────────── */
export default function PDCAProcessControl() {
  return (
    <div className="space-y-6">

      {/* Title */}
      <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
        <p className="text-sm font-bold text-slate-800">ISO 22000:2018 — PDCA Process Control Model</p>
        <p className="text-xs text-slate-500 mt-0.5">
          Two-level Plan-Do-Check-Act cycle: organisational FSMS level (§4–§10) and operational food safety level (§8).
          Click any <span className="text-emerald-600 font-medium">Open</span> link to navigate to that module.
        </p>
      </div>

      {/* ── LEVEL 1: Organisational PDCA ── */}
      <div className="border border-slate-300 rounded-xl p-4 bg-white shadow-sm">
        <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 text-center">
          Organizational Planning and Control
        </p>

        {/* Flow row */}
        <div className="flex flex-col sm:flex-row items-stretch gap-2">
          {ORG_PHASES.map((box, i) => {
            const c = PHASE[box.phase];
            return (
              <React.Fragment key={box.phase}>
                <div className={`flex-1 rounded-lg border-2 ${c.border} ${c.bg} p-3`}>
                  <PhaseLabel phase={box.phase} label={box.label} />
                  <ul className="mt-2 space-y-1">
                    {box.clauses.map(cl => (
                      <li key={cl.num} className="flex items-start gap-1 text-[11px]">
                        <span className="font-bold text-slate-600 flex-shrink-0">{cl.num}.</span>
                        <span className={`${c.text} leading-tight`}>{cl.title}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                {i < ORG_PHASES.length - 1 && (
                  <div className="hidden sm:flex items-center">
                    <ArrowRight className="w-5 h-5 text-slate-400" />
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Loop-back arrow label */}
        <div className="mt-2 flex justify-center">
          <span className="text-[10px] text-slate-400 italic">↺ Continual improvement loop — ACT feeds back into PLAN</span>
        </div>
      </div>

      {/* ── LEVEL 2: Operational PDCA ── */}
      <div className="border-2 border-slate-400 rounded-2xl p-4 bg-slate-50 shadow-sm">
        <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 text-center">
          Operational Planning and Control — Clause 8
        </p>

        {/* Top row: PLAN (food safety) */}
        <div className={`rounded-xl border-2 ${PHASE.plan.border} ${PHASE.plan.bg} p-3 mb-3`}>
          <div className="flex items-center gap-2 mb-3">
            <PhaseLabel phase="plan" label="PLAN (food safety)" />
          </div>

          {/* Foundations */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-3">
            {OP_PLAN_FOUNDATIONS.map(item => (
              <FoundationItem key={item.label} item={item} />
            ))}
          </div>

          {/* Horizontal flow */}
          <div className="flex flex-wrap items-center gap-1">
            {OP_PLAN_FLOW.map((item, i) => (
              <FlowItem key={item.label} item={item} showArrow={i < OP_PLAN_FLOW.length - 1} />
            ))}
          </div>
        </div>

        {/* Arrow down to DO */}
        <div className="flex justify-end pr-8 mb-1">
          <ArrowDown className="w-5 h-5 text-slate-500" />
        </div>

        {/* Middle row: DO + CHECK + ACT */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">

          {/* ACT (food safety) */}
          <div className={`rounded-xl border-2 ${PHASE.act.border} ${PHASE.act.bg} p-3 flex flex-col`}>
            <div className="flex items-center gap-2 mb-2">
              <PhaseLabel phase="act" label="ACT (food safety)" />
            </div>
            <div className="flex flex-col gap-1.5 flex-1">
              {OP_ACT.map(item => <OperationalItem key={item.label} item={item} />)}
            </div>
            <div className="flex justify-start mt-2">
              <ArrowUp className="w-4 h-4 text-emerald-500" />
            </div>
          </div>

          {/* CHECK (food safety) */}
          <div className={`rounded-xl border-2 ${PHASE.check.border} ${PHASE.check.bg} p-3 flex flex-col`}>
            <div className="flex items-center gap-2 mb-2">
              <PhaseLabel phase="check" label="CHECK (food safety)" />
            </div>
            <div className="flex flex-col gap-1.5 flex-1">
              {OP_CHECK.map(item => <OperationalItem key={item.label} item={item} />)}
            </div>
            <div className="flex justify-start mt-2">
              <ArrowLeft className="w-4 h-4 text-amber-500" />
            </div>
          </div>

          {/* DO (food safety) */}
          <div className={`rounded-xl border-2 ${PHASE.do.border} ${PHASE.do.bg} p-3 flex flex-col`}>
            <div className="flex items-center gap-2 mb-2">
              <PhaseLabel phase="do" label="DO (food safety)" />
            </div>
            <div className="flex flex-col gap-1.5 flex-1">
              {OP_DO.map(item => <OperationalItem key={item.label} item={item} />)}
            </div>
            <div className="flex justify-end mt-2">
              <ArrowLeft className="w-4 h-4 text-blue-500" />
            </div>
          </div>

        </div>

        {/* Flow labels */}
        <div className="mt-3 flex flex-wrap gap-3 justify-center text-[10px] text-slate-400 italic">
          <span>PLAN → DO (implementation)</span>
          <span>DO → CHECK (verification)</span>
          <span>CHECK → ACT (analysis)</span>
          <span>ACT → PLAN (update & improve)</span>
        </div>
      </div>

      {/* Clause quick-reference */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3">ISO 22000:2018 Clause Quick Reference</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { clause: "§4", title: "Context", phase: "plan" },
            { clause: "§5", title: "Leadership", phase: "plan" },
            { clause: "§6", title: "Planning", phase: "plan" },
            { clause: "§7", title: "Support", phase: "plan" },
            { clause: "§8", title: "Operation", phase: "do" },
            { clause: "§9", title: "Performance Evaluation", phase: "check" },
            { clause: "§10", title: "Improvement", phase: "act" },
            { clause: "§8.5", title: "HACCP / Food Safety Plan", phase: "do" },
          ].map(item => {
            const c = PHASE[item.phase];
            return (
              <div key={item.clause} className={`rounded-lg border ${c.border} ${c.bg} px-3 py-2`}>
                <span className={`text-xs font-mono font-bold ${c.text}`}>{item.clause}</span>
                <p className={`text-[11px] mt-0.5 ${c.text}`}>{item.title}</p>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}