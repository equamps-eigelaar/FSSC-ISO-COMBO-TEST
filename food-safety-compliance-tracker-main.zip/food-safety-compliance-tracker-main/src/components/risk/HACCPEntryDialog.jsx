import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";

const LIKELIHOOD_OPTIONS = [
  { value: "rare", label: "Rare (1)", score: 1 },
  { value: "unlikely", label: "Unlikely (2)", score: 2 },
  { value: "possible", label: "Possible (3)", score: 3 },
  { value: "likely", label: "Likely (4)", score: 4 },
  { value: "almost_certain", label: "Almost Certain (5)", score: 5 },
];

const SEVERITY_OPTIONS = [
  { value: "negligible", label: "Low / Negligible (1)", score: 1 },
  { value: "minor", label: "Minor (2)", score: 2 },
  { value: "moderate", label: "Moderate (3)", score: 3 },
  { value: "major", label: "Major (4)", score: 4 },
  { value: "catastrophic", label: "Extreme / Catastrophic (5)", score: 5 },
];

const RISK_MATRIX = [
  ["L","L","L","M","H"],
  ["L","L","M","H","E"],
  ["L","M","H","E","E"],
  ["M","H","H","E","E"],
  ["H","H","E","E","E"],
];

const RISK_COLORS = {
  L: "bg-emerald-100 text-emerald-800 border-emerald-300",
  M: "bg-yellow-100 text-yellow-800 border-yellow-300",
  H: "bg-orange-100 text-orange-800 border-orange-300",
  E: "bg-red-100 text-red-800 border-red-300",
};

function getRiskLevel(likelihood, severity) {
  const lScore = LIKELIHOOD_OPTIONS.find(o => o.value === likelihood)?.score;
  const sScore = SEVERITY_OPTIONS.find(o => o.value === severity)?.score;
  if (!lScore || !sScore) return null;
  return RISK_MATRIX[lScore - 1][sScore - 1];
}

function mapRiskLevel(code) {
  return { L: "low", M: "medium", H: "high", E: "critical" }[code] || "low";
}

export default function HACCPEntryDialog({ open, onClose, onSaved, entry }) {
  const isEdit = !!entry;
  const [form, setForm] = useState(entry ? {
    process_step: entry.notes?.split("||")[0] || "",
    hazard_source: entry.notes?.split("||")[1] || "P",
    acceptable_level: entry.critical_limits || "",
    hazard_type: entry.hazard_type || "chemical",
    hazard_description: entry.hazard_description || "",
    control_measures: entry.mitigation_strategy || "",
    likelihood: entry.likelihood || "",
    severity: entry.severity || "",
    q1: entry.haccp_decision_tree?.includes("q1") ? "yes" : "",
    q2: "",
    q3: "",
    q4: "",
    monitoring_procedure: entry.monitoring_procedure || "",
    corrective_action_plan: entry.corrective_action_plan || "",
    verification_procedure: entry.verification_procedure || "",
    comments: entry.approval_notes || "",
  } : {
    process_step: "",
    hazard_source: "P",
    acceptable_level: "",
    hazard_type: "chemical",
    hazard_description: "",
    control_measures: "",
    likelihood: "",
    severity: "",
    q1: "",
    q2: "",
    q3: "",
    q4: "",
    monitoring_procedure: "",
    corrective_action_plan: "",
    verification_procedure: "",
    comments: "",
  });
  const [saving, setSaving] = useState(false);

  const riskCode = getRiskLevel(form.likelihood, form.severity);
  const lScore = LIKELIHOOD_OPTIONS.find(o => o.value === form.likelihood)?.score || "-";
  const sScore = SEVERITY_OPTIONS.find(o => o.value === form.severity)?.score || "-";
  const totalScore = (typeof lScore === "number" && typeof sScore === "number") ? lScore * sScore : "-";

  // Determine CCP/OPRP from decision tree
  const isCCP = form.q1 === "yes" && form.q2 === "yes";
  const isOPRP = form.q1 === "yes" && form.q2 === "no" && form.q3 === "yes" && form.q4 === "no";
  const notCCP = form.q1 === "no" || (form.q2 === "no" && form.q3 === "no") || (form.q3 === "yes" && form.q4 === "yes");
  const ccp_oprp_label = isCCP ? "CCP" : isOPRP ? "OPRP" : notCCP ? "Not CCP" : "";

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setSaving(true);
    const data = {
      hazard_type: form.hazard_type,
      hazard_description: form.hazard_description,
      likelihood: form.likelihood,
      severity: form.severity,
      risk_level: riskCode ? mapRiskLevel(riskCode) : "low",
      mitigation_strategy: form.control_measures,
      critical_limits: form.acceptable_level,
      monitoring_procedure: form.monitoring_procedure,
      corrective_action_plan: form.corrective_action_plan,
      verification_procedure: form.verification_procedure,
      is_ccp: isCCP,
      is_oprp: isOPRP,
      status: "identified",
      workflow_status: "draft",
      notes: `${form.process_step}||${form.hazard_source}`,
      approval_notes: form.comments,
      haccp_decision_tree: isCCP ? "q2_yes_ccp" : isOPRP ? "q4_no_oprp" : notCCP ? "not_ccp" : "q1_no",
    };
    if (isEdit) {
      await base44.entities.RiskAssessment.update(entry.id, data);
    } else {
      await base44.entities.RiskAssessment.create({ ...data, requirement_id: "haccp_study" });
    }
    setSaving(false);
    onSaved();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>HACCP Hazard Analysis Entry</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {/* Process Step */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Process Step</Label>
              <Input value={form.process_step} onChange={e => set("process_step", e.target.value)} placeholder="e.g. Receiving, Extrusion, Storage" />
            </div>
            <div className="space-y-1.5">
              <Label>Hazard Source</Label>
              <Select value={form.hazard_source} onValueChange={v => set("hazard_source", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="P">P – Present</SelectItem>
                  <SelectItem value="I">I – Introduced</SelectItem>
                  <SelectItem value="G">G – Grow</SelectItem>
                  <SelectItem value="S">S – Survive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Hazard Type & Description */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Hazard Type</Label>
              <Select value={form.hazard_type} onValueChange={v => set("hazard_type", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="biological">B – Biological</SelectItem>
                  <SelectItem value="chemical">C – Chemical</SelectItem>
                  <SelectItem value="physical">P – Physical</SelectItem>
                  <SelectItem value="allergen">A – Allergen</SelectItem>
                  <SelectItem value="radiological">M – Migration / Radiological</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Acceptable Level of Hazard</Label>
              <Input value={form.acceptable_level} onChange={e => set("acceptable_level", e.target.value)} placeholder="e.g. None detected, <10 CFU/g" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>List Hazards for This Process Step</Label>
            <Textarea value={form.hazard_description} onChange={e => set("hazard_description", e.target.value)} placeholder="Describe specific hazards present at this step..." rows={2} />
          </div>

          <div className="space-y-1.5">
            <Label>Control Measures / Preventive Measures</Label>
            <Textarea value={form.control_measures} onChange={e => set("control_measures", e.target.value)} placeholder="Existing controls and preventive measures..." rows={2} />
          </div>

          {/* Risk Scoring */}
          <div className="bg-slate-50 rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-semibold text-slate-700">Risk Scoring (Principle 4 – Monitoring)</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Likelihood (L)</Label>
                <Select value={form.likelihood} onValueChange={v => set("likelihood", v)}>
                  <SelectTrigger><SelectValue placeholder="Select likelihood" /></SelectTrigger>
                  <SelectContent>
                    {LIKELIHOOD_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Severity (S)</Label>
                <Select value={form.severity} onValueChange={v => set("severity", v)}>
                  <SelectTrigger><SelectValue placeholder="Select severity" /></SelectTrigger>
                  <SelectContent>
                    {SEVERITY_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center gap-4 pt-1">
              <span className="text-sm text-slate-600">Total Score (L × S): <strong>{totalScore}</strong></span>
              {riskCode && (
                <Badge className={RISK_COLORS[riskCode]}>
                  Risk Level: {riskCode === "L" ? "Low" : riskCode === "M" ? "Medium" : riskCode === "H" ? "High" : "Extreme"}
                </Badge>
              )}
              {riskCode && (riskCode === "H" || riskCode === "E") && (
                <Badge className="bg-rose-100 text-rose-800">⚠ Significant Risk</Badge>
              )}
            </div>
          </div>

          {/* CCP Decision Tree */}
          <div className="bg-blue-50 rounded-lg p-4 space-y-3">
            <h3 className="text-sm font-semibold text-blue-800">CCP Decision Tree (Principle 5 – Assessment)</h3>
            <p className="text-xs text-blue-600">Only complete if Significant Risk (High or Extreme)</p>
            <div className="space-y-3">
              <DecisionQ
                q="Q1"
                label="Do control measures exist for this hazard?"
                value={form.q1}
                onChange={v => set("q1", v)}
              />
              {form.q1 === "yes" && (
                <DecisionQ
                  q="Q2"
                  label="Is this step specifically designed to eliminate or reduce the likely occurrence of a hazard to an acceptable level?"
                  value={form.q2}
                  onChange={v => set("q2", v)}
                />
              )}
              {form.q1 === "yes" && form.q2 === "no" && (
                <DecisionQ
                  q="Q3"
                  label="Could contamination occur in excess of acceptable levels or increase to unacceptable levels?"
                  value={form.q3}
                  onChange={v => set("q3", v)}
                />
              )}
              {form.q1 === "yes" && form.q2 === "no" && form.q3 === "yes" && (
                <DecisionQ
                  q="Q4"
                  label="Will a subsequent step eliminate or reduce identified hazard(s) to an acceptable level?"
                  value={form.q4}
                  onChange={v => set("q4", v)}
                />
              )}
            </div>
            {ccp_oprp_label && (
              <div className="pt-1">
                <Badge className={
                  ccp_oprp_label === "CCP" ? "bg-red-100 text-red-800" :
                  ccp_oprp_label === "OPRP" ? "bg-orange-100 text-orange-800" :
                  "bg-slate-100 text-slate-600"
                }>
                  Outcome: {ccp_oprp_label}
                </Badge>
              </div>
            )}
          </div>

          {/* HACCP Control Fields */}
          {(isCCP || isOPRP) && (
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-slate-700">HACCP Control Parameters</h3>
              <div className="space-y-1.5">
                <Label>Monitoring Procedure (What, How, Frequency, Who)</Label>
                <Textarea value={form.monitoring_procedure} onChange={e => set("monitoring_procedure", e.target.value)} rows={2} placeholder="e.g. Temperature checked every 2 hours by QC operator..." />
              </div>
              <div className="space-y-1.5">
                <Label>Corrective Action Plan</Label>
                <Textarea value={form.corrective_action_plan} onChange={e => set("corrective_action_plan", e.target.value)} rows={2} placeholder="Actions when critical limits are exceeded..." />
              </div>
              <div className="space-y-1.5">
                <Label>Verification Procedure</Label>
                <Textarea value={form.verification_procedure} onChange={e => set("verification_procedure", e.target.value)} rows={2} placeholder="Activities to confirm control effectiveness..." />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <Label>Comments / Documentation Reference</Label>
            <Input value={form.comments} onChange={e => set("comments", e.target.value)} placeholder="e.g. COA, SOP reference, form number..." />
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2 border-t">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving || !form.process_step || !form.hazard_description || !form.likelihood || !form.severity} className="bg-emerald-600 hover:bg-emerald-700">
            {saving ? "Saving..." : isEdit ? "Update Entry" : "Add Entry"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function DecisionQ({ q, label, value, onChange }) {
  return (
    <div className="flex items-start gap-3">
      <span className="text-xs font-bold text-blue-700 mt-1 w-6 flex-shrink-0">{q}:</span>
      <div className="flex-1">
        <p className="text-xs text-slate-700 mb-1.5">{label}</p>
        <div className="flex gap-2">
          <button
            onClick={() => onChange("yes")}
            className={`px-3 py-1 text-xs rounded border font-medium transition-colors ${value === "yes" ? "bg-emerald-600 text-white border-emerald-600" : "bg-white text-slate-600 border-slate-300 hover:border-emerald-400"}`}
          >
            Yes
          </button>
          <button
            onClick={() => onChange("no")}
            className={`px-3 py-1 text-xs rounded border font-medium transition-colors ${value === "no" ? "bg-rose-600 text-white border-rose-600" : "bg-white text-slate-600 border-slate-300 hover:border-rose-400"}`}
          >
            No
          </button>
        </div>
      </div>
    </div>
  );
}