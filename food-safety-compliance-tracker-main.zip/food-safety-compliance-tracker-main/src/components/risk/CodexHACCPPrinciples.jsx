import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, CheckCircle2, AlertTriangle, ClipboardList, Shield, FileText, Search, BookOpen } from "lucide-react";

const PRELIMINARY_STEPS = [
  {
    number: "Step 1",
    title: "Assemble the HACCP Team",
    description: "Form a multidisciplinary team with knowledge and expertise in the products, processes, and hazards relevant to the FSMS.",
    requirements: ["Team leader designated", "Cross-functional expertise", "Training records maintained"],
    iso_ref: "ISO 22000:2018 §5.3",
    iso_title: "Food safety team",
  },
  {
    number: "Step 2",
    title: "Describe the Product",
    description: "Provide a full description of all raw materials, ingredients, product-contact materials and end products covered by the HACCP plan.",
    requirements: ["Composition & ingredients", "Physical/chemical properties", "Packaging & shelf life", "Characteristics of end products"],
    iso_ref: "ISO 22000:2018 §8.5.1.2 / §8.5.1.3",
    iso_title: "Characteristics of raw materials & end products",
  },
  {
    number: "Step 3",
    title: "Identify Intended Use",
    description: "Describe the intended use of the product, including the target consumer group, particularly vulnerable populations.",
    requirements: ["Target consumer group", "Likely misuse identified", "Vulnerable groups considered"],
    iso_ref: "ISO 22000:2018 §8.5.1.4",
    iso_title: "Intended use",
  },
  {
    number: "Step 4",
    title: "Construct a Flow Diagram",
    description: "Develop a clear, simple flow diagram covering all steps in the process from raw material receipt to distribution.",
    requirements: ["All process steps included", "Input materials shown", "Rework / recycle loops", "Outsourced steps identified"],
    iso_ref: "ISO 22000:2018 §8.5.1.5",
    iso_title: "Flow diagrams and descriptions of processes",
  },
  {
    number: "Step 5",
    title: "On-Site Confirmation of Flow Diagram",
    description: "Confirm the flow diagram on-site during all stages and hours of operation and amend as appropriate.",
    requirements: ["Walk-through performed", "All shifts verified", "Diagram updated & dated", "Team sign-off"],
    iso_ref: "ISO 22000:2018 §8.5.1.5",
    iso_title: "Flow diagrams and descriptions of processes",
  },
];

const CODEX_PRINCIPLES = [
  {
    number: 1,
    codex_step: "Step 6",
    title: "Conduct a Hazard Analysis",
    icon: Search,
    color: "blue",
    description: "List all potential hazards associated with each step, conduct a hazard analysis and consider any control measures.",
    key_activities: [
      "List all potential hazards at each process step",
      "Evaluate likelihood of occurrence and severity of adverse health effects",
      "Identify control measures for each significant hazard",
      "Validate control measure(s) and combinations of control measures",
    ],
    codex_ref: "CODEX CAC/RCP 1-1969 – Principle 1",
    iso_refs: [
      { clause: "§8.5.2", title: "Hazard analysis" },
      { clause: "§8.5.3", title: "Validation of control measure(s) and combinations of control measure(s)" },
    ],
    in_app: "Hazard Analysis Table",
  },
  {
    number: 2,
    codex_step: "Step 7",
    title: "Determine the Critical Control Points (CCPs)",
    icon: Shield,
    color: "red",
    description: "Identify the point(s), step(s) or procedure(s) at which control can be applied to prevent, eliminate or reduce a food safety hazard to an acceptable level.",
    key_activities: [
      "Apply the HACCP Decision Tree to each significant hazard",
      "Distinguish CCPs from OPRPs",
      "Assign a CCP number to each identified CCP",
      "Document the rationale for each determination",
    ],
    codex_ref: "CODEX CAC/RCP 1-1969 – Principle 2",
    iso_refs: [
      { clause: "§8.5.4", title: "Hazard control plan" },
    ],
    in_app: "CCP / OPRP Register",
  },
  {
    number: 3,
    codex_step: "Step 8",
    title: "Establish Critical Limits",
    icon: AlertTriangle,
    color: "orange",
    description: "Establish critical limits for each CCP that separate the acceptable from the unacceptable to prevent, eliminate or reduce a food safety hazard.",
    key_activities: [
      "Define measurable critical limits (temperature, pH, time, etc.)",
      "Base limits on scientific evidence or regulatory requirements",
      "Include operational limits where applicable",
      "Document the basis for each critical limit",
    ],
    codex_ref: "CODEX CAC/RCP 1-1969 – Principle 3",
    iso_refs: [
      { clause: "§8.5.4", title: "Hazard control plan" },
    ],
    in_app: "CCP / OPRP Register → Critical Limits field",
  },
  {
    number: 4,
    codex_step: "Step 9",
    title: "Establish a Monitoring System",
    icon: ClipboardList,
    color: "amber",
    description: "Establish a system to monitor control of each CCP by scheduled testing or observations to ensure each CCP is under control.",
    key_activities: [
      "Define what will be monitored at each CCP",
      "Specify monitoring frequency and methods",
      "Assign monitoring responsibility to named persons",
      "Ensure monitoring records are maintained",
    ],
    codex_ref: "CODEX CAC/RCP 1-1969 – Principle 4",
    iso_refs: [
      { clause: "§8.5.4.3", title: "Monitoring systems at CCPs and for OPRPs" },
    ],
    in_app: "Daily Monitoring → CCP log templates",
  },
  {
    number: 5,
    codex_step: "Step 10",
    title: "Establish Corrective Actions",
    icon: CheckCircle2,
    color: "emerald",
    description: "Establish the corrective actions to be taken when monitoring indicates that a CCP is not under control, ensuring the product affected is identified and handled.",
    key_activities: [
      "Define corrective actions for each CCP deviation",
      "Specify who is responsible for corrective actions",
      "Determine disposition of potentially unsafe product",
      "Record all deviations and corrective actions taken",
    ],
    codex_ref: "CODEX CAC/RCP 1-1969 – Principle 5",
    iso_refs: [
      { clause: "§8.5.4", title: "Hazard control plan" },
      { clause: "§8.9.2", title: "Corrections" },
      { clause: "§8.9.3", title: "Corrective actions" },
    ],
    in_app: "Action Items → CCP corrective actions",
  },
  {
    number: 6,
    codex_step: "Step 11",
    title: "Establish Verification Procedures",
    icon: CheckCircle2,
    color: "purple",
    description: "Establish procedures for verification to confirm that the HACCP system is working effectively and that the hazard analysis is still valid.",
    key_activities: [
      "Audit CCPs against the HACCP plan",
      "Review monitoring records and deviations",
      "Verify critical limits are scientifically validated",
      "Conduct periodic reassessment of the full HACCP system",
    ],
    codex_ref: "CODEX CAC/RCP 1-1969 – Principle 6",
    iso_refs: [
      { clause: "§8.7", title: "Control of monitoring and measuring" },
      { clause: "§8.8", title: "Verification related to PRPs and the hazard control plan" },
      { clause: "§9.2", title: "Internal audit" },
    ],
    in_app: "Internal Audits → HACCP verification audit",
  },
  {
    number: 7,
    codex_step: "Step 12",
    title: "Establish Documentation & Record Keeping",
    icon: FileText,
    color: "slate",
    description: "Establish documentation and record keeping procedures appropriate to the nature and size of the operation to demonstrate effective application of the HACCP system.",
    key_activities: [
      "Document the HACCP plan including hazard analysis",
      "Maintain CCP monitoring records",
      "Record deviations and corrective actions",
      "Keep verification activities and results",
    ],
    codex_ref: "CODEX CAC/RCP 1-1969 – Principle 7",
    iso_refs: [
      { clause: "§7.5", title: "Documented information" },
    ],
    in_app: "Document Repository → HACCP documentation",
  },
];

const COLOR_MAP = {
  blue:    { badge: "bg-blue-100 text-blue-800 border-blue-200",   header: "bg-blue-50 border-blue-200",   num: "bg-blue-600 text-white" },
  red:     { badge: "bg-red-100 text-red-800 border-red-200",     header: "bg-red-50 border-red-200",     num: "bg-red-600 text-white" },
  orange:  { badge: "bg-orange-100 text-orange-800 border-orange-200", header: "bg-orange-50 border-orange-200", num: "bg-orange-600 text-white" },
  amber:   { badge: "bg-amber-100 text-amber-800 border-amber-200", header: "bg-amber-50 border-amber-200", num: "bg-amber-600 text-white" },
  emerald: { badge: "bg-emerald-100 text-emerald-800 border-emerald-200", header: "bg-emerald-50 border-emerald-200", num: "bg-emerald-600 text-white" },
  purple:  { badge: "bg-purple-100 text-purple-800 border-purple-200", header: "bg-purple-50 border-purple-200", num: "bg-purple-600 text-white" },
  slate:   { badge: "bg-slate-100 text-slate-700 border-slate-200", header: "bg-slate-50 border-slate-200", num: "bg-slate-700 text-white" },
};

function PrincipleCard({ principle }) {
  const [expanded, setExpanded] = useState(false);
  const c = COLOR_MAP[principle.color];
  const Icon = principle.icon;

  return (
    <Card className={`border shadow-sm overflow-hidden ${c.header}`}>
      <button className="w-full text-left" onClick={() => setExpanded(!expanded)}>
        <div className="flex items-center gap-4 p-4">
          <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${c.num}`}>
            {principle.number}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-sm text-slate-900">{principle.title}</span>
              <Badge className={`text-[10px] border ${c.badge}`}>{principle.codex_step}</Badge>
            </div>
            <div className="flex flex-wrap gap-1 mt-1">
              {principle.iso_refs.map(r => (
                <span key={r.clause} className="text-[10px] text-slate-500 bg-white border border-slate-200 rounded px-1.5 py-0.5">{r.clause} {r.title}</span>
              ))}
            </div>
          </div>
          <div className="flex-shrink-0">
            {expanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
          </div>
        </div>
      </button>

      {expanded && (
        <div className="px-4 pb-4 border-t border-slate-200 bg-white">
          <p className="text-sm text-slate-600 mt-3 leading-relaxed">{principle.description}</p>
          <div className="mt-3">
            <p className="text-xs font-semibold text-slate-700 mb-1.5">Key Activities</p>
            <ul className="space-y-1">
              {principle.key_activities.map((a, i) => (
                <li key={i} className="flex items-start gap-2 text-xs text-slate-600">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                  {a}
                </li>
              ))}
            </ul>
          </div>
          <div className="mt-3">
            <p className="text-xs font-semibold text-slate-700 mb-1.5">ISO 22000:2018 Clauses</p>
            <div className="space-y-1">
              {principle.iso_refs.map(r => (
                <div key={r.clause} className="flex items-center gap-2 text-xs">
                  <span className="font-mono font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded">{r.clause}</span>
                  <span className="text-slate-600">{r.title}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <span className="text-[11px] font-medium text-slate-500">In this app:</span>
            <Badge variant="outline" className="text-[11px]">{principle.in_app}</Badge>
          </div>
        </div>
      )}
    </Card>
  );
}

function PreliminaryStepCard({ step }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <Card className="border border-slate-200 shadow-sm">
      <button className="w-full text-left" onClick={() => setExpanded(!expanded)}>
        <div className="flex items-center gap-3 p-3">
          <div className="w-14 h-8 rounded-full bg-slate-700 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
            {step.number}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-800">{step.title}</p>
            <p className="text-[11px] text-slate-400">{step.iso_ref}</p>
          </div>
          {expanded ? <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0" /> : <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />}
        </div>
      </button>
      {expanded && (
        <div className="px-4 pb-3 border-t border-slate-100 bg-slate-50">
          <p className="text-xs text-slate-600 mt-2">{step.description}</p>
          <p className="text-[11px] font-medium text-slate-500 mt-2">ISO clause: <span className="font-mono text-slate-700">{step.iso_ref}</span> — {step.iso_title}</p>
          <ul className="mt-2 space-y-1">
            {step.requirements.map((r, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-slate-500">
                <CheckCircle2 className="w-3 h-3 text-emerald-500 flex-shrink-0" />
                {r}
              </li>
            ))}
          </ul>
        </div>
      )}
    </Card>
  );
}

export default function CodexHACCPPrinciples() {
  return (
    <div className="space-y-6">
      {/* Header banner */}
      <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 flex items-start gap-3">
        <BookOpen className="w-5 h-5 text-emerald-700 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-semibold text-emerald-800">CODEX Alimentarius — HACCP System & Guidelines</p>
          <p className="text-xs text-emerald-700 mt-0.5">
            Based on <strong>CAC/RCP 1-1969 (Rev. 2020)</strong> — 5 Preliminary Steps (Steps 1–5) + 7 Principles (Steps 6–12).
            Mapped to <strong>ISO 22000:2018</strong> clauses per the normative annex.
          </p>
        </div>
      </div>

      {/* Cross-reference table */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">CODEX Steps → ISO 22000:2018 Clause Cross-Reference</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-700 text-white">
                  <th className="px-3 py-2 text-left font-medium">CODEX Principle</th>
                  <th className="px-3 py-2 text-left font-medium">Application Step</th>
                  <th className="px-3 py-2 text-left font-medium">ISO 22000:2018 Clause</th>
                  <th className="px-3 py-2 text-left font-medium">Clause Title</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { principle: "—", step: "Step 1", clause: "5.3", title: "Food safety team" },
                  { principle: "—", step: "Step 2", clause: "8.5.1.2", title: "Characteristics of raw materials, ingredients and product-contact materials" },
                  { principle: "—", step: "Step 2", clause: "8.5.1.3", title: "Characteristics of end products" },
                  { principle: "—", step: "Step 3", clause: "8.5.1.4", title: "Intended use" },
                  { principle: "—", step: "Step 4 / 5", clause: "8.5.1.5", title: "Flow diagrams and descriptions of processes" },
                  { principle: "Principle 1", step: "Step 6", clause: "8.5.2", title: "Hazard analysis" },
                  { principle: "Principle 1", step: "Step 6", clause: "8.5.3", title: "Validation of control measure(s) and combinations of control measures" },
                  { principle: "Principle 2", step: "Step 7", clause: "8.5.4", title: "Hazard control plan" },
                  { principle: "Principle 3", step: "Step 8", clause: "8.5.4", title: "Hazard control plan" },
                  { principle: "Principle 4", step: "Step 9", clause: "8.5.4.3", title: "Monitoring systems at CCPs and for OPRPs" },
                  { principle: "Principle 5", step: "Step 10", clause: "8.5.4", title: "Hazard control plan" },
                  { principle: "Principle 5", step: "Step 10", clause: "8.9.2", title: "Corrections" },
                  { principle: "Principle 5", step: "Step 10", clause: "8.9.3", title: "Corrective actions" },
                  { principle: "Principle 6", step: "Step 11", clause: "8.7", title: "Control of monitoring and measuring" },
                  { principle: "Principle 6", step: "Step 11", clause: "8.8", title: "Verification related to PRPs and the hazard control plan" },
                  { principle: "Principle 6", step: "Step 11", clause: "9.2", title: "Internal audit" },
                  { principle: "Principle 7", step: "Step 12", clause: "7.5", title: "Documented information" },
                ].map((row, i) => (
                  <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50"}>
                    <td className="px-3 py-2 font-medium text-slate-700">{row.principle}</td>
                    <td className="px-3 py-2 text-slate-600">{row.step}</td>
                    <td className="px-3 py-2 font-mono font-semibold text-emerald-700">{row.clause}</td>
                    <td className="px-3 py-2 text-slate-600">{row.title}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Preliminary Steps */}
      <div>
        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide mb-3">
          Preliminary Steps — Steps 1 to 5
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {PRELIMINARY_STEPS.map(step => (
            <PreliminaryStepCard key={step.number} step={step} />
          ))}
        </div>
      </div>

      {/* 7 Principles */}
      <div>
        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide mb-3">
          The 7 CODEX HACCP Principles — Steps 6 to 12
        </h3>
        <div className="space-y-3">
          {CODEX_PRINCIPLES.map(p => (
            <PrincipleCard key={p.number} principle={p} />
          ))}
        </div>
      </div>

      {/* Bibliography */}
      <Card className="border border-slate-200 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <FileText className="w-4 h-4 text-slate-500" />
            Bibliography — Referenced Standards & Publications
          </CardTitle>
          <p className="text-xs text-slate-500">Normative and informative references supporting ISO 22000:2018 and CODEX HACCP compliance</p>
        </CardHeader>
        <CardContent>
          <ol className="space-y-2">
            {[
              { ref: "[1]", citation: "ISO 9000:2015", title: "Quality management systems — Fundamentals and vocabulary" },
              { ref: "[2]", citation: "ISO 9001:2015", title: "Quality management systems — Requirements" },
              { ref: "[3]", citation: "ISO 19011", title: "Guidelines for auditing management systems" },
              { ref: "[4]", citation: "ISO/TS 22002 (all parts)", title: "Prerequisite programmes on food safety" },
              { ref: "[5]", citation: "ISO/TS 22003", title: "Food safety management systems — Requirements for bodies providing audit and certification of food safety management systems" },
              { ref: "[6]", citation: "ISO 22005", title: "Traceability in the feed and food chain — General principles and basic requirements for system design and implementation" },
              { ref: "[7]", citation: "ISO Guide 73:2009", title: "Risk management — Vocabulary" },
              { ref: "[8]", citation: "CAC/GL 60-2006", title: "Principles for Traceability / Product Tracing as a Tool Within a Food Inspection and Certification System" },
              { ref: "[9]", citation: "CAC/GL 81-2013", title: "Guidance for governments on prioritizing hazards in feed" },
              { ref: "[10]", citation: "CAC/RCP 1-1969", title: "General Principles of Food Hygiene" },
              { ref: "[11]", citation: "Joint FAO/WHO Food Standards Programme", title: "Codex Alimentarius Commission: Procedural Manual. Twenty-fifth edition, 2016" },
              { ref: "[12]", citation: "Codex Alimentarius", title: "Available from:", url: "http://www.fao.org/fao-who-codexalimentarius/en/" },
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-xs text-slate-600 border-b border-slate-100 pb-2 last:border-0 last:pb-0">
                <span className="font-mono font-bold text-slate-500 flex-shrink-0 w-8">{item.ref}</span>
                <span>
                  <span className="font-semibold text-slate-800">{item.citation}</span>
                  {", "}
                  {item.url ? (
                    <>
                      {item.title}{" "}
                      <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:underline break-all">{item.url}</a>
                    </>
                  ) : (
                    item.title
                  )}
                </span>
              </li>
            ))}
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}