import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  Plus, ChevronDown, ChevronUp, Pencil, Trash2, ArrowRight,
  AlertTriangle, Shield, Layers, CheckCircle2, FlaskConical, X
} from "lucide-react";
import { toast } from "sonner";

const PROCESS_TYPES = [
  "receiving", "storage", "preparation", "processing",
  "packaging", "labelling", "distribution", "cleaning", "other"
];

const STEP_TYPES = {
  operation:  { label: "Operation",   color: "bg-blue-100 text-blue-700",    icon: Layers },
  inspection: { label: "Inspection",  color: "bg-amber-100 text-amber-700",  icon: CheckCircle2 },
  ccp:        { label: "CCP",         color: "bg-rose-100 text-rose-700",    icon: AlertTriangle },
  oprp:       { label: "OPRP",        color: "bg-orange-100 text-orange-700",icon: Shield },
  transport:  { label: "Transport",   color: "bg-slate-100 text-slate-600",  icon: ArrowRight },
  storage:    { label: "Storage",     color: "bg-indigo-100 text-indigo-700",icon: Layers },
  decision:   { label: "Decision",    color: "bg-violet-100 text-violet-700",icon: FlaskConical },
};

const STATUS_COLOR = {
  draft:          "bg-slate-100 text-slate-600",
  active:         "bg-emerald-100 text-emerald-700",
  review_needed:  "bg-amber-100 text-amber-700",
  archived:       "bg-slate-200 text-slate-500",
};

const EMPTY_STEP = { id: "", name: "", description: "", step_type: "operation", hazards: "", controls: "", critical_limits: "", monitoring: "", notes: "", linked_requirement_ids: [], linked_risk_ids: [] };
const EMPTY_PROCESS = { name: "", process_type: "processing", description: "", status: "draft", owner: "", steps: [] };

export default function ManufacturingProcessTab({ requirements = [], risks = [] }) {
  const [selected, setSelected] = useState(null);
  const [showProcessDialog, setShowProcessDialog] = useState(false);
  const [editingProcess, setEditingProcess] = useState(null);
  const [expandedSteps, setExpandedSteps] = useState(new Set());
  const [editingStepIdx, setEditingStepIdx] = useState(null);
  const [stepDraft, setStepDraft] = useState(null);
  const queryClient = useQueryClient();

  const { data: processes = [], isLoading } = useQuery({
    queryKey: ["manufacturing-processes"],
    queryFn: () => base44.entities.ManufacturingProcess.list("-created_date", 100),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => data.id
      ? base44.entities.ManufacturingProcess.update(data.id, data)
      : base44.entities.ManufacturingProcess.create(data),
    onSuccess: (saved) => {
      queryClient.invalidateQueries({ queryKey: ["manufacturing-processes"] });
      toast.success("Process saved");
      setShowProcessDialog(false);
      setEditingProcess(null);
      if (selected?.id === saved?.id) setSelected(saved);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ManufacturingProcess.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["manufacturing-processes"] });
      toast.success("Process deleted");
      setSelected(null);
    },
  });

  const openNew = () => { setEditingProcess({ ...EMPTY_PROCESS }); setShowProcessDialog(true); };
  const openEdit = (p, e) => { e.stopPropagation(); setEditingProcess({ ...p }); setShowProcessDialog(true); };

  const toggleStep = (idx) => {
    const next = new Set(expandedSteps);
    next.has(idx) ? next.delete(idx) : next.add(idx);
    setExpandedSteps(next);
  };

  // --- Step editing on the detail view ---
  const addStep = () => {
    const newStep = { ...EMPTY_STEP, id: Date.now().toString() };
    const updated = { ...selected, steps: [...(selected.steps || []), newStep] };
    setSelected(updated);
    setEditingStepIdx((updated.steps.length - 1));
    setStepDraft({ ...newStep });
  };

  const startEditStep = (idx) => {
    setEditingStepIdx(idx);
    setStepDraft({ ...selected.steps[idx] });
  };

  const cancelEditStep = () => { setEditingStepIdx(null); setStepDraft(null); };

  const saveStep = () => {
    const steps = selected.steps.map((s, i) => i === editingStepIdx ? stepDraft : s);
    const updated = { ...selected, steps };
    saveMutation.mutate(updated);
    setSelected(updated);
    setEditingStepIdx(null);
    setStepDraft(null);
  };

  const deleteStep = (idx) => {
    const steps = selected.steps.filter((_, i) => i !== idx);
    const updated = { ...selected, steps };
    saveMutation.mutate(updated);
    setSelected(updated);
  };

  // list view
  if (!selected) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-slate-500">{processes.length} process{processes.length !== 1 ? "es" : ""} mapped</p>
          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={openNew}>
            <Plus className="w-4 h-4 mr-1.5" /> Add Process
          </Button>
        </div>

        {isLoading ? (
          <div className="py-12 flex justify-center"><div className="w-7 h-7 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" /></div>
        ) : processes.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-16 text-center">
              <Layers className="w-12 h-12 mx-auto text-slate-200 mb-3" />
              <p className="text-slate-500 font-medium">No manufacturing processes mapped yet</p>
              <p className="text-xs text-slate-400 mt-1 mb-4">Map your production flows and identify CCPs / OPRPs at each step</p>
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={openNew}><Plus className="w-4 h-4 mr-1" />Add Process</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {processes.map(p => {
              const ccps = p.steps?.filter(s => s.step_type === "ccp").length || 0;
              const oprps = p.steps?.filter(s => s.step_type === "oprp").length || 0;
              return (
                <Card key={p.id} className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelected(p)}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <p className="font-semibold text-slate-900 text-sm">{p.name}</p>
                        <p className="text-xs text-slate-400 capitalize">{p.process_type?.replace("_", " ")}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Badge className={`text-[10px] px-1.5 py-0 ${STATUS_COLOR[p.status]}`}>{p.status?.replace("_", " ")}</Badge>
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={(e) => openEdit(p, e)}><Pencil className="w-3 h-3" /></Button>
                      </div>
                    </div>
                    {p.description && <p className="text-xs text-slate-500 mb-3 line-clamp-2">{p.description}</p>}
                    <div className="flex flex-wrap gap-2 text-xs">
                      <span className="text-slate-500">{p.steps?.length || 0} steps</span>
                      {ccps > 0 && <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700">{ccps} CCP{ccps > 1 ? "s" : ""}</span>}
                      {oprps > 0 && <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-700">{oprps} OPRP{oprps > 1 ? "s" : ""}</span>}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <ProcessDialog
          open={showProcessDialog}
          process={editingProcess}
          onClose={() => { setShowProcessDialog(false); setEditingProcess(null); }}
          onSave={(data) => saveMutation.mutate(data)}
          saving={saveMutation.isPending}
        />
      </div>
    );
  }

  // detail / step map view
  const steps = selected.steps || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => setSelected(null)} className="text-xs text-slate-500 hover:text-slate-700 hover:bg-slate-100 px-2 py-1 rounded">← Back</button>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="font-semibold text-slate-900">{selected.name}</h2>
            <Badge className={`text-[10px] px-1.5 py-0 ${STATUS_COLOR[selected.status]}`}>{selected.status?.replace("_", " ")}</Badge>
            <span className="text-xs text-slate-400 capitalize">{selected.process_type?.replace("_", " ")}</span>
          </div>
          {selected.description && <p className="text-xs text-slate-500 mt-0.5">{selected.description}</p>}
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-rose-500 hover:bg-rose-50" onClick={() => { if (confirm("Delete this process?")) deleteMutation.mutate(selected.id); }}>
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      {/* Visual flow */}
      <div className="space-y-2">
        {steps.map((step, idx) => {
          const cfg = STEP_TYPES[step.step_type] || STEP_TYPES.operation;
          const Icon = cfg.icon;
          const isEditing = editingStepIdx === idx;

          return (
            <div key={step.id || idx} className="flex gap-3">
              {/* Connector */}
              <div className="flex flex-col items-center w-8 shrink-0">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${cfg.color} font-bold text-xs`}>{idx + 1}</div>
                {idx < steps.length - 1 && <div className="w-0.5 flex-1 bg-slate-200 my-1" />}
              </div>

              <Card className={`flex-1 border shadow-sm ${step.step_type === "ccp" ? "border-rose-200" : step.step_type === "oprp" ? "border-orange-200" : "border-slate-100"}`}>
                {!isEditing ? (
                  <>
                    <div className="flex items-center gap-2 p-3 cursor-pointer" onClick={() => toggleStep(idx)}>
                      <Icon className={`w-4 h-4 shrink-0 ${step.step_type === "ccp" ? "text-rose-600" : step.step_type === "oprp" ? "text-orange-500" : "text-slate-400"}`} />
                      <span className="flex-1 text-sm font-medium text-slate-800">{step.name || <span className="italic text-slate-400">Unnamed step</span>}</span>
                      <Badge className={`text-[10px] px-1.5 py-0 ${cfg.color} shrink-0`}>{cfg.label}</Badge>
                      <div className="flex gap-1 shrink-0">
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={(e) => { e.stopPropagation(); startEditStep(idx); }}><Pencil className="w-3 h-3" /></Button>
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-rose-400 hover:bg-rose-50" onClick={(e) => { e.stopPropagation(); deleteStep(idx); }}><Trash2 className="w-3 h-3" /></Button>
                        {expandedSteps.has(idx) ? <ChevronUp className="w-3.5 h-3.5 text-slate-400" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-400" />}
                      </div>
                    </div>

                    {expandedSteps.has(idx) && (
                      <CardContent className="pt-0 pb-3 px-3 space-y-2 border-t border-slate-100 text-xs text-slate-600">
                        {step.description && <p><span className="font-medium">Description:</span> {step.description}</p>}
                        {step.hazards && <p><span className="font-medium text-rose-600">Hazards:</span> {step.hazards}</p>}
                        {step.controls && <p><span className="font-medium text-emerald-700">Controls:</span> {step.controls}</p>}
                        {step.critical_limits && <p><span className="font-medium">Critical Limits:</span> {step.critical_limits}</p>}
                        {step.monitoring && <p><span className="font-medium">Monitoring:</span> {step.monitoring}</p>}
                        {step.notes && <p className="text-slate-400 italic">{step.notes}</p>}
                        {step.linked_requirement_ids?.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {step.linked_requirement_ids.map(id => {
                              const req = requirements.find(r => r.id === id);
                              return req ? <span key={id} className="px-1.5 py-0.5 rounded bg-blue-50 text-blue-700">{req.clause_number}</span> : null;
                            })}
                          </div>
                        )}
                      </CardContent>
                    )}
                  </>
                ) : (
                  <StepEditor
                    step={stepDraft}
                    onChange={setStepDraft}
                    requirements={requirements}
                    risks={risks}
                    onSave={saveStep}
                    onCancel={cancelEditStep}
                    saving={saveMutation.isPending}
                  />
                )}
              </Card>
            </div>
          );
        })}

        {/* Add step button */}
        <div className="flex gap-3">
          <div className="w-8 shrink-0" />
          <Button variant="outline" size="sm" className="w-full border-dashed text-slate-500" onClick={addStep}>
            <Plus className="w-3.5 h-3.5 mr-1.5" /> Add Step
          </Button>
        </div>
      </div>

      <ProcessDialog
        open={showProcessDialog}
        process={editingProcess}
        onClose={() => { setShowProcessDialog(false); setEditingProcess(null); }}
        onSave={(data) => saveMutation.mutate(data)}
        saving={saveMutation.isPending}
      />
    </div>
  );
}

function StepEditor({ step, onChange, requirements, risks, onSave, onCancel, saving }) {
  const set = (field, val) => onChange(prev => ({ ...prev, [field]: val }));

  return (
    <div className="p-3 space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">Step Name *</Label>
          <Input className="mt-1 h-8 text-xs" value={step.name} onChange={e => set("name", e.target.value)} placeholder="e.g. Mixing" />
        </div>
        <div>
          <Label className="text-xs">Type</Label>
          <Select value={step.step_type} onValueChange={v => set("step_type", v)}>
            <SelectTrigger className="mt-1 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(STEP_TYPES).map(([k, c]) => (
                <SelectItem key={k} value={k}><span className={`px-1 rounded text-xs ${c.color}`}>{c.label}</span></SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label className="text-xs">Description</Label>
        <Textarea className="mt-1 text-xs" rows={2} value={step.description || ""} onChange={e => set("description", e.target.value)} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs text-rose-600">Hazards (B/C/P)</Label>
          <Textarea className="mt-1 text-xs" rows={2} value={step.hazards || ""} onChange={e => set("hazards", e.target.value)} placeholder="Biological, Chemical, Physical…" />
        </div>
        <div>
          <Label className="text-xs text-emerald-700">Control Measures</Label>
          <Textarea className="mt-1 text-xs" rows={2} value={step.controls || ""} onChange={e => set("controls", e.target.value)} />
        </div>
      </div>
      {(step.step_type === "ccp" || step.step_type === "oprp") && (
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-xs">Critical Limits</Label>
            <Input className="mt-1 h-8 text-xs" value={step.critical_limits || ""} onChange={e => set("critical_limits", e.target.value)} placeholder="e.g. ≥72°C for 15s" />
          </div>
          <div>
            <Label className="text-xs">Monitoring</Label>
            <Input className="mt-1 h-8 text-xs" value={step.monitoring || ""} onChange={e => set("monitoring", e.target.value)} placeholder="e.g. Continuous temp logger" />
          </div>
        </div>
      )}
      <div>
        <Label className="text-xs">Linked Requirements</Label>
        <div className="mt-1 flex flex-wrap gap-1 max-h-24 overflow-y-auto">
          {requirements.map(r => {
            const linked = step.linked_requirement_ids?.includes(r.id);
            return (
              <button
                key={r.id}
                type="button"
                className={`text-[10px] px-1.5 py-0.5 rounded border transition-colors ${linked ? "bg-blue-100 border-blue-300 text-blue-700" : "bg-white border-slate-200 text-slate-500 hover:border-slate-300"}`}
                onClick={() => {
                  const ids = linked ? step.linked_requirement_ids.filter(i => i !== r.id) : [...(step.linked_requirement_ids || []), r.id];
                  set("linked_requirement_ids", ids);
                }}
              >
                {r.clause_number}
              </button>
            );
          })}
        </div>
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="ghost" size="sm" onClick={onCancel}><X className="w-3.5 h-3.5 mr-1" />Cancel</Button>
        <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" disabled={saving || !step.name} onClick={onSave}>Save Step</Button>
      </div>
    </div>
  );
}

function ProcessDialog({ open, process, onClose, onSave, saving }) {
  const [form, setForm] = useState(process || EMPTY_PROCESS);
  React.useEffect(() => { if (process) setForm(process); }, [process]);
  const set = (f, v) => setForm(p => ({ ...p, [f]: v }));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>{form?.id ? "Edit Process" : "New Manufacturing Process"}</DialogTitle></DialogHeader>
        <div className="space-y-3 py-2">
          <div>
            <Label className="text-xs">Process Name *</Label>
            <Input className="mt-1" value={form.name || ""} onChange={e => set("name", e.target.value)} placeholder="e.g. Blow Moulding Line A" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Type</Label>
              <Select value={form.process_type} onValueChange={v => set("process_type", v)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{PROCESS_TYPES.map(t => <SelectItem key={t} value={t} className="capitalize">{t.replace("_", " ")}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={v => set("status", v)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="review_needed">Review Needed</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label className="text-xs">Description</Label>
            <Textarea className="mt-1" rows={2} value={form.description || ""} onChange={e => set("description", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs">Process Owner (email)</Label>
            <Input className="mt-1" value={form.owner || ""} onChange={e => set("owner", e.target.value)} placeholder="email@company.com" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" disabled={saving || !form.name} onClick={() => onSave(form)}>
            {saving ? "Saving…" : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}