import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import InitiateRiskDialog from "./InitiateRiskDialog";

export default function RequirementsNeedingRisk({ requirements, risks }) {
  const [showInitiate, setShowInitiate] = useState(false);
  const [selectedReqId, setSelectedReqId] = useState(null);

  // Find requirements that don't have approved risk assessments
  const requirementsNeedingRisk = requirements.filter(req => {
    const reqRisks = risks.filter(r => r.requirement_id === req.id);
    const hasApprovedRisk = reqRisks.some(r => r.workflow_status === "approved");
    return !hasApprovedRisk && (req.priority === "critical" || req.priority === "high");
  });

  const handleInitiate = (reqId) => {
    setSelectedReqId(reqId);
    setShowInitiate(true);
  };

  return (
    <>
      <Card className="border-0 shadow-sm">
        <CardHeader className="border-b border-slate-100">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <CardTitle className="text-sm font-semibold">
              Requirements Needing Risk Assessment
            </CardTitle>
            <Badge variant="secondary" className="ml-auto">
              {requirementsNeedingRisk.length}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {requirementsNeedingRisk.length === 0 ? (
            <div className="p-12 text-center text-slate-500 text-sm">
              All critical and high priority requirements have approved risk assessments
            </div>
          ) : (
            <div className="divide-y divide-slate-50">
              {requirementsNeedingRisk.map(req => {
                const reqRisks = risks.filter(r => r.requirement_id === req.id);
                const hasDraft = reqRisks.some(r => r.workflow_status === "draft");
                const hasPending = reqRisks.some(r => r.workflow_status === "pending_review");

                return (
                  <div key={req.id} className="p-4 hover:bg-slate-50 transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-mono font-bold text-slate-400">
                            {req.clause_number}
                          </span>
                          <Badge
                            variant="outline"
                            className={
                              req.priority === "critical"
                                ? "bg-rose-50 text-rose-600 border-rose-200"
                                : "bg-orange-50 text-orange-600 border-orange-200"
                            }
                          >
                            {req.priority}
                          </Badge>
                          {hasDraft && (
                            <Badge variant="outline" className="bg-slate-100 text-slate-600 text-xs">
                              Draft exists
                            </Badge>
                          )}
                          {hasPending && (
                            <Badge variant="outline" className="bg-amber-50 text-amber-700 text-xs">
                              Pending review
                            </Badge>
                          )}
                        </div>
                        <h3 className="text-sm font-medium text-slate-900 mb-1">
                          {req.clause_title}
                        </h3>
                        {req.description && (
                          <p className="text-xs text-slate-500 line-clamp-2">
                            {req.description}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Link to={createPageUrl("RequirementDetail") + `?id=${req.id}`}>
                          <Button size="sm" variant="outline">
                            View
                          </Button>
                        </Link>
                        <Button
                          size="sm"
                          onClick={() => handleInitiate(req.id)}
                          className="bg-emerald-600 hover:bg-emerald-700"
                        >
                          <Plus className="w-3 h-3 mr-1" />
                          Initiate
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <InitiateRiskDialog
        open={showInitiate}
        onClose={() => {
          setShowInitiate(false);
          setSelectedReqId(null);
        }}
      />
    </>
  );
}