import React, { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const LIKELIHOOD_LEVELS = [
  { value: "rare", label: "Rare", index: 0 },
  { value: "unlikely", label: "Unlikely", index: 1 },
  { value: "possible", label: "Possible", index: 2 },
  { value: "likely", label: "Likely", index: 3 },
  { value: "almost_certain", label: "Almost Certain", index: 4 },
];

const SEVERITY_LEVELS = [
  { value: "negligible", label: "Negligible", index: 0 },
  { value: "minor", label: "Minor", index: 1 },
  { value: "moderate", label: "Moderate", index: 2 },
  { value: "major", label: "Major", index: 3 },
  { value: "catastrophic", label: "Catastrophic", index: 4 },
];

const getRiskColor = (likelihoodIdx, severityIdx) => {
  const score = likelihoodIdx + severityIdx;
  if (score <= 2) return "bg-emerald-100 border-emerald-300 hover:bg-emerald-200";
  if (score <= 4) return "bg-yellow-100 border-yellow-300 hover:bg-yellow-200";
  if (score <= 6) return "bg-orange-100 border-orange-300 hover:bg-orange-200";
  return "bg-rose-100 border-rose-300 hover:bg-rose-200";
};

const getRiskLevel = (likelihoodIdx, severityIdx) => {
  const score = likelihoodIdx + severityIdx;
  if (score <= 2) return "Low";
  if (score <= 4) return "Medium";
  if (score <= 6) return "High";
  return "Critical";
};

export default function RiskHeatmap({ risks, onCellClick }) {
  const heatmapData = useMemo(() => {
    const matrix = {};
    
    // Initialize matrix
    LIKELIHOOD_LEVELS.forEach(l => {
      matrix[l.value] = {};
      SEVERITY_LEVELS.forEach(s => {
        matrix[l.value][s.value] = [];
      });
    });

    // Populate with risks
    risks.forEach(risk => {
      if (matrix[risk.likelihood]?.[risk.severity]) {
        matrix[risk.likelihood][risk.severity].push(risk);
      }
    });

    return matrix;
  }, [risks]);

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="border-b border-slate-100">
        <CardTitle className="text-sm font-semibold">Risk Assessment Heatmap</CardTitle>
        <p className="text-xs text-slate-500 mt-1">Likelihood vs Severity Matrix</p>
      </CardHeader>
      <CardContent className="p-3 sm:p-6">
        {/* Scrollable wrapper so the matrix never overflows on mobile */}
        <div className="overflow-x-auto -mx-3 sm:mx-0 px-3 sm:px-0">
          <div className="min-w-[340px]">
            {/* Header: severity labels */}
            <div className="grid grid-cols-6 gap-1 sm:gap-2 mb-1">
              <div className="text-[10px] font-semibold text-slate-500 flex items-end pb-1">Likelihood ↓</div>
              {SEVERITY_LEVELS.map(severity => (
                <div key={severity.value} className="text-center">
                  <div className="text-[9px] sm:text-xs font-medium text-slate-600 leading-tight">
                    {severity.label}
                  </div>
                </div>
              ))}
            </div>

            {/* Data rows */}
            {[...LIKELIHOOD_LEVELS].reverse().map(likelihood => (
              <div key={likelihood.value} className="grid grid-cols-6 gap-1 sm:gap-2 mb-1 sm:mb-2">
                <div className="flex items-center justify-end pr-1">
                  <div className="text-[9px] sm:text-xs font-medium text-slate-600 text-right leading-tight">
                    {likelihood.label}
                  </div>
                </div>
                {SEVERITY_LEVELS.map(severity => {
                  const cellRisks = heatmapData[likelihood.value]?.[severity.value] || [];
                  const colorClass = getRiskColor(likelihood.index, severity.index);
                  const riskLevel = getRiskLevel(likelihood.index, severity.index);

                  return (
                    <TooltipProvider key={severity.value}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button
                            onClick={() => onCellClick?.(likelihood.value, severity.value, cellRisks)}
                            className={`aspect-square rounded-lg border-2 transition-all ${colorClass}
                              ${cellRisks.length > 0 ? "cursor-pointer" : "cursor-default opacity-60"}
                              flex items-center justify-center relative group`}
                          >
                            {cellRisks.length > 0 && (
                              <>
                                <div className="text-sm sm:text-lg font-bold text-slate-700">
                                  {cellRisks.length}
                                </div>
                                <div className="absolute inset-0 bg-black/5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity" />
                              </>
                            )}
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="top" className="max-w-xs">
                          <div className="text-xs">
                            <div className="font-semibold mb-1">{riskLevel} Risk Zone</div>
                            <div className="text-slate-400">{likelihood.label} × {severity.label}</div>
                            {cellRisks.length > 0 && (
                              <div className="mt-2 pt-2 border-t border-slate-200">
                                <div className="font-semibold mb-1">
                                  {cellRisks.length} risk{cellRisks.length !== 1 ? "s" : ""} in this zone
                                </div>
                                {cellRisks.slice(0, 3).map(risk => (
                                  <div key={risk.id} className="text-slate-300 truncate">
                                    • {risk.hazard_description.substring(0, 40)}...
                                  </div>
                                ))}
                                {cellRisks.length > 3 && (
                                  <div className="text-slate-400 mt-1">+{cellRisks.length - 3} more</div>
                                )}
                              </div>
                            )}
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  );
                })}
              </div>
            ))}

            {/* X-axis label */}
            <div className="text-center mt-1">
              <div className="text-[10px] font-semibold text-slate-500">← Severity →</div>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-center gap-3 mt-4 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-emerald-100 border-2 border-emerald-300" />
            <span className="text-slate-600">Low</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-yellow-100 border-2 border-yellow-300" />
            <span className="text-slate-600">Medium</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-orange-100 border-2 border-orange-300" />
            <span className="text-slate-600">High</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded bg-rose-100 border-2 border-rose-300" />
            <span className="text-slate-600">Critical</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}