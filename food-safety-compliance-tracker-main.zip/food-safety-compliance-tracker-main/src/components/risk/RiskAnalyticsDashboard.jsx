import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { base44 } from "@/api/base44Client";
import {
  Sparkles, TrendingUp, GitBranch, Shield, AlertTriangle,
  Loader2, RefreshCw, ChevronDown, ChevronUp
} from "lucide-react";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";

const RISK_COLORS = { critical: "#f43f5e", high: "#f97316", medium: "#f59e0b", low: "#10b981" };
const HAZARD_LABELS = { biological: "Biological", chemical: "Chemical", physical: "Physical" };

function computeCorrelations(risks) {
  // Find pairs of hazard types that frequently co-occur at the same risk level
  const pairs = {};
  const hazardTypes = ["biological", "chemical", "physical"];
  hazardTypes.forEach(a => {
    hazardTypes.forEach(b => {
      if (a >= b) return;
      const aRisks = risks.filter(r => r.hazard_type === a);
      const bRisks = risks.filter(r => r.hazard_type === b);
      const sharedLevels = ["critical", "high", "medium", "low"].filter(level =>
        aRisks.some(r => r.risk_level === level) && bRisks.some(r => r.risk_level === level)
      );
      if (sharedLevels.length > 0) {
        pairs[`${a}_${b}`] = {
          typeA: HAZARD_LABELS[a],
          typeB: HAZARD_LABELS[b],
          sharedLevels,
          strength: sharedLevels.length >= 2 ? "strong" : "moderate",
        };
      }
    });
  });
  return Object.values(pairs);
}

function computeRadarData(risks) {
  const types = ["biological", "chemical", "physical"];
  return types.map(type => {
    const group = risks.filter(r => r.hazard_type === type);
    const score = group.length === 0 ? 0 : Math.round(
      group.reduce((sum, r) => {
        const lvl = { critical: 100, high: 75, medium: 50, low: 25 };
        return sum + (lvl[r.risk_level] || 0);
      }, 0) / group.length
    );
    return { subject: HAZARD_LABELS[type], score, count: group.length };
  });
}

function predictHighRiskAreas(risks) {
  // Identify hazard types with many high/critical items as predicted trouble spots
  const predictions = [];
  const types = ["biological", "chemical", "physical"];
  types.forEach(type => {
    const group = risks.filter(r => r.hazard_type === type);
    const highCritical = group.filter(r => r.risk_level === "critical" || r.risk_level === "high");
    const unmitigated = group.filter(r => !r.mitigation_strategy || r.mitigation_strategy.length < 20);
    if (highCritical.length >= 2 || unmitigated.length >= 2) {
      predictions.push({
        type,
        label: HAZARD_LABELS[type],
        riskCount: highCritical.length,
        unmitigatedCount: unmitigated.length,
        confidence: Math.min(95, 50 + highCritical.length * 10 + unmitigated.length * 8),
        trend: highCritical.length > unmitigated.length ? "escalating" : "stable",
      });
    }
  });
  return predictions.sort((a, b) => b.confidence - a.confidence);
}

function MitigationSuggestionCard({ risk }) {
  const [suggestion, setSuggestion] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const fetchSuggestion = async () => {
    setLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a food packaging compliance expert. Provide 3 specific, actionable mitigation strategies for the following risk:

Hazard Type: ${risk.hazard_type}
Hazard Description: ${risk.hazard_description}
Risk Level: ${risk.risk_level}
Likelihood: ${risk.likelihood}
Severity: ${risk.severity}
Current Mitigation (if any): ${risk.mitigation_strategy || "None"}

Return JSON with: { strategies: [{title, action, priority, timeframe, expected_reduction}] }`,
        response_json_schema: {
          type: "object",
          properties: {
            strategies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  action: { type: "string" },
                  priority: { type: "string" },
                  timeframe: { type: "string" },
                  expected_reduction: { type: "string" }
                }
              }
            }
          }
        }
      });
      setSuggestion(res.strategies || []);
    } catch {
      setSuggestion([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border border-slate-200 shadow-none">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <Badge className={`text-[10px] ${
                risk.risk_level === "critical" ? "bg-rose-100 text-rose-700" :
                risk.risk_level === "high" ? "bg-orange-100 text-orange-700" :
                "bg-amber-100 text-amber-700"
              }`}>{risk.risk_level?.toUpperCase()}</Badge>
              <span className="text-[10px] text-slate-400 capitalize">{risk.hazard_type}</span>
            </div>
            <p className="text-sm font-medium text-slate-800 truncate">{risk.hazard_description}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {suggestion && (
              <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)} className="h-7 px-2">
                {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </Button>
            )}
            <Button
              size="sm"
              variant="outline"
              onClick={fetchSuggestion}
              disabled={loading}
              className="h-7 px-2 text-xs gap-1.5"
            >
              {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3 text-emerald-600" />}
              {loading ? "..." : suggestion ? "Refresh" : "Suggest"}
            </Button>
          </div>
        </div>

        {suggestion && expanded && (
          <div className="mt-3 space-y-2">
            {suggestion.map((s, i) => (
              <div key={i} className="bg-emerald-50 border border-emerald-100 rounded-lg p-3">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <p className="text-xs font-semibold text-emerald-800">{s.title}</p>
                  <div className="flex gap-1 shrink-0">
                    {s.priority && <Badge className="text-[9px] bg-emerald-100 text-emerald-700">{s.priority}</Badge>}
                    {s.timeframe && <Badge className="text-[9px] bg-slate-100 text-slate-600">{s.timeframe}</Badge>}
                  </div>
                </div>
                <p className="text-xs text-emerald-700 leading-relaxed">{s.action}</p>
                {s.expected_reduction && (
                  <p className="text-[10px] text-emerald-600 mt-1 font-medium">
                    Expected reduction: {s.expected_reduction}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function RiskAnalyticsDashboard({ risks = [] }) {
  const [aiInsights, setAiInsights] = useState(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  const radarData = computeRadarData(risks);
  const correlations = computeCorrelations(risks);
  const predictions = predictHighRiskAreas(risks);

  const highPriorityRisks = risks.filter(r =>
    (r.risk_level === "critical" || r.risk_level === "high") &&
    r.workflow_status !== "approved"
  ).slice(0, 6);

  const byLevel = ["critical", "high", "medium", "low"].map(level => ({
    level,
    count: risks.filter(r => r.risk_level === level).length,
  }));

  const fetchAIInsights = async () => {
    setLoadingInsights(true);
    try {
      const summary = risks.map(r =>
        `${r.hazard_type}: ${r.hazard_description} (${r.risk_level}, ${r.likelihood} likelihood, ${r.severity} severity, status: ${r.workflow_status})`
      ).join("\n");

      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a food packaging compliance risk analyst. Analyze the following risk assessment data and provide strategic insights:

${summary || "No risks recorded yet."}

Provide:
1. Key patterns and trends you observe
2. Top 3 priority actions management should take immediately
3. Predicted risk escalations if no action is taken
4. Overall risk posture assessment

Return JSON: { patterns: string[], priority_actions: string[], escalation_risks: string[], posture: string, posture_level: "low"|"medium"|"high"|"critical" }`,
        response_json_schema: {
          type: "object",
          properties: {
            patterns: { type: "array", items: { type: "string" } },
            priority_actions: { type: "array", items: { type: "string" } },
            escalation_risks: { type: "array", items: { type: "string" } },
            posture: { type: "string" },
            posture_level: { type: "string" }
          }
        }
      });
      setAiInsights(res);
    } catch {
      setAiInsights(null);
    } finally {
      setLoadingInsights(false);
    }
  };

  if (risks.length === 0) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="p-12 text-center">
          <TrendingUp className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500">No risk data available for analytics. Add risk assessments to see insights.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* AI Insights Panel */}
      <Card className="border-0 shadow-sm bg-gradient-to-br from-emerald-50 to-blue-50">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold text-slate-800 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              AI Risk Intelligence
            </CardTitle>
            <Button
              size="sm"
              onClick={fetchAIInsights}
              disabled={loadingInsights}
              className="h-8 text-xs bg-emerald-600 hover:bg-emerald-700 gap-1.5"
            >
              {loadingInsights ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
              {loadingInsights ? "Analyzing..." : aiInsights ? "Re-analyze" : "Run AI Analysis"}
            </Button>
          </div>
        </CardHeader>
        {aiInsights && (
          <CardContent className="pt-0 space-y-4">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${
              aiInsights.posture_level === "critical" ? "bg-rose-100 text-rose-800" :
              aiInsights.posture_level === "high" ? "bg-orange-100 text-orange-800" :
              aiInsights.posture_level === "medium" ? "bg-amber-100 text-amber-800" :
              "bg-emerald-100 text-emerald-800"
            }`}>
              <Shield className="w-4 h-4 shrink-0" />
              <p className="text-sm font-medium">{aiInsights.posture}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-blue-500" /> Key Patterns
                </p>
                <ul className="space-y-1.5">
                  {aiInsights.patterns?.map((p, i) => (
                    <li key={i} className="text-xs text-slate-700 bg-white rounded-md px-2.5 py-1.5 shadow-sm">{p}</li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500" /> Priority Actions
                </p>
                <ul className="space-y-1.5">
                  {aiInsights.priority_actions?.map((a, i) => (
                    <li key={i} className="text-xs text-slate-700 bg-white rounded-md px-2.5 py-1.5 shadow-sm flex items-start gap-1.5">
                      <span className="text-emerald-600 font-bold shrink-0">{i + 1}.</span> {a}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-500" /> Escalation Risks
                </p>
                <ul className="space-y-1.5">
                  {aiInsights.escalation_risks?.map((r, i) => (
                    <li key={i} className="text-xs text-slate-700 bg-rose-50 rounded-md px-2.5 py-1.5">{r}</li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        )}
        {!aiInsights && !loadingInsights && (
          <CardContent className="pt-0">
            <p className="text-sm text-slate-500">Click "Run AI Analysis" to get AI-driven insights on your risk profile, predictions, and recommended actions.</p>
          </CardContent>
        )}
      </Card>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Radar Chart */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-slate-800">Risk Profile by Hazard Type</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="#e2e8f0" />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11, fill: "#64748b" }} />
                <Radar name="Risk Score" dataKey="score" stroke="#10b981" fill="#10b981" fillOpacity={0.25} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Bar Chart */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-slate-800">Risk Distribution by Level</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={byLevel} barSize={36}>
                <XAxis dataKey="level" tick={{ fontSize: 11, fill: "#64748b" }} />
                <YAxis tick={{ fontSize: 11, fill: "#64748b" }} allowDecimals={false} />
                <Tooltip formatter={(v) => [v, "Risks"]} />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {byLevel.map((entry, i) => (
                    <Cell key={i} fill={RISK_COLORS[entry.level] || "#94a3b8"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Predictions & Correlations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Predictions */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-slate-800 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-orange-500" />
              Predicted High-Risk Areas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {predictions.length === 0 ? (
              <p className="text-sm text-slate-400 py-4 text-center">No high-risk predictions at this time</p>
            ) : predictions.map((p, i) => (
              <div key={i} className="bg-orange-50 border border-orange-100 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-semibold text-orange-800">{p.label} Hazards</p>
                  <Badge className={`text-[10px] ${p.trend === "escalating" ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-700"}`}>
                    {p.trend}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <Progress value={p.confidence} className="h-1.5 flex-1" />
                  <span className="text-xs font-semibold text-orange-700 shrink-0">{p.confidence}% confidence</span>
                </div>
                <p className="text-xs text-orange-700">
                  {p.riskCount} high/critical risk{p.riskCount !== 1 ? "s" : ""} · {p.unmitigatedCount} without adequate mitigation
                </p>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Correlations */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-slate-800 flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-blue-500" />
              Risk Correlations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {correlations.length === 0 ? (
              <p className="text-sm text-slate-400 py-4 text-center">Not enough data to identify correlations</p>
            ) : correlations.map((c, i) => (
              <div key={i} className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-semibold text-blue-800">
                    {c.typeA} ↔ {c.typeB}
                  </p>
                  <Badge className={`text-[10px] ${c.strength === "strong" ? "bg-blue-200 text-blue-800" : "bg-blue-100 text-blue-700"}`}>
                    {c.strength}
                  </Badge>
                </div>
                <p className="text-xs text-blue-700">
                  Co-occur at: {c.sharedLevels.join(", ")} risk levels — addressing one may reduce the other
                </p>
              </div>
            ))}
            {correlations.length === 0 && risks.length < 3 && (
              <p className="text-xs text-slate-400 text-center">Add more risk assessments to identify correlations</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* AI Mitigation Suggestions */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-600" />
            AI Mitigation Suggestions
            <Badge className="text-[10px] bg-emerald-100 text-emerald-700 ml-1">Per Risk</Badge>
          </CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">Click "Suggest" on any high/critical risk to get tailored AI mitigation strategies</p>
        </CardHeader>
        <CardContent className="space-y-3">
          {highPriorityRisks.length === 0 ? (
            <p className="text-sm text-slate-400 py-4 text-center">No high or critical risks requiring mitigation</p>
          ) : highPriorityRisks.map(risk => (
            <MitigationSuggestionCard key={risk.id} risk={risk} />
          ))}
        </CardContent>
      </Card>
    </div>
  );
}