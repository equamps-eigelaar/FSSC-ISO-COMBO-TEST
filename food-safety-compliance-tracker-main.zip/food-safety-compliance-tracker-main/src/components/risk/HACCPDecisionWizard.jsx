import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, ChevronRight, ChevronLeft, AlertTriangle, ShieldCheck, Info, ArrowRight } from "lucide-react";

/* ─── Scoring ──────────────────────────────────────────────────── */
const LIKELIHOOD_OPTIONS = [
  { value: "rare", label: "Rare (1)", score: 1 },
  { value: "unlikely", label: "Unlikely (2)", score: 2 },
  { value: "possible", label: "Possible (3)", score: 3 },
  { value: "likely", label: "Likely (4)", score: 4 },
  { value: "almost_certain", label: "Almost Certain (5)", score: 5 },
];
const SEVERITY_OPTIONS = [
  { value: "negligible", label: "Low / Negligible (1)", score: 1 },
  { value: "minor", label: "Minor (2)", score: 2 },
  { value: "moderate", label: "Moderate (3)", score: 3 },
  { value: "major", label: "Major (4)", score: 4 },
  { value: "catastrophic", label: "Extreme / Catastrophic (5)", score: 5 },
];
const RISK_MATRIX = [
  ["L","L","L","M","H"],
  ["L","L","M","H","E"],
  ["L","M","H","E","E"],
  ["M","H","H","E","E"],
  ["H","H","E","E","E"],
];
function getRiskCode(likelihood, severity) {
  const l = LIKELIHOOD_OPTIONS.find(o => o.value === likelihood)?.score;
  const s = SEVERITY_OPTIONS.find(o => o.value === severity)?.score;
  if (!l || !s) return null;
  return RISK_MATRIX[l - 1][s - 1];
}
function mapRiskLevel(code) {
  return { L: "low", M: "medium", H: "high", E: "critical" }[code] || "low";
}
const RISK_LABELS = { L: "Low", M: "Medium", H: "High", E: "Extreme" };
const RISK_COLORS = {
  L: "bg-emerald-100 text-emerald-800 border-emerald-300",
  M: "bg-yellow-100 text-yellow-800 border-yellow-300",
  H: "bg-orange-100 text-orange-800 border-orange-300",
  E: "bg-red-100 text-red-800 border-red-300",
};

/* ─── Decision tree questions ──────────────────────────────────── */
const DT_QUESTIONS = [
  {
    id: "q1",
    number: "Q1",
    question: "Do preventive or control measures exist for the identified hazard at this process step?",
    guidance: "Consider physical, chemical or biological controls already in place (e.g. temperature control, chemical testing, allergen segregation). If YES, proceed to Q2. If NO — modify the process step, product or process to include a control measure, or mark as Not a CCP.",
    clause: "ISO 22000:2018 §8.5.2.3 / Codex Step 7",
    yesRoute: "q2",
    noOutcome: "modify",
    noLabel: "Modify step",
  },
  {
    id: "q2",
    number: "Q2",
    question: "Is this step specifically designed to eliminate or reduce the likely occurrence of the hazard to an acceptable level?",
    guidance: "If the step's PRIMARY purpose is hazard reduction (e.g. pasteurisation, metal detection, cook step), answer YES → CCP. If the step contributes but is not the primary control, answer NO and continue.",
    clause: "ISO 22000:2018 §8.5.4 / Codex Step 8",
    yesOutcome: "ccp",
    noRoute: "q3",
  },
  {
    id: "q3",
    number: "Q3",
    question: "Could contamination with identified hazard(s) occur in excess of acceptable levels, or could these increase to unacceptable levels?",
    guidance: "Consider the realistic contamination scenario at this step. If YES, the hazard is significant enough to warrant further consideration. If NO, this is not a CCP — apply GMP/PRP controls.",
    clause: "ISO 22000:2018 §8.5.2.4 / Codex Step 8",
    yesRoute: "q4",
    noOutcome: "not_ccp",
    noLabel: "Not a CCP — apply GMP/PRP",
  },
  {
    id: "q4",
    number: "Q4",
    question: "Will a subsequent step eliminate or reduce the identified hazard(s) to an acceptable level?",
    guidance: "If a LATER step in the process will adequately control this hazard (e.g. a downstream cook step will eliminate pathogens), answer YES → OPRP at this step. If NO — this step IS the last opportunity to control the hazard → CCP.",
    clause: "ISO 22000:2018 §8.5.4 / Codex Step 8",
    yesOutcome: "oprp",
    noOutcome: "ccp",
    yesLabel: "OPRP",
    noLabel: "CCP",
  },
];

const OUTCOMES = {
  ccp: { label: "CCP — Critical Control Point", color: "bg-red-100 text-red-800 border-red-400", icon: "🔴", description: "A Critical Control Point must be established with documented critical limits, monitoring procedures, corrective actions and verification activities per ISO 22000:2018 §8.5.4." },
  oprp: { label: "OPRP — Operational PRP", color: "bg-orange-100 text-orange-800 border-orange-400", icon: "🟠", description: "An Operational Prerequisite Programme is required. Document monitoring procedure, corrective actions and verification per ISO 22000:2018 §8.5.4." },
  not_ccp: { label: "Not a CCP — Manage via GMP/PRP", color: "bg-emerald-100 text-emerald-800 border-emerald-400", icon: "🟢", description: "No CCP required at this step. Ensure adequate GMP and PRP controls are documented and monitored per ISO 22000:2018 §8.2." },
  modify: { label: "Modify Process Step / Product", color: "bg-slate-100 text-slate-800 border-slate-400", icon: "⚙️", description: "The process step must be modified to include control measures before re-evaluation. Refer to ISO 22000:2018 §8.5.2.3." },
};

/* ─── Wizard steps ─────────────────────────────────────────────── */
const STEPS = [
  { id: "info",     label: "Process Step", number: 1 },
  { id: "hazard",   label: "Hazard Detail", number: 2 },
  { id: "risk",     label: "Risk Scoring", number: 3 },
  { id: "decision", label: "Decision Tree", number: 4 },
  { id: "controls", label: "Control Plan", number: 5 },
  { id: "summary",  label: "Summary & Log", number: 6 },
];

const BLANK = {
  process_step: "", hazard_source: "P", hazard_type: "chemical",
  acceptable_level: "", hazard_description: "", control_measures: "",
  likelihood: "", severity: "",
  q_answers: {}, // { q1: "yes"|"no", ... }
  monitoring_procedure: "", corrective_action_plan: "", verification_procedure: "",
  comments: "",
};

/* ─── Derive outcome from answers ─────────────────────────────── */
function deriveOutcome(answers) {
  if (!answers.q1) return null;
  if (answers.q1 === "no") return "modify";
  if (!answers.q2) return null;
  if (answers.q2 === "yes") return "ccp";
  if (!answers.q3) return null;
  if (answers.q3 === "no") return "not_ccp";
  if (!answers.q4) return null;
  return answers.q4 === "yes" ? "oprp" : "ccp";
}

/* ─── Build justification text ─────────────────────────────────── */
function buildJustification(form, outcome) {
  const riskCode = getRiskCode(form.likelihood, form.severity);
  const lines = [
    `Process Step: ${form.process_step}`,
    `Hazard Type: ${form.hazard_type} | Source: ${form.hazard_source}`,
    `Hazard: ${form.hazard_description}`,
    `Risk Score: ${(LIKELIHOOD_OPTIONS.find(o=>o.value===form.likelihood)?.score||'-')} × ${(SEVERITY_OPTIONS.find(o=>o.value===form.severity)?.score||'-')} = Level ${riskCode ? RISK_LABELS[riskCode] : '-'}`,
    `--- Decision Tree ---`,
  ];
  DT_QUESTIONS.forEach(q => {
    if (form.q_answers[q.id]) lines.push(`${q.number}: ${form.q_answers[q.id].toUpperCase()}`);
  });
  lines.push(`Outcome: ${outcome ? OUTCOMES[outcome]?.label : 'Incomplete'}`);
  if (form.comments) lines.push(`Notes: ${form.comments}`);
  return lines.join(" | ");
}

/* ─── Main wizard component ────────────────────────────────────── */
export default function HACCPDecisionWizard({ open, onClose, onSaved }) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({ ...BLANK });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const setAnswer = (q, v) => {
    // Reset downstream answers when changing a question
    const qIndex = DT_QUESTIONS.findIndex(dq => dq.id === q);
    const newAnswers = { ...form.q_answers };
    DT_QUESTIONS.slice(qIndex).forEach(dq => delete newAnswers[dq.id]);
    newAnswers[q] = v;
    setForm(f => ({ ...f, q_answers: newAnswers }));
  };

  const riskCode = getRiskCode(form.likelihood, form.severity);
  const outcome = deriveOutcome(form.q_answers);
  const isCCP = outcome === "ccp";
  const isOPRP = outcome === "oprp";

  const canNext = () => {
    if (step === 0) return !!form.process_step;
    if (step === 1) return !!form.hazard_description;
    if (step === 2) return !!form.likelihood && !!form.severity;
    if (step === 3) return !!outcome;
    return true;
  };

  const handleSave = async () => {
    setSaving(true);
    const justification = buildJustification(form, outcome);
    const dtCode = isCCP ? "q2_yes_ccp" : isOPRP ? "q4_no_oprp" : outcome === "modify" ? "q1_no" : "not_ccp";
    const data = {
      requirement_id: "haccp_study",
      hazard_type: form.hazard_type,
      hazard_description: form.hazard_description,
      likelihood: form.likelihood,
      severity: form.severity,
      risk_level: riskCode ? mapRiskLevel(riskCode) : "low",
      mitigation_strategy: form.control_measures,
      critical_limits: form.acceptable_level,
      monitoring_procedure: form.monitoring_procedure,
      corrective_action_plan: form.corrective_action_plan,
      verification_procedure: form.verification_procedure,
      is_ccp: isCCP,
      is_oprp: isOPRP,
      status: "identified",
      workflow_status: "draft",
      notes: `${form.process_step}||${form.hazard_source}`,
      approval_notes: justification,
      haccp_decision_tree: dtCode,
    };
    await base44.entities.RiskAssessment.create(data);
    setSaving(false);
    onSaved();
    onClose();
  };

  const currentStepId = STEPS[step].id;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto p-0">
        <DialogHeader className="px-6 pt-5 pb-3 border-b border-slate-100">
          <DialogTitle className="text-base font-bold text-slate-800">
            HACCP Decision Tree Wizard
          </DialogTitle>
          <p className="text-xs text-slate-500">ISO 22000:2018 §8.5 · Codex Alimentarius Step 7–8</p>
        </DialogHeader>

        {/* Step Progress */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-1">
            {STEPS.map((s, i) => (
              <React.Fragment key={s.id}>
                <div className={`flex items-center gap-1.5 ${i <= step ? "opacity-100" : "opacity-40"}`}>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0
                    ${i < step ? "bg-emerald-600 text-white" : i === step ? "bg-blue-600 text-white" : "bg-slate-200 text-slate-500"}`}>
                    {i < step ? <CheckCircle2 className="w-3.5 h-3.5" /> : s.number}
                  </div>
                  <span className={`text-[10px] font-medium hidden sm:block ${i === step ? "text-blue-700" : "text-slate-500"}`}>
                    {s.label}
                  </span>
                </div>
                {i < STEPS.length - 1 && <div className="flex-1 h-px bg-slate-200 mx-1" />}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <div className="px-6 py-5 space-y-4">

          {/* STEP 1: Process Step Info */}
          {currentStepId === "info" && (
            <StepSection title="Process Step Details" subtitle="Identify the step in your manufacturing/production process being evaluated.">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2 space-y-1.5">
                  <Label>Process Step Name <span className="text-rose-500">*</span></Label>
                  <Input value={form.process_step} onChange={e => set("process_step", e.target.value)} placeholder="e.g. Pasteurisation, Metal Detection, Receiving" />
                </div>
                <div className="space-y-1.5">
                  <Label>Hazard Source</Label>
                  <Select value={form.hazard_source} onValueChange={v => set("hazard_source", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="P">P – Present</SelectItem>
                      <SelectItem value="I">I – Introduced</SelectItem>
                      <SelectItem value="G">G – Grow</SelectItem>
                      <SelectItem value="S">S – Survive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Hazard Type</Label>
                  <Select value={form.hazard_type} onValueChange={v => set("hazard_type", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="biological">B – Biological</SelectItem>
                      <SelectItem value="chemical">C – Chemical</SelectItem>
                      <SelectItem value="physical">P – Physical</SelectItem>
                      <SelectItem value="allergen">A – Allergen</SelectItem>
                      <SelectItem value="radiological">M – Migration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </StepSection>
          )}

          {/* STEP 2: Hazard Detail */}
          {currentStepId === "hazard" && (
            <StepSection title="Hazard Identification" subtitle="Describe the specific hazard(s) present at this step and existing control measures.">
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label>Hazards Identified at This Step <span className="text-rose-500">*</span></Label>
                  <Textarea value={form.hazard_description} onChange={e => set("hazard_description", e.target.value)} rows={3} placeholder="e.g. Salmonella spp. from raw poultry input; metal fragments from equipment wear..." />
                </div>
                <div className="space-y-1.5">
                  <Label>Acceptable Level of Hazard</Label>
                  <Input value={form.acceptable_level} onChange={e => set("acceptable_level", e.target.value)} placeholder="e.g. Absent in 25g, <10 CFU/g, no particles >7mm" />
                </div>
                <div className="space-y-1.5">
                  <Label>Existing Control / Preventive Measures</Label>
                  <Textarea value={form.control_measures} onChange={e => set("control_measures", e.target.value)} rows={2} placeholder="List all current controls at this step..." />
                </div>
              </div>
            </StepSection>
          )}

          {/* STEP 3: Risk Scoring */}
          {currentStepId === "risk" && (
            <StepSection title="Risk Scoring" subtitle="Score likelihood and severity to determine if the hazard is significant (required for CCP/OPRP consideration).">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Likelihood (L)</Label>
                  <Select value={form.likelihood} onValueChange={v => set("likelihood", v)}>
                    <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {LIKELIHOOD_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Severity (S)</Label>
                  <Select value={form.severity} onValueChange={v => set("severity", v)}>
                    <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {SEVERITY_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {riskCode && (
                <div className={`rounded-lg border-2 p-4 mt-2 ${RISK_COLORS[riskCode]}`}>
                  <div className="flex items-center gap-3">
                    <div className="text-2xl font-black">
                      {LIKELIHOOD_OPTIONS.find(o=>o.value===form.likelihood)?.score || "-"} × {SEVERITY_OPTIONS.find(o=>o.value===form.severity)?.score || "-"} = {(LIKELIHOOD_OPTIONS.find(o=>o.value===form.likelihood)?.score || 0) * (SEVERITY_OPTIONS.find(o=>o.value===form.severity)?.score || 0)}
                    </div>
                    <div>
                      <p className="font-bold text-sm">Risk Level: {RISK_LABELS[riskCode]}</p>
                      {(riskCode === "H" || riskCode === "E") ? (
                        <p className="text-xs font-semibold">⚠ Significant Risk — proceed to Decision Tree</p>
                      ) : (
                        <p className="text-xs">Non-significant risk — Decision Tree not required, but can still proceed</p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </StepSection>
          )}

          {/* STEP 4: Decision Tree */}
          {currentStepId === "decision" && (
            <StepSection title="CCP Decision Tree" subtitle="Answer each question in order. The wizard will automatically route you to the correct outcome.">
              {/* Visual flow diagram */}
              <DecisionTreeFlow answers={form.q_answers} />

              {/* Active question panel */}
              <div className="space-y-3 mt-4">
                {DT_QUESTIONS.map((q, idx) => {
                  // Determine if this question is reachable
                  const prevAnswers = DT_QUESTIONS.slice(0, idx).every(pq => {
                    const ans = form.q_answers[pq.id];
                    if (!ans) return false;
                    // If a previous question terminated early, this question is not reachable
                    if (pq.noOutcome && ans === "no") return false;
                    if (pq.yesOutcome && ans === "yes") return false;
                    return true;
                  });
                  const isFirst = idx === 0;
                  const isReachable = isFirst || prevAnswers;
                  const isAnswered = !!form.q_answers[q.id];
                  const isActive = isReachable && !isAnswered;
                  const isTerminated = !isReachable;

                  if (isTerminated) return null;

                  return (
                    <div key={q.id} className={`rounded-lg border-2 p-4 transition-all ${
                      isActive ? "border-blue-400 bg-blue-50 shadow-md" :
                      isAnswered ? "border-emerald-300 bg-emerald-50" :
                      "border-slate-200 bg-white opacity-50"
                    }`}>
                      <div className="flex items-start gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                          isAnswered ? "bg-emerald-600 text-white" : isActive ? "bg-blue-600 text-white" : "bg-slate-300 text-slate-600"
                        }`}>
                          {q.number}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-semibold text-slate-800 leading-snug">{q.question}</p>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">{q.guidance}</p>
                          <p className="text-[10px] font-mono text-slate-400 mt-1">{q.clause}</p>
                          {(isActive || isAnswered) && (
                            <div className="flex gap-2 mt-3">
                              <button
                                onClick={() => setAnswer(q.id, "yes")}
                                className={`px-4 py-1.5 text-xs rounded-lg border-2 font-bold transition-all ${
                                  form.q_answers[q.id] === "yes"
                                    ? "bg-emerald-600 text-white border-emerald-600 scale-105"
                                    : "bg-white text-slate-600 border-slate-300 hover:border-emerald-400 hover:text-emerald-700"
                                }`}
                              >
                                YES {q.yesOutcome && `→ ${OUTCOMES[q.yesOutcome]?.label?.split("—")[0]?.trim()}`}
                              </button>
                              <button
                                onClick={() => setAnswer(q.id, "no")}
                                className={`px-4 py-1.5 text-xs rounded-lg border-2 font-bold transition-all ${
                                  form.q_answers[q.id] === "no"
                                    ? "bg-rose-600 text-white border-rose-600 scale-105"
                                    : "bg-white text-slate-600 border-slate-300 hover:border-rose-400 hover:text-rose-700"
                                }`}
                              >
                                NO {q.noOutcome && `→ ${q.noLabel || OUTCOMES[q.noOutcome]?.label?.split("—")[0]?.trim()}`}
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Outcome banner */}
              {outcome && (
                <div className={`rounded-xl border-2 p-4 mt-3 ${OUTCOMES[outcome].color}`}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xl">{OUTCOMES[outcome].icon}</span>
                    <span className="font-bold text-sm">{OUTCOMES[outcome].label}</span>
                  </div>
                  <p className="text-xs leading-relaxed">{OUTCOMES[outcome].description}</p>
                </div>
              )}
            </StepSection>
          )}

          {/* STEP 5: Control Plan */}
          {currentStepId === "controls" && (
            <StepSection
              title={isCCP ? "CCP Control Parameters" : isOPRP ? "OPRP Control Parameters" : "Documentation Notes"}
              subtitle={isCCP || isOPRP ? "Document the control plan requirements for this CCP/OPRP per ISO 22000:2018 §8.5.4." : "Add any notes for this process step."}
            >
              {(isCCP || isOPRP) && (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <Label>Monitoring Procedure <span className="text-xs text-slate-400">(What, How, Frequency, Who)</span></Label>
                    <Textarea value={form.monitoring_procedure} onChange={e => set("monitoring_procedure", e.target.value)} rows={2} placeholder="e.g. Temperature logged every 2 hours by QC operator using calibrated probe..." />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Corrective Action Plan</Label>
                    <Textarea value={form.corrective_action_plan} onChange={e => set("corrective_action_plan", e.target.value)} rows={2} placeholder="Actions to take when critical limits are exceeded..." />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Verification Procedure</Label>
                    <Textarea value={form.verification_procedure} onChange={e => set("verification_procedure", e.target.value)} rows={2} placeholder="Activities to confirm the control measure is effective..." />
                  </div>
                </div>
              )}
              <div className="space-y-1.5">
                <Label>Comments / Documentation Reference</Label>
                <Input value={form.comments} onChange={e => set("comments", e.target.value)} placeholder="e.g. SOP-QC-004, HACCP Plan Rev 3, FSMS Form 12..." />
              </div>
            </StepSection>
          )}

          {/* STEP 6: Summary */}
          {currentStepId === "summary" && (
            <StepSection title="Summary & Justification Log" subtitle="Review the auto-generated decision justification before saving to the HACCP study register.">
              {/* Outcome badge */}
              {outcome && (
                <div className={`rounded-xl border-2 p-4 ${OUTCOMES[outcome].color}`}>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{OUTCOMES[outcome].icon}</span>
                    <div>
                      <p className="font-bold text-sm">{OUTCOMES[outcome].label}</p>
                      <p className="text-xs mt-0.5">{OUTCOMES[outcome].description}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Decision path */}
              <div className="rounded-lg bg-slate-50 border border-slate-200 p-4 space-y-2">
                <p className="text-xs font-bold text-slate-600 uppercase tracking-wide">Decision Path</p>
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  {DT_QUESTIONS.map((q, i) => {
                    const ans = form.q_answers[q.id];
                    if (!ans) return null;
                    return (
                      <React.Fragment key={q.id}>
                        <span className={`px-2 py-1 rounded font-medium ${ans === "yes" ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"}`}>
                          {q.number}: {ans.toUpperCase()}
                        </span>
                        <ArrowRight className="w-3 h-3 text-slate-400" />
                      </React.Fragment>
                    );
                  })}
                  {outcome && <span className={`px-2 py-1 rounded font-bold border ${OUTCOMES[outcome].color}`}>{OUTCOMES[outcome].label.split("—")[0].trim()}</span>}
                </div>
              </div>

              {/* Auto-generated justification */}
              <div className="rounded-lg bg-white border border-slate-200 p-4">
                <p className="text-xs font-bold text-slate-600 uppercase tracking-wide mb-2">Auto-Generated Justification (logged to record)</p>
                <p className="text-[11px] text-slate-600 leading-relaxed font-mono bg-slate-50 p-3 rounded border border-slate-100 break-words">
                  {buildJustification(form, outcome)}
                </p>
              </div>

              {/* Summary table */}
              <div className="rounded-lg bg-white border border-slate-200 overflow-hidden">
                <table className="w-full text-xs">
                  <tbody>
                    {[
                      ["Process Step", form.process_step],
                      ["Hazard Type", form.hazard_type],
                      ["Hazard Description", form.hazard_description],
                      ["Risk Level", riskCode ? RISK_LABELS[riskCode] : "-"],
                      ["Outcome", outcome ? OUTCOMES[outcome]?.label : "-"],
                    ].map(([k, v]) => (
                      <tr key={k} className="border-b border-slate-100 last:border-0">
                        <td className="px-3 py-2 font-semibold text-slate-600 bg-slate-50 w-1/3">{k}</td>
                        <td className="px-3 py-2 text-slate-700">{v}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </StepSection>
          )}
        </div>

        {/* Footer nav */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <Button variant="outline" onClick={() => step === 0 ? onClose() : setStep(s => s - 1)} className="gap-2">
            <ChevronLeft className="w-4 h-4" />
            {step === 0 ? "Cancel" : "Back"}
          </Button>
          <span className="text-xs text-slate-400">Step {step + 1} of {STEPS.length}</span>
          {step < STEPS.length - 1 ? (
            <Button onClick={() => setStep(s => s + 1)} disabled={!canNext()} className="bg-blue-600 hover:bg-blue-700 gap-2">
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          ) : (
            <Button onClick={handleSave} disabled={saving || !outcome || !form.process_step} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
              {saving ? "Saving..." : "Save to HACCP Register"}
              <CheckCircle2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ─── Sub-components ────────────────────────────────────────────── */
function StepSection({ title, subtitle, children }) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-bold text-slate-800">{title}</h3>
        {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

function DecisionTreeFlow({ answers }) {
  const nodes = [
    { id: "start", label: "Hazard Identified", type: "start" },
    { id: "q1", label: "Q1: Control measures exist?", type: "q", yes: "q2", no: "modify" },
    { id: "modify", label: "⚙ Modify Step", type: "end_grey" },
    { id: "q2", label: "Q2: Step designed to eliminate/reduce?", type: "q", yes: "ccp", no: "q3" },
    { id: "q3", label: "Q3: Contamination > acceptable?", type: "q", yes: "q4", no: "not_ccp" },
    { id: "not_ccp", label: "🟢 Not CCP — apply GMP/PRP", type: "end_green" },
    { id: "q4", label: "Q4: Subsequent step eliminates hazard?", type: "q", yes: "oprp", no: "ccp" },
    { id: "oprp", label: "🟠 OPRP", type: "end_orange" },
    { id: "ccp", label: "🔴 CCP", type: "end_red" },
  ];

  const outcome = deriveOutcome(answers);

  const isActive = (nodeId) => {
    if (nodeId === "start") return true;
    if (nodeId === "q1") return true;
    if (nodeId === "q2") return answers.q1 === "yes";
    if (nodeId === "modify") return answers.q1 === "no";
    if (nodeId === "q3") return answers.q1 === "yes" && answers.q2 === "no";
    if (nodeId === "not_ccp") return answers.q1 === "yes" && answers.q2 === "no" && answers.q3 === "no";
    if (nodeId === "q4") return answers.q1 === "yes" && answers.q2 === "no" && answers.q3 === "yes";
    if (nodeId === "oprp") return outcome === "oprp";
    if (nodeId === "ccp") return outcome === "ccp";
    return false;
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-3 overflow-x-auto">
      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">Decision Path Visualisation</p>
      <div className="flex items-center flex-wrap gap-1 text-[10px]">
        {["start","q1","q2","q3","q4"].map((id, i) => {
          const node = nodes.find(n => n.id === id);
          const active = isActive(id);
          return (
            <React.Fragment key={id}>
              <div className={`px-2 py-1 rounded border font-medium transition-all ${
                active ? "bg-blue-100 text-blue-800 border-blue-400" : "bg-slate-50 text-slate-400 border-slate-200"
              }`}>
                {node?.label}
              </div>
              {i < 4 && <ArrowRight className={`w-3 h-3 flex-shrink-0 ${active && isActive(["q1","q2","q3","q4",""][i]) ? "text-blue-400" : "text-slate-300"}`} />}
            </React.Fragment>
          );
        })}
        {outcome && (
          <>
            <ArrowRight className="w-3 h-3 text-slate-400 flex-shrink-0" />
            <div className={`px-2 py-1 rounded border font-bold ${OUTCOMES[outcome].color}`}>
              {OUTCOMES[outcome].icon} {OUTCOMES[outcome].label.split("—")[0].trim()}
            </div>
          </>
        )}
      </div>
    </div>
  );
}