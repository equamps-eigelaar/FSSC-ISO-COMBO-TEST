import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle2, XCircle, MinusCircle, ClipboardList, Download, RefreshCw, UserCheck } from "lucide-react";
import { format } from "date-fns";
import { base44 } from "@/api/base44Client";

const GMP_SECTIONS = [
  {
    title: "Facility & Premises",
    items: [
      "Facility exterior and grounds are well-maintained and free from debris",
      "Building structure (walls, floors, ceilings) is in good repair and cleanable",
      "Adequate lighting in all work areas",
      "Proper drainage and no standing water",
      "Pest exclusion measures are in place (screens, door seals, etc.)",
      "Waste collection areas are properly managed and covered",
    ],
  },
  {
    title: "Equipment & Machinery",
    items: [
      "All equipment is clean, in good repair, and free from product contamination risk",
      "Equipment surfaces in contact with packaging are food-safe and non-toxic",
      "Equipment maintenance records are up to date",
      "Calibration records for measuring devices are current",
      "Equipment is adequately spaced to allow cleaning and inspection",
    ],
  },
  {
    title: "Cleaning & Sanitation",
    items: [
      "Written cleaning and sanitation procedures are documented and followed",
      "Cleaning chemicals are properly labelled and stored separately from packaging",
      "Cleaning schedules are posted and records maintained",
      "Sanitation verification (swabs/ATP) is performed and recorded",
      "Cleaning equipment (mops, brushes) is in good condition and stored hygienically",
    ],
  },
  {
    title: "Personnel Hygiene",
    items: [
      "All personnel wear appropriate PPE (gloves, hairnets, lab coats)",
      "Handwashing facilities are accessible, functional, and stocked with soap",
      "Personnel hygiene training records are current",
      "Eating, drinking, and smoking are restricted to designated areas",
      "Open wounds and jewellery policy is enforced",
      "Illness reporting procedure is documented and communicated",
    ],
  },
  {
    title: "Raw Materials & Packaging Components",
    items: [
      "Incoming materials are inspected and approved before use",
      "Raw materials are stored off the floor, labelled, and segregated",
      "Certificates of compliance/conformance are available for raw materials",
      "FIFO (First In, First Out) rotation is practised",
      "Non-conforming materials are clearly identified and quarantined",
    ],
  },
  {
    title: "Production Controls",
    items: [
      "Batch/lot traceability records are maintained for all production runs",
      "Product specifications and work instructions are available at workstations",
      "In-process checks are documented (dimensions, print quality, integrity)",
      "Allergen control procedures are documented if applicable",
      "Rework is controlled and documented",
    ],
  },
  {
    title: "Storage & Distribution",
    items: [
      "Finished goods are stored in a clean, dry, and secure area",
      "Temperature and humidity controls are in place where required",
      "Finished goods are labelled with batch number and expiry/manufacture date",
      "Delivery vehicles are inspected for cleanliness before loading",
      "Distribution records allow traceability of finished goods",
    ],
  },
  {
    title: "Documentation & Records",
    items: [
      "Quality management system documents are current and controlled",
      "Records are legible, accurate, and retained per retention schedule",
      "Internal audit programme is active and records are available",
      "Corrective action records are maintained and closed out",
      "Management review records are available",
    ],
  },
];

const RESULT_CONFIG = {
  pass: { label: "Pass", icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50 border-emerald-200" },
  fail: { label: "Fail", icon: XCircle, color: "text-rose-600", bg: "bg-rose-50 border-rose-200" },
  na: { label: "N/A", icon: MinusCircle, color: "text-slate-400", bg: "bg-slate-50 border-slate-200" },
};

export default function GMPInspection() {
  const [inspector, setInspector] = useState("");
  const [inspectionDate, setInspectionDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [area, setArea] = useState("");
  const [results, setResults] = useState({});
  const [notes, setNotes] = useState({});
  const [responsible, setResponsible] = useState({});
  const [users, setUsers] = useState([]);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    base44.entities.User.list().then(setUsers).catch(() => {});
  }, []);

  const allItems = GMP_SECTIONS.flatMap(s => s.items);
  const answered = allItems.filter(item => results[item]);
  const passed = allItems.filter(item => results[item] === "pass");
  const failed = allItems.filter(item => results[item] === "fail");
  const naItems = allItems.filter(item => results[item] === "na");
  const applicable = allItems.length - naItems.length;
  const score = applicable > 0 ? Math.round((passed.length / applicable) * 100) : 0;

  const setResult = (item, value) => setResults(prev => ({ ...prev, [item]: value }));
  const setNote = (item, value) => setNotes(prev => ({ ...prev, [item]: value }));
  const setResponsibleUser = (item, value) => setResponsible(prev => ({ ...prev, [item]: value }));

  const handleReset = () => {
    setResults({});
    setNotes({});
    setResponsible({});
    setSubmitted(false);
  };

  const handleExport = () => {
    const lines = [
      "GMP INSPECTION REPORT — FOOD PACKAGING MANUFACTURER",
      "=".repeat(55),
      `Inspector: ${inspector || "—"}`,
      `Date: ${inspectionDate}`,
      `Area / Line: ${area || "—"}`,
      `Score: ${score}% (${passed.length} pass / ${failed.length} fail / ${naItems.length} N/A of ${allItems.length} items)`,
      "",
    ];
    GMP_SECTIONS.forEach(section => {
      lines.push(`\n## ${section.title}`);
      section.items.forEach(item => {
        const r = results[item] || "not answered";
        const n = notes[item] ? ` — Note: ${notes[item]}` : "";
        const resp = responsible[item] ? ` — Responsible: ${responsible[item]}` : "";
        lines.push(`  [${r.toUpperCase()}] ${item}${n}${resp}`);
      });
    });

    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `GMP_Inspection_${inspectionDate}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const scoreColor = score >= 85 ? "text-emerald-600" : score >= 60 ? "text-amber-600" : "text-rose-600";
  const scoreLabel = score >= 85 ? "Satisfactory" : score >= 60 ? "Requires Attention" : "Unsatisfactory";

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-emerald-600" />
              <CardTitle className="text-base">GMP Inspection Checklist — Food Packaging Manufacturer</CardTitle>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleReset}>
                <RefreshCw className="w-3.5 h-3.5 mr-1.5" />Reset
              </Button>
              <Button variant="outline" size="sm" onClick={handleExport}>
                <Download className="w-3.5 h-3.5 mr-1.5" />Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
            <div>
              <Label className="text-xs">Inspector Name</Label>
              <Input value={inspector} onChange={e => setInspector(e.target.value)} placeholder="Full name" />
            </div>
            <div>
              <Label className="text-xs">Inspection Date</Label>
              <Input type="date" value={inspectionDate} onChange={e => setInspectionDate(e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">Area / Production Line</Label>
              <Input value={area} onChange={e => setArea(e.target.value)} placeholder="e.g. Line 3, Warehouse" />
            </div>
          </div>

          {/* Score Summary */}
          {answered.length > 0 && (
            <div className="flex flex-wrap gap-3 items-center p-3 bg-slate-50 rounded-lg border border-slate-100">
              <div className={`text-2xl font-bold ${scoreColor}`}>{score}%</div>
              <Badge className={score >= 85 ? "bg-emerald-100 text-emerald-700" : score >= 60 ? "bg-amber-100 text-amber-700" : "bg-rose-100 text-rose-700"}>
                {scoreLabel}
              </Badge>
              <span className="text-xs text-slate-500">{answered.length}/{allItems.length} answered</span>
              <span className="text-xs text-emerald-600 font-medium">{passed.length} Pass</span>
              <span className="text-xs text-rose-600 font-medium">{failed.length} Fail</span>
              <span className="text-xs text-slate-400 font-medium">{naItems.length} N/A</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Checklist Sections */}
      {GMP_SECTIONS.map((section) => {
        const sectionPassed = section.items.filter(i => results[i] === "pass").length;
        const sectionFailed = section.items.filter(i => results[i] === "fail").length;
        const sectionAnswered = section.items.filter(i => results[i]).length;

        return (
          <Card key={section.title} className="border-0 shadow-sm">
            <CardHeader className="pb-3 border-b border-slate-100">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold text-slate-800">{section.title}</CardTitle>
                <div className="flex gap-2 text-xs">
                  {sectionAnswered > 0 && (
                    <>
                      <span className="text-emerald-600 font-medium">{sectionPassed}✓</span>
                      {sectionFailed > 0 && <span className="text-rose-600 font-medium">{sectionFailed}✗</span>}
                    </>
                  )}
                  <span className="text-slate-400">{sectionAnswered}/{section.items.length}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0 divide-y divide-slate-50">
              {section.items.map((item, idx) => {
                const result = results[item];
                const note = notes[item] || "";
                return (
                  <div key={idx} className={`p-4 transition-colors ${result === "fail" ? "bg-rose-50/30" : result === "pass" ? "bg-emerald-50/20" : ""}`}>
                    <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                      <p className="flex-1 text-sm text-slate-700">{item}</p>
                      <div className="flex gap-2 shrink-0">
                        {["pass", "fail", "na"].map(opt => {
                          const cfg = RESULT_CONFIG[opt];
                          const Icon = cfg.icon;
                          const active = result === opt;
                          return (
                            <button
                              key={opt}
                              onClick={() => setResult(item, active ? null : opt)}
                              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium border transition-all ${
                                active ? `${cfg.bg} ${cfg.color} border-current` : "bg-white text-slate-400 border-slate-200 hover:border-slate-300"
                              }`}
                            >
                              <Icon className="w-3.5 h-3.5" />
                              {cfg.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                    {result === "fail" && (
                      <div className="mt-2 space-y-2">
                        <Textarea
                          value={note}
                          onChange={e => setNote(item, e.target.value)}
                          placeholder="Describe the non-conformance and required corrective action..."
                          className="text-xs min-h-[60px] border-rose-200 focus:border-rose-400"
                          rows={2}
                        />
                        <div className="flex items-center gap-2">
                          <UserCheck className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                          <Select
                            value={responsible[item] || ""}
                            onValueChange={val => setResponsibleUser(item, val)}
                          >
                            <SelectTrigger className="h-8 text-xs border-rose-200 focus:border-rose-400 flex-1">
                              <SelectValue placeholder="Assign responsible person..." />
                            </SelectTrigger>
                            <SelectContent>
                              {users.map(u => (
                                <SelectItem key={u.id} value={u.email} className="text-xs">
                                  {u.full_name || u.email}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        );
      })}

      {/* Failed Items Summary */}
      {failed.length > 0 && (
        <Card className="border-0 shadow-sm border-l-4 border-l-rose-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-rose-700 flex items-center gap-2">
              <XCircle className="w-4 h-4" />
              Non-Conformances Summary ({failed.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {failed.map((item, i) => (
                <li key={i} className="text-sm text-slate-700 flex items-start gap-2">
                  <span className="text-rose-500 font-bold shrink-0">{i + 1}.</span>
                  <div>
                    <p>{item}</p>
                    {notes[item] && <p className="text-xs text-slate-500 mt-0.5 italic">{notes[item]}</p>}
                    {responsible[item] && (
                      <p className="text-xs text-rose-600 mt-0.5 flex items-center gap-1">
                        <UserCheck className="w-3 h-3" />
                        Responsible: {users.find(u => u.email === responsible[item])?.full_name || responsible[item]}
                      </p>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}