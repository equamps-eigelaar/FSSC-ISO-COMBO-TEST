import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  CheckCircle,
  XCircle,
  Clock,
  FileEdit,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Send,
} from "lucide-react";
import { usePermissions } from "@/components/permissions/usePermissions";
import { toast } from "sonner";
import { format } from "date-fns";
import DocumentUploader from "@/components/documents/DocumentUploader";
import DocumentList from "@/components/documents/DocumentList";

const WORKFLOW_STATUS_CONFIG = {
  draft: { label: "Draft", icon: FileEdit, className: "bg-slate-100 text-slate-600" },
  pending_review: { label: "Pending Review", icon: Clock, className: "bg-amber-50 text-amber-700" },
  approved: { label: "Approved", icon: CheckCircle, className: "bg-emerald-50 text-emerald-700" },
  rejected: { label: "Rejected", icon: XCircle, className: "bg-rose-50 text-rose-700" },
  revision_required: { label: "Revision Required", icon: AlertTriangle, className: "bg-orange-50 text-orange-700" },
};

const RISK_LEVEL_CONFIG = {
  low: { className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  medium: { className: "bg-amber-50 text-amber-700 border-amber-200" },
  high: { className: "bg-orange-50 text-orange-700 border-orange-200" },
  critical: { className: "bg-rose-50 text-rose-700 border-rose-200" },
};

export default function RiskWorkflowCard({ risk, requirements }) {
  const [expanded, setExpanded] = useState(false);
  const [approvalNotes, setApprovalNotes] = useState("");
  const [showApproval, setShowApproval] = useState(false);
  const [showDocUpload, setShowDocUpload] = useState(false);

  const { permissions, user } = usePermissions();
  const queryClient = useQueryClient();

  const requirement = requirements.find(r => r.id === risk.requirement_id);
  const statusConfig = WORKFLOW_STATUS_CONFIG[risk.workflow_status] || WORKFLOW_STATUS_CONFIG.draft;
  const riskConfig = RISK_LEVEL_CONFIG[risk.risk_level] || RISK_LEVEL_CONFIG.medium;
  const StatusIcon = statusConfig.icon;

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RiskAssessment.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["risk-assessments-workflow"] });
      toast.success("Assessment updated");
      setShowApproval(false);
      setApprovalNotes("");
    },
    onError: () => toast.error("Failed to update assessment"),
  });

  const handleSubmitForReview = () => {
    updateMutation.mutate({
      id: risk.id,
      data: { workflow_status: "pending_review" }
    });
  };

  const handleApprove = () => {
    updateMutation.mutate({
      id: risk.id,
      data: {
        workflow_status: "approved",
        approver_email: user?.email,
        approval_date: new Date().toISOString().split('T')[0],
        approval_notes: approvalNotes,
      }
    });
  };

  const handleReject = () => {
    updateMutation.mutate({
      id: risk.id,
      data: {
        workflow_status: "rejected",
        approver_email: user?.email,
        approval_date: new Date().toISOString().split('T')[0],
        approval_notes: approvalNotes,
      }
    });
  };

  const handleRequestRevision = () => {
    updateMutation.mutate({
      id: risk.id,
      data: {
        workflow_status: "revision_required",
        approver_email: user?.email,
        approval_notes: approvalNotes,
      }
    });
  };

  const canSubmit = permissions.canManageRisks && risk.workflow_status === "draft";
  const canApprove = permissions.canEditAll && risk.workflow_status === "pending_review";

  return (
    <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-5">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline" className={statusConfig.className}>
                  <StatusIcon className="w-3 h-3 mr-1" />
                  {statusConfig.label}
                </Badge>
                <Badge variant="outline" className={riskConfig.className}>
                  {risk.risk_level?.toUpperCase()}
                </Badge>
                {risk.priority && (
                  <Badge variant="outline" className="text-xs">
                    {risk.priority} priority
                  </Badge>
                )}
              </div>
              <h3 className="text-sm font-semibold text-slate-900 mb-1">
                {risk.hazard_description}
              </h3>
              {requirement && (
                <p className="text-xs text-slate-500">
                  Requirement: {requirement.clause_number} - {requirement.clause_title}
                </p>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </Button>
          </div>

          {/* Expanded Details */}
          {expanded && (
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-500">Hazard Type:</span>
                  <span className="ml-2 text-slate-900 font-medium capitalize">{risk.hazard_type}</span>
                </div>
                <div>
                  <span className="text-slate-500">Likelihood:</span>
                  <span className="ml-2 text-slate-900 font-medium capitalize">{risk.likelihood?.replace(/_/g, " ")}</span>
                </div>
                <div>
                  <span className="text-slate-500">Severity:</span>
                  <span className="ml-2 text-slate-900 font-medium capitalize">{risk.severity}</span>
                </div>
                {risk.assigned_to && (
                  <div>
                    <span className="text-slate-500">Assigned To:</span>
                    <span className="ml-2 text-slate-900 font-medium">{risk.assigned_to}</span>
                  </div>
                )}
              </div>

              {risk.mitigation_strategy && (
                <div>
                  <p className="text-xs font-semibold text-slate-700 mb-1">Mitigation Strategy:</p>
                  <p className="text-xs text-slate-600">{risk.mitigation_strategy}</p>
                </div>
              )}

              {risk.approval_notes && (
                <div className="bg-slate-50 p-3 rounded-lg">
                  <p className="text-xs font-semibold text-slate-700 mb-1">Approval Notes:</p>
                  <p className="text-xs text-slate-600">{risk.approval_notes}</p>
                  {risk.approver_email && (
                    <p className="text-xs text-slate-500 mt-2">
                      By {risk.approver_email} on {risk.approval_date ? format(new Date(risk.approval_date), "MMM d, yyyy") : ""}
                    </p>
                  )}
                </div>
              )}

              {/* Documents */}
              <div className="bg-slate-50 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-700">Documents</span>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowDocUpload(true)}
                    className="h-7 px-2 text-xs"
                  >
                    Upload
                  </Button>
                </div>
                <DocumentList entityType="RiskAssessment" entityId={risk.id} />
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2">
                {canSubmit && (
                  <Button
                    size="sm"
                    onClick={handleSubmitForReview}
                    disabled={updateMutation.isPending}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Send className="w-3 h-3 mr-1" />
                    Submit for Review
                  </Button>
                )}

                {canApprove && !showApproval && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowApproval(true)}
                  >
                    Review
                  </Button>
                )}
              </div>

              {/* Approval Section */}
              {showApproval && canApprove && (
                <div className="bg-slate-50 p-4 rounded-lg space-y-3">
                  <div>
                    <label className="text-xs font-medium text-slate-700 mb-1 block">
                      Review Notes
                    </label>
                    <Textarea
                      placeholder="Add your review comments..."
                      value={approvalNotes}
                      onChange={(e) => setApprovalNotes(e.target.value)}
                      rows={3}
                      className="text-xs"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      onClick={handleApprove}
                      disabled={updateMutation.isPending}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleRequestRevision}
                      disabled={updateMutation.isPending}
                    >
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      Request Revision
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleReject}
                      disabled={updateMutation.isPending}
                      className="text-rose-600 hover:text-rose-700"
                    >
                      <XCircle className="w-3 h-3 mr-1" />
                      Reject
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setShowApproval(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
      <DocumentUploader
        entityType="RiskAssessment"
        entityId={risk.id}
        open={showDocUpload}
        onClose={() => setShowDocUpload(false)}
      />
    </Card>
  );
}