import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, FileText, ShieldAlert } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

export default function RiskTemplateManager() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [form, setForm] = useState({
    name: "",
    description: "",
    hazard_type: "biological",
    standard_controls: [],
    review_frequency_days: 90,
    is_active: true,
    is_ccp_template: false,
    is_oprp_template: false,
    default_critical_limits: "",
    default_monitoring_procedure: "",
    default_corrective_action: "",
    default_verification: "",
  });
  const [controlInput, setControlInput] = useState("");

  const queryClient = useQueryClient();

  const { data: templates = [] } = useQuery({
    queryKey: ["risk-templates"],
    queryFn: () => base44.entities.RiskTemplate.list("-created_date", 100),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.RiskTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["risk-templates"] });
      toast.success("Template created");
      handleClose();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RiskTemplate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["risk-templates"] });
      toast.success("Template updated");
      handleClose();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RiskTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["risk-templates"] });
      toast.success("Template deleted");
    },
  });

  const handleOpen = (template = null) => {
    if (template) {
      setEditingTemplate(template);
      setForm({ ...template });
    } else {
      setEditingTemplate(null);
      setForm({
        name: "",
        description: "",
        hazard_type: "biological",
        standard_controls: [],
        review_frequency_days: 90,
        is_active: true,
        is_ccp_template: false,
        is_oprp_template: false,
        default_critical_limits: "",
        default_monitoring_procedure: "",
        default_corrective_action: "",
        default_verification: "",
      });
    }
    setShowDialog(true);
  };

  const handleClose = () => {
    setShowDialog(false);
    setEditingTemplate(null);
    setControlInput("");
  };

  const handleAddControl = () => {
    if (controlInput.trim()) {
      setForm({
        ...form,
        standard_controls: [...(form.standard_controls || []), controlInput.trim()],
      });
      setControlInput("");
    }
  };

  const handleRemoveControl = (index) => {
    const controls = [...(form.standard_controls || [])];
    controls.splice(index, 1);
    setForm({ ...form, standard_controls: controls });
  };

  const handleSave = () => {
    if (editingTemplate) {
      updateMutation.mutate({ id: editingTemplate.id, data: form });
    } else {
      createMutation.mutate(form);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">Risk Assessment Templates</h2>
          <p className="text-xs text-slate-500 mt-1">Standardized templates for common risk scenarios</p>
        </div>
        <Button onClick={() => handleOpen()} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="w-4 h-4 mr-1" />
          New Template
        </Button>
      </div>

      <div className="grid gap-3">
        {templates.map(template => (
          <Card key={template.id} className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-sm font-semibold text-slate-900">{template.name}</h3>
                    <Badge variant="outline" className="text-xs">
                      {template.hazard_type}
                    </Badge>
                    {!template.is_active && (
                      <Badge variant="secondary" className="text-xs">Inactive</Badge>
                    )}
                  </div>
                  {template.description && (
                    <p className="text-xs text-slate-600 mb-2">{template.description}</p>
                  )}
                  <div className="flex items-center gap-4 text-xs text-slate-500">
                    <span>Review every {template.review_frequency_days} days</span>
                    {template.standard_controls?.length > 0 && (
                      <span>• {template.standard_controls.length} standard controls</span>
                    )}
                    {template.is_ccp_template && (
                      <Badge className="bg-amber-100 text-amber-800 border border-amber-300 text-[10px] gap-1 py-0">
                        <ShieldAlert className="w-2.5 h-2.5" /> CCP
                      </Badge>
                    )}
                    {template.is_oprp_template && (
                      <Badge className="bg-blue-100 text-blue-800 border border-blue-300 text-[10px] gap-1 py-0">
                        <ShieldAlert className="w-2.5 h-2.5" /> OPRP
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleOpen(template)}
                    className="h-8 w-8 p-0"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      if (confirm("Delete this template?")) deleteMutation.mutate(template.id);
                    }}
                    className="h-8 w-8 p-0 text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {templates.length === 0 && (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-8 text-center">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-slate-500">No templates yet. Create your first template.</p>
            </CardContent>
          </Card>
        )}
      </div>

      <Dialog open={showDialog} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingTemplate ? "Edit" : "New"} Risk Template</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-xs">Template Name*</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g., Chemical Contamination"
              />
            </div>

            <div>
              <Label className="text-xs">Description</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Brief description..."
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Hazard Type*</Label>
                <Select value={form.hazard_type} onValueChange={(v) => setForm({ ...form, hazard_type: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="biological">Biological</SelectItem>
                    <SelectItem value="chemical">Chemical</SelectItem>
                    <SelectItem value="physical">Physical</SelectItem>
                    <SelectItem value="radiological">Radiological</SelectItem>
                    <SelectItem value="allergen">Allergen</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-xs">Review Frequency (days)</Label>
                <Input
                  type="number"
                  value={form.review_frequency_days}
                  onChange={(e) => setForm({ ...form, review_frequency_days: parseInt(e.target.value) })}
                />
              </div>
            </div>

            {/* HACCP Classification */}
            <div className="border border-amber-200 bg-amber-50 rounded-lg p-4 space-y-3">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-600" />
                <Label className="text-xs font-semibold text-amber-800">HACCP Classification</Label>
              </div>
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="is_ccp_template"
                    checked={!!form.is_ccp_template}
                    onCheckedChange={(v) => setForm({ ...form, is_ccp_template: !!v, is_oprp_template: v ? false : form.is_oprp_template })}
                  />
                  <Label htmlFor="is_ccp_template" className="text-xs cursor-pointer">Critical Control Point (CCP)</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="is_oprp_template"
                    checked={!!form.is_oprp_template}
                    onCheckedChange={(v) => setForm({ ...form, is_oprp_template: !!v, is_ccp_template: v ? false : form.is_ccp_template })}
                  />
                  <Label htmlFor="is_oprp_template" className="text-xs cursor-pointer">Operational PRP (OPRP)</Label>
                </div>
              </div>
              {(form.is_ccp_template || form.is_oprp_template) && (
                <div className="space-y-2">
                  <div>
                    <Label className="text-xs">Default Critical Limits</Label>
                    <Textarea value={form.default_critical_limits || ""} onChange={(e) => setForm({ ...form, default_critical_limits: e.target.value })} placeholder="e.g. Temperature ≤ 4°C; metal ≥ 2mm Fe" rows={2} className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs">Default Monitoring Procedure</Label>
                    <Textarea value={form.default_monitoring_procedure || ""} onChange={(e) => setForm({ ...form, default_monitoring_procedure: e.target.value })} placeholder="What, how, frequency, who..." rows={2} className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs">Default Corrective Action</Label>
                    <Textarea value={form.default_corrective_action || ""} onChange={(e) => setForm({ ...form, default_corrective_action: e.target.value })} placeholder="Actions when limits are exceeded..." rows={2} className="mt-1" />
                  </div>
                  <div>
                    <Label className="text-xs">Default Verification Procedure</Label>
                    <Textarea value={form.default_verification || ""} onChange={(e) => setForm({ ...form, default_verification: e.target.value })} placeholder="Calibration, audits, testing..." rows={2} className="mt-1" />
                  </div>
                </div>
              )}
            </div>

            <div>
              <Label className="text-xs">Standard Control Measures</Label>
              <div className="space-y-2">
                {(form.standard_controls || []).map((control, idx) => (
                  <div key={idx} className="flex items-center gap-2 p-2 bg-slate-50 rounded text-xs">
                    <span className="flex-1">{control}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveControl(idx)}
                      className="h-6 w-6 p-0"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 mt-2">
                <Input
                  value={controlInput}
                  onChange={(e) => setControlInput(e.target.value)}
                  placeholder="Add control measure..."
                  onKeyPress={(e) => e.key === "Enter" && handleAddControl()}
                />
                <Button size="sm" onClick={handleAddControl} variant="outline">
                  Add
                </Button>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleClose}>Cancel</Button>
            <Button onClick={handleSave} disabled={!form.name} className="bg-emerald-600 hover:bg-emerald-700">
              {editingTemplate ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}