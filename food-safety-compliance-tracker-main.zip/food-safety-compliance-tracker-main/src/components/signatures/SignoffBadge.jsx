import React from "react";
import { CheckCircle2, Pen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

export default function SignoffBadge({ signoffBy, signoffDate, signatureUrl, onSign, compact = false }) {
  if (signoffBy && signatureUrl) {
    return (
      <div className={`rounded-lg border border-emerald-200 bg-emerald-50 ${compact ? "p-2" : "p-3"}`}>
        <div className="flex items-center gap-2 mb-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <div className="min-w-0">
            <p className="text-xs font-semibold text-emerald-800">Signed off</p>
            <p className="text-[11px] text-emerald-600 truncate">
              {signoffBy}{signoffDate ? ` · ${format(new Date(signoffDate), "d MMM yyyy, HH:mm")}` : ""}
            </p>
          </div>
        </div>
        <img
          src={signatureUrl}
          alt="Signature"
          className="w-full h-12 object-contain bg-white border border-emerald-100 rounded"
        />
        {onSign && (
          <Button variant="ghost" size="sm" onClick={onSign} className="mt-2 w-full h-7 text-xs text-emerald-700 hover:bg-emerald-100">
            <Pen className="w-3 h-3 mr-1" />
            Re-sign
          </Button>
        )}
      </div>
    );
  }

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={onSign}
      className="w-full gap-2 border-dashed border-slate-300 text-slate-500 hover:border-emerald-400 hover:text-emerald-700 hover:bg-emerald-50"
    >
      <Pen className="w-3.5 h-3.5" />
      Sign Off
    </Button>
  );
}