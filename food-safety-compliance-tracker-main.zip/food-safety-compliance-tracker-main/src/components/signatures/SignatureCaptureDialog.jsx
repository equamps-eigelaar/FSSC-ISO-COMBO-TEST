import React, { useRef, useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Pen, Trash2, Check, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function SignatureCaptureDialog({ open, onClose, onSave, existingSignatureUrl, signerName }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [saving, setSaving] = useState(false);
  const lastPos = useRef(null);

  useEffect(() => {
    if (open) {
      setHasDrawn(false);
      setTimeout(() => {
        const canvas = canvasRef.current;
        if (canvas) {
          const ctx = canvas.getContext("2d");
          ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
      }, 50);
    }
  }, [open]);

  const getPos = (e, canvas) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    if (e.touches) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const startDrawing = (e) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsDrawing(true);
    setHasDrawn(true);
    lastPos.current = getPos(e, canvas);
  };

  const draw = (e) => {
    e.preventDefault();
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const pos = getPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(lastPos.current.x, lastPos.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = "#0f172a";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
    lastPos.current = pos;
  };

  const stopDrawing = (e) => {
    e?.preventDefault();
    setIsDrawing(false);
    lastPos.current = null;
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
  };

  const handleSave = async () => {
    const canvas = canvasRef.current;
    if (!canvas || !hasDrawn) {
      toast.error("Please draw your signature first");
      return;
    }
    setSaving(true);
    canvas.toBlob(async (blob) => {
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: blob });
        onSave(file_url);
        toast.success("Signature saved successfully");
        onClose();
      } catch (err) {
        toast.error("Failed to save signature");
      } finally {
        setSaving(false);
      }
    }, "image/png");
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <Pen className="w-4 h-4 text-emerald-600" />
            Digital Sign-Off
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {signerName && (
            <p className="text-sm text-slate-500">Signing as: <strong className="text-slate-800">{signerName}</strong></p>
          )}

          {existingSignatureUrl && (
            <div className="space-y-1">
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wide">Current signature</p>
              <img
                src={existingSignatureUrl}
                alt="Existing signature"
                className="h-16 w-full border border-slate-200 rounded-lg bg-white p-2 object-contain"
              />
              <p className="text-xs text-amber-600">Drawing a new signature will replace the existing one.</p>
            </div>
          )}

          <div className="space-y-1.5">
            <p className="text-xs text-slate-500 font-medium">Draw your signature below:</p>
            <div className="relative border-2 border-dashed border-slate-200 rounded-xl bg-slate-50 overflow-hidden select-none">
              <canvas
                ref={canvasRef}
                width={460}
                height={160}
                className="w-full touch-none cursor-crosshair block"
                style={{ height: "160px" }}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
              />
              {!hasDrawn && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <p className="text-sm text-slate-300 italic">Sign here</p>
                </div>
              )}
              {/* baseline */}
              <div className="absolute bottom-8 left-6 right-6 border-b border-slate-300 pointer-events-none" />
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <Button variant="outline" size="sm" onClick={clearCanvas} className="gap-1.5 text-rose-600 hover:text-rose-700 hover:bg-rose-50 border-rose-200">
              <Trash2 className="w-3.5 h-3.5" />
              Clear
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
              <Button
                size="sm"
                onClick={handleSave}
                disabled={saving || !hasDrawn}
                className="bg-emerald-600 hover:bg-emerald-700 gap-1.5"
              >
                {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                {saving ? "Saving…" : "Save Signature"}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}