import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sparkles, Check, X, Loader2, Calendar, User, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const PRIORITY_CONFIG = {
  critical: { color: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400", icon: AlertCircle },
  high: { color: "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400", icon: AlertCircle },
  medium: { color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400", icon: AlertCircle },
  low: { color: "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400", icon: AlertCircle }
};

export default function AISuggestedActions() {
  const [generating, setGenerating] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [summary, setSummary] = useState("");
  const [editingAction, setEditingAction] = useState(null);
  const [editedData, setEditedData] = useState({});
  const queryClient = useQueryClient();

  const createActionMutation = useMutation({
    mutationFn: (actionData) => base44.entities.ActionItem.create(actionData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['action-items'] });
      toast.success('Action item created');
    },
    onError: () => {
      toast.error('Failed to create action item');
    }
  });

  const handleGenerateSuggestions = async () => {
    setGenerating(true);
    try {
      const response = await base44.functions.invoke('suggestActionItems', {});
      setSuggestions(response.data.suggestions || []);
      setSummary(response.data.summary || "");
      toast.success(`Generated ${response.data.suggestions.length} suggestions`);
    } catch (error) {
      toast.error('Failed to generate suggestions');
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  const handleAccept = (suggestion) => {
    setEditingAction(suggestion);
    setEditedData({
      title: suggestion.title,
      description: suggestion.description,
      assigned_to: suggestion.recommended_owner !== "unassigned" ? suggestion.recommended_owner : "",
      timeline: suggestion.timeline,
      priority: suggestion.priority
    });
  };

  const handleCreateAction = () => {
    const dueDate = calculateDueDate(editedData.timeline);
    
    createActionMutation.mutate({
      title: editedData.title,
      description: editedData.description,
      source_type: "manual",
      priority: editedData.priority,
      status: "pending",
      assigned_to: editedData.assigned_to || undefined,
      due_date: dueDate
    });

    setSuggestions(prev => prev.filter(s => s !== editingAction));
    setEditingAction(null);
  };

  const handleReject = (suggestion) => {
    setSuggestions(prev => prev.filter(s => s !== suggestion));
    toast.success('Suggestion dismissed');
  };

  const calculateDueDate = (timeline) => {
    const now = new Date();
    const match = timeline.match(/(\d+)\s*(day|week|month)s?/i);
    
    if (!match) return null;
    
    const amount = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    
    if (unit === 'day') {
      now.setDate(now.getDate() + amount);
    } else if (unit === 'week') {
      now.setDate(now.getDate() + (amount * 7));
    } else if (unit === 'month') {
      now.setMonth(now.getMonth() + amount);
    }
    
    return now.toISOString().split('T')[0];
  };

  if (suggestions.length === 0 && !generating) {
    return (
      <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20 border-emerald-100 dark:border-emerald-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-emerald-900 dark:text-emerald-100">
            <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            AI Action Suggestions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <Sparkles className="w-12 h-12 text-emerald-400 dark:text-emerald-600 mx-auto mb-3" />
            <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">
              Let AI analyze your compliance data and suggest actionable items
            </p>
            <Button
              onClick={handleGenerateSuggestions}
              disabled={generating}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate Suggestions
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20 border-emerald-100 dark:border-emerald-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-emerald-900 dark:text-emerald-100">
              <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              AI Suggested Actions ({suggestions.length})
            </CardTitle>
            <Button
              size="sm"
              variant="outline"
              onClick={handleGenerateSuggestions}
              disabled={generating}
              className="border-emerald-300 dark:border-emerald-700"
            >
              {generating ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {summary && (
            <div className="bg-white/60 dark:bg-slate-800/60 rounded-lg p-3 mb-4">
              <p className="text-sm text-slate-700 dark:text-slate-300">{summary}</p>
            </div>
          )}

          {suggestions.map((suggestion, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-800 rounded-lg p-4 border border-emerald-100 dark:border-emerald-800 shadow-sm"
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-slate-900 dark:text-white text-sm mb-1">
                    {suggestion.title}
                  </h4>
                  <Badge className={PRIORITY_CONFIG[suggestion.priority].color}>
                    {suggestion.priority}
                  </Badge>
                </div>
                <div className="flex gap-1 shrink-0">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleAccept(suggestion)}
                    className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 min-h-[44px] min-w-[44px]"
                  >
                    <Check className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleReject(suggestion)}
                    className="text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 min-h-[44px] min-w-[44px]"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 mb-3 line-clamp-2">
                {suggestion.description}
              </p>

              <div className="flex flex-wrap gap-3 text-xs text-slate-500 dark:text-slate-400">
                <div className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  {suggestion.recommended_owner}
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {suggestion.timeline}
                </div>
              </div>

              {suggestion.source_reference && (
                <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    <span className="font-medium">Source:</span> {suggestion.source_reference}
                  </p>
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      <Dialog open={!!editingAction} onOpenChange={() => setEditingAction(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Review & Create Action</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label className="text-xs text-slate-500 dark:text-slate-400">Title</Label>
              <Input
                value={editedData.title || ""}
                onChange={(e) => setEditedData({ ...editedData, title: e.target.value })}
                className="mt-1"
              />
            </div>

            <div>
              <Label className="text-xs text-slate-500 dark:text-slate-400">Description</Label>
              <textarea
                value={editedData.description || ""}
                onChange={(e) => setEditedData({ ...editedData, description: e.target.value })}
                className="w-full min-h-[80px] px-3 py-2 text-sm border rounded-md mt-1 bg-white dark:bg-slate-800 dark:border-slate-700"
              />
            </div>

            <div>
              <Label className="text-xs text-slate-500 dark:text-slate-400">Assign To (Email)</Label>
              <Input
                type="email"
                value={editedData.assigned_to || ""}
                onChange={(e) => setEditedData({ ...editedData, assigned_to: e.target.value })}
                placeholder="user@example.com"
                className="mt-1"
              />
            </div>

            <div>
              <Label className="text-xs text-slate-500 dark:text-slate-400">Timeline</Label>
              <Input
                value={editedData.timeline || ""}
                onChange={(e) => setEditedData({ ...editedData, timeline: e.target.value })}
                placeholder="e.g., 2 weeks"
                className="mt-1"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setEditingAction(null)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateAction}
              disabled={createActionMutation.isPending}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {createActionMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                "Create Action"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}