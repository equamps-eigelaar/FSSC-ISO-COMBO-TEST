import React, { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Clock, User, GripVertical, Link2, CheckSquare } from "lucide-react";
import { format } from "date-fns";

const COLUMNS = [
  { id: "pending", label: "Pending", color: "bg-amber-500", headerBg: "bg-amber-50 border-amber-200" },
  { id: "in_progress", label: "In Progress", color: "bg-blue-500", headerBg: "bg-blue-50 border-blue-200" },
  { id: "blocked", label: "Blocked", color: "bg-rose-500", headerBg: "bg-rose-50 border-rose-200" },
  { id: "completed", label: "Completed", color: "bg-emerald-500", headerBg: "bg-emerald-50 border-emerald-200" },
];

const PRIORITY_COLORS = {
  critical: "bg-rose-50 text-rose-700 border-rose-200",
  high: "bg-orange-50 text-orange-700 border-orange-200",
  medium: "bg-amber-50 text-amber-700 border-amber-200",
  low: "bg-blue-50 text-blue-700 border-blue-200",
};

function isOverdue(action) {
  if (!action.due_date || action.status === "completed") return false;
  return new Date(action.due_date) < new Date();
}

function KanbanCard({ action, index, onClick, allActions }) {
  const dependencyTitles = (action.depends_on || []).map(id => allActions.find(a => a.id === id)?.title).filter(Boolean);
  const subtasks = action.subtasks || [];
  const completedSubtasks = subtasks.filter(s => s.completed).length;
  const hasBlockedDeps = (action.depends_on || []).some(id => {
    const dep = allActions.find(a => a.id === id);
    return dep && dep.status !== "completed";
  });

  return (
    <Draggable draggableId={action.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className={`bg-white rounded-lg border shadow-sm p-3 mb-2 cursor-pointer hover:shadow-md transition-shadow ${snapshot.isDragging ? "shadow-lg rotate-1" : ""} ${hasBlockedDeps ? "opacity-70 border-rose-200" : "border-slate-200"}`}
          onClick={() => onClick(action)}
        >
          <div className="flex items-start gap-1.5 mb-2">
            <div {...provided.dragHandleProps} className="mt-0.5 shrink-0 text-slate-300 hover:text-slate-500" onClick={e => e.stopPropagation()}>
              <GripVertical className="w-3.5 h-3.5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-slate-900 leading-snug line-clamp-2">{action.title}</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-1 mb-2">
            <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${PRIORITY_COLORS[action.priority] || ""}`}>
              {action.priority}
            </Badge>
            {isOverdue(action) && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-rose-50 text-rose-700 border-rose-200">
                <AlertTriangle className="w-2.5 h-2.5 mr-0.5" />Overdue
              </Badge>
            )}
            {hasBlockedDeps && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-rose-50 text-rose-600 border-rose-200">
                Dep. pending
              </Badge>
            )}
          </div>

          <div className="space-y-1 text-[10px] text-slate-500">
            {action.assigned_to && (
              <div className="flex items-center gap-1">
                <User className="w-2.5 h-2.5" />
                <span className="truncate">{action.assigned_to}</span>
              </div>
            )}
            {action.due_date && (
              <div className={`flex items-center gap-1 ${isOverdue(action) ? "text-rose-600 font-semibold" : ""}`}>
                <Clock className="w-2.5 h-2.5" />
                {format(new Date(action.due_date), "MMM d")}
              </div>
            )}
            {subtasks.length > 0 && (
              <div className="flex items-center gap-1">
                <CheckSquare className="w-2.5 h-2.5" />
                {completedSubtasks}/{subtasks.length} subtasks
              </div>
            )}
            {dependencyTitles.length > 0 && (
              <div className="flex items-center gap-1">
                <Link2 className="w-2.5 h-2.5" />
                {dependencyTitles.length} dep.
              </div>
            )}
          </div>

          {subtasks.length > 0 && (
            <div className="mt-2">
              <div className="h-1 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all"
                  style={{ width: `${(completedSubtasks / subtasks.length) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}
    </Draggable>
  );
}

export default function KanbanBoard({ actions, allActions, onCardClick, onStatusChange }) {
  const grouped = COLUMNS.reduce((acc, col) => {
    acc[col.id] = actions.filter(a => a.status === col.id);
    return acc;
  }, {});

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const { draggableId, destination } = result;
    const newStatus = destination.droppableId;
    const action = actions.find(a => a.id === draggableId);
    if (action && action.status !== newStatus) {
      onStatusChange(action, newStatus);
    }
  };

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="flex gap-4 overflow-x-auto pb-4" style={{ minHeight: "60vh" }}>
        {COLUMNS.map(col => (
          <div key={col.id} className="flex-shrink-0 w-64 flex flex-col">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-t-lg border ${col.headerBg} mb-1`}>
              <div className={`w-2 h-2 rounded-full ${col.color}`} />
              <span className="text-xs font-semibold text-slate-700">{col.label}</span>
              <span className="ml-auto text-xs text-slate-500 font-medium">{grouped[col.id].length}</span>
            </div>
            <Droppable droppableId={col.id}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={`flex-1 p-2 rounded-b-lg min-h-[120px] transition-colors ${snapshot.isDraggingOver ? "bg-slate-100" : "bg-slate-50"}`}
                >
                  {grouped[col.id].map((action, index) => (
                    <KanbanCard
                      key={action.id}
                      action={action}
                      index={index}
                      onClick={onCardClick}
                      allActions={allActions}
                    />
                  ))}
                  {provided.placeholder}
                  {grouped[col.id].length === 0 && !snapshot.isDraggingOver && (
                    <p className="text-[10px] text-slate-400 text-center pt-6">Drop items here</p>
                  )}
                </div>
              )}
            </Droppable>
          </div>
        ))}
      </div>
    </DragDropContext>
  );
}