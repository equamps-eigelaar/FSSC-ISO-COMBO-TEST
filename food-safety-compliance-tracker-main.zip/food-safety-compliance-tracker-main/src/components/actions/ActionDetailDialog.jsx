import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Plus, Trash2, Link2, CheckSquare, AlertTriangle, X } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import SignatureCaptureDialog from "@/components/signatures/SignatureCaptureDialog";
import SignoffBadge from "@/components/signatures/SignoffBadge";


const PRIORITY_COLORS = {
  critical: "bg-rose-50 text-rose-700 border-rose-200",
  high: "bg-orange-50 text-orange-700 border-orange-200",
  medium: "bg-amber-50 text-amber-700 border-amber-200",
  low: "bg-blue-50 text-blue-700 border-blue-200",
};

export default function ActionDetailDialog({ action, onClose, onUpdate, allActions = [] }) {
  const [status, setStatus] = useState(action.status);
  const [notes, setNotes] = useState(action.progress_notes || "");
  const [assignedTo, setAssignedTo] = useState(action.assigned_to || "");
  const [dueDate, setDueDate] = useState(action.due_date || "");
  const [subtasks, setSubtasks] = useState(action.subtasks || []);
  const [newSubtask, setNewSubtask] = useState("");
  const [depends_on, setDependsOn] = useState(action.depends_on || []);
  const [isSaving, setIsSaving] = useState(false);
  const [showSignature, setShowSignature] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  React.useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const otherActions = allActions.filter(a => a.id !== action.id);
  const completedSubtasks = subtasks.filter(s => s.completed).length;

  const handleAddSubtask = () => {
    if (!newSubtask.trim()) return;
    setSubtasks(prev => [...prev, { id: String(Date.now()), title: newSubtask.trim(), completed: false }]);
    setNewSubtask("");
  };

  const handleToggleSubtask = (id) => {
    setSubtasks(prev => prev.map(s => s.id === id ? { ...s, completed: !s.completed } : s));
  };

  const handleDeleteSubtask = (id) => {
    setSubtasks(prev => prev.filter(s => s.id !== id));
  };

  const handleToggleDependency = (depId) => {
    setDependsOn(prev => prev.includes(depId) ? prev.filter(id => id !== depId) : [...prev, depId]);
  };

  const handleSignoff = async (signatureUrl) => {
    await onUpdate({
      entityId: action.id,
      data: {
        signoff_signature_url: signatureUrl,
        signoff_by: currentUser?.email,
        signoff_date: new Date().toISOString(),
      }
    });
  };

  const handleSave = async () => {
    setIsSaving(true);
    const data = {
      status,
      progress_notes: notes,
      assigned_to: assignedTo,
      due_date: dueDate || undefined,
      subtasks,
      depends_on,
    };
    if (status === "completed") data.completed_date = new Date().toISOString();
    await onUpdate({ entityId: action.id, data });
    setIsSaving(false);
    onClose();
  };

  const blockedDeps = depends_on.map(id => allActions.find(a => a.id === id)).filter(a => a && a.status !== "completed");

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base pr-8">{action.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          {/* Blocked warning */}
          {blockedDeps.length > 0 && (
            <div className="flex items-start gap-2 px-3 py-2 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span>Waiting on: <strong>{blockedDeps.map(d => d.title).join(", ")}</strong></span>
            </div>
          )}

          {/* Description */}
          {action.description && (
            <div>
              <Label className="text-xs text-slate-500">Description</Label>
              <p className="text-sm text-slate-700 mt-1">{action.description}</p>
            </div>
          )}

          {/* Status + Priority */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Priority</Label>
              <div className="mt-1">
                <Badge variant="outline" className={`text-xs ${PRIORITY_COLORS[action.priority]}`}>{action.priority}</Badge>
              </div>
            </div>
          </div>

          {/* Assigned + Due */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Assigned To</Label>
              <Input className="mt-1" value={assignedTo} onChange={e => setAssignedTo(e.target.value)} placeholder="user@email.com" />
            </div>
            <div>
              <Label className="text-xs">Due Date</Label>
              <Input className="mt-1" type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
            </div>
          </div>

          {/* Subtasks */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-xs flex items-center gap-1.5">
                <CheckSquare className="w-3.5 h-3.5 text-emerald-600" />
                Subtasks {subtasks.length > 0 && <span className="text-slate-400">({completedSubtasks}/{subtasks.length})</span>}
              </Label>
            </div>
            {subtasks.length > 0 && (
              <div className="mb-2">
                <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden mb-3">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${subtasks.length ? (completedSubtasks / subtasks.length) * 100 : 0}%` }} />
                </div>
                <div className="space-y-1.5">
                  {subtasks.map(s => (
                    <div key={s.id} className="flex items-center gap-2 group">
                      <Checkbox
                        checked={s.completed}
                        onCheckedChange={() => handleToggleSubtask(s.id)}
                        id={`st-${s.id}`}
                      />
                      <label
                        htmlFor={`st-${s.id}`}
                        className={`text-sm flex-1 cursor-pointer ${s.completed ? "line-through text-slate-400" : "text-slate-700"}`}
                      >
                        {s.title}
                      </label>
                      <button onClick={() => handleDeleteSubtask(s.id)} className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-500 transition-opacity">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="flex gap-2">
              <Input
                value={newSubtask}
                onChange={e => setNewSubtask(e.target.value)}
                placeholder="Add a subtask…"
                className="text-sm h-8"
                onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); handleAddSubtask(); } }}
              />
              <Button size="sm" variant="outline" onClick={handleAddSubtask} className="h-8 px-2">
                <Plus className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>

          {/* Dependencies */}
          {otherActions.length > 0 && (
            <div>
              <Label className="text-xs flex items-center gap-1.5 mb-2">
                <Link2 className="w-3.5 h-3.5 text-blue-600" />
                Depends On (must complete before this starts)
              </Label>
              <div className="max-h-36 overflow-y-auto space-y-1.5 border border-slate-100 rounded-lg p-2 bg-slate-50">
                {otherActions.map(a => (
                  <div key={a.id} className="flex items-center gap-2">
                    <Checkbox
                      checked={depends_on.includes(a.id)}
                      onCheckedChange={() => handleToggleDependency(a.id)}
                      id={`dep-${a.id}`}
                    />
                    <label htmlFor={`dep-${a.id}`} className="text-xs text-slate-700 cursor-pointer flex-1 truncate">
                      {a.title}
                    </label>
                    <Badge className={`text-[10px] px-1 py-0 shrink-0 ${
                      a.status === "completed" ? "bg-emerald-100 text-emerald-700" :
                      a.status === "in_progress" ? "bg-blue-100 text-blue-700" :
                      "bg-slate-100 text-slate-600"
                    }`}>{a.status?.replace(/_/g, " ")}</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Progress Notes */}
          <div>
            <Label className="text-xs">Progress Notes</Label>
            <Textarea className="mt-1" value={notes} onChange={e => setNotes(e.target.value)} rows={3} placeholder="Add notes…" />
          </div>

          {/* Sign-Off */}
          <div>
            <Label className="text-xs mb-2 block">Auditor Sign-Off</Label>
            <SignoffBadge
              signoffBy={action.signoff_by}
              signoffDate={action.signoff_date}
              signatureUrl={action.signoff_signature_url}
              onSign={() => setShowSignature(true)}
              compact
            />
          </div>

          <SignatureCaptureDialog
            open={showSignature}
            onClose={() => setShowSignature(false)}
            onSave={handleSignoff}
            existingSignatureUrl={action.signoff_signature_url}
            signerName={currentUser?.full_name || currentUser?.email}
          />

          <div className="flex justify-end gap-2 pt-1">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSave} disabled={isSaving} className="bg-emerald-600 hover:bg-emerald-700">
              {isSaving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Save Changes
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}