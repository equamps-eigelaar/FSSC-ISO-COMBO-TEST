import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Video, Loader2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { format, addHours } from "date-fns";

export default function TeamsMeetingDialog({ onClose, defaultSubject = "", defaultDescription = "" }) {
  const now = new Date();
  const oneHourLater = addHours(now, 1);

  const [form, setForm] = useState({
    subject: defaultSubject || "Compliance Action Items Review",
    description: defaultDescription,
    startTime: format(now, "yyyy-MM-dd'T'HH:mm"),
    endTime: format(oneHourLater, "yyyy-MM-dd'T'HH:mm"),
  });
  const [loading, setLoading] = useState(false);
  const [meetingUrl, setMeetingUrl] = useState(null);

  const handleCreate = async () => {
    if (!form.subject.trim()) { toast.error("Subject is required"); return; }
    setLoading(true);
    try {
      const res = await base44.functions.invoke("createTeamsMeeting", {
        subject: form.subject,
        startTime: new Date(form.startTime).toISOString(),
        endTime: new Date(form.endTime).toISOString(),
        description: form.description,
      });
      setMeetingUrl(res.data.joinUrl);
      toast.success("Teams meeting created!");
    } catch {
      toast.error("Failed to create meeting. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Video className="w-4 h-4 text-blue-600" />
            Schedule Teams Meeting
          </DialogTitle>
        </DialogHeader>

        {meetingUrl ? (
          <div className="space-y-4 py-2">
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-center">
              <Video className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-emerald-800 mb-1">Meeting Created!</p>
              <p className="text-xs text-emerald-600 mb-3">{form.subject}</p>
              <a
                href={meetingUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                Join Meeting
              </a>
            </div>
            <Button variant="outline" className="w-full" onClick={onClose}>Close</Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <Label className="text-xs">Subject *</Label>
              <Input
                value={form.subject}
                onChange={e => setForm({ ...form, subject: e.target.value })}
                placeholder="Meeting subject"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Start Time</Label>
                <Input
                  type="datetime-local"
                  value={form.startTime}
                  onChange={e => setForm({ ...form, startTime: e.target.value })}
                />
              </div>
              <div>
                <Label className="text-xs">End Time</Label>
                <Input
                  type="datetime-local"
                  value={form.endTime}
                  onChange={e => setForm({ ...form, endTime: e.target.value })}
                />
              </div>
            </div>
            <div>
              <Label className="text-xs">Agenda / Description</Label>
              <Textarea
                value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
                rows={3}
                placeholder="Meeting agenda..."
              />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button onClick={handleCreate} disabled={loading} className="bg-blue-600 hover:bg-blue-700 text-white">
                {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Video className="w-4 h-4 mr-2" />}
                Create Meeting
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}