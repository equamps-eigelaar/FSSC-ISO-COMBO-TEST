import React, { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Upload, Camera } from "lucide-react";
import { toast } from "sonner";

const LOG_TYPES = [
  "temperature", "cleaning", "receiving_check", "ccp", "oprp", 
  "pest_control", "calibration", "other"
];

const SHIFTS = ["morning", "afternoon", "night"];

export default function MonitoringLogDialog({ open, onClose, log, templates }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    log_type: "temperature",
    log_date: new Date().toISOString().split('T')[0],
    shift: "morning",
    location: "",
    readings: [{ parameter: "", value: "", unit: "", acceptable_range: "", status: "acceptable", timestamp: new Date().toISOString() }],
    corrective_action: "",
    notes: "",
    status: "completed",
    photo_evidence: []
  });
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (log) {
      setFormData(log);
    } else {
      setFormData({
        log_type: "temperature",
        log_date: new Date().toISOString().split('T')[0],
        shift: "morning",
        location: "",
        readings: [{ parameter: "", value: "", unit: "", acceptable_range: "", status: "acceptable", timestamp: new Date().toISOString() }],
        corrective_action: "",
        notes: "",
        status: "completed",
        photo_evidence: []
      });
    }
  }, [log, open]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MonitoringLog.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring-logs'] });
      toast.success("Log saved");
      onClose();
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MonitoringLog.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring-logs'] });
      toast.success("Log updated");
      onClose();
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (log) {
      updateMutation.mutate({ id: log.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files);
    setUploading(true);
    try {
      const uploads = await Promise.all(
        files.map(file => base44.integrations.Core.UploadFile({ file }))
      );
      setFormData(prev => ({
        ...prev,
        photo_evidence: [...(prev.photo_evidence || []), ...uploads.map(u => u.file_url)]
      }));
      toast.success(`${files.length} photo(s) uploaded`);
    } catch (error) {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const addReading = () => {
    setFormData(prev => ({
      ...prev,
      readings: [...prev.readings, { 
        parameter: "", value: "", unit: "", acceptable_range: "", 
        status: "acceptable", timestamp: new Date().toISOString() 
      }]
    }));
  };

  const updateReading = (index, field, value) => {
    const newReadings = [...formData.readings];
    newReadings[index][field] = value;
    setFormData(prev => ({ ...prev, readings: newReadings }));
  };

  const removeReading = (index) => {
    setFormData(prev => ({
      ...prev,
      readings: prev.readings.filter((_, i) => i !== index)
    }));
  };

  const loadTemplate = (templateId) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setFormData(prev => ({
        ...prev,
        log_type: template.log_type,
        template_id: template.id,
        readings: template.parameters?.map(p => ({
          parameter: p.name,
          value: "",
          unit: p.unit || "",
          acceptable_range: p.acceptable_range || "",
          status: "acceptable",
          timestamp: new Date().toISOString()
        })) || prev.readings
      }));
      toast.success(`Template "${template.name}" loaded`);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{log ? "Edit Log" : "New Monitoring Log"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Template Selector */}
          {!log && templates.length > 0 && (
            <div>
              <Label>Load from Template</Label>
              <Select onValueChange={loadTemplate}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a template..." />
                </SelectTrigger>
                <SelectContent>
                  {templates.map(t => (
                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Log Type</Label>
              <Select value={formData.log_type} onValueChange={(v) => setFormData(prev => ({ ...prev, log_type: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LOG_TYPES.map(type => (
                    <SelectItem key={type} value={type}>
                      {type.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase())}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Date</Label>
              <Input
                type="date"
                value={formData.log_date}
                onChange={(e) => setFormData(prev => ({ ...prev, log_date: e.target.value }))}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Shift</Label>
              <Select value={formData.shift} onValueChange={(v) => setFormData(prev => ({ ...prev, shift: v }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SHIFTS.map(shift => (
                    <SelectItem key={shift} value={shift}>
                      {shift.charAt(0).toUpperCase() + shift.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Location/Area</Label>
              <Input
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                placeholder="e.g., Cold Storage Room 1"
              />
            </div>
          </div>

          {/* Readings */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Readings</Label>
              <Button type="button" size="sm" variant="outline" onClick={addReading}>
                <Plus className="w-4 h-4 mr-1" />
                Add Reading
              </Button>
            </div>
            <div className="space-y-3">
              {formData.readings.map((reading, index) => (
                <div key={index} className="p-3 border rounded-lg space-y-2">
                  <div className="grid grid-cols-4 gap-2">
                    <Input
                      placeholder="Parameter"
                      value={reading.parameter}
                      onChange={(e) => updateReading(index, 'parameter', e.target.value)}
                    />
                    <Input
                      placeholder="Value"
                      value={reading.value}
                      onChange={(e) => updateReading(index, 'value', e.target.value)}
                    />
                    <Input
                      placeholder="Unit"
                      value={reading.unit}
                      onChange={(e) => updateReading(index, 'unit', e.target.value)}
                    />
                    <Select value={reading.status} onValueChange={(v) => updateReading(index, 'status', v)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="acceptable">✓ OK</SelectItem>
                        <SelectItem value="out_of_spec">⚠ Out of Spec</SelectItem>
                        <SelectItem value="corrected">✓ Corrected</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Acceptable range (e.g., 2-8°C)"
                      value={reading.acceptable_range}
                      onChange={(e) => updateReading(index, 'acceptable_range', e.target.value)}
                      className="flex-1"
                    />
                    {formData.readings.length > 1 && (
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => removeReading(index)}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Photo Evidence */}
          <div>
            <Label>Photo Evidence</Label>
            <div className="flex items-center gap-2">
              <Button type="button" variant="outline" size="sm" disabled={uploading} asChild>
                <label className="cursor-pointer">
                  <Camera className="w-4 h-4 mr-2" />
                  {uploading ? "Uploading..." : "Add Photos"}
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    capture="environment"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </Button>
              {formData.photo_evidence?.length > 0 && (
                <Badge>{formData.photo_evidence.length} photo(s)</Badge>
              )}
            </div>
          </div>

          <div>
            <Label>Corrective Action (if out of spec)</Label>
            <Textarea
              value={formData.corrective_action}
              onChange={(e) => setFormData(prev => ({ ...prev, corrective_action: e.target.value }))}
              placeholder="Describe corrective action taken..."
            />
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Additional observations..."
            />
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
              {log ? "Update" : "Save"} Log
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}