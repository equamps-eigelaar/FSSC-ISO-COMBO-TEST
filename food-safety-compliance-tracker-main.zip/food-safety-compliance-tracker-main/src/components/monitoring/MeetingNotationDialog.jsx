import React, { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, FileText, Users, Mail, Calendar, Mic, MicOff, Languages, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";

export default function MeetingNotationDialog({ open, onOpenChange }) {
  const [language, setLanguage] = useState("english");
  const [loading, setLoading] = useState(false);
  const [users, setUsers] = useState([]);
  const [attendees, setAttendees] = useState([]);
  const [newAttendee, setNewAttendee] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  
  const [meetingData, setMeetingData] = useState({
    title: "",
    date: format(new Date(), "yyyy-MM-dd"),
    time: format(new Date(), "HH:mm"),
    location: "",
    notes: "",
  });

  useEffect(() => {
    if (open) {
      base44.entities.User.list().then(setUsers).catch(() => {});
    }
  }, [open]);

  const handleInputChange = (field, value) => {
    setMeetingData(prev => ({ ...prev, [field]: value }));
  };

  const addAttendee = (email) => {
    if (email && !attendees.includes(email)) {
      setAttendees(prev => [...prev, email]);
      setNewAttendee("");
    }
  };

  const removeAttendee = (email) => {
    setAttendees(prev => prev.filter(a => a !== email));
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        stream.getTracks().forEach(track => track.stop());
        await transcribeAudio(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
      toast.success(language === "english" ? "Recording started" : "Opname begin");
    } catch (error) {
      toast.error(language === "english" 
        ? "Microphone access denied" 
        : "Mikrofoon toegang geweier");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const transcribeAudio = async (audioBlob) => {
    setIsTranscribing(true);
    try {
      // Upload audio file
      const audioFile = new File([audioBlob], 'meeting-recording.webm', { type: 'audio/webm' });
      const uploadResult = await base44.integrations.Core.UploadFile({ file: audioFile });
      const audioUrl = uploadResult.file_url;

      // Transcribe using AI with language context
      const transcriptionPrompt = language === "english"
        ? `Transcribe this audio recording of a meeting. Provide detailed meeting notes including discussion points, decisions made, and action items. Format it clearly.`
        : `Transkribeer hierdie oudio-opname van 'n vergadering. Verskaf gedetailleerde vergadernotas insluitend besprekingspunte, besluite geneem, en aksie-items. Formateer dit duidelik.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: transcriptionPrompt,
        file_urls: [audioUrl]
      });

      const transcription = typeof result === 'string' ? result : result.transcription || result.response || JSON.stringify(result);

      // Append to existing notes or replace if empty
      setMeetingData(prev => ({
        ...prev,
        notes: prev.notes ? `${prev.notes}\n\n---\n\n${transcription}` : transcription
      }));

      toast.success(language === "english" 
        ? "Recording transcribed successfully" 
        : "Opname suksesvol getranskribeer");
    } catch (error) {
      toast.error(language === "english" 
        ? "Transcription failed: " + error.message 
        : "Transkripsie misluk: " + error.message);
    } finally {
      setIsTranscribing(false);
    }
  };

  const handleGenerateSummary = async () => {
    if (!meetingData.title || !meetingData.notes) {
      toast.error("Please provide meeting title and notes");
      return;
    }

    if (attendees.length === 0) {
      toast.error("Please add at least one attendee");
      return;
    }

    setLoading(true);
    try {
      // Generate AI summary in selected language
      const summaryPrompt = language === "english"
        ? `Generate a professional meeting summary based on the following notes. Format it clearly with sections for: Meeting Details, Key Discussion Points, Action Items, and Next Steps.\n\nMeeting: ${meetingData.title}\nDate: ${meetingData.date} at ${meetingData.time}\nLocation: ${meetingData.location}\n\nNotes:\n${meetingData.notes}`
        : `Genereer 'n professionele vergadersamevatting gebaseer op die volgende notas. Formateer dit duidelik met afdelings vir: Vergaderbesonderhede, Sleutelbespreekingspunte, Aksie-items, en Volgende Stappe.\n\nVergadering: ${meetingData.title}\nDatum: ${meetingData.date} om ${meetingData.time}\nLigging: ${meetingData.location}\n\nNotas:\n${meetingData.notes}`;

      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: summaryPrompt,
      });

      const summary = typeof aiResponse === 'string' ? aiResponse : aiResponse.summary || aiResponse.response || JSON.stringify(aiResponse);

      // Send email to all attendees
      const emailSubject = language === "english"
        ? `Meeting Summary: ${meetingData.title}`
        : `Vergadersamevatting: ${meetingData.title}`;

      const emailBody = language === "english"
        ? `Meeting Summary\n${"=".repeat(50)}\n\nMeeting: ${meetingData.title}\nDate: ${meetingData.date} at ${meetingData.time}\nLocation: ${meetingData.location || "N/A"}\n\n${summary}\n\n---\nThis summary was generated automatically from meeting notes.`
        : `Vergadersamevatting\n${"=".repeat(50)}\n\nVergadering: ${meetingData.title}\nDatum: ${meetingData.date} om ${meetingData.time}\nLigging: ${meetingData.location || "Nie beskikbaar"}\n\n${summary}\n\n---\nHierdie samevatting is outomaties gegenereer uit vergadernotas.`;

      // Send via Gmail to all attendees
      const response = await base44.functions.invoke('sendMeetingSummary', {
        attendees,
        subject: emailSubject,
        body: emailBody,
      });

      if (response.data.success) {
        toast.success(`Meeting summary sent to ${response.data.sent} attendee(s) via Gmail`);
      } else {
        toast.error(`Failed to send to some attendees: ${response.data.failed} failed`);
      }
      onOpenChange(false);
      
      // Reset form
      setMeetingData({
        title: "",
        date: format(new Date(), "yyyy-MM-dd"),
        time: format(new Date(), "HH:mm"),
        location: "",
        notes: "",
      });
      setAttendees([]);
      setLanguage("english");
    } catch (error) {
      toast.error("Failed to generate summary: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[95vh] overflow-y-auto">
        <DialogHeader className="pb-4 border-b">
          <DialogTitle className="flex items-center gap-3 text-xl">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <FileText className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <div className="font-bold">Meeting Notation Service</div>
              <div className="text-xs font-normal text-slate-500 mt-0.5">
                Record, transcribe, and share meeting minutes
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 pt-2">
          {/* Language Selection */}
          <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
            <Label className="text-sm font-semibold flex items-center gap-2 mb-3 text-slate-700">
              <Languages className="w-4 h-4 text-emerald-600" />
              Language / Taal
            </Label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="english">🇬🇧 English</SelectItem>
                <SelectItem value="afrikaans">🇿🇦 Afrikaans</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Meeting Details */}
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <h3 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-600" />
              {language === "english" ? "Meeting Details" : "Vergaderbesonderhede"}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Label htmlFor="title" className="text-sm font-medium text-slate-700">
                  {language === "english" ? "Meeting Title *" : "Vergadertitel *"}
                </Label>
                <Input
                  id="title"
                  value={meetingData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  placeholder={language === "english" ? "e.g., Daily Safety Briefing" : "bv. Daaglikse Veiligheidsbriefing"}
                  className="mt-1.5"
                />
              </div>

              <div>
                <Label htmlFor="date" className="text-sm font-medium text-slate-700">
                  {language === "english" ? "Date" : "Datum"}
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={meetingData.date}
                  onChange={(e) => handleInputChange("date", e.target.value)}
                  className="mt-1.5"
                />
              </div>

              <div>
                <Label htmlFor="time" className="text-sm font-medium text-slate-700">
                  {language === "english" ? "Time" : "Tyd"}
                </Label>
                <Input
                  id="time"
                  type="time"
                  value={meetingData.time}
                  onChange={(e) => handleInputChange("time", e.target.value)}
                  className="mt-1.5"
                />
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="location" className="text-sm font-medium text-slate-700">
                  {language === "english" ? "Location" : "Ligging"}
                </Label>
                <Input
                  id="location"
                  value={meetingData.location}
                  onChange={(e) => handleInputChange("location", e.target.value)}
                  placeholder={language === "english" ? "e.g., Production Floor, Boardroom" : "bv. Produksievloer, Bestuurskamer"}
                  className="mt-1.5"
                />
              </div>
            </div>
          </div>

          {/* Meeting Notes */}
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-3">
              <Label htmlFor="notes" className="text-sm font-semibold flex items-center gap-2 text-slate-700">
                <Mic className="w-4 h-4 text-emerald-600" />
                {language === "english" ? "Meeting Notes *" : "Vergadernotas *"}
              </Label>
              <div className="flex gap-2">
                {isRecording ? (
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    onClick={stopRecording}
                    className="gap-2"
                  >
                    <div className="w-2 h-2 rounded-full bg-white animate-pulse mr-1" />
                    {language === "english" ? "Stop" : "Stop"}
                  </Button>
                ) : (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={startRecording}
                    disabled={isTranscribing}
                    className="gap-2 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                  >
                    <Mic className="w-4 h-4" />
                    {language === "english" ? "Record" : "Neem op"}
                  </Button>
                )}
              </div>
            </div>
            <Textarea
              id="notes"
              value={meetingData.notes}
              onChange={(e) => handleInputChange("notes", e.target.value)}
              placeholder={language === "english" 
                ? "Type meeting notes here or click Record to transcribe audio automatically..."
                : "Tik vergadernotas hier of klik Neem op om oudio outomaties te transkribeer..."}
              className="min-h-[180px] border-slate-200 focus:border-emerald-400 focus:ring-emerald-400"
              rows={9}
              disabled={isTranscribing}
            />
            {isTranscribing && (
              <div className="flex items-center gap-2 text-sm text-emerald-600 mt-3 bg-emerald-50 px-3 py-2 rounded-lg">
                <Loader2 className="w-4 h-4 animate-spin" />
                {language === "english" ? "Transcribing audio..." : "Transkribeer oudio..."}
              </div>
            )}
          </div>

          {/* Attendees */}
          <div className="bg-white rounded-lg border border-slate-200 p-5">
            <Label className="text-sm font-semibold flex items-center gap-2 mb-3 text-slate-700">
              <Users className="w-4 h-4 text-emerald-600" />
              {language === "english" ? "Attendees *" : "Bywoners *"}
            </Label>
            
            <div className="flex gap-2 mb-3">
              <Select value={newAttendee} onValueChange={addAttendee}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder={language === "english" ? "Select user..." : "Kies gebruiker..."} />
                </SelectTrigger>
                <SelectContent>
                  {users.filter(u => !attendees.includes(u.email)).map(user => (
                    <SelectItem key={user.id} value={user.email}>
                      {user.full_name || user.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                type="button"
                variant="outline"
                onClick={() => addAttendee(newAttendee)}
                disabled={!newAttendee}
                className="border-emerald-200 text-emerald-700 hover:bg-emerald-50"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {attendees.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {attendees.map(email => {
                  const user = users.find(u => u.email === email);
                  return (
                    <Badge key={email} variant="secondary" className="gap-2 pr-1 bg-emerald-50 text-emerald-700 border-emerald-200">
                      <Mail className="w-3 h-3" />
                      {user?.full_name || email}
                      <button
                        type="button"
                        onClick={() => removeAttendee(email)}
                        className="ml-1 hover:bg-emerald-200 rounded-full p-0.5 transition-colors"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">
                {language === "english" ? "No attendees added yet" : "Geen bywoners bygevoeg nie"}
              </p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-6 border-t-2 border-slate-100">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 h-11"
            >
              {language === "english" ? "Cancel" : "Kanselleer"}
            </Button>
            <Button
              onClick={handleGenerateSummary}
              disabled={loading || !meetingData.title || !meetingData.notes || attendees.length === 0}
              className="flex-1 h-11 bg-emerald-600 hover:bg-emerald-700 gap-2 text-base font-semibold shadow-lg shadow-emerald-600/20"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  {language === "english" ? "Generating..." : "Genereer..."}
                </>
              ) : (
                <>
                  <Mail className="w-5 h-5" />
                  {language === "english" ? "Generate & Send Summary" : "Genereer & Stuur"}
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}