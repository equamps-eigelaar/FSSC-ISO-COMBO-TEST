import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function MonitoringTemplateManager({ open, onClose }) {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);

  const { data: templates = [] } = useQuery({
    queryKey: ['monitoring-templates'],
    queryFn: () => base44.entities.MonitoringTemplate.list('-created_date', 100),
    enabled: open
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MonitoringTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring-templates'] });
      toast.success("Template deleted");
    }
  });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Monitoring Templates</DialogTitle>
            <Button size="sm" onClick={() => { setEditingTemplate(null); setShowForm(true); }}>
              <Plus className="w-4 h-4 mr-2" />
              New Template
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-3">
          {templates.map(template => (
            <div key={template.id} className="p-4 border rounded-lg">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <h4 className="font-medium text-slate-900 dark:text-white">{template.name}</h4>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{template.description}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="capitalize">
                    {template.frequency}
                  </Badge>
                  <Badge className="capitalize">
                    {template.log_type.replace(/_/g, " ")}
                  </Badge>
                </div>
              </div>
              
              {template.parameters?.length > 0 && (
                <div className="flex gap-2 flex-wrap mb-2">
                  {template.parameters.map((param, idx) => (
                    <span key={idx} className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-1 rounded">
                      {param.name} ({param.unit})
                    </span>
                  ))}
                </div>
              )}

              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <div>
                  {template.reminder_enabled && (
                    <span>🔔 Reminder at {template.reminder_time}</span>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => { setEditingTemplate(template); setShowForm(true); }}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => deleteMutation.mutate(template.id)}
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </Button>
                </div>
              </div>
            </div>
          ))}

          {templates.length === 0 && (
            <div className="text-center py-8 text-slate-500 dark:text-slate-400">
              No templates yet. Create your first template to get started.
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}