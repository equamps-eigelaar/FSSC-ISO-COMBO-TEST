import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Upload, FileText } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function NewAssessmentDialog({ open, onClose, onCreated }) {
  const [title, setTitle] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [assignedTo, setAssignedTo] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file || !title || !customerName) {
      toast.error("Please fill in all required fields and upload a questionnaire file");
      return;
    }
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const assessment = await base44.entities.SupplierSelfAssessment.create({
        title,
        customer_name: customerName,
        assigned_to: assignedTo,
        due_date: dueDate || undefined,
        questionnaire_file_url: file_url,
        questionnaire_file_name: file.name,
        status: "draft",
      });
      toast.success("Assessment created! AI analysis starting…");
      onCreated(assessment);
      onClose();
      // Reset
      setTitle(""); setCustomerName(""); setAssignedTo(""); setDueDate(""); setFile(null);
    } catch (err) {
      toast.error("Failed to create assessment");
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>New Self-Assessment</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div>
            <Label>Assessment Title *</Label>
            <Input placeholder="e.g. Woolworths Supplier Assessment 2026" value={title} onChange={e => setTitle(e.target.value)} required />
          </div>
          <div>
            <Label>Customer / Auditing Party *</Label>
            <Input placeholder="e.g. Woolworths, Pick n Pay, Nestlé" value={customerName} onChange={e => setCustomerName(e.target.value)} required />
          </div>
          <div>
            <Label>Assigned To (email)</Label>
            <Input type="email" placeholder="person@ctpflexibles.co.za" value={assignedTo} onChange={e => setAssignedTo(e.target.value)} />
          </div>
          <div>
            <Label>Due Date</Label>
            <Input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
          </div>
          <div>
            <Label>Customer Questionnaire File * (PDF, DOCX, XLSX)</Label>
            <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-slate-200 rounded-lg p-6 cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors mt-1">
              {file ? (
                <>
                  <FileText className="w-6 h-6 text-emerald-600" />
                  <span className="text-sm text-emerald-700 font-medium">{file.name}</span>
                  <span className="text-xs text-slate-400">{(file.size / 1024).toFixed(1)} KB</span>
                </>
              ) : (
                <>
                  <Upload className="w-6 h-6 text-slate-400" />
                  <span className="text-sm text-slate-500">Click to upload questionnaire</span>
                  <span className="text-xs text-slate-400">PDF, DOCX, or XLSX</span>
                </>
              )}
              <input type="file" className="hidden" accept=".pdf,.docx,.doc,.xlsx,.xls" onChange={e => setFile(e.target.files[0])} />
            </label>
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
            <Button type="submit" disabled={uploading} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              {uploading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Uploading…</> : "Create & Analyse"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}