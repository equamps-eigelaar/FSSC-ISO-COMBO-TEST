import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle2, ClipboardList, Flag, ChevronDown, ChevronUp } from "lucide-react";

const RISK_CONFIG = {
  low:      { color: "text-emerald-600", bg: "bg-emerald-50",  border: "border-emerald-200", label: "Low Risk",      stroke: "#16a34a" },
  medium:   { color: "text-amber-600",   bg: "bg-amber-50",    border: "border-amber-200",   label: "Medium Risk",   stroke: "#d97706" },
  high:     { color: "text-orange-600",  bg: "bg-orange-50",   border: "border-orange-200",  label: "High Risk",     stroke: "#ea580c" },
  critical: { color: "text-red-600",     bg: "bg-red-50",      border: "border-red-200",     label: "Critical Risk", stroke: "#dc2626" },
};

const SEVERITY_BADGE = {
  low:      "bg-slate-100 text-slate-600",
  medium:   "bg-amber-100 text-amber-800",
  high:     "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
};

const PRIORITY_BADGE = {
  low:      "bg-slate-100 text-slate-600",
  medium:   "bg-amber-100 text-amber-800",
  high:     "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
};

export default function AssessmentScoreCard({ assessment }) {
  const [showRisks, setShowRisks] = useState(false);
  const [showActions, setShowActions] = useState(false);

  const cfg = RISK_CONFIG[assessment.risk_rating] || RISK_CONFIG.medium;
  const score = Math.round(assessment.risk_score || 0);
  const circumference = 2 * Math.PI * 40;
  const strokeDash = (score / 100) * circumference;

  const risks = assessment.identified_risks || [];
  const actions = assessment.required_actions || [];
  const flagged = assessment.flagged_for_review || [];
  const sections = assessment.compliance_status_by_section || [];

  return (
    <div className="space-y-3 mb-6">
      {/* Top row: score + section breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Score ring */}
        <Card className={`border ${cfg.border} ${cfg.bg} shadow-sm`}>
          <CardContent className="p-4 flex items-center gap-4">
            <svg width="90" height="90" viewBox="0 0 90 90" className="shrink-0">
              <circle cx="45" cy="45" r="40" fill="none" stroke="#e2e8f0" strokeWidth="8" />
              <circle cx="45" cy="45" r="40" fill="none" stroke={cfg.stroke} strokeWidth="8"
                strokeDasharray={`${strokeDash} ${circumference}`}
                strokeLinecap="round"
                transform="rotate(-90 45 45)" />
              <text x="45" y="45" textAnchor="middle" dominantBaseline="middle" fontSize="18" fontWeight="bold" fill={cfg.stroke}>{score}%</text>
            </svg>
            <div>
              <div className={`text-lg font-bold ${cfg.color}`}>{cfg.label}</div>
              <div className="text-xs text-slate-500 mt-0.5">Overall Compliance</div>
              <Badge variant="outline" className={`mt-2 text-xs ${cfg.color} border-current`}>
                {assessment.status?.replace(/_/g, " ")}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Section compliance */}
        <Card className="border-0 shadow-sm col-span-2">
          <CardHeader className="py-3 px-4 border-b border-slate-100">
            <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Section Compliance</CardTitle>
          </CardHeader>
          <CardContent className="p-3">
            {sections.length > 0 ? (
              <div className="space-y-1.5">
                {sections.map((s, i) => {
                  const pct = Math.round(s.score || 0);
                  const barColor = pct >= 80 ? "bg-emerald-500" : pct >= 60 ? "bg-amber-500" : pct >= 40 ? "bg-orange-500" : "bg-red-500";
                  return (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-xs text-slate-600 w-40 truncate shrink-0">{s.section}</span>
                      <div className="flex-1 bg-slate-100 rounded-full h-2">
                        <div className={`h-2 rounded-full ${barColor}`} style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs font-medium text-slate-700 w-8 text-right">{pct}%</span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="space-y-1.5">
                {(assessment.ai_gaps || []).slice(0, 4).map((g, i) => (
                  <p key={i} className="text-xs text-slate-700 flex items-start gap-1.5">
                    <span className="text-orange-500 shrink-0 mt-0.5">•</span>{g}
                  </p>
                ))}
                {!assessment.ai_gaps?.length && <p className="text-xs text-slate-400">No gaps identified</p>}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Identified Risks */}
      {risks.length > 0 && (
        <Card className="border-0 shadow-sm border-l-4 border-l-orange-400">
          <CardContent className="p-0">
            <button
              className="w-full flex items-center gap-2 px-4 py-3 text-left hover:bg-slate-50 transition-colors"
              onClick={() => setShowRisks(v => !v)}
            >
              <AlertTriangle className="w-4 h-4 text-orange-500 shrink-0" />
              <span className="text-sm font-semibold text-slate-800 flex-1">
                Identified Risks <span className="text-orange-600">({risks.length})</span>
              </span>
              {showRisks ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
            </button>
            {showRisks && (
              <div className="px-4 pb-3 space-y-2 border-t border-slate-100">
                {risks.map((r, i) => (
                  <div key={i} className="flex items-start gap-2 pt-2">
                    <Badge className={`text-xs shrink-0 mt-0.5 ${SEVERITY_BADGE[r.severity] || SEVERITY_BADGE.medium}`}>
                      {r.severity}
                    </Badge>
                    <div>
                      <p className="text-xs text-slate-800">{r.risk}</p>
                      {r.area && <p className="text-xs text-slate-400 mt-0.5">Area: {r.area}</p>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Required Actions */}
      {actions.length > 0 && (
        <Card className="border-0 shadow-sm border-l-4 border-l-blue-400">
          <CardContent className="p-0">
            <button
              className="w-full flex items-center gap-2 px-4 py-3 text-left hover:bg-slate-50 transition-colors"
              onClick={() => setShowActions(v => !v)}
            >
              <ClipboardList className="w-4 h-4 text-blue-500 shrink-0" />
              <span className="text-sm font-semibold text-slate-800 flex-1">
                Required Actions <span className="text-blue-600">({actions.length})</span>
              </span>
              {showActions ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
            </button>
            {showActions && (
              <div className="px-4 pb-3 space-y-2 border-t border-slate-100">
                {actions.map((a, i) => (
                  <div key={i} className="flex items-start gap-2 pt-2">
                    <Badge className={`text-xs shrink-0 mt-0.5 ${PRIORITY_BADGE[a.priority] || PRIORITY_BADGE.medium}`}>
                      {a.priority}
                    </Badge>
                    <div>
                      <p className="text-xs text-slate-800">{a.action}</p>
                      {a.area && <p className="text-xs text-slate-400 mt-0.5">Area: {a.area}</p>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Flagged for Review */}
      {flagged.length > 0 && (
        <Card className="border-0 shadow-sm border-l-4 border-l-purple-400 bg-purple-50">
          <CardContent className="px-4 py-3">
            <div className="flex items-center gap-2 mb-2">
              <Flag className="w-4 h-4 text-purple-500" />
              <span className="text-sm font-semibold text-purple-800">Flagged for Human Review ({flagged.length})</span>
            </div>
            <ul className="space-y-1">
              {flagged.map((f, i) => (
                <li key={i} className="text-xs text-purple-700 flex items-start gap-1.5">
                  <span className="shrink-0 mt-0.5">•</span>{f}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}