import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronDown, ChevronUp, Sparkles, Flag } from "lucide-react";

const ANSWER_CONFIG = {
  yes: { label: "Yes", color: "bg-emerald-100 text-emerald-800" },
  partial: { label: "Partial", color: "bg-amber-100 text-amber-800" },
  no: { label: "No", color: "bg-red-100 text-red-800" },
  na: { label: "N/A", color: "bg-slate-100 text-slate-600" },
};

function QuestionRow({ question, onChange }) {
  const [expanded, setExpanded] = useState(question.needs_review || false);
  const aiDiffers = question.ai_answer && question.user_answer && question.ai_answer !== question.user_answer;

  return (
    <div className={`border rounded-lg overflow-hidden ${question.needs_review ? "border-purple-200 bg-purple-50/30" : "border-slate-100"}`}>
      <div className="flex items-start gap-3 p-3 hover:bg-slate-50 cursor-pointer" onClick={() => setExpanded(v => !v)}>
        <div className="flex-1 min-w-0">
          <p className="text-sm text-slate-800 leading-snug">{question.question}</p>
          {question.requirement && (
            <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">Requirement: {question.requirement}</p>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {question.needs_review && (
            <span title="Flagged for review">
              <Flag className="w-3.5 h-3.5 text-purple-500" />
            </span>
          )}
          {aiDiffers && (
            <span title="You changed the AI answer">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            </span>
          )}
          <Badge className={`text-xs ${ANSWER_CONFIG[question.user_answer || question.ai_answer]?.color || "bg-slate-100 text-slate-600"}`}>
            {ANSWER_CONFIG[question.user_answer || question.ai_answer]?.label || "-"}
          </Badge>
          {expanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </div>
      </div>

      {expanded && (
        <div className="px-3 pb-3 pt-0 border-t border-slate-100 bg-slate-50 space-y-3">
          {question.needs_review && (
            <div className="flex items-start gap-1.5 pt-2 bg-purple-100 rounded px-2 py-1.5 -mx-0">
              <Flag className="w-3.5 h-3.5 text-purple-600 mt-0.5 shrink-0" />
              <p className="text-xs text-purple-700 font-medium">Flagged for review — please verify this answer with evidence</p>
            </div>
          )}
          {question.risk_flag && (
            <div className="flex items-start gap-1.5 bg-orange-50 rounded px-2 py-1.5">
              <span className="text-orange-500 text-xs font-medium shrink-0">⚠ Risk:</span>
              <p className="text-xs text-orange-700">{question.risk_flag}</p>
            </div>
          )}
          {question.comments && (
            <div className="flex items-start gap-1.5 pt-2">
              <Sparkles className="w-3.5 h-3.5 text-purple-500 mt-0.5 shrink-0" />
              <p className="text-xs text-slate-600 italic">{question.comments}</p>
            </div>
          )}
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="text-xs font-medium text-slate-600 mb-1 block">Your Answer</label>
              <Select value={question.user_answer || question.ai_answer} onValueChange={val => onChange({ ...question, user_answer: val })}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">✅ Yes — Compliant</SelectItem>
                  <SelectItem value="partial">⚠️ Partial — Some gaps</SelectItem>
                  <SelectItem value="no">❌ No — Non-compliant</SelectItem>
                  <SelectItem value="na">➖ N/A — Not applicable</SelectItem>
                </SelectContent>
              </Select>
              {question.ai_answer && (
                <p className="text-xs text-slate-400 mt-1">AI suggested: <strong>{ANSWER_CONFIG[question.ai_answer]?.label}</strong></p>
              )}
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-600 mb-1 block">Evidence / Notes</label>
            <Textarea
              placeholder="Reference document, procedure, or supporting evidence…"
              value={question.evidence_notes || ""}
              onChange={e => onChange({ ...question, evidence_notes: e.target.value })}
              rows={2}
              className="text-xs resize-none"
            />
          </div>
        </div>
      )}
    </div>
  );
}

export default function AssessmentQuestionsEditor({ sections, onChange }) {
  const updateQuestion = (sectionIdx, qIdx, updatedQ) => {
    const newSections = sections.map((s, si) => {
      if (si !== sectionIdx) return s;
      return {
        ...s,
        questions: s.questions.map((q, qi) => qi === qIdx ? updatedQ : q)
      };
    });
    onChange(newSections);
  };

  return (
    <div className="space-y-4">
      {sections.map((section, si) => (
        <Card key={si} className="border-0 shadow-sm">
          <CardHeader className="py-3 px-4 border-b border-slate-100">
            <CardTitle className="text-sm font-semibold text-slate-800">{section.section_title}</CardTitle>
            <div className="text-xs text-slate-500">
              {section.questions?.length || 0} questions ·{" "}
              {section.questions?.filter(q => (q.user_answer || q.ai_answer) === "yes").length || 0} compliant ·{" "}
              {section.questions?.filter(q => q.needs_review).length > 0 && (
                <span className="text-purple-600 font-medium">
                  {section.questions.filter(q => q.needs_review).length} need review
                </span>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-3 space-y-2">
            {(section.questions || []).map((q, qi) => (
              <QuestionRow
                key={qi}
                question={q}
                onChange={updated => updateQuestion(si, qi, updated)}
              />
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}