import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ClipboardCheck, Calendar, User, ChevronRight, Plus, Trash2 } from "lucide-react";
import { format } from "date-fns";

const RISK_COLORS = {
  low: "bg-emerald-100 text-emerald-800 border-emerald-200",
  medium: "bg-amber-100 text-amber-800 border-amber-200",
  high: "bg-orange-100 text-orange-800 border-orange-200",
  critical: "bg-red-100 text-red-800 border-red-200",
};

const STATUS_COLORS = {
  draft: "bg-slate-100 text-slate-600",
  in_progress: "bg-blue-100 text-blue-700",
  completed: "bg-emerald-100 text-emerald-700",
  submitted: "bg-purple-100 text-purple-700",
};

export default function AssessmentList({ assessments, onSelect, onNew, onDelete }) {
  if (assessments.length === 0) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="p-12 text-center">
          <ClipboardCheck className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500 font-medium mb-2">No self-assessments yet</p>
          <p className="text-slate-400 text-sm mb-6">Upload a customer questionnaire to get started</p>
          <Button onClick={onNew} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-2" />
            New Assessment
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {assessments.map(a => (
        <Card key={a.id} className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => onSelect(a)}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
                <ClipboardCheck className="w-5 h-5 text-emerald-600" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-sm font-semibold text-slate-900 truncate">{a.title}</h3>
                  <Badge variant="outline" className={`text-xs shrink-0 ${STATUS_COLORS[a.status]}`}>
                    {a.status?.replace(/_/g, " ")}
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                  <span className="font-medium text-slate-700">{a.customer_name}</span>
                  {a.assigned_to && <span className="flex items-center gap-1"><User className="w-3 h-3" />{a.assigned_to}</span>}
                  {a.due_date && <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{format(new Date(a.due_date), "MMM d, yyyy")}</span>}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {a.risk_score != null && (
                  <div className="text-right">
                    <div className="text-lg font-bold text-slate-900">{Math.round(a.risk_score)}%</div>
                    {a.risk_rating && (
                      <Badge variant="outline" className={`text-xs ${RISK_COLORS[a.risk_rating]}`}>
                        {a.risk_rating}
                      </Badge>
                    )}
                  </div>
                )}
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-300 hover:text-rose-500"
                  onClick={e => { e.stopPropagation(); onDelete(a.id); }}>
                  <Trash2 className="w-4 h-4" />
                </Button>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}