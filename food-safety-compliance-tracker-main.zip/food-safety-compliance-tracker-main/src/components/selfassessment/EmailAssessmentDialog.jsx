import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Mail } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function EmailAssessmentDialog({ open, onClose, assessment, onSent }) {
  const [recipientEmail, setRecipientEmail] = useState(assessment?.submitted_to || assessment?.customer_name ? "" : "");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!recipientEmail) { toast.error("Please enter a recipient email"); return; }
    setSending(true);
    try {
      await base44.functions.invoke("emailSelfAssessment", {
        assessment_id: assessment.id,
        recipient_email: recipientEmail,
        message
      });
      toast.success("Assessment emailed successfully!");
      onSent?.();
      onClose();
    } catch (err) {
      toast.error("Failed to send email");
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-emerald-600" />
            Email Assessment Report
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <div>
            <Label>Recipient Email *</Label>
            <Input
              type="email"
              placeholder="customer@example.com"
              value={recipientEmail}
              onChange={e => setRecipientEmail(e.target.value)}
            />
            <p className="text-xs text-slate-400 mt-1">A full HTML assessment report will be emailed to this address.</p>
          </div>
          <div>
            <Label>Personal Message (optional)</Label>
            <Textarea
              placeholder="Please find attached our completed self-assessment…"
              value={message}
              onChange={e => setMessage(e.target.value)}
              rows={3}
            />
          </div>
          <div className="flex gap-2 pt-1">
            <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
            <Button onClick={handleSend} disabled={sending} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              {sending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Sending…</> : <><Mail className="w-4 h-4 mr-2" />Send Report</>}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}