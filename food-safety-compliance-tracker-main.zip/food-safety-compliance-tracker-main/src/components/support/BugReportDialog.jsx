import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

const EMPTY_FORM = {
  reporter_email: "",
  reporter_name: "",
  title: "",
  category: "bug",
  priority: "medium",
  ncr_date: new Date().toISOString().slice(0, 10),
  ncr_time: new Date().toTimeString().slice(0, 5),
  issued_by: "",
  product: "",
  qms_ref: "",
  owner_issued_to: "",
  action_by_date: "",
  shift: "",
  customer_supplier: "",
  is_external_complaint: false,
  is_internal_complaint: false,
  section_a_issued_by: "",
  section_a_non_conformance_details: "",
  section_b_issued_to: "",
  root_cause: "",
  corrections: "",
  deviation_request_included: false,
  deviation_request_number: "",
  corrections_completion_date: "",
  corrections_name: "",
  corrections_signature: "",
  section_c_issued_to: "",
  corrective_preventive_actions: "",
  corrective_category: "",
  corrective_completion_date: "",
  corrective_name: "",
  corrective_signature: "",
  section_d_follow_up: "",
  action_acceptable: "",
  follow_up_signature: "",
  follow_up_date: "",
  section_e_extension_reason: "",
  extension_new_completion_date: "",
  extension_new_followup_date: "",
  extension_signature: "",
  extension_date: "",
};

function Field({ label, required, children }) {
  return (
    <div>
      <Label className="text-xs font-medium text-slate-600">
        {label}{required && <span className="text-rose-500 ml-0.5">*</span>}
      </Label>
      <div className="mt-1">{children}</div>
    </div>
  );
}

function SectionHeader({ letter, title, subtitle }) {
  return (
    <div className="flex items-start gap-3 bg-slate-800 text-white px-4 py-2.5 rounded-lg mt-4">
      <span className="font-bold text-sm shrink-0">{letter}.</span>
      <div>
        <p className="font-semibold text-sm">{title}</p>
        {subtitle && <p className="text-xs text-slate-300">{subtitle}</p>}
      </div>
    </div>
  );
}

export default function BugReportDialog({ open, onOpenChange }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const queryClient = useQueryClient();

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const generateTicketNumber = () => `NCR-${String(Math.floor(Math.random() * 1000000)).padStart(6, '0')}`;

  const createTicketMutation = useMutation({
    mutationFn: async (data) => {
      const ticket = await base44.entities.SupportTicket.create(data);
      await base44.functions.invoke('sendTicketNotification', {
        ticketId: ticket.id,
        ticketNumber: ticket.ticket_number,
        title: ticket.title,
        description: ticket.description || ticket.section_a_non_conformance_details,
        reporterEmail: ticket.reporter_email,
        category: ticket.category,
        priority: ticket.priority,
      });
      return ticket;
    },
    onSuccess: (ticket) => {
      queryClient.invalidateQueries({ queryKey: ["tickets"] });
      toast.success(`NCR ${ticket.ticket_number} submitted successfully`);
      setForm(EMPTY_FORM);
      onOpenChange(false);
    },
    onError: () => toast.error("Failed to submit NCR"),
  });

  const handleSubmit = () => {
    if (!form.title.trim() || !form.reporter_email.trim()) {
      toast.error("Title and email are required");
      return;
    }
    createTicketMutation.mutate({
      ...form,
      ticket_number: generateTicketNumber(),
      description: form.section_a_non_conformance_details || form.title,
      status: "open",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base font-bold">Customer Complaint / Non-Conformance Report (NCR)</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Header row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
            <Field label="Date" required>
              <Input type="date" value={form.ncr_date} onChange={e => set("ncr_date", e.target.value)} />
            </Field>
            <Field label="Time">
              <Input type="time" value={form.ncr_time} onChange={e => set("ncr_time", e.target.value)} />
            </Field>
            <Field label="Issued By" required>
              <Input value={form.issued_by} onChange={e => set("issued_by", e.target.value)} placeholder="Name" />
            </Field>
            <Field label="Your Email" required>
              <Input type="email" value={form.reporter_email} onChange={e => set("reporter_email", e.target.value)} placeholder="email@company.com" />
            </Field>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Field label="Product">
              <Input value={form.product} onChange={e => set("product", e.target.value)} />
            </Field>
            <Field label="QMS Ref">
              <Input value={form.qms_ref} onChange={e => set("qms_ref", e.target.value)} />
            </Field>
            <Field label="Owner / Issued To">
              <Input value={form.owner_issued_to} onChange={e => set("owner_issued_to", e.target.value)} />
            </Field>
            <Field label="Action By Date">
              <Input type="date" value={form.action_by_date} onChange={e => set("action_by_date", e.target.value)} />
            </Field>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 items-end">
            <Field label="Shift">
              <Select value={form.shift} onValueChange={v => set("shift", v)}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="morning">Morning</SelectItem>
                  <SelectItem value="afternoon">Afternoon</SelectItem>
                  <SelectItem value="night">Night</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Customer / Supplier">
              <Input value={form.customer_supplier} onChange={e => set("customer_supplier", e.target.value)} />
            </Field>
            <div className="flex items-center gap-2 pt-5">
              <Checkbox id="ext" checked={form.is_external_complaint} onCheckedChange={v => set("is_external_complaint", v)} />
              <Label htmlFor="ext" className="text-xs cursor-pointer">External Complaint</Label>
            </div>
            <div className="flex items-center gap-2 pt-5">
              <Checkbox id="int" checked={form.is_internal_complaint} onCheckedChange={v => set("is_internal_complaint", v)} />
              <Label htmlFor="int" className="text-xs cursor-pointer">Internal Complaint</Label>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Title / Summary" required>
              <Input value={form.title} onChange={e => set("title", e.target.value)} placeholder="Brief NCR title" />
            </Field>
            <Field label="Priority">
              <Select value={form.priority} onValueChange={v => set("priority", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>

          {/* Section A */}
          <SectionHeader letter="A" title="ISSUED BY" subtitle="Details of Non-Conformance" />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Field label="Issued By (Name/Dept)">
              <Input value={form.section_a_issued_by} onChange={e => set("section_a_issued_by", e.target.value)} />
            </Field>
            <div className="sm:col-span-2">
              <Field label="Details of Non-Conformance">
                <Textarea value={form.section_a_non_conformance_details} onChange={e => set("section_a_non_conformance_details", e.target.value)} className="h-20" />
              </Field>
            </div>
          </div>

          {/* Section B */}
          <SectionHeader letter="B" title="ISSUED TO" subtitle="Root Cause & Corrections" />
          <Field label="Issued To">
            <Input value={form.section_b_issued_to} onChange={e => set("section_b_issued_to", e.target.value)} />
          </Field>
          <Field label="1. Root Cause (e.g. use WI 11.1 Five Whys)">
            <Textarea value={form.root_cause} onChange={e => set("root_cause", e.target.value)} className="h-20" />
          </Field>
          <Field label="2. Corrections">
            <Textarea value={form.corrections} onChange={e => set("corrections", e.target.value)} className="h-20" />
          </Field>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 items-end">
            <div className="flex items-center gap-2 pt-5">
              <Checkbox id="dev" checked={form.deviation_request_included} onCheckedChange={v => set("deviation_request_included", v)} />
              <Label htmlFor="dev" className="text-xs cursor-pointer">Deviation Request Included?</Label>
            </div>
            <Field label="Deviation Request Number">
              <Input value={form.deviation_request_number} onChange={e => set("deviation_request_number", e.target.value)} disabled={!form.deviation_request_included} />
            </Field>
            <Field label="Name">
              <Input value={form.corrections_name} onChange={e => set("corrections_name", e.target.value)} />
            </Field>
            <Field label="Completion Date">
              <Input type="date" value={form.corrections_completion_date} onChange={e => set("corrections_completion_date", e.target.value)} />
            </Field>
          </div>

          {/* Section C */}
          <SectionHeader letter="C" title="ISSUED TO" subtitle="Corrective (Preventive) Actions" />
          <Field label="Issued To">
            <Input value={form.section_c_issued_to} onChange={e => set("section_c_issued_to", e.target.value)} />
          </Field>
          <Field label="Corrective / Preventive Actions">
            <Textarea value={form.corrective_preventive_actions} onChange={e => set("corrective_preventive_actions", e.target.value)} className="h-20" />
          </Field>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-2">
              <Field label="Category">
                <Select value={form.corrective_category} onValueChange={v => set("corrective_category", v)}>
                  <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="document">Document</SelectItem>
                    <SelectItem value="records">Records</SelectItem>
                    <SelectItem value="process">Process</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                    <SelectItem value="people_training">People – Training</SelectItem>
                    <SelectItem value="people_behaviour">People – Behaviour</SelectItem>
                    <SelectItem value="plant">Plant</SelectItem>
                    <SelectItem value="equipment">Equipment</SelectItem>
                    <SelectItem value="technology">Technology</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
            </div>
            <Field label="Name">
              <Input value={form.corrective_name} onChange={e => set("corrective_name", e.target.value)} />
            </Field>
            <Field label="Completion Date">
              <Input type="date" value={form.corrective_completion_date} onChange={e => set("corrective_completion_date", e.target.value)} />
            </Field>
          </div>

          {/* Section D */}
          <SectionHeader letter="D" title="BRC T/LEADER" subtitle="Follow-up Report" />
          <Field label="Follow-up Report Details">
            <Textarea value={form.section_d_follow_up} onChange={e => set("section_d_follow_up", e.target.value)} className="h-20" />
          </Field>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Action Acceptable?">
              <Select value={form.action_acceptable} onValueChange={v => set("action_acceptable", v)}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Yes</SelectItem>
                  <SelectItem value="no">No</SelectItem>
                </SelectContent>
              </Select>
            </Field>
            <Field label="Signature">
              <Input value={form.follow_up_signature} onChange={e => set("follow_up_signature", e.target.value)} />
            </Field>
            <Field label="Date">
              <Input type="date" value={form.follow_up_date} onChange={e => set("follow_up_date", e.target.value)} />
            </Field>
          </div>

          {/* Section E */}
          <SectionHeader letter="E" title="BRC T/LEADER" subtitle="Extension Request" />
          <Field label="Reason for Extension">
            <Textarea value={form.section_e_extension_reason} onChange={e => set("section_e_extension_reason", e.target.value)} className="h-16" />
          </Field>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Field label="New Completion Date">
              <Input type="date" value={form.extension_new_completion_date} onChange={e => set("extension_new_completion_date", e.target.value)} />
            </Field>
            <Field label="New Follow-up Date">
              <Input type="date" value={form.extension_new_followup_date} onChange={e => set("extension_new_followup_date", e.target.value)} />
            </Field>
            <Field label="Signature">
              <Input value={form.extension_signature} onChange={e => set("extension_signature", e.target.value)} />
            </Field>
            <Field label="Date">
              <Input type="date" value={form.extension_date} onChange={e => set("extension_date", e.target.value)} />
            </Field>
          </div>
        </div>

        <DialogFooter className="pt-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={createTicketMutation.isPending} className="bg-emerald-600 hover:bg-emerald-700">
            {createTicketMutation.isPending ? "Submitting..." : "Submit NCR"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}