import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ClipboardList, CheckCircle2 } from "lucide-react";
import { format, differenceInDays } from "date-fns";

const priorityConfig = {
  critical: { color: "bg-red-100 text-red-700", dot: "bg-red-500" },
  high: { color: "bg-orange-100 text-orange-700", dot: "bg-orange-500" },
  medium: { color: "bg-yellow-100 text-yellow-700", dot: "bg-yellow-600" },
  low: { color: "bg-slate-100 text-slate-600", dot: "bg-slate-400" },
};

export default function PendingTasksWidget() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.ActionItem.list("-created_date", 50)
      .then(data => {
        setTasks(data.filter(t => t.status === "pending" || t.status === "in_progress" || t.status === "blocked"));
        setLoading(false);
      })
      .catch(() => setLoading(false));

    const unsub = base44.entities.ActionItem.subscribe((event) => {
      if (event.type === "create") setTasks(prev => [event.data, ...prev].filter(t => ["pending","in_progress","blocked"].includes(t.status)));
      if (event.type === "update") setTasks(prev => prev.map(t => t.id === event.id ? event.data : t).filter(t => ["pending","in_progress","blocked"].includes(t.status)));
      if (event.type === "delete") setTasks(prev => prev.filter(t => t.id !== event.id));
    });
    return () => unsub();
  }, []);

  const today = new Date();
  const critical = tasks.filter(t => t.priority === "critical").length;
  const overdue = tasks.filter(t => t.due_date && differenceInDays(today, new Date(t.due_date)) > 0).length;

  return (
    <Card className="border-0 shadow-md bg-white">
      <CardHeader className="pb-3 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
              <ClipboardList className="w-4 h-4 text-blue-600" />
            </div>
            <CardTitle className="text-sm font-semibold text-slate-800">Pending Quality Tasks</CardTitle>
          </div>
          <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse inline-block" />
        </div>
        <div className="flex gap-4 mt-3">
          <div className="text-center">
            <p className="text-2xl font-bold text-slate-800">{tasks.length}</p>
            <p className="text-xs text-slate-500">Open</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-red-600">{critical}</p>
            <p className="text-xs text-slate-500">Critical</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-orange-600">{overdue}</p>
            <p className="text-xs text-slate-500">Overdue</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {loading ? (
          <div className="p-4 space-y-2">
            {[1,2,3].map(i => <div key={i} className="h-12 bg-slate-100 rounded animate-pulse" />)}
          </div>
        ) : tasks.length === 0 ? (
          <div className="p-6 text-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm text-slate-500">All clear — no pending tasks</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-50 max-h-72 overflow-y-auto">
            {tasks.slice(0, 20).map(task => {
              const isOverdue = task.due_date && differenceInDays(today, new Date(task.due_date)) > 0;
              const p = priorityConfig[task.priority] || priorityConfig.medium;
              return (
                <div key={task.id} className="px-4 py-3 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2 flex-1 min-w-0">
                      <span className={`mt-1.5 w-2 h-2 rounded-full flex-shrink-0 ${p.dot}`} />
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-slate-800 truncate">{task.title}</p>
                        {task.assigned_to && <p className="text-[11px] text-slate-400 truncate">{task.assigned_to}</p>}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1 flex-shrink-0">
                      <Badge className={`text-[10px] px-1.5 py-0 h-4 ${p.color}`}>{task.priority}</Badge>
                      {task.due_date && (
                        <span className={`text-[10px] ${isOverdue ? "text-red-500 font-semibold" : "text-slate-400"}`}>
                          {isOverdue ? "⚠ Overdue" : format(new Date(task.due_date), "dd MMM")}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}