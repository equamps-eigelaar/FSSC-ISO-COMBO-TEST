import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, CheckCircle2 } from "lucide-react";
import { format, differenceInDays } from "date-fns";

const trainingLabels = {
  hygiene_induction: "Hygiene Induction",
  hygiene_refresher: "Hygiene Refresher",
  ccp_awareness: "CCP Awareness",
  allergen_awareness: "Allergen Awareness",
  annual_refresher: "Annual Refresher",
  gmp_training: "GMP Training",
  haccp_training: "HACCP Training",
  food_safety_culture: "Food Safety Culture",
  custom: "Custom",
};

function getUrgency(days) {
  if (days < 0)  return { badge: "bg-red-100 text-red-700",    dot: "bg-red-500",    label: "Overdue" };
  if (days <= 14) return { badge: "bg-red-100 text-red-700",    dot: "bg-red-400",    label: `${days}d left` };
  if (days <= 30) return { badge: "bg-orange-100 text-orange-700", dot: "bg-orange-400", label: `${days}d left` };
  return           { badge: "bg-yellow-100 text-yellow-700",  dot: "bg-yellow-400", label: `${days}d left` };
}

export default function ExpiringCertificationsWidget() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  const filterAndSort = (data) => {
    const today = new Date();
    return data
      .filter(r => r.due_date && differenceInDays(new Date(r.due_date), today) <= 60)
      .sort((a, b) => new Date(a.due_date) - new Date(b.due_date));
  };

  useEffect(() => {
    base44.entities.StaffCompetency.list("-due_date", 100)
      .then(data => { setRecords(filterAndSort(data)); setLoading(false); })
      .catch(() => setLoading(false));

    const unsub = base44.entities.StaffCompetency.subscribe((event) => {
      if (event.type === "create") setRecords(prev => filterAndSort([...prev, event.data]));
      if (event.type === "update") setRecords(prev => filterAndSort(prev.map(r => r.id === event.id ? event.data : r)));
      if (event.type === "delete") setRecords(prev => prev.filter(r => r.id !== event.id));
    });
    return () => unsub();
  }, []);

  const today = new Date();
  const overdue  = records.filter(r => differenceInDays(new Date(r.due_date), today) < 0).length;
  const dueSoon  = records.filter(r => { const d = differenceInDays(new Date(r.due_date), today); return d >= 0 && d <= 14; }).length;

  return (
    <Card className="border-0 shadow-md bg-white">
      <CardHeader className="pb-3 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center">
              <GraduationCap className="w-4 h-4 text-amber-600" />
            </div>
            <CardTitle className="text-sm font-semibold text-slate-800">Training Certifications</CardTitle>
          </div>
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse inline-block" />
        </div>
        <div className="flex gap-4 mt-3">
          <div className="text-center">
            <p className="text-2xl font-bold text-slate-800">{records.length}</p>
            <p className="text-xs text-slate-500">Expiring ≤60d</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-red-600">{overdue}</p>
            <p className="text-xs text-slate-500">Overdue</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-orange-600">{dueSoon}</p>
            <p className="text-xs text-slate-500">Due ≤14d</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {loading ? (
          <div className="p-4 space-y-2">
            {[1,2,3].map(i => <div key={i} className="h-12 bg-slate-100 rounded animate-pulse" />)}
          </div>
        ) : records.length === 0 ? (
          <div className="p-6 text-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm text-slate-500">No certifications expiring within 60 days</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-50 max-h-72 overflow-y-auto">
            {records.map(record => {
              const days = differenceInDays(new Date(record.due_date), today);
              const urgency = getUrgency(days);
              return (
                <div key={record.id} className="px-4 py-3 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2 flex-1 min-w-0">
                      <span className={`mt-1.5 w-2 h-2 rounded-full flex-shrink-0 ${urgency.dot}`} />
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-slate-800 truncate">{record.staff_name}</p>
                        <p className="text-[11px] text-slate-400 truncate">
                          {trainingLabels[record.training_type] || record.custom_training_name || record.training_type}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1 flex-shrink-0">
                      <Badge className={`text-[10px] px-1.5 py-0 h-4 ${urgency.badge}`}>{urgency.label}</Badge>
                      <span className="text-[10px] text-slate-400">{format(new Date(record.due_date), "dd MMM yyyy")}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}