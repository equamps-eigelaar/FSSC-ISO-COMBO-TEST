import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trash2, CheckCircle2 } from "lucide-react";
import { format, addDays, addWeeks, addMonths } from "date-fns";

const frequencyConfig = {
  after_each_use: { label: "After Each Use", color: "bg-purple-100 text-purple-700" },
  daily:          { label: "Daily",          color: "bg-blue-100 text-blue-700" },
  weekly:         { label: "Weekly",         color: "bg-cyan-100 text-cyan-700" },
  fortnightly:    { label: "Fortnightly",    color: "bg-teal-100 text-teal-700" },
  monthly:        { label: "Monthly",        color: "bg-emerald-100 text-emerald-700" },
  quarterly:      { label: "Quarterly",      color: "bg-slate-100 text-slate-600" },
  as_needed:      { label: "As Needed",      color: "bg-slate-100 text-slate-500" },
};

function getNextDue(frequency, lastReviewed) {
  const base = lastReviewed ? new Date(lastReviewed) : new Date();
  switch (frequency) {
    case "daily":       return addDays(base, 1);
    case "weekly":      return addWeeks(base, 1);
    case "fortnightly": return addWeeks(base, 2);
    case "monthly":     return addMonths(base, 1);
    case "quarterly":   return addMonths(base, 3);
    default:            return null;
  }
}

export default function WasteScheduleWidget() {
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.CleaningSchedule.filter({ status: "active" }, "name", 100)
      .then(data => {
        // Prefer waste-tagged items; fall back to all active schedules
        const wasteKeyword = /waste|bin|rubbish|refuse|disposal|skip|compactor|collection/i;
        const wasteItems = data.filter(s => wasteKeyword.test(`${s.name} ${s.area}`));
        setSchedules(wasteItems.length > 0 ? wasteItems : data.slice(0, 12));
        setLoading(false);
      })
      .catch(() => setLoading(false));

    const unsub = base44.entities.CleaningSchedule.subscribe((event) => {
      if (event.type === "create") setSchedules(prev => [...prev, event.data]);
      if (event.type === "update") setSchedules(prev => prev.map(s => s.id === event.id ? event.data : s));
      if (event.type === "delete") setSchedules(prev => prev.filter(s => s.id !== event.id));
    });
    return () => unsub();
  }, []);

  const today = new Date();
  const overdueCount = schedules.filter(s => {
    const next = getNextDue(s.frequency, s.last_reviewed_date);
    return next && next < today;
  }).length;
  const dueTodayCount = schedules.filter(s => {
    const next = getNextDue(s.frequency, s.last_reviewed_date);
    return next && next.toDateString() === today.toDateString();
  }).length;

  return (
    <Card className="border-0 shadow-md bg-white">
      <CardHeader className="pb-3 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center">
              <Trash2 className="w-4 h-4 text-emerald-600" />
            </div>
            <CardTitle className="text-sm font-semibold text-slate-800">Waste Collection Schedules</CardTitle>
          </div>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
        </div>
        <div className="flex gap-4 mt-3">
          <div className="text-center">
            <p className="text-2xl font-bold text-slate-800">{schedules.length}</p>
            <p className="text-xs text-slate-500">Active</p>
          </div>
          <div className="text-center">
            <p className={`text-2xl font-bold ${overdueCount > 0 ? "text-red-600" : "text-emerald-600"}`}>{overdueCount}</p>
            <p className="text-xs text-slate-500">Overdue</p>
          </div>
          <div className="text-center">
            <p className={`text-2xl font-bold ${dueTodayCount > 0 ? "text-orange-600" : "text-slate-800"}`}>{dueTodayCount}</p>
            <p className="text-xs text-slate-500">Due Today</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {loading ? (
          <div className="p-4 space-y-2">
            {[1,2,3].map(i => <div key={i} className="h-12 bg-slate-100 rounded animate-pulse" />)}
          </div>
        ) : schedules.length === 0 ? (
          <div className="p-6 text-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm text-slate-500">No waste schedules configured yet</p>
            <p className="text-xs text-slate-400 mt-1">Add waste collection tasks in Cleaning Registers</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-50 max-h-72 overflow-y-auto">
            {schedules.map(schedule => {
              const nextDue = getNextDue(schedule.frequency, schedule.last_reviewed_date);
              const isOverdue = nextDue && nextDue < today;
              const isDueToday = nextDue && nextDue.toDateString() === today.toDateString();
              const freq = frequencyConfig[schedule.frequency] || { label: schedule.frequency, color: "bg-slate-100 text-slate-600" };
              return (
                <div key={schedule.id} className={`px-4 py-3 hover:bg-slate-50 transition-colors ${isOverdue ? "bg-red-50/60" : isDueToday ? "bg-orange-50/60" : ""}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-slate-800 truncate">{schedule.name}</p>
                      <p className="text-[11px] text-slate-400 truncate">
                        {schedule.area}{schedule.responsible_person ? ` · ${schedule.responsible_person}` : ""}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-1 flex-shrink-0">
                      <Badge className={`text-[10px] px-1.5 py-0 h-4 ${freq.color}`}>{freq.label}</Badge>
                      {nextDue ? (
                        <span className={`text-[10px] ${isOverdue ? "text-red-500 font-semibold" : isDueToday ? "text-orange-500 font-semibold" : "text-slate-400"}`}>
                          {isOverdue ? "⚠ Overdue" : isDueToday ? "Due Today" : `Next: ${format(nextDue, "dd MMM")}`}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-300">Schedule varies</span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}