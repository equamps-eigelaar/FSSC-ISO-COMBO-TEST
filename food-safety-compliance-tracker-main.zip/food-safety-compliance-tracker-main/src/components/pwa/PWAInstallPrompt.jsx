import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { X, Smartphone, Monitor, Apple, Download } from "lucide-react";

function detectPlatform() {
  const ua = navigator.userAgent;
  if (/android/i.test(ua)) return "android";
  if (/ipad|iphone|ipod/i.test(ua)) return "ios";
  if (/windows/i.test(ua)) return "windows";
  if (/mac/i.test(ua)) return "mac";
  return "desktop";
}

function isInStandaloneMode() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    window.navigator.standalone === true
  );
}

const STORAGE_KEY = "pwa_install_dismissed";
const PROMPT_COUNT_KEY = "pwa_prompt_count";
const LAST_PROMPT_KEY = "pwa_last_prompt";
const MAX_PROMPTS = 3;
const REPROMPT_DELAY_MS = 24 * 60 * 60 * 1000;

// Global deferred prompt store so it's never missed
let _globalDeferredPrompt = null;
const _globalPromptListeners = [];

function notifyListeners() {
  _globalPromptListeners.forEach(fn => fn(_globalDeferredPrompt));
}

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  _globalDeferredPrompt = e;
  notifyListeners();
});

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [show, setShow] = useState(false);
  const [platform, setPlatform] = useState("desktop");
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    if (isInStandaloneMode()) return;
    if (localStorage.getItem(STORAGE_KEY)) return;

    const count = parseInt(localStorage.getItem(PROMPT_COUNT_KEY) || "0", 10);
    const lastPrompt = parseInt(localStorage.getItem(LAST_PROMPT_KEY) || "0", 10);
    const now = Date.now();

    if (count >= MAX_PROMPTS) {
      localStorage.setItem(STORAGE_KEY, "1");
      return;
    }

    if (count > 0 && now - lastPrompt < REPROMPT_DELAY_MS) return;

    const p = detectPlatform();
    setPlatform(p);

    // Pick up any already-captured prompt immediately
    if (_globalDeferredPrompt) {
      setDeferredPrompt(_globalDeferredPrompt);
    }

    // Subscribe to future prompt events via global listener
    const listener = (prompt) => {
      if (prompt) setDeferredPrompt(prompt);
    };
    _globalPromptListeners.push(listener);

    // Show after short delay
    const timer = setTimeout(() => setShow(true), 1500);

    return () => {
      clearTimeout(timer);
      const idx = _globalPromptListeners.indexOf(listener);
      if (idx > -1) _globalPromptListeners.splice(idx, 1);
    };
  }, []);

  const dismiss = () => {
    setShow(false);
    const count = parseInt(localStorage.getItem(PROMPT_COUNT_KEY) || "0", 10) + 1;
    localStorage.setItem(PROMPT_COUNT_KEY, String(count));
    localStorage.setItem(LAST_PROMPT_KEY, String(Date.now()));
    if (count >= MAX_PROMPTS) {
      localStorage.setItem(STORAGE_KEY, "1");
    }
  };

  const handleInstall = () => {
    const prompt = deferredPrompt || _globalDeferredPrompt;
    if (prompt) {
      // Must call .prompt() synchronously inside user gesture handler
      prompt.prompt();
      prompt.userChoice.then((result) => {
        if (result.outcome === "accepted") {
          localStorage.setItem(STORAGE_KEY, "1");
        }
        _globalDeferredPrompt = null;
        setDeferredPrompt(null);
        dismiss();
      }).catch((err) => {
        console.warn("PWA install userChoice error:", err);
        dismiss();
      });
    } else {
      alert(
        "To install this app:\n\n" +
        "• Chrome/Edge: Click the install icon (⊕) in the address bar\n" +
        "• Or open the browser menu → 'Install app' / 'Add to Home Screen'"
      );
      dismiss();
    }
  };

  if (!show) return null;

  const isIOS = platform === "ios";
  const isAndroid = platform === "android";
  const isWindows = platform === "windows";
  const promptCount = parseInt(localStorage.getItem(PROMPT_COUNT_KEY) || "0", 10) + 1;
  const remaining = MAX_PROMPTS - promptCount;
  const canInstallNatively = !!(deferredPrompt || _globalDeferredPrompt);

  return (
    <AnimatePresence>
      {show && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[99] bg-slate-900/50 backdrop-blur-sm"
            onClick={dismiss}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.92 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="fixed top-4 left-4 z-[100] w-full max-w-sm px-0"
          >
            <div className="bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden">
              <div className="h-1 bg-gradient-to-r from-emerald-500 to-emerald-600" />

              <div className="p-5">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center flex-shrink-0">
                      {isIOS ? (
                        <Apple className="w-5 h-5 text-white" />
                      ) : isAndroid ? (
                        <Smartphone className="w-5 h-5 text-white" />
                      ) : (
                        <Monitor className="w-5 h-5 text-white" />
                      )}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-900 text-sm">Install the App</p>
                      <p className="text-xs text-slate-500">
                        {isIOS
                          ? "Add to your Home Screen"
                          : isAndroid
                          ? "Install on your Android device"
                          : isWindows
                          ? "Install on your Windows PC"
                          : "Install on your device"}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={dismiss}
                    className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors flex-shrink-0"
                  >
                    <X className="w-4 h-4 text-slate-400" />
                  </button>
                </div>

                {isIOS ? (
                  <div className="bg-slate-50 rounded-xl p-3 mb-4 text-xs text-slate-600 space-y-1.5">
                    <p className="font-medium text-slate-700">How to install on iOS:</p>
                    <p>1. Tap the <strong>Share</strong> button (□↑) in Safari</p>
                    <p>2. Scroll down and tap <strong>"Add to Home Screen"</strong></p>
                    <p>3. Tap <strong>Add</strong> to confirm</p>
                  </div>
                ) : !canInstallNatively ? (
                  <div className="bg-slate-50 rounded-xl p-3 mb-4 text-xs text-slate-600 space-y-1.5">
                    <p className="font-medium text-slate-700">How to install:</p>
                    <p>1. Look for the <strong>install icon (⊕)</strong> in your browser's address bar</p>
                    <p>2. Or open the browser menu and select <strong>"Install app"</strong></p>
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 mb-4 leading-relaxed">
                    Get quick access, offline support, and a faster experience — no app store required.
                  </p>
                )}

                <div className="flex gap-2">
                  {!isIOS && (
                    <Button
                      onClick={handleInstall}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 gap-2 text-sm h-9"
                    >
                      <Download className="w-4 h-4" />
                      {canInstallNatively ? "Install Now" : "How to Install"}
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    onClick={dismiss}
                    className="text-slate-500 text-sm h-9"
                  >
                    {isIOS ? "Got it" : "Not now"}
                  </Button>
                </div>

                {remaining > 0 && (
                  <p className="text-center text-[10px] text-slate-400 mt-3">
                    We'll remind you {remaining} more time{remaining !== 1 ? "s" : ""}
                  </p>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}