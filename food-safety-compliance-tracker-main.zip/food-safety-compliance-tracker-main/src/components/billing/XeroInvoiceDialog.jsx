import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { Sparkles, Loader2, CheckCircle2, AlertCircle } from "lucide-react";

const COMMON_CODES = [
  { code: "200", name: "Sales" },
  { code: "260", name: "Other Revenue" },
  { code: "270", name: "Interest Income" },
  { code: "408", name: "IT Software & Subscriptions" },
  { code: "412", name: "Professional Services" },
  { code: "441", name: "Consulting & Legal" },
  { code: "461", name: "Research & Development" },
];

export default function XeroInvoiceDialog({ open, onOpenChange, record, onSuccess }) {
  const [accountCode, setAccountCode] = useState("200");
  const [dueDate, setDueDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().split("T")[0];
  });
  const [suggestion, setSuggestion] = useState(null);
  const [loadingSuggest, setLoadingSuggest] = useState(false);
  const [loadingCreate, setLoadingCreate] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleSuggest = async () => {
    setLoadingSuggest(true);
    setSuggestion(null);
    setError(null);
    try {
      const res = await base44.functions.invoke("xeroSync", {
        action: "suggest_account_code",
        billingRecord: record,
      });
      const s = res.data?.suggestion;
      if (s) {
        setSuggestion(s);
        setAccountCode(s.account_code);
      }
    } catch (e) {
      setError("AI suggestion failed. You can enter a code manually.");
    } finally {
      setLoadingSuggest(false);
    }
  };

  const handleCreate = async () => {
    setLoadingCreate(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("xeroSync", {
        action: "create_draft_invoice",
        billingRecord: record,
        accountCode,
        dueDate,
      });
      if (res.data?.success) {
        // Mark as pending_approval locally
        const xeroInvoice = res.data.invoice;
        if (xeroInvoice?.InvoiceID && record?.id) {
          await base44.entities.BillingRecord.update(record.id, {
            xero_invoice_id: xeroInvoice.InvoiceID,
            xero_approval_status: "pending_approval",
          });
        }
        setResult(xeroInvoice);
        if (onSuccess) onSuccess();
      } else {
        setError("Failed to create draft invoice in Xero.");
      }
    } catch (e) {
      setError(e.message || "An error occurred.");
    } finally {
      setLoadingCreate(false);
    }
  };

  const handleClose = () => {
    setResult(null);
    setError(null);
    setSuggestion(null);
    setAccountCode("200");
    onOpenChange(false);
  };

  if (!record) return null;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <img src="https://www.xero.com/favicon.ico" className="w-5 h-5" alt="Xero" />
            Create Draft Invoice in Xero
          </DialogTitle>
          <DialogDescription>
            Generate a draft Xero invoice for <strong>{record.customer_name}</strong>. You can review and approve it in Xero before sending.
          </DialogDescription>
        </DialogHeader>

        {result ? (
          <div className="text-center py-6 space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <p className="font-semibold text-slate-800">Draft Invoice Created!</p>
            <p className="text-sm text-slate-500">Invoice <strong>{result.InvoiceNumber}</strong> is now a draft in Xero. Open Xero to review and approve it.</p>
            <Button onClick={handleClose} className="mt-2">Done</Button>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Summary */}
            <div className="bg-slate-50 rounded-lg p-4 space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Customer</span><span className="font-medium">{record.customer_name}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Description</span><span className="font-medium text-right max-w-[60%] truncate">{record.entity_name || record.billable_type}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Amount</span><span className="font-semibold text-emerald-700">${record.total_cost?.toFixed(2)} {record.currency || "USD"}</span></div>
            </div>

            {/* Account Code */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-sm font-medium text-slate-700">Xero Account Code</label>
                <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-purple-600 hover:text-purple-700" onClick={handleSuggest} disabled={loadingSuggest}>
                  {loadingSuggest ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  {loadingSuggest ? "Thinking..." : "AI Suggest"}
                </Button>
              </div>

              {suggestion && (
                <div className="mb-2 p-3 bg-purple-50 border border-purple-100 rounded-lg text-xs text-purple-800 space-y-0.5">
                  <p className="font-semibold">{suggestion.account_code} — {suggestion.account_name}</p>
                  <p className="text-purple-600">{suggestion.reasoning}</p>
                </div>
              )}

              <Input
                value={accountCode}
                onChange={(e) => setAccountCode(e.target.value)}
                placeholder="e.g. 200"
                className="mb-2"
              />

              <div className="flex flex-wrap gap-1.5">
                {COMMON_CODES.map((c) => (
                  <button
                    key={c.code}
                    onClick={() => setAccountCode(c.code)}
                    className={`text-xs px-2 py-1 rounded-full border transition-colors ${
                      accountCode === c.code
                        ? "bg-slate-800 text-white border-slate-800"
                        : "border-slate-200 text-slate-600 hover:border-slate-400"
                    }`}
                  >
                    {c.code} {c.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Due Date */}
            <div>
              <label className="text-sm font-medium text-slate-700 block mb-1.5">Due Date</label>
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </div>

            {error && (
              <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 p-3 rounded-lg">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {error}
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={handleClose} className="flex-1">Cancel</Button>
              <Button
                onClick={handleCreate}
                disabled={loadingCreate || !accountCode}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700"
              >
                {loadingCreate ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Creating...</> : "Create Draft Invoice"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}