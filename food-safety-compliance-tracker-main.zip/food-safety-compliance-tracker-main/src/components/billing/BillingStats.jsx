import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { DollarSign, Clock, FileText, CheckCircle2 } from "lucide-react";

const StatCard = ({ label, amount, icon: Icon, color }) => (
  <Card>
    <CardContent className="pt-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-600">{label}</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">R {(amount || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </CardContent>
  </Card>
);

export default function BillingStats({ stats }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <StatCard label="Total Revenue" amount={stats.total} icon={DollarSign} color="bg-emerald-100 text-emerald-700" />
      <StatCard label="Pending" amount={stats.pending} icon={Clock} color="bg-yellow-100 text-yellow-700" />
      <StatCard label="Invoiced" amount={stats.invoiced} icon={FileText} color="bg-blue-100 text-blue-700" />
      <StatCard label="Paid" amount={stats.paid} icon={CheckCircle2} color="bg-green-100 text-green-700" />
    </div>
  );
}