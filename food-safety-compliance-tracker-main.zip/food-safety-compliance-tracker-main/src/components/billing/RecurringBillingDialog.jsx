import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const CYCLE_OPTIONS = [
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly (every 3 months)" },
  { value: "semi_annual", label: "Semi-Annual (every 6 months)" },
  { value: "annual", label: "Annual (yearly)" },
];

function getNextBillingDate(startDate, cycle) {
  if (!startDate) return "";
  const d = new Date(startDate);
  switch (cycle) {
    case "monthly": d.setMonth(d.getMonth() + 1); break;
    case "quarterly": d.setMonth(d.getMonth() + 3); break;
    case "semi_annual": d.setMonth(d.getMonth() + 6); break;
    case "annual": d.setFullYear(d.getFullYear() + 1); break;
  }
  return d.toISOString().split("T")[0];
}

const defaultForm = {
  customer_name: "",
  customer_email: "",
  customer_type: "internal",
  billable_type: "audit",
  entity_name: "",
  description: "",
  quantity: 1,
  unit_cost: "",
  currency: "USD",
  cycle: "monthly",
  start_date: new Date().toISOString().split("T")[0],
};

export default function RecurringBillingDialog({ open, onOpenChange, onSubmit, isLoading }) {
  const [form, setForm] = useState(defaultForm);

  const set = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const totalCost = form.unit_cost ? (parseFloat(form.unit_cost) * parseInt(form.quantity || 1)).toFixed(2) : "0.00";
  const nextBillingDate = getNextBillingDate(form.start_date, form.cycle);

  const handleSubmit = () => {
    onSubmit({
      ...form,
      quantity: parseInt(form.quantity),
      unit_cost: parseFloat(form.unit_cost),
      total_cost: parseFloat(totalCost),
      next_billing_date: nextBillingDate,
      status: "active",
    });
    setForm(defaultForm);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>New Recurring Billing Schedule</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-xs font-medium mb-1 block">Customer Name</Label>
            <Input placeholder="Department or company" value={form.customer_name} onChange={(e) => set("customer_name", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Customer Email</Label>
            <Input type="email" placeholder="email@example.com" value={form.customer_email} onChange={(e) => set("customer_email", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Customer Type</Label>
            <Select value={form.customer_type} onValueChange={(v) => set("customer_type", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="internal">Internal</SelectItem>
                <SelectItem value="external">External</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Billable Type</Label>
            <Select value={form.billable_type} onValueChange={(v) => set("billable_type", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="audit">Audit</SelectItem>
                <SelectItem value="template_usage">Template Usage</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label className="text-xs font-medium mb-1 block">Service / Item Name</Label>
            <Input placeholder="e.g., Monthly Compliance Audit" value={form.entity_name} onChange={(e) => set("entity_name", e.target.value)} />
          </div>
          <div className="col-span-2">
            <Label className="text-xs font-medium mb-1 block">Description</Label>
            <Textarea placeholder="Describe the recurring service..." value={form.description} onChange={(e) => set("description", e.target.value)} rows={2} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Quantity</Label>
            <Input type="number" min="1" value={form.quantity} onChange={(e) => set("quantity", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Unit Cost ($)</Label>
            <Input type="number" min="0" step="0.01" placeholder="0.00" value={form.unit_cost} onChange={(e) => set("unit_cost", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Billing Cycle</Label>
            <Select value={form.cycle} onValueChange={(v) => set("cycle", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {CYCLE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Start Date</Label>
            <Input type="date" value={form.start_date} onChange={(e) => set("start_date", e.target.value)} />
          </div>

          <div className="col-span-2 bg-slate-50 border border-slate-200 rounded-lg p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">First auto-invoice on</p>
              <p className="font-semibold text-slate-900">{nextBillingDate ? new Date(nextBillingDate).toLocaleDateString() : "—"}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-600">Per cycle total</p>
              <p className="text-2xl font-bold text-emerald-600">${totalCost}</p>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={isLoading || !form.customer_name || !form.unit_cost}>
            {isLoading ? "Creating..." : "Create Schedule"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}