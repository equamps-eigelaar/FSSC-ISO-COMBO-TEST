import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const CYCLE_OPTIONS = [
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly (every 3 months)" },
  { value: "semi_annual", label: "Semi-Annual (every 6 months)" },
  { value: "annual", label: "Annual (yearly)" },
];

export default function EditRecurringDialog({ open, onOpenChange, schedule, onSubmit, isLoading }) {
  const [form, setForm] = useState({});

  useEffect(() => {
    if (schedule) setForm({ ...schedule });
  }, [schedule]);

  const set = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const totalCost = form.unit_cost ? (parseFloat(form.unit_cost) * parseInt(form.quantity || 1)).toFixed(2) : "0.00";

  const handleSubmit = () => {
    onSubmit({
      id: form.id,
      data: {
        customer_name: form.customer_name,
        customer_email: form.customer_email,
        customer_type: form.customer_type,
        billable_type: form.billable_type,
        entity_name: form.entity_name,
        description: form.description,
        quantity: parseInt(form.quantity),
        unit_cost: parseFloat(form.unit_cost),
        total_cost: parseFloat(totalCost),
        currency: form.currency,
        cycle: form.cycle,
        notes: form.notes,
      },
    });
  };

  if (!schedule) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Edit Recurring Schedule</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-xs font-medium mb-1 block">Customer Name</Label>
            <Input value={form.customer_name || ""} onChange={(e) => set("customer_name", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Customer Email</Label>
            <Input type="email" value={form.customer_email || ""} onChange={(e) => set("customer_email", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Customer Type</Label>
            <Select value={form.customer_type} onValueChange={(v) => set("customer_type", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="internal">Internal</SelectItem>
                <SelectItem value="external">External</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Billable Type</Label>
            <Select value={form.billable_type} onValueChange={(v) => set("billable_type", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="audit">Audit</SelectItem>
                <SelectItem value="template_usage">Template Usage</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label className="text-xs font-medium mb-1 block">Service / Item Name</Label>
            <Input value={form.entity_name || ""} onChange={(e) => set("entity_name", e.target.value)} />
          </div>
          <div className="col-span-2">
            <Label className="text-xs font-medium mb-1 block">Description</Label>
            <Textarea value={form.description || ""} onChange={(e) => set("description", e.target.value)} rows={2} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Quantity</Label>
            <Input type="number" min="1" value={form.quantity || 1} onChange={(e) => set("quantity", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Unit Cost</Label>
            <Input type="number" min="0" step="0.01" value={form.unit_cost || ""} onChange={(e) => set("unit_cost", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Billing Cycle</Label>
            <Select value={form.cycle} onValueChange={(v) => set("cycle", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {CYCLE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-medium mb-1 block">Currency</Label>
            <Select value={form.currency || "USD"} onValueChange={(v) => set("currency", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="USD">USD</SelectItem>
                <SelectItem value="EUR">EUR</SelectItem>
                <SelectItem value="GBP">GBP</SelectItem>
                <SelectItem value="ZAR">ZAR</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label className="text-xs font-medium mb-1 block">Notes</Label>
            <Textarea value={form.notes || ""} onChange={(e) => set("notes", e.target.value)} rows={2} />
          </div>

          <div className="col-span-2 bg-slate-50 border border-slate-200 rounded-lg p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Next Invoice Date</p>
              <p className="font-semibold text-slate-900">
                {form.next_billing_date ? new Date(form.next_billing_date).toLocaleDateString() : "—"}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-600">Per cycle total</p>
              <p className="text-2xl font-bold text-emerald-600">${totalCost}</p>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={isLoading || !form.customer_name || !form.unit_cost}>
            {isLoading ? "Saving..." : "Save Changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}