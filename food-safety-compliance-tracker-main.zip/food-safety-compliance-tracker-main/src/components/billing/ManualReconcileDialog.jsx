import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Search, Loader2, Link2, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";

export default function ManualReconcileDialog({ open, onClose, onDone }) {
  const [search, setSearch] = useState("");
  const [xeroInvoices, setXeroInvoices] = useState([]);
  const [loadingXero, setLoadingXero] = useState(false);
  const [selectedXero, setSelectedXero] = useState(null);
  const [selectedLocal, setSelectedLocal] = useState(null);
  const [linking, setLinking] = useState(false);

  const { data: localRecords = [], isLoading: loadingLocal } = useQuery({
    queryKey: ["billing_open"],
    queryFn: () => base44.entities.BillingRecord.filter({ billing_status: "invoiced" }),
    enabled: open,
  });

  const fetchXeroInvoices = async () => {
    setLoadingXero(true);
    try {
      const res = await base44.functions.invoke("xeroSync", { action: "get_paid_invoices", search });
      setXeroInvoices(res.data?.invoices || []);
    } catch {
      toast.error("Failed to fetch Xero invoices");
    } finally {
      setLoadingXero(false);
    }
  };

  useEffect(() => {
    if (open) fetchXeroInvoices();
  }, [open]);

  const handleLink = async () => {
    if (!selectedXero || !selectedLocal) return;
    setLinking(true);
    try {
      await base44.functions.invoke("xeroSync", {
        action: "manual_reconcile",
        localRecordId: selectedLocal.id,
        xeroInvoiceId: selectedXero.xero_id,
        xeroInvoiceNumber: selectedXero.invoice_number,
      });
      toast.success(`Matched & marked as paid: ${selectedLocal.customer_name} ↔ ${selectedXero.invoice_number}`);
      setSelectedXero(null);
      setSelectedLocal(null);
      onDone?.();
    } catch {
      toast.error("Reconciliation failed");
    } finally {
      setLinking(false);
    }
  };

  const statusColor = {
    PAID: "bg-green-100 text-green-800",
    AUTHORISED: "bg-blue-100 text-blue-800",
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 className="w-5 h-5 text-blue-600" />
            Manual Reconciliation — Match Xero to Local Records
          </DialogTitle>
        </DialogHeader>

        <div className="flex gap-4 items-end mb-2">
          <div className="flex-1">
            <Input
              placeholder="Search by contact name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && fetchXeroInvoices()}
            />
          </div>
          <Button variant="outline" onClick={fetchXeroInvoices} disabled={loadingXero} size="sm">
            {loadingXero ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            {loadingXero ? "Loading..." : "Refresh"}
          </Button>
        </div>

        {selectedXero && selectedLocal && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center justify-between text-sm">
            <span className="text-emerald-800">
              Match: <strong>{selectedXero.invoice_number}</strong> ({selectedXero.contact_name}) ↔{" "}
              <strong>{selectedLocal.invoice_number || selectedLocal.customer_name}</strong>
            </span>
            <Button size="sm" onClick={handleLink} disabled={linking} className="bg-emerald-600 hover:bg-emerald-700">
              {linking ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              Confirm & Mark Paid
            </Button>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4 overflow-hidden flex-1 min-h-0">
          {/* Xero Invoices */}
          <div className="flex flex-col min-h-0">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">
              Xero Invoices ({xeroInvoices.length})
            </p>
            <div className="overflow-y-auto flex-1 space-y-1.5 pr-1">
              {loadingXero ? (
                <div className="flex items-center justify-center py-10 text-slate-400">
                  <Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading...
                </div>
              ) : xeroInvoices.length === 0 ? (
                <p className="text-sm text-slate-400 text-center py-8">No Xero invoices found.</p>
              ) : (
                xeroInvoices.map((inv) => (
                  <button
                    key={inv.xero_id}
                    onClick={() => setSelectedXero(inv)}
                    className={`w-full text-left p-2.5 rounded-lg border text-xs transition-all ${
                      selectedXero?.xero_id === inv.xero_id
                        ? "border-blue-400 bg-blue-50 ring-1 ring-blue-300"
                        : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-slate-800">{inv.invoice_number || "No Ref"}</span>
                      <Badge className={`text-[10px] py-0 ${statusColor[inv.status] || "bg-slate-100 text-slate-600"}`}>
                        {inv.status}
                      </Badge>
                    </div>
                    <div className="text-slate-600">{inv.contact_name}</div>
                    <div className="flex justify-between mt-1 text-slate-500">
                      <span>{inv.date_iso}</span>
                      <span className="font-medium text-slate-800">
                        {inv.currency} {inv.total?.toLocaleString()}
                        {inv.status === "PAID" ? "" : ` (Due: ${inv.amount_due?.toLocaleString()})`}
                      </span>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Local Billing Records */}
          <div className="flex flex-col min-h-0">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">
              Local Records — Invoiced ({localRecords.length})
            </p>
            <div className="overflow-y-auto flex-1 space-y-1.5 pr-1">
              {loadingLocal ? (
                <div className="flex items-center justify-center py-10 text-slate-400">
                  <Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading...
                </div>
              ) : localRecords.length === 0 ? (
                <p className="text-sm text-slate-400 text-center py-8">No invoiced local records.</p>
              ) : (
                localRecords.map((rec) => (
                  <button
                    key={rec.id}
                    onClick={() => setSelectedLocal(rec)}
                    className={`w-full text-left p-2.5 rounded-lg border text-xs transition-all ${
                      selectedLocal?.id === rec.id
                        ? "border-emerald-400 bg-emerald-50 ring-1 ring-emerald-300"
                        : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-slate-800">{rec.invoice_number || "—"}</span>
                      <Badge variant="outline" className="text-[10px] py-0">invoiced</Badge>
                    </div>
                    <div className="text-slate-600">{rec.customer_name}</div>
                    <div className="flex justify-between mt-1 text-slate-500">
                      <span>{rec.transaction_date}</span>
                      <span className="font-medium text-slate-800">
                        {rec.currency || "ZAR"} {rec.total_cost?.toLocaleString()}
                      </span>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="pt-3 border-t text-xs text-slate-400">
          Select one Xero invoice and one local record, then click "Confirm & Mark Paid" to reconcile.
        </div>
      </DialogContent>
    </Dialog>
  );
}