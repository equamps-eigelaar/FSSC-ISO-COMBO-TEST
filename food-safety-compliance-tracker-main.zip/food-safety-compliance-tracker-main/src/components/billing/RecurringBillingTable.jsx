import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { RefreshCw, Pause, Play, X, Pencil } from "lucide-react";

const CYCLE_LABELS = {
  monthly: "Monthly",
  quarterly: "Quarterly",
  semi_annual: "Semi-Annual",
  annual: "Annual",
};

const STATUS_BADGE = {
  active: <Badge className="bg-emerald-100 text-emerald-800">Active</Badge>,
  paused: <Badge className="bg-yellow-100 text-yellow-800">Paused</Badge>,
  cancelled: <Badge className="bg-red-100 text-red-800">Cancelled</Badge>,
};

export default function RecurringBillingTable({ schedules, onUpdateStatus, isUpdating, onEdit }) {
  const today = new Date().toISOString().split("T")[0];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="border-b border-slate-200 bg-slate-50">
          <tr>
            <th className="text-left py-3 px-4 font-medium text-slate-600">Customer</th>
            <th className="text-left py-3 px-4 font-medium text-slate-600">Service</th>
            <th className="text-left py-3 px-4 font-medium text-slate-600">Cycle</th>
            <th className="text-left py-3 px-4 font-medium text-slate-600">Next Invoice</th>
            <th className="text-right py-3 px-4 font-medium text-slate-600">Amount / Cycle</th>
            <th className="text-left py-3 px-4 font-medium text-slate-600">Status</th>
            <th className="text-center py-3 px-4 font-medium text-slate-600">Actions</th>
          </tr>
        </thead>
        <tbody>
          {schedules.map((schedule) => {
            const isDue = schedule.next_billing_date <= today && schedule.status === "active";
            return (
              <tr key={schedule.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                <td className="py-3 px-4">
                  <p className="font-medium text-slate-900">{schedule.customer_name}</p>
                  <p className="text-xs text-slate-500">{schedule.customer_type === "internal" ? "Internal" : "External"}</p>
                </td>
                <td className="py-3 px-4">
                  <p className="text-slate-900">{schedule.entity_name || schedule.description || "—"}</p>
                  <p className="text-xs text-slate-500">{schedule.billable_type === "audit" ? "Audit" : "Template"}</p>
                </td>
                <td className="py-3 px-4">
                  <div className="flex items-center gap-1 text-slate-700">
                    <RefreshCw className="w-3 h-3 text-slate-400" />
                    {CYCLE_LABELS[schedule.cycle] || schedule.cycle}
                  </div>
                </td>
                <td className="py-3 px-4">
                  {schedule.next_billing_date ? (
                    <span className={isDue ? "text-red-600 font-semibold" : "text-slate-900"}>
                      {new Date(schedule.next_billing_date).toLocaleDateString()}
                      {isDue && <span className="ml-1 text-xs">(Due!)</span>}
                    </span>
                  ) : "—"}
                </td>
                <td className="py-3 px-4 text-right font-medium text-emerald-700">
                  {schedule.currency || "USD"} {(schedule.total_cost || 0).toFixed(2)}
                </td>
                <td className="py-3 px-4">{STATUS_BADGE[schedule.status] || schedule.status}</td>
                <td className="py-3 px-4">
                  <div className="flex items-center justify-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-slate-500 hover:text-slate-700 h-8 px-2"
                      onClick={() => onEdit?.(schedule)}
                      title="Edit"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    {schedule.status === "active" ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-yellow-600 hover:text-yellow-700 h-8 px-2"
                        onClick={() => onUpdateStatus({ id: schedule.id, status: "paused" })}
                        disabled={isUpdating}
                        title="Pause"
                      >
                        <Pause className="w-3.5 h-3.5" />
                      </Button>
                    ) : schedule.status === "paused" ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-emerald-600 hover:text-emerald-700 h-8 px-2"
                        onClick={() => onUpdateStatus({ id: schedule.id, status: "active" })}
                        disabled={isUpdating}
                        title="Resume"
                      >
                        <Play className="w-3.5 h-3.5" />
                      </Button>
                    ) : null}
                    {schedule.status !== "cancelled" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500 hover:text-red-600 h-8 px-2"
                        onClick={() => onUpdateStatus({ id: schedule.id, status: "cancelled" })}
                        disabled={isUpdating}
                        title="Cancel"
                      >
                        <X className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}