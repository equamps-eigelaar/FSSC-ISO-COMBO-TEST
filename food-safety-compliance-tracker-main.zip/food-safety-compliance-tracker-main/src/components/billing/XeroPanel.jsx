import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { RefreshCw, Link, Unlink, Upload, Download, CheckCircle2, AlertCircle, Sparkles, GitMerge, UserCheck } from "lucide-react";
import ReconciliationResults from "@/components/billing/ReconciliationResults";
import ManualReconcileDialog from "@/components/billing/ManualReconcileDialog";
import DraftInvoiceReviewPanel from "@/components/billing/DraftInvoiceReviewPanel";

export default function XeroPanel({ pendingCount, onSyncComplete }) {
  const [status, setStatus] = useState(null); // null = loading, {connected, org_name}
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [reconcileResult, setReconcileResult] = useState(null);
  const [showManualReconcile, setShowManualReconcile] = useState(false);
  const [activationResult, setActivationResult] = useState(null);

  const checkStatus = async () => {
    try {
      const res = await base44.functions.invoke("xeroAuth", { action: "get_status" });
      setStatus(res.data ?? { connected: false });
    } catch {
      setStatus({ connected: false });
    }
  };

  useEffect(() => {
    checkStatus();
    // Handle OAuth callback
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    const state = params.get("state");
    if (code && state) {
      handleOAuthCallback(code);
    }
  }, []);

  const handleOAuthCallback = async (code) => {
    setLoading(true);
    setMessage(null);
    const res = await base44.functions.invoke("xeroAuth", { action: "exchange_code", code });
    if (res.data?.success) {
      setMessage({ type: "success", text: `Connected to ${res.data.org_name}!` });
      // Clean URL
      window.history.replaceState({}, document.title, window.location.pathname);
      checkStatus();
    } else {
      setMessage({ type: "error", text: "Failed to connect to Xero. Please try again." });
    }
    setLoading(false);
  };

  const handleConnect = async () => {
    setLoading(true);
    const res = await base44.functions.invoke("xeroAuth", { action: "get_auth_url" });
    if (res.data?.url) {
      window.location.href = res.data.url;
    }
    setLoading(false);
  };

  const handleDisconnect = async () => {
    setLoading(true);
    await base44.functions.invoke("xeroAuth", { action: "disconnect" });
    setStatus({ connected: false });
    setMessage({ type: "success", text: "Disconnected from Xero." });
    setLoading(false);
  };

  const handlePushPending = async () => {
    setLoading(true);
    setMessage(null);
    const res = await base44.functions.invoke("xeroSync", { action: "push_all_pending" });
    if (res.data?.success) {
      setMessage({ type: "success", text: `Pushed ${res.data.pushed} invoices to Xero.` });
      onSyncComplete?.();
    } else {
      setMessage({ type: "error", text: "Failed to push invoices to Xero." });
    }
    setLoading(false);
  };

  const handlePullPayments = async () => {
    setLoading(true);
    setMessage(null);
    const res = await base44.functions.invoke("xeroSync", { action: "pull_payments" });
    if (res.data?.success) {
      setMessage({ type: "success", text: `Synced ${res.data.updated} payments from Xero.` });
      onSyncComplete?.();
    } else {
      setMessage({ type: "error", text: "Failed to pull payments from Xero." });
    }
    setLoading(false);
  };

  const handleGrantAccess = async () => {
    setLoading(true);
    setMessage(null);
    setActivationResult(null);
    const res = await base44.functions.invoke("grantAccessOnXeroPayment", {});
    if (res.data?.success) {
      setActivationResult(res.data);
      if (res.data.activated > 0) {
        setMessage({ type: "success", text: `✅ ${res.data.activated} account(s) activated based on Xero payments.` });
      } else {
        setMessage({ type: "success", text: `Checked ${res.data.checked} pending request(s) — no new payments found in Xero yet.` });
      }
      onSyncComplete?.();
    } else {
      setMessage({ type: "error", text: "Failed to check Xero payments: " + (res.data?.error || "Unknown error") });
    }
    setLoading(false);
  };

  const handleAIReconcile = async () => {
    setLoading(true);
    setMessage(null);
    const res = await base44.functions.invoke("xeroSync", { action: "ai_reconcile" });
    if (res.data?.success) {
      setReconcileResult(res.data);
      onSyncComplete?.();
    } else {
      setMessage({ type: "error", text: "AI reconciliation failed. Please try again." });
    }
    setLoading(false);
  };

  return (
    <Card className="border-blue-100 bg-blue-50/30">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <img src="https://www.xero.com/favicon.ico" className="w-5 h-5" alt="Xero" onError={(e) => { e.target.style.display = 'none'; }} />
            Xero Integration
          </CardTitle>
          {status === null ? (
            <Badge variant="outline" className="text-slate-500">Checking...</Badge>
          ) : status?.connected ? (
            <Badge className={`${status.token_expired ? "bg-amber-100 text-amber-800 border-amber-200" : "bg-green-100 text-green-800 border-green-200"}`}>
              <CheckCircle2 className="w-3 h-3 mr-1" />
              {status.token_expired ? `Token Expired · Reconnect` : `Connected · ${status.org_name}`}
            </Badge>
          ) : (
            <Badge variant="outline" className="text-red-500 border-red-200">Not Connected — Reconnect to push invoices</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {message && (
          <div className={`flex items-center gap-2 text-sm p-2 rounded-md ${message.type === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
            {message.type === "success" ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
            {message.text}
          </div>
        )}

        {(!status?.connected || status?.token_expired) ? (
          <Button onClick={handleConnect} disabled={loading} className="gap-2 bg-blue-600 hover:bg-blue-700 w-full">
            <Link className="w-4 h-4" />
            {loading ? "Connecting..." : status?.token_expired ? "Reconnect to Xero" : "Connect to Xero"}
          </Button>
        ) : (
          <div className="flex flex-wrap gap-2">
            <Button onClick={handlePushPending} disabled={loading || pendingCount === 0} variant="outline" className="gap-2 flex-1">
              <Upload className="w-4 h-4" />
              {loading ? "Syncing..." : `Push ${pendingCount} Pending to Xero`}
            </Button>
            <Button onClick={handlePullPayments} disabled={loading} variant="outline" className="gap-2 flex-1">
              <Download className="w-4 h-4" />
              {loading ? "Syncing..." : "Pull Payments from Xero"}
            </Button>
            <Button onClick={handleAIReconcile} disabled={loading} className="gap-2 flex-1 bg-purple-600 hover:bg-purple-700">
              <Sparkles className="w-4 h-4" />
              {loading ? "Reconciling..." : "AI Reconcile"}
            </Button>
            <Button onClick={() => setShowManualReconcile(true)} disabled={loading} variant="outline" className="gap-2 flex-1">
              <GitMerge className="w-4 h-4" />
              Manual Match
            </Button>
            <Button onClick={handleDisconnect} disabled={loading} variant="ghost" size="sm" className="text-slate-500 gap-1">
              <Unlink className="w-3.5 h-3.5" />
              Disconnect
            </Button>
          </div>
        )}

        {/* Grant Access on Payment — always visible when connected */}
        {status?.connected && !status?.token_expired && (
          <div className="border border-emerald-200 bg-emerald-50 rounded-lg p-3 flex items-start justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-emerald-800">🔗 Activate Accounts on Xero Payment</p>
              <p className="text-xs text-emerald-700 mt-0.5">Checks Xero for paid invoices and automatically activates matching <em>Payment Pending</em> accounts. Run this after a customer pays.</p>
            </div>
            <Button onClick={handleGrantAccess} disabled={loading} size="sm" className="shrink-0 bg-emerald-600 hover:bg-emerald-700 gap-1.5 whitespace-nowrap">
              <UserCheck className="w-3.5 h-3.5" />
              Grant Access
            </Button>
          </div>
        )}

        <p className="text-xs text-slate-500">Push creates Xero drafts for admin approval. Approve to authorise in Xero, or reject to void the draft.</p>
      </CardContent>

      <DraftInvoiceReviewPanel onDone={onSyncComplete} />

      <ManualReconcileDialog
        open={showManualReconcile}
        onClose={() => setShowManualReconcile(false)}
        onDone={() => { setShowManualReconcile(false); onSyncComplete?.(); }}
      />

      <Dialog open={!!reconcileResult} onOpenChange={(v) => { if (!v) setReconcileResult(null); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-500" />
              AI Reconciliation Results
            </DialogTitle>
          </DialogHeader>
          {reconcileResult && (
            <ReconciliationResults
              matched={reconcileResult.matched}
              flagged={reconcileResult.flagged}
              autoUpdated={reconcileResult.auto_updated}
              onClose={() => setReconcileResult(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}