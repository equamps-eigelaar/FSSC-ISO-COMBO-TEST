import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { CheckCircle2, XCircle, Loader2, FileText, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function InvoiceApprovalDialog({ open, onOpenChange, record, onSuccess }) {
  const [rejectionReason, setRejectionReason] = useState("");
  const [showRejectForm, setShowRejectForm] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleApprove = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke("xeroSync", {
        action: "authorise_invoice",
        xeroInvoiceId: record.xero_invoice_id,
        localRecordId: record.id,
      });
      if (res.data?.success) {
        toast.success("Invoice authorised in Xero!");
        onSuccess?.();
        onOpenChange(false);
      } else {
        toast.error("Failed to authorise invoice.");
      }
    } catch (e) {
      toast.error(e.message || "An error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      toast.error("Please provide a rejection reason.");
      return;
    }
    setLoading(true);
    try {
      const res = await base44.functions.invoke("xeroSync", {
        action: "reject_invoice",
        xeroInvoiceId: record.xero_invoice_id,
        localRecordId: record.id,
        rejectionReason: rejectionReason.trim(),
      });
      if (res.data?.success) {
        toast.success("Invoice rejected and voided in Xero.");
        onSuccess?.();
        onOpenChange(false);
      } else {
        toast.error("Failed to reject invoice.");
      }
    } catch (e) {
      toast.error(e.message || "An error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setRejectionReason("");
    setShowRejectForm(false);
    onOpenChange(false);
  };

  if (!record) return null;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Review Draft Invoice
          </DialogTitle>
          <DialogDescription>
            Approve to authorise this invoice in Xero, or reject to void it.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Invoice summary */}
          <div className="bg-slate-50 rounded-lg p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">Customer</span>
              <span className="font-medium">{record.customer_name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Description</span>
              <span className="font-medium text-right max-w-[60%] truncate">{record.entity_name || record.billable_type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Amount</span>
              <span className="font-semibold text-emerald-700">
                {record.currency || "USD"} {record.total_cost?.toFixed(2)}
              </span>
            </div>
            {record.invoice_number && (
              <div className="flex justify-between">
                <span className="text-slate-500">Invoice #</span>
                <span className="font-medium">{record.invoice_number}</span>
              </div>
            )}
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Xero Status</span>
              <Badge className="bg-yellow-100 text-yellow-800">DRAFT</Badge>
            </div>
          </div>

          {record.xero_rejection_reason && (
            <div className="flex items-start gap-2 text-sm text-amber-700 bg-amber-50 p-3 rounded-lg">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium">Previously Rejected</p>
                <p className="text-xs mt-0.5">{record.xero_rejection_reason}</p>
              </div>
            </div>
          )}

          {showRejectForm ? (
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-slate-700 block mb-1">Rejection Reason *</label>
                <Textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Explain why this invoice is being rejected..."
                  rows={3}
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setShowRejectForm(false)} className="flex-1" disabled={loading}>
                  Back
                </Button>
                <Button onClick={handleReject} disabled={loading} className="flex-1 bg-red-600 hover:bg-red-700">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <XCircle className="w-4 h-4 mr-1" />}
                  Confirm Reject
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex gap-2 pt-1">
              <Button
                variant="outline"
                onClick={() => setShowRejectForm(true)}
                className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                disabled={loading}
              >
                <XCircle className="w-4 h-4 mr-1" />
                Reject
              </Button>
              <Button
                onClick={handleApprove}
                disabled={loading}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <CheckCircle2 className="w-4 h-4 mr-1" />}
                Approve & Authorise
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}