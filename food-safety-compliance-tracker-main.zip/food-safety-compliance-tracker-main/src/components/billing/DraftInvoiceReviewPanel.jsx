import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { CheckCircle2, XCircle, FileText, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function DraftInvoiceReviewPanel({ onDone }) {
  const queryClient = useQueryClient();
  const [rejectTarget, setRejectTarget] = useState(null);
  const [rejectReason, setRejectReason] = useState("");
  const [processing, setProcessing] = useState(null); // record id being processed

  const { data: drafts = [], isLoading } = useQuery({
    queryKey: ["draft_invoices"],
    queryFn: () => base44.entities.BillingRecord.filter({ billing_status: "draft_invoice" }),
    refetchInterval: 30000,
  });

  const handleApprove = async (record) => {
    setProcessing(record.id);
    try {
      const res = await base44.functions.invoke("xeroSync", {
        action: "approve_draft_invoice",
        localRecordId: record.id,
        xeroDraftId: record.xero_draft_id,
      });
      if (res.data?.success) {
        toast.success(`Invoice authorised in Xero: ${record.customer_name}`);
        queryClient.invalidateQueries({ queryKey: ["draft_invoices"] });
        onDone?.();
      } else {
        toast.error("Failed to authorise invoice in Xero");
      }
    } catch {
      toast.error("Error authorising invoice");
    } finally {
      setProcessing(null);
    }
  };

  const handleReject = async () => {
    if (!rejectTarget) return;
    setProcessing(rejectTarget.id);
    try {
      const res = await base44.functions.invoke("xeroSync", {
        action: "reject_draft_invoice",
        localRecordId: rejectTarget.id,
        xeroDraftId: rejectTarget.xero_draft_id,
        reason: rejectReason,
      });
      if (res.data?.success) {
        toast.success(`Draft rejected: ${rejectTarget.customer_name}`);
        queryClient.invalidateQueries({ queryKey: ["draft_invoices"] });
        setRejectTarget(null);
        setRejectReason("");
        onDone?.();
      } else {
        toast.error("Failed to reject draft");
      }
    } catch {
      toast.error("Error rejecting draft");
    } finally {
      setProcessing(null);
    }
  };

  if (isLoading) return null;
  if (drafts.length === 0) return null;

  return (
    <>
      <Card className="border-amber-200 bg-amber-50/40">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-500" />
            Draft Invoices Awaiting Approval
            <Badge className="bg-amber-100 text-amber-800 border-amber-200 ml-1">{drafts.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {drafts.map((rec) => (
            <div
              key={rec.id}
              className="flex items-start justify-between gap-3 p-3 bg-white rounded-lg border border-amber-200"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <FileText className="w-4 h-4 text-amber-500 shrink-0" />
                  <span className="font-semibold text-sm text-slate-800 truncate">{rec.customer_name}</span>
                  {rec.invoice_number && (
                    <span className="text-xs text-slate-500">#{rec.invoice_number}</span>
                  )}
                </div>
                <p className="text-xs text-slate-600 truncate">{rec.entity_name || rec.description || rec.billable_type}</p>
                <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                  <span>{rec.currency || "ZAR"} {rec.total_cost?.toLocaleString()}</span>
                  {rec.transaction_date && <span>{format(new Date(rec.transaction_date), "dd MMM yyyy")}</span>}
                  {rec.xero_draft_id && (
                    <span className="font-mono text-[10px] text-slate-400">Xero: {rec.xero_draft_id.slice(0, 8)}…</span>
                  )}
                </div>
              </div>
              <div className="flex gap-2 shrink-0">
                <Button
                  size="sm"
                  variant="outline"
                  className="text-red-600 border-red-200 hover:bg-red-50 gap-1"
                  onClick={() => { setRejectTarget(rec); setRejectReason(""); }}
                  disabled={!!processing}
                >
                  <XCircle className="w-3.5 h-3.5" />
                  Reject
                </Button>
                <Button
                  size="sm"
                  className="bg-emerald-600 hover:bg-emerald-700 gap-1"
                  onClick={() => handleApprove(rec)}
                  disabled={!!processing}
                >
                  {processing === rec.id ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  )}
                  Approve
                </Button>
              </div>
            </div>
          ))}
          <p className="text-xs text-slate-500 pt-1">
            Approving will authorise the invoice in Xero. Rejecting will void the Xero draft and mark it as rejected locally.
          </p>
        </CardContent>
      </Card>

      {/* Reject Dialog */}
      <Dialog open={!!rejectTarget} onOpenChange={(v) => { if (!v) { setRejectTarget(null); setRejectReason(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <XCircle className="w-5 h-5" />
              Reject Draft Invoice
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <p className="text-sm text-slate-600">
              Rejecting will void the Xero draft for <strong>{rejectTarget?.customer_name}</strong> and mark the local record as rejected.
            </p>
            <div>
              <Label>Reason for rejection (optional)</Label>
              <Textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="e.g. Wrong amount, needs revision…"
                rows={3}
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => { setRejectTarget(null); setRejectReason(""); }}>
                Cancel
              </Button>
              <Button
                className="flex-1 bg-red-600 hover:bg-red-700"
                onClick={handleReject}
                disabled={!!processing}
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
                Confirm Rejection
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}