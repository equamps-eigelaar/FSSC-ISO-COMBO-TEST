import React from "react";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Bell, Clock } from "lucide-react";

export default function UpcomingBillingAlerts({ schedules }) {
  const today = new Date();
  const in7Days = new Date(today);
  in7Days.setDate(in7Days.getDate() + 7);
  const todayStr = today.toISOString().split("T")[0];
  const in7Str = in7Days.toISOString().split("T")[0];

  const overdue = schedules.filter(
    (s) => s.status === "active" && s.next_billing_date < todayStr
  );
  const dueToday = schedules.filter(
    (s) => s.status === "active" && s.next_billing_date === todayStr
  );
  const upcoming = schedules.filter(
    (s) =>
      s.status === "active" &&
      s.next_billing_date > todayStr &&
      s.next_billing_date <= in7Str
  );

  if (overdue.length === 0 && dueToday.length === 0 && upcoming.length === 0) return null;

  return (
    <div className="space-y-2">
      {overdue.length > 0 && (
        <div className="flex items-start gap-3 p-3 bg-red-50 border border-red-200 rounded-lg">
          <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-red-800">Overdue Billing ({overdue.length})</p>
            <p className="text-xs text-red-700 mt-0.5">
              {overdue.map((s) => s.customer_name).join(", ")} — process immediately
            </p>
          </div>
          <Badge className="bg-red-100 text-red-800 shrink-0">{overdue.length} overdue</Badge>
        </div>
      )}

      {dueToday.length > 0 && (
        <div className="flex items-start gap-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
          <Bell className="w-4 h-4 text-orange-600 mt-0.5 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-orange-800">Due Today ({dueToday.length})</p>
            <p className="text-xs text-orange-700 mt-0.5">
              {dueToday.map((s) => `${s.customer_name} (${s.currency || "USD"} ${(s.total_cost || 0).toFixed(2)})`).join(", ")}
            </p>
          </div>
          <Badge className="bg-orange-100 text-orange-800 shrink-0">{dueToday.length} today</Badge>
        </div>
      )}

      {upcoming.length > 0 && (
        <div className="flex items-start gap-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <Clock className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-blue-800">Upcoming in 7 Days ({upcoming.length})</p>
            <p className="text-xs text-blue-700 mt-0.5">
              {upcoming.map((s) => `${s.customer_name} on ${new Date(s.next_billing_date).toLocaleDateString()}`).join(", ")}
            </p>
          </div>
          <Badge className="bg-blue-100 text-blue-800 shrink-0">{upcoming.length} upcoming</Badge>
        </div>
      )}
    </div>
  );
}