import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export default function BillingDialog({ open, onOpenChange, onSubmit, isLoading }) {
  const [formData, setFormData] = useState({
    transaction_date: new Date().toISOString().split("T")[0],
    billable_type: "audit",
    customer_type: "internal",
    customer_name: "",
    customer_email: "",
    entity_name: "",
    quantity: 1,
    unit_cost: "",
    currency: "USD",
    description: "",
  });

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    const totalCost = parseFloat(formData.unit_cost) * parseInt(formData.quantity);
    onSubmit({
      transaction_date: formData.transaction_date,
      billable_type: formData.billable_type,
      customer_type: formData.customer_type,
      customer_name: formData.customer_name,
      customer_email: formData.customer_email,
      entity_name: formData.entity_name,
      quantity: parseInt(formData.quantity),
      unit_cost: parseFloat(formData.unit_cost),
      total_cost: totalCost,
      currency: formData.currency,
      description: formData.description,
      billing_status: "pending",
    });
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      transaction_date: new Date().toISOString().split("T")[0],
      billable_type: "audit",
      customer_type: "internal",
      customer_name: "",
      customer_email: "",
      entity_name: "",
      quantity: 1,
      unit_cost: "",
      currency: "USD",
      description: "",
    });
  };

  const totalCost = formData.unit_cost ? (parseFloat(formData.unit_cost) * parseInt(formData.quantity)).toFixed(2) : "0.00";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Add Billing Record</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-xs font-medium mb-2 block">Transaction Date</Label>
            <Input type="date" value={formData.transaction_date} onChange={(e) => handleChange("transaction_date", e.target.value)} />
          </div>

          <div>
            <Label className="text-xs font-medium mb-2 block">Billable Type</Label>
            <Select value={formData.billable_type} onValueChange={(value) => handleChange("billable_type", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="audit">Audit</SelectItem>
                <SelectItem value="template_usage">Template Usage</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-xs font-medium mb-2 block">Customer Type</Label>
            <Select value={formData.customer_type} onValueChange={(value) => handleChange("customer_type", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="internal">Internal</SelectItem>
                <SelectItem value="external">External</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-xs font-medium mb-2 block">Customer Name</Label>
            <Input placeholder="Department or company name" value={formData.customer_name} onChange={(e) => handleChange("customer_name", e.target.value)} />
          </div>

          <div>
            <Label className="text-xs font-medium mb-2 block">Customer Email</Label>
            <Input type="email" placeholder="email@example.com" value={formData.customer_email} onChange={(e) => handleChange("customer_email", e.target.value)} />
          </div>

          <div>
            <Label className="text-xs font-medium mb-2 block">Item Name</Label>
            <Input placeholder="Audit name or template name" value={formData.entity_name} onChange={(e) => handleChange("entity_name", e.target.value)} />
          </div>

          <div>
            <Label className="text-xs font-medium mb-2 block">Quantity</Label>
            <Input type="number" min="1" value={formData.quantity} onChange={(e) => handleChange("quantity", e.target.value)} />
          </div>

          <div>
            <Label className="text-xs font-medium mb-2 block">Unit Cost ($)</Label>
            <Input type="number" min="0" step="0.01" placeholder="0.00" value={formData.unit_cost} onChange={(e) => handleChange("unit_cost", e.target.value)} />
          </div>

          <div className="col-span-2">
            <Label className="text-xs font-medium mb-2 block">Description (Optional)</Label>
            <Textarea placeholder="Additional details about this billing item..." value={formData.description} onChange={(e) => handleChange("description", e.target.value)} rows={2} />
          </div>

          <div className="col-span-2 bg-slate-100 p-4 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="font-medium">Total Cost:</span>
              <span className="text-2xl font-bold text-emerald-600">
                {formData.currency} {totalCost}
              </span>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isLoading || !formData.customer_name || !formData.unit_cost}>
            {isLoading ? "Adding..." : "Add Record"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}