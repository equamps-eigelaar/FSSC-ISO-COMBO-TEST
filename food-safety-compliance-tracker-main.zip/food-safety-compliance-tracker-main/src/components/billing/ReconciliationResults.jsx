import React from "react";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, AlertTriangle, Zap } from "lucide-react";

const confidenceColors = {
  high: "bg-green-100 text-green-800",
  medium: "bg-yellow-100 text-yellow-800",
  low: "bg-orange-100 text-orange-800",
};

export default function ReconciliationResults({ matched, flagged, autoUpdated, onClose }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-100 rounded-lg text-sm text-emerald-800">
        <Zap className="w-4 h-4 shrink-0" />
        <span>AI auto-updated <strong>{autoUpdated}</strong> high-confidence match{autoUpdated !== 1 ? "es" : ""} to <em>paid</em>.</span>
      </div>

      {matched.length > 0 && (
        <div>
          <p className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            Matched ({matched.length})
          </p>
          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {matched.map((m, i) => (
              <div key={i} className="flex items-center justify-between text-xs bg-slate-50 rounded-md px-3 py-2">
                <div>
                  <span className="font-medium text-slate-800">{m.xero_invoice_number}</span>
                  <span className="text-slate-500 mx-1.5">→</span>
                  <span className="text-slate-700">{m.local_customer_name}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500">${m.amount?.toFixed(2)}</span>
                  <Badge className={`text-[10px] py-0 ${confidenceColors[m.confidence]}`}>{m.confidence}</Badge>
                  <Badge variant="outline" className="text-[10px] py-0">
                    {m.action === "mark_paid" ? "→ Paid" : "→ Invoiced"}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {flagged.length > 0 && (
        <div>
          <p className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            Flagged for Review ({flagged.length})
          </p>
          <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
            {flagged.map((f, i) => (
              <div key={i} className="text-xs bg-amber-50 border border-amber-100 rounded-md px-3 py-2 space-y-0.5">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-slate-800">{f.xero_invoice_number || f.xero_id}</span>
                  <span className="text-slate-600">{f.contact_name} · ${f.amount?.toFixed(2)}</span>
                </div>
                <p className="text-amber-700">{f.reason}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {matched.length === 0 && flagged.length === 0 && (
        <p className="text-sm text-slate-500 text-center py-3">No Xero invoices found to reconcile.</p>
      )}
    </div>
  );
}