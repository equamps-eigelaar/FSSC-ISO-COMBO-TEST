import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Pencil, Trash2, Package, Users, ShieldAlert, CalendarClock, Building2, Search } from "lucide-react";
import { toast } from "sonner";

// ───── Generic Table ─────────────────────────────────────────────
function MasterTable({ columns, rows, onEdit, onDelete, emptyLabel }) {
  const [search, setSearch] = useState("");
  const filtered = rows.filter(r =>
    columns.some(c => String(r[c.key] ?? "").toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div>
      <div className="relative mb-3">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
        <Input placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-xs" />
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-10 text-slate-400 text-sm">{emptyLabel || "No records found."}</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-100">
                {columns.map(c => (
                  <th key={c.key} className="text-left py-2 px-2 font-semibold text-slate-500">{c.label}</th>
                ))}
                <th className="text-right py-2 px-2 font-semibold text-slate-500">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(row => (
                <tr key={row.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  {columns.map(c => (
                    <td key={c.key} className="py-2 px-2 text-slate-700 max-w-[200px]">
                      {c.render ? c.render(row[c.key], row) : (row[c.key] != null ? String(row[c.key]) : "-")}
                    </td>
                  ))}
                  <td className="py-2 px-2 text-right space-x-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-slate-400 hover:text-indigo-600" onClick={() => onEdit(row)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-slate-400 hover:text-red-600" onClick={() => onDelete(row.id)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ───── Generic Form Dialog ───────────────────────────────────────
function RecordDialog({ open, onOpenChange, title, fields, initial, onSave }) {
  const [form, setForm] = useState(initial || {});
  React.useEffect(() => { setForm(initial || {}); }, [initial, open]);
  const set = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base">{title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          {fields.map(f => (
            <div key={f.key}>
              <Label className="text-xs font-medium text-slate-700 mb-1 block">{f.label}{f.required && " *"}</Label>
              {f.type === "select" ? (
                <Select value={form[f.key] || ""} onValueChange={v => set(f.key, v)}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder={`Select ${f.label}`} />
                  </SelectTrigger>
                  <SelectContent>
                    {f.options.map(o => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : f.type === "textarea" ? (
                <Textarea value={form[f.key] || ""} onChange={e => set(f.key, e.target.value)} className="text-xs" rows={3} />
              ) : (
                <Input value={form[f.key] || ""} onChange={e => set(f.key, e.target.value)} className="h-8 text-xs" type={f.type || "text"} />
              )}
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => { onSave(form); onOpenChange(false); }}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ───── Section builder ───────────────────────────────────────────
function MasterSection({ icon: Icon, title, entityName, columns, fields, statusKey = "status" }) {
  const qc = useQueryClient();
  const [dialog, setDialog] = useState(false);
  const [editing, setEditing] = useState(null);

  const { data: rows = [] } = useQuery({
    queryKey: [entityName],
    queryFn: () => base44.entities[entityName].list("-created_date", 500),
  });

  const createMut = useMutation({
    mutationFn: data => base44.entities[entityName].create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: [entityName] }); toast.success("Created"); },
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities[entityName].update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: [entityName] }); toast.success("Updated"); },
  });
  const deleteMut = useMutation({
    mutationFn: id => base44.entities[entityName].delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: [entityName] }); toast.success("Deleted"); },
  });

  const handleSave = (form) => {
    if (editing?.id) updateMut.mutate({ id: editing.id, data: form });
    else createMut.mutate(form);
    setEditing(null);
  };

  const openEdit = (row) => { setEditing(row); setDialog(true); };
  const openNew = () => { setEditing(null); setDialog(true); };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Icon className="w-4 h-4 text-emerald-600" />
            {title}
            <Badge variant="secondary" className="text-xs">{rows.length}</Badge>
          </CardTitle>
          <Button size="sm" className="h-7 gap-1 bg-emerald-600 hover:bg-emerald-700 text-xs" onClick={openNew}>
            <Plus className="w-3.5 h-3.5" />Add
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <MasterTable
          columns={columns}
          rows={rows}
          onEdit={openEdit}
          onDelete={id => deleteMut.mutate(id)}
          emptyLabel={`No ${title} records yet. Click Add to create one.`}
        />
      </CardContent>

      <RecordDialog
        open={dialog}
        onOpenChange={setDialog}
        title={editing?.id ? `Edit ${title}` : `Add ${title}`}
        fields={fields}
        initial={editing}
        onSave={handleSave}
      />
    </Card>
  );
}

// ───── Status badge helper ───────────────────────────────────────
const StatusBadge = ({ val }) => {
  const map = {
    active: "bg-emerald-100 text-emerald-700",
    inactive: "bg-slate-100 text-slate-500",
    discontinued: "bg-red-100 text-red-700",
    development: "bg-blue-100 text-blue-700",
    under_review: "bg-amber-100 text-amber-700",
    superseded: "bg-rose-100 text-rose-700",
    prospect: "bg-indigo-100 text-indigo-700",
  };
  return <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${map[val] || "bg-slate-100 text-slate-600"}`}>{val?.replace(/_/g, " ") || "-"}</span>;
};

// ───── Main Export ───────────────────────────────────────────────
export default function MasterDataTab() {
  return (
    <div className="space-y-6">
      <p className="text-sm text-slate-500">Manage master data referenced across the compliance system.</p>

      {/* Products */}
      <MasterSection
        icon={Package}
        title="Products"
        entityName="Product"
        columns={[
          { key: "name", label: "Name" },
          { key: "product_code", label: "Code" },
          { key: "category", label: "Category", render: v => <span className="capitalize">{v?.replace(/_/g, " ")}</span> },
          { key: "allergens", label: "Allergens", render: v => v?.length ? v.join(", ") : "-" },
          { key: "shelf_life_days", label: "Shelf Life (days)" },
          { key: "status", label: "Status", render: v => <StatusBadge val={v} /> },
        ]}
        fields={[
          { key: "name", label: "Product Name", required: true },
          { key: "product_code", label: "Product Code / SKU" },
          { key: "category", label: "Category", type: "select", options: [
            { value: "raw_material", label: "Raw Material" },
            { value: "intermediate", label: "Intermediate" },
            { value: "finished_product", label: "Finished Product" },
            { value: "packaging", label: "Packaging" },
            { value: "other", label: "Other" },
          ]},
          { key: "description", label: "Description", type: "textarea" },
          { key: "shelf_life_days", label: "Shelf Life (days)", type: "number" },
          { key: "storage_conditions", label: "Storage Conditions" },
          { key: "intended_use", label: "Intended Use" },
          { key: "status", label: "Status", type: "select", options: [
            { value: "active", label: "Active" },
            { value: "development", label: "In Development" },
            { value: "discontinued", label: "Discontinued" },
          ]},
          { key: "notes", label: "Notes", type: "textarea" },
        ]}
      />

      {/* Suppliers — linked to existing SupplierProfile */}
      <SuppliersSection />

      {/* Customers */}
      <MasterSection
        icon={Users}
        title="Customers"
        entityName="Customer"
        columns={[
          { key: "name", label: "Name" },
          { key: "customer_code", label: "Code" },
          { key: "contact_email", label: "Email" },
          { key: "segment", label: "Segment", render: v => <span className="capitalize">{v?.replace(/_/g, " ")}</span> },
          { key: "country", label: "Country" },
          { key: "status", label: "Status", render: v => <StatusBadge val={v} /> },
        ]}
        fields={[
          { key: "name", label: "Customer Name", required: true },
          { key: "customer_code", label: "Customer Code" },
          { key: "contact_name", label: "Contact Name" },
          { key: "contact_email", label: "Contact Email" },
          { key: "contact_phone", label: "Contact Phone" },
          { key: "country", label: "Country" },
          { key: "segment", label: "Segment", type: "select", options: [
            { value: "retail", label: "Retail" },
            { value: "food_service", label: "Food Service" },
            { value: "industrial", label: "Industrial" },
            { value: "export", label: "Export" },
            { value: "internal", label: "Internal" },
            { value: "other", label: "Other" },
          ]},
          { key: "status", label: "Status", type: "select", options: [
            { value: "active", label: "Active" },
            { value: "inactive", label: "Inactive" },
            { value: "prospect", label: "Prospect" },
          ]},
          { key: "notes", label: "Notes", type: "textarea" },
        ]}
      />

      {/* CCPs */}
      <MasterSection
        icon={ShieldAlert}
        title="CCPs / OPRPs"
        entityName="CCP"
        columns={[
          { key: "name", label: "Name" },
          { key: "ccp_type", label: "Type", render: v => <span className="uppercase font-bold text-xs">{v}</span> },
          { key: "process_step", label: "Process Step" },
          { key: "hazard_type", label: "Hazard Type", render: v => <span className="capitalize">{v}</span> },
          { key: "critical_limit", label: "Critical Limit" },
          { key: "monitoring_frequency", label: "Frequency" },
          { key: "status", label: "Status", render: v => <StatusBadge val={v} /> },
        ]}
        fields={[
          { key: "name", label: "CCP Name / ID", required: true },
          { key: "ccp_type", label: "Type", type: "select", options: [
            { value: "ccp", label: "CCP" }, { value: "oprp", label: "OPRP" },
          ]},
          { key: "process_step", label: "Process Step", required: true },
          { key: "hazard", label: "Hazard Description", type: "textarea", required: true },
          { key: "hazard_type", label: "Hazard Type", type: "select", options: [
            { value: "biological", label: "Biological" },
            { value: "chemical", label: "Chemical" },
            { value: "physical", label: "Physical" },
            { value: "allergen", label: "Allergen" },
            { value: "radiological", label: "Radiological" },
          ]},
          { key: "critical_limit", label: "Critical Limit" },
          { key: "monitoring_procedure", label: "Monitoring Procedure", type: "textarea" },
          { key: "monitoring_frequency", label: "Monitoring Frequency" },
          { key: "responsible_person", label: "Responsible Person" },
          { key: "corrective_action", label: "Corrective Action", type: "textarea" },
          { key: "verification_activity", label: "Verification Activity" },
          { key: "status", label: "Status", type: "select", options: [
            { value: "active", label: "Active" },
            { value: "under_review", label: "Under Review" },
            { value: "superseded", label: "Superseded" },
          ]},
          { key: "notes", label: "Notes", type: "textarea" },
        ]}
      />

      {/* Cleaning Schedules */}
      <MasterSection
        icon={CalendarClock}
        title="Cleaning Schedules"
        entityName="CleaningSchedule"
        columns={[
          { key: "name", label: "Task Name" },
          { key: "area", label: "Area / Equipment" },
          { key: "frequency", label: "Frequency", render: v => <span className="capitalize">{v?.replace(/_/g, " ")}</span> },
          { key: "chemical", label: "Chemical" },
          { key: "responsible_person", label: "Responsible" },
          { key: "status", label: "Status", render: v => <StatusBadge val={v} /> },
        ]}
        fields={[
          { key: "name", label: "Task Name", required: true },
          { key: "area", label: "Area / Equipment", required: true },
          { key: "frequency", label: "Frequency", type: "select", required: true, options: [
            { value: "after_each_use", label: "After Each Use" },
            { value: "daily", label: "Daily" },
            { value: "weekly", label: "Weekly" },
            { value: "fortnightly", label: "Fortnightly" },
            { value: "monthly", label: "Monthly" },
            { value: "quarterly", label: "Quarterly" },
            { value: "as_needed", label: "As Needed" },
          ]},
          { key: "method", label: "Cleaning Method", type: "textarea" },
          { key: "chemical", label: "Chemical & Concentration" },
          { key: "responsible_person", label: "Responsible Person" },
          { key: "verification_method", label: "Verification Method" },
          { key: "record_form", label: "Record Form / Register" },
          { key: "last_reviewed_date", label: "Last Reviewed Date", type: "date" },
          { key: "status", label: "Status", type: "select", options: [
            { value: "active", label: "Active" },
            { value: "under_review", label: "Under Review" },
            { value: "inactive", label: "Inactive" },
          ]},
          { key: "notes", label: "Notes", type: "textarea" },
        ]}
      />
    </div>
  );
}

// ───── Suppliers (re-uses existing SupplierProfile entity) ───────
function SuppliersSection() {
  const { data: rows = [] } = useQuery({
    queryKey: ["supplier-profiles-masterdata"],
    queryFn: () => base44.entities.SupplierProfile.list("-created_date", 500),
  });

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-600" />
            Suppliers
            <Badge variant="secondary" className="text-xs">{rows.length}</Badge>
          </CardTitle>
          <a href={`/supplier-management`} className="text-xs text-emerald-600 hover:underline">Manage in Supplier Portal →</a>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <MasterTable
          columns={[
            { key: "company_name", label: "Company" },
            { key: "contact_name", label: "Contact" },
            { key: "contact_email", label: "Email" },
            { key: "country", label: "Country" },
            { key: "approval_status", label: "Status", render: v => <StatusBadge val={v} /> },
          ]}
          rows={rows}
          onEdit={() => {}}
          onDelete={() => {}}
          emptyLabel="No suppliers yet. Add suppliers via the Supplier Portal."
        />
        {rows.length > 0 && (
          <p className="text-xs text-slate-400 mt-2">Edit suppliers via Supplier Management page.</p>
        )}
      </CardContent>
    </Card>
  );
}