import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { Icon } from "leaflet";
import { Users, Navigation } from "lucide-react";
import "leaflet/dist/leaflet.css";

const userIcon = new Icon({
  iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-blue.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

export default function LocationMap({ locations, currentUserLocation }) {
  if (!locations.length && !currentUserLocation) {
    return (
      <div className="w-full h-96 bg-slate-100 rounded-lg flex items-center justify-center">
        <div className="text-center">
          <Navigation className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-sm text-slate-600">No location data available</p>
        </div>
      </div>
    );
  }

  const center = currentUserLocation
    ? [currentUserLocation.latitude, currentUserLocation.longitude]
    : locations[0]
    ? [locations[0].latitude, locations[0].longitude]
    : [0, 0];

  return (
    <MapContainer
      center={center}
      zoom={13}
      className="w-full h-96 rounded-lg border border-slate-200"
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; OpenStreetMap contributors'
      />

      {currentUserLocation && (
        <Marker
          position={[currentUserLocation.latitude, currentUserLocation.longitude]}
          icon={userIcon}
        >
          <Popup>
            <div>
              <p className="font-semibold text-sm">Your Location</p>
              <p className="text-xs text-slate-600">{currentUserLocation.address}</p>
            </div>
          </Popup>
        </Marker>
      )}

      {locations.map((loc) => (
        <Marker
          key={loc.id}
          position={[loc.latitude, loc.longitude]}
          icon={userIcon}
        >
          <Popup>
            <div>
              <p className="font-semibold text-sm flex items-center gap-1">
                <Users className="w-3 h-3" />
                {loc.user_email}
              </p>
              <p className="text-xs text-slate-600">{loc.address}</p>
              <p className="text-xs text-slate-500 mt-1">
                {loc.location_type === "live" ? "🔴 Live" : "📍 Snapshot"}
              </p>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}