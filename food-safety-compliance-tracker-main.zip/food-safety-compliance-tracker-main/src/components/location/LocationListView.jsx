import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Navigation, MapPin, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function LocationListView({ locations, currentUserLocation }) {
  const allLocations = currentUserLocation
    ? [{ ...currentUserLocation, isOwn: true }, ...locations]
    : locations;

  if (!allLocations.length) {
    return (
      <Card className="p-6 text-center">
        <Navigation className="w-8 h-8 text-slate-300 mx-auto mb-2" />
        <p className="text-sm text-slate-600">No shared locations</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {allLocations.map((loc) => (
        <Card key={loc.id} className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span className="font-semibold text-sm text-slate-900">
                  {loc.isOwn ? "Your Location" : loc.user_email}
                </span>
              </div>
              
              <p className="text-sm text-slate-700 mb-2">{loc.address}</p>

              <div className="flex flex-wrap gap-2 items-center text-xs">
                <Badge variant={loc.location_type === "live" ? "default" : "secondary"}>
                  {loc.location_type === "live" ? "🔴 Live Tracking" : "📍 Snapshot"}
                </Badge>
                
                <span className="text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {formatDistanceToNow(new Date(loc.created_date), { addSuffix: true })}
                </span>

                {loc.accuracy && (
                  <span className="text-slate-500 text-xs">
                    ±{Math.round(loc.accuracy)}m accuracy
                  </span>
                )}
              </div>
            </div>

            <div className="text-right text-xs text-slate-500">
              {loc.latitude.toFixed(4)}, {loc.longitude.toFixed(4)}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}