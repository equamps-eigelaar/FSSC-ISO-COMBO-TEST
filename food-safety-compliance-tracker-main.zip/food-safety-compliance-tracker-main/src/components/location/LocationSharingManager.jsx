import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Navigation, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function LocationSharingManager({ connections = [] }) {
  const [shares, setShares] = useState([]);
  const [selectedUser, setSelectedUser] = useState("");
  const [shareType, setShareType] = useState("snapshot");
  const [loading, setLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  React.useEffect(() => {
    const loadData = async () => {
      const user = await base44.auth.me();
      setCurrentUser(user);
      
      const userShares = await base44.entities.LocationShare.filter({
        owner_email: user.email,
      });
      setShares(userShares);
    };
    loadData();
  }, []);

  const handleShareLocation = async () => {
    if (!selectedUser) {
      toast.error("Please select a user to share with");
      return;
    }

    setLoading(true);
    try {
      await base44.entities.LocationShare.create({
        owner_email: currentUser.email,
        shared_with_email: selectedUser,
        share_type: shareType,
        status: "accepted",
      });

      setShares((prev) => [
        ...prev,
        {
          shared_with_email: selectedUser,
          share_type: shareType,
          status: "accepted",
        },
      ]);

      setSelectedUser("");
      setShareType("snapshot");
      toast.success("Location sharing enabled");
    } catch (error) {
      toast.error("Failed to enable location sharing");
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveShare = async (email) => {
    try {
      const share = shares.find((s) => s.shared_with_email === email);
      if (share?.id) {
        await base44.entities.LocationShare.delete(share.id);
        setShares((prev) => prev.filter((s) => s.shared_with_email !== email));
        toast.success("Location sharing removed");
      }
    } catch (error) {
      toast.error("Failed to remove sharing");
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Navigation className="w-4 h-4" />
          Location Sharing
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add New Share */}
        <div className="space-y-3 p-4 bg-slate-50 rounded-lg">
          <h3 className="text-sm font-semibold text-slate-900">Share Your Location</h3>
          
          <div>
            <label className="text-xs text-slate-600 block mb-1">Invited User</label>
            <select
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-md"
            >
              <option value="">Select a connected user</option>
              {connections.map((conn) => (
                <option key={conn} value={conn}>
                  {conn}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs text-slate-600 block mb-1">Share Type</label>
            <Select value={shareType} onValueChange={setShareType}>
              <SelectTrigger className="text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="snapshot">One-time Snapshot</SelectItem>
                <SelectItem value="live">Live Tracking</SelectItem>
                <SelectItem value="both">Both Options</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={handleShareLocation}
            disabled={loading || !selectedUser}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            size="sm"
          >
            <Plus className="w-4 h-4 mr-1" />
            {loading ? "Enabling..." : "Enable Sharing"}
          </Button>
        </div>

        {/* Active Shares */}
        <div>
          <h3 className="text-sm font-semibold text-slate-900 mb-3">
            Sharing With ({shares.length})
          </h3>
          {shares.length === 0 ? (
            <p className="text-sm text-slate-500">Not sharing with anyone yet</p>
          ) : (
            <div className="space-y-2">
              {shares.map((share) => (
                <div
                  key={share.shared_with_email}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded-lg"
                >
                  <div>
                    <p className="text-sm font-medium text-slate-900">
                      {share.shared_with_email}
                    </p>
                    <Badge variant="secondary" className="text-xs mt-1">
                      {share.share_type === "live" && "🔴 Live Tracking"}
                      {share.share_type === "snapshot" && "📍 Snapshot"}
                      {share.share_type === "both" && "Both Options"}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveShare(share.shared_with_email)}
                    className="text-slate-400 hover:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}