import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Package, MapPin, FileText } from "lucide-react";
import { usePermissions } from "@/components/permissions/usePermissions";
import { toast } from "sonner";
import { format } from "date-fns";
import CommentSection from "@/components/collaboration/CommentSection";
import DocumentUploader from "@/components/documents/DocumentUploader";
import DocumentList from "@/components/documents/DocumentList";

export default function BatchDetailDialog({ batch, open, onClose }) {
  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState(batch);
  const [showDocUpload, setShowDocUpload] = useState(false);
  
  const { permissions } = usePermissions();
  const queryClient = useQueryClient();

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.RawMaterialBatch.update(batch.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["raw-material-batches"] });
      toast.success("Batch updated");
      setIsEditing(false);
    },
    onError: () => toast.error("Failed to update batch"),
  });

  const handleSave = () => {
    const data = { ...form };
    if (data.quantity) data.quantity = parseFloat(data.quantity);
    updateMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Batch Details</span>
            {permissions.canEditAll && !isEditing && (
              <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                Edit
              </Button>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-slate-500">Batch Number</Label>
              {isEditing ? (
                <Input
                  value={form.batch_number}
                  onChange={(e) => setForm({ ...form, batch_number: e.target.value })}
                />
              ) : (
                <p className="text-sm font-mono font-semibold text-slate-900">{batch.batch_number}</p>
              )}
            </div>
            <div>
              <Label className="text-xs text-slate-500">PO Number</Label>
              {isEditing ? (
                <Input
                  value={form.po_number}
                  onChange={(e) => setForm({ ...form, po_number: e.target.value })}
                />
              ) : (
                <p className="text-sm font-semibold text-slate-900">{batch.po_number}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-slate-500">Material Name</Label>
              {isEditing ? (
                <Input
                  value={form.material_name}
                  onChange={(e) => setForm({ ...form, material_name: e.target.value })}
                />
              ) : (
                <p className="text-sm font-medium text-slate-900">{batch.material_name}</p>
              )}
            </div>
            <div>
              <Label className="text-xs text-slate-500">Material Code</Label>
              {isEditing ? (
                <Input
                  value={form.material_code || ""}
                  onChange={(e) => setForm({ ...form, material_code: e.target.value })}
                />
              ) : (
                <p className="text-sm text-slate-700">{batch.material_code || "-"}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-slate-500">Supplier</Label>
              {isEditing ? (
                <Input
                  value={form.supplier}
                  onChange={(e) => setForm({ ...form, supplier: e.target.value })}
                />
              ) : (
                <p className="text-sm text-slate-900">{batch.supplier}</p>
              )}
            </div>
            <div>
              <Label className="text-xs text-slate-500">Supplier Batch Number</Label>
              {isEditing ? (
                <Input
                  value={form.supplier_batch_number || ""}
                  onChange={(e) => setForm({ ...form, supplier_batch_number: e.target.value })}
                />
              ) : (
                <p className="text-sm text-slate-700">{batch.supplier_batch_number || "-"}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label className="text-xs text-slate-500">Quantity</Label>
              {isEditing ? (
                <Input
                  type="number"
                  value={form.quantity || ""}
                  onChange={(e) => setForm({ ...form, quantity: e.target.value })}
                />
              ) : (
                <p className="text-sm text-slate-900">{batch.quantity || "-"}</p>
              )}
            </div>
            <div>
              <Label className="text-xs text-slate-500">Unit</Label>
              {isEditing ? (
                <Select value={form.unit || "kg"} onValueChange={(v) => setForm({ ...form, unit: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="kg">kg</SelectItem>
                    <SelectItem value="L">L</SelectItem>
                    <SelectItem value="pcs">pcs</SelectItem>
                    <SelectItem value="rolls">rolls</SelectItem>
                    <SelectItem value="boxes">boxes</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <p className="text-sm text-slate-900">{batch.unit || "-"}</p>
              )}
            </div>
            <div>
              <Label className="text-xs text-slate-500">Status</Label>
              {isEditing ? (
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending_inspection">Pending Inspection</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="in_use">In Use</SelectItem>
                    <SelectItem value="depleted">Depleted</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <Badge variant="outline" className="text-xs">
                  {batch.status?.replace(/_/g, " ")}
                </Badge>
              )}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label className="text-xs text-slate-500 flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Manufacturing Date
              </Label>
              {isEditing ? (
                <Input
                  type="date"
                  value={form.manufacturing_date || ""}
                  onChange={(e) => setForm({ ...form, manufacturing_date: e.target.value })}
                />
              ) : (
                <p className="text-sm text-slate-900">
                  {batch.manufacturing_date ? format(new Date(batch.manufacturing_date), "MMM d, yyyy") : "-"}
                </p>
              )}
            </div>
            <div>
              <Label className="text-xs text-slate-500 flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Expiry Date
              </Label>
              {isEditing ? (
                <Input
                  type="date"
                  value={form.expiry_date || ""}
                  onChange={(e) => setForm({ ...form, expiry_date: e.target.value })}
                />
              ) : (
                <p className="text-sm text-slate-900">
                  {batch.expiry_date ? format(new Date(batch.expiry_date), "MMM d, yyyy") : "-"}
                </p>
              )}
            </div>
            <div>
              <Label className="text-xs text-slate-500 flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Received Date
              </Label>
              {isEditing ? (
                <Input
                  type="date"
                  value={form.received_date || ""}
                  onChange={(e) => setForm({ ...form, received_date: e.target.value })}
                />
              ) : (
                <p className="text-sm text-slate-900">
                  {batch.received_date ? format(new Date(batch.received_date), "MMM d, yyyy") : "-"}
                </p>
              )}
            </div>
          </div>

          <div>
            <Label className="text-xs text-slate-500 flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              Storage Location
            </Label>
            {isEditing ? (
              <Input
                value={form.storage_location || ""}
                onChange={(e) => setForm({ ...form, storage_location: e.target.value })}
              />
            ) : (
              <p className="text-sm text-slate-900">{batch.storage_location || "-"}</p>
            )}
          </div>

          {batch.notes && (
            <div>
              <Label className="text-xs text-slate-500">Notes</Label>
              {isEditing ? (
                <Textarea
                  value={form.notes || ""}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  rows={3}
                />
              ) : (
                <p className="text-sm text-slate-700">{batch.notes}</p>
              )}
            </div>
          )}
        </div>

        {isEditing && (
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={() => { setIsEditing(false); setForm(batch); }}>
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={updateMutation.isPending}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {updateMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        )}

        <div className="pt-4 border-t space-y-4">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-slate-900">Documents</h3>
              <Button
                size="sm"
                onClick={() => setShowDocUpload(true)}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                Upload
              </Button>
            </div>
            <DocumentList entityType="RawMaterialBatch" entityId={batch.id} />
          </div>

          <CommentSection entityType="RawMaterialBatch" entityId={batch.id} />
        </div>
      </DialogContent>
      <DocumentUploader
        entityType="RawMaterialBatch"
        entityId={batch.id}
        open={showDocUpload}
        onClose={() => setShowDocUpload(false)}
      />
    </Dialog>
  );
}