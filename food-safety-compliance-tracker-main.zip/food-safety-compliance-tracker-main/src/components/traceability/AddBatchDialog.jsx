import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function AddBatchDialog({ open, onClose }) {
  const [form, setForm] = useState({
    batch_number: "",
    po_number: "",
    material_name: "",
    material_code: "",
    supplier: "",
    supplier_batch_number: "",
    quantity: "",
    unit: "kg",
    manufacturing_date: "",
    expiry_date: "",
    received_date: "",
    storage_location: "",
    status: "pending_inspection",
    notes: "",
  });

  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.RawMaterialBatch.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["raw-material-batches"] });
      toast.success("Batch added successfully");
      onClose();
      setForm({
        batch_number: "",
        po_number: "",
        material_name: "",
        material_code: "",
        supplier: "",
        supplier_batch_number: "",
        quantity: "",
        unit: "kg",
        manufacturing_date: "",
        expiry_date: "",
        received_date: "",
        storage_location: "",
        status: "pending_inspection",
        notes: "",
      });
    },
    onError: () => toast.error("Failed to add batch"),
  });

  const handleSubmit = () => {
    const data = { ...form };
    if (data.quantity) data.quantity = parseFloat(data.quantity);
    createMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Raw Material Batch</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Batch Number*</Label>
              <Input
                placeholder="e.g. RM-2024-001"
                value={form.batch_number}
                onChange={(e) => setForm({ ...form, batch_number: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">PO Number*</Label>
              <Input
                placeholder="e.g. PO-12345"
                value={form.po_number}
                onChange={(e) => setForm({ ...form, po_number: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Material Name*</Label>
              <Input
                placeholder="e.g. Polyethylene Film"
                value={form.material_name}
                onChange={(e) => setForm({ ...form, material_name: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Material Code</Label>
              <Input
                placeholder="e.g. MAT-001"
                value={form.material_code}
                onChange={(e) => setForm({ ...form, material_code: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Supplier*</Label>
              <Input
                placeholder="Supplier name"
                value={form.supplier}
                onChange={(e) => setForm({ ...form, supplier: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Supplier Batch Number</Label>
              <Input
                placeholder="Supplier's batch ID"
                value={form.supplier_batch_number}
                onChange={(e) => setForm({ ...form, supplier_batch_number: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label className="text-xs">Quantity</Label>
              <Input
                type="number"
                placeholder="1000"
                value={form.quantity}
                onChange={(e) => setForm({ ...form, quantity: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Unit</Label>
              <Select value={form.unit} onValueChange={(v) => setForm({ ...form, unit: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="kg">kg</SelectItem>
                  <SelectItem value="L">L</SelectItem>
                  <SelectItem value="pcs">pcs</SelectItem>
                  <SelectItem value="rolls">rolls</SelectItem>
                  <SelectItem value="boxes">boxes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending_inspection">Pending Inspection</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="in_use">In Use</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label className="text-xs">Manufacturing Date</Label>
              <Input
                type="date"
                value={form.manufacturing_date}
                onChange={(e) => setForm({ ...form, manufacturing_date: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Expiry Date</Label>
              <Input
                type="date"
                value={form.expiry_date}
                onChange={(e) => setForm({ ...form, expiry_date: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Received Date</Label>
              <Input
                type="date"
                value={form.received_date}
                onChange={(e) => setForm({ ...form, received_date: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label className="text-xs">Storage Location</Label>
            <Input
              placeholder="e.g. Warehouse A, Bay 3"
              value={form.storage_location}
              onChange={(e) => setForm({ ...form, storage_location: e.target.value })}
            />
          </div>

          <div>
            <Label className="text-xs">Notes</Label>
            <Textarea
              placeholder="Additional notes..."
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={handleSubmit}
            disabled={!form.batch_number || !form.po_number || !form.material_name || !form.supplier || createMutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {createMutation.isPending ? "Adding..." : "Add Batch"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}