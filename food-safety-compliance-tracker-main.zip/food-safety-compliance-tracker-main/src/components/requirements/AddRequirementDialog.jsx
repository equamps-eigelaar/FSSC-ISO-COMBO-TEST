import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const SECTIONS = [
  "4 - Context of the Organization",
  "5 - Leadership",
  "6 - Planning",
  "7 - Support",
  "8 - Operation",
  "9 - Performance Evaluation",
  "10 - Improvement",
  "TS 22002-4 - Establishment",
  "TS 22002-4 - Utilities",
  "TS 22002-4 - Equipment",
  "TS 22002-4 - Hygiene",
  "TS 22002-4 - Personnel",
  "TS 22002-4 - Transportation",
  "TS 22002-4 - Product Information",
  "TS 22002-4 - Other Requirements",
];

export default function AddRequirementDialog({ open, onClose }) {
  const [form, setForm] = useState({
    clause_number: "",
    clause_title: "",
    section: SECTIONS[0],
    description: "",
    priority: "medium",
    status: "not_started",
  });

  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ComplianceRequirement.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-requirements"] });
      onClose();
      setForm({
        clause_number: "",
        clause_title: "",
        section: SECTIONS[0],
        description: "",
        priority: "medium",
        status: "not_started",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Requirement</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Clause Number</Label>
              <Input
                placeholder="e.g. 4.1"
                value={form.clause_number}
                onChange={(e) => setForm({ ...form, clause_number: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Section</Label>
              <Select value={form.section} onValueChange={(v) => setForm({ ...form, section: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SECTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label className="text-xs">Title</Label>
            <Input
              placeholder="Clause title"
              value={form.clause_title}
              onChange={(e) => setForm({ ...form, clause_title: e.target.value })}
            />
          </div>
          <div>
            <Label className="text-xs">Description</Label>
            <Textarea
              placeholder="What does this clause require?"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Priority</Label>
              <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="not_started">Not Started</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                  <SelectItem value="compliant">Compliant</SelectItem>
                  <SelectItem value="non_compliant">Non-Compliant</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={() => createMutation.mutate(form)}
            disabled={!form.clause_number || !form.clause_title || createMutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {createMutation.isPending ? "Adding..." : "Add Requirement"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}