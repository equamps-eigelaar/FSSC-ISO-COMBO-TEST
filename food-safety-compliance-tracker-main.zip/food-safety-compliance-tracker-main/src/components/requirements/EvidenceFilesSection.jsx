import React, { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, FileText, Image, File, Download, Trash2, Loader2 } from "lucide-react";

function getFileIcon(url) {
  const lower = (url || "").toLowerCase();
  if (lower.endsWith(".pdf")) return FileText;
  if (lower.match(/\.(png|jpg|jpeg|gif|webp)$/)) return Image;
  return File;
}

function getFileName(url) {
  try {
    return decodeURIComponent(url.split("/").pop().split("?")[0]) || url;
  } catch {
    return url;
  }
}

function getFileExtBadge(url) {
  const lower = (url || "").toLowerCase();
  if (lower.endsWith(".pdf")) return { label: "PDF", className: "bg-rose-50 text-rose-700 border-rose-100" };
  if (lower.match(/\.docx?$/)) return { label: "DOC", className: "bg-blue-50 text-blue-700 border-blue-100" };
  if (lower.match(/\.xlsx?$/)) return { label: "XLS", className: "bg-emerald-50 text-emerald-700 border-emerald-100" };
  if (lower.match(/\.(png|jpg|jpeg|gif|webp)$/)) return { label: "IMG", className: "bg-purple-50 text-purple-700 border-purple-100" };
  return { label: "FILE", className: "bg-slate-50 text-slate-600 border-slate-200" };
}

export default function EvidenceFilesSection({ files = [], onFilesChange, uploading, onUpload, readOnly = false }) {
  const inputRef = useRef();

  return (
    <div className="space-y-3">
      {files.length > 0 && (
        <div className="space-y-2">
          {files.map((url, i) => {
            const IconComponent = getFileIcon(url);
            const ext = getFileExtBadge(url);
            const name = getFileName(url);
            const isImage = url.match(/\.(png|jpg|jpeg|gif|webp)$/i);

            return (
              <div key={i} className="flex items-start gap-3 p-3 bg-slate-50 border border-slate-100 rounded-lg group hover:border-slate-200 transition-colors">
                {isImage ? (
                  <a href={url} target="_blank" rel="noopener noreferrer" className="shrink-0">
                    <img
                      src={url}
                      alt={name}
                      className="w-12 h-12 rounded object-cover border border-slate-200"
                      onError={(e) => { e.target.style.display = 'none'; }}
                    />
                  </a>
                ) : (
                  <div className="w-12 h-12 rounded-lg bg-white border border-slate-200 flex items-center justify-center shrink-0">
                    <IconComponent className="w-6 h-6 text-slate-400" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800 truncate">{name}</p>
                  <Badge variant="outline" className={`text-xs mt-1 ${ext.className}`}>{ext.label}</Badge>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <a
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="h-8 w-8 flex items-center justify-center rounded-md text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 transition-colors"
                    title="Download / Open"
                  >
                    <Download className="w-4 h-4" />
                  </a>
                  {!readOnly && (
                    <button
                      onClick={() => {
                        const updated = [...files];
                        updated.splice(i, 1);
                        onFilesChange(updated);
                      }}
                      className="h-8 w-8 flex items-center justify-center rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {!readOnly && (
        <>
          <input
            ref={inputRef}
            type="file"
            className="hidden"
            accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg,.gif,.webp"
            multiple
            onChange={onUpload}
            disabled={uploading}
          />
          <button
            onClick={() => inputRef.current?.click()}
            disabled={uploading}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-slate-200 rounded-lg cursor-pointer hover:border-emerald-300 hover:bg-emerald-50/30 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {uploading ? (
              <><Loader2 className="w-4 h-4 text-emerald-600 animate-spin" /><span className="text-xs text-slate-500">Uploading...</span></>
            ) : (
              <><Upload className="w-4 h-4 text-slate-400" /><span className="text-xs text-slate-500">Upload evidence files (PDF, DOCX, JPG, PNG…)</span></>
            )}
          </button>
        </>
      )}
    </div>
  );
}