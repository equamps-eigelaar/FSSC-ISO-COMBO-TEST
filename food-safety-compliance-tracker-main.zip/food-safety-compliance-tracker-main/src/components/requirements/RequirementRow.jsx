import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronRight, ArrowRight } from "lucide-react";

const STATUS_CONFIG = {
  not_started: { label: "Not Started", className: "bg-slate-100 text-slate-600" },
  in_progress: { label: "In Progress", className: "bg-blue-50 text-blue-700" },
  partial: { label: "Partial", className: "bg-amber-50 text-amber-700" },
  compliant: { label: "Compliant", className: "bg-emerald-50 text-emerald-700" },
  non_compliant: { label: "Non-Compliant", className: "bg-rose-50 text-rose-700" },
};

const PRIORITY_CONFIG = {
  critical: { label: "Critical", className: "bg-rose-50 text-rose-600 border-rose-200" },
  high: { label: "High", className: "bg-orange-50 text-orange-600 border-orange-200" },
  medium: { label: "Medium", className: "bg-slate-50 text-slate-500 border-slate-200" },
  low: { label: "Low", className: "bg-slate-50 text-slate-400 border-slate-200" },
};

export default function RequirementRow({ requirement, onStatusChange, canEdit = true, canApprove = false, isHidden = false }) {
  if (isHidden) return null;
  
  const status = STATUS_CONFIG[requirement.status] || STATUS_CONFIG.not_started;
  const priority = PRIORITY_CONFIG[requirement.priority] || PRIORITY_CONFIG.medium;

  return (
    <Link
      to={createPageUrl("RequirementDetail") + `?id=${requirement.id}`}
      className="block px-4 sm:px-5 py-3 hover:bg-slate-50/50 transition-colors group"
    >
      {/* Mobile layout */}
      <div className="flex sm:hidden flex-col gap-2 py-1">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <span className="text-xs font-mono font-bold text-slate-400 block mb-0.5">
              {requirement.clause_number}
            </span>
            <span className="text-sm font-medium text-slate-800 group-hover:text-emerald-700 transition-colors">
              {requirement.clause_title}
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 shrink-0 mt-1" />
        </div>
        {requirement.description && (
          <p className="text-xs text-slate-400 line-clamp-2">{requirement.description}</p>
        )}
        <div className="flex flex-col gap-1.5">
          <Badge variant="outline" className={`text-xs w-fit ${priority.className}`}>
            {priority.label}
          </Badge>
          <div onClick={(e) => e.stopPropagation()}>
            <Select value={requirement.status} onValueChange={onStatusChange} disabled={!canEdit}>
              <SelectTrigger className={`h-8 text-xs border-0 w-36 ${status.className} ${!canEdit ? 'cursor-not-allowed opacity-70' : ''}`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="not_started">Not Started</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="partial">Partial</SelectItem>
                <SelectItem value="compliant">Compliant</SelectItem>
                <SelectItem value="non_compliant">Non-Compliant</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Desktop layout */}
      <div className="hidden sm:flex sm:items-center sm:gap-4 min-h-[60px]">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2.5 mb-1">
            <span className="text-xs font-mono font-bold text-slate-400 shrink-0">
              {requirement.clause_number}
            </span>
            <span className="text-sm font-medium text-slate-800 group-hover:text-emerald-700 transition-colors break-words">
              {requirement.clause_title}
            </span>
          </div>
          <div className="flex flex-wrap gap-2 items-center">
            <Badge variant="outline" className={`text-xs shrink-0 ${priority.className}`}>
              {priority.label}
            </Badge>
          </div>
        </div>
        <div className="shrink-0" onClick={(e) => e.stopPropagation()}>
          <Select value={requirement.status} onValueChange={onStatusChange} disabled={!canEdit}>
            <SelectTrigger className={`w-32 h-8 text-xs border-0 ${status.className} ${!canEdit ? 'cursor-not-allowed opacity-70' : ''}`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="not_started">Not Started</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="partial">Partial</SelectItem>
              <SelectItem value="compliant">Compliant</SelectItem>
              <SelectItem value="non_compliant">Non-Compliant</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 shrink-0" />
      </div>
    </Link>
  );
}