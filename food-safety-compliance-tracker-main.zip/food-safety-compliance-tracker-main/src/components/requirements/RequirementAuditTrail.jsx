import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { History, User, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const STATUS_COLORS = {
  compliant: "bg-emerald-100 text-emerald-700",
  in_progress: "bg-blue-100 text-blue-700",
  partial: "bg-amber-100 text-amber-700",
  not_started: "bg-slate-100 text-slate-600",
  non_compliant: "bg-rose-100 text-rose-700",
};

export default function RequirementAuditTrail({ requirementId }) {
  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["audit-logs", requirementId],
    queryFn: async () => {
      const all = await base44.entities.ActivityLog.list("-created_date", 100);
      return all.filter(
        (l) => l.entity_id === requirementId && l.entity_type === "ComplianceRequirement"
      );
    },
    enabled: !!requirementId,
  });

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <History className="w-4 h-4 text-slate-400" />
          Audit Trail
          {logs.length > 0 && (
            <Badge variant="secondary" className="text-xs">{logs.length}</Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        {isLoading ? (
          <div className="py-4 flex justify-center">
            <div className="w-5 h-5 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : logs.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-4">No changes recorded yet</p>
        ) : (
          <div className="space-y-0 relative">
            {/* Timeline line */}
            <div className="absolute left-3 top-2 bottom-2 w-px bg-slate-100" />
            {logs.map((log, i) => (
              <div key={log.id} className="flex gap-3 pb-4 relative">
                <div className="w-6 h-6 rounded-full bg-white border-2 border-slate-200 flex items-center justify-center shrink-0 z-10">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                </div>
                <div className="flex-1 min-w-0 pt-0.5">
                  <p className="text-xs text-slate-700 leading-snug">{log.description}</p>

                  {/* Field changes */}
                  {log.field_changes?.length > 0 && (
                    <div className="mt-1.5 space-y-1">
                      {log.field_changes.map((fc, j) => (
                        <div key={j} className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-mono bg-slate-50 border border-slate-200 text-slate-500 px-1.5 py-0.5 rounded">{fc.field}</span>
                          {fc.old_value && (
                            <>
                              <Badge className={`text-[10px] py-0 px-1.5 ${STATUS_COLORS[fc.old_value] || "bg-slate-100 text-slate-500"}`}>
                                {fc.old_value}
                              </Badge>
                              <span className="text-[10px] text-slate-400">→</span>
                            </>
                          )}
                          {fc.new_value && (
                            <Badge className={`text-[10px] py-0 px-1.5 ${STATUS_COLORS[fc.new_value] || "bg-slate-100 text-slate-500"}`}>
                              {fc.new_value}
                            </Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center gap-2 mt-1.5">
                    {log.user_name || log.user_email ? (
                      <span className="text-[10px] text-slate-400 flex items-center gap-1">
                        <User className="w-2.5 h-2.5" />
                        {log.user_name || log.user_email}
                      </span>
                    ) : null}
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      {log.created_date
                        ? formatDistanceToNow(new Date(log.created_date), { addSuffix: true })
                        : ""}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}