import React, { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { CheckCircle2, XCircle, ArrowRight, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

export default function TrainingModuleDialog({ module, open, onClose }) {
  const [currentView, setCurrentView] = useState('content'); // 'content' or 'quiz'
  const [answers, setAnswers] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [startTime, setStartTime] = useState(null);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });

  const { data: existingProgress } = useQuery({
    queryKey: ['training-progress', user?.email, module?.id],
    queryFn: async () => {
      const all = await base44.entities.UserTrainingProgress.filter({ 
        user_email: user.email,
        module_id: module.id 
      });
      return all[0];
    },
    enabled: !!user && !!module
  });

  const createProgressMutation = useMutation({
    mutationFn: (data) => base44.entities.UserTrainingProgress.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-progress'] });
    }
  });

  const updateProgressMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.UserTrainingProgress.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-progress'] });
    }
  });

  useEffect(() => {
    if (open && module) {
      setCurrentView('content');
      setAnswers([]);
      setShowResults(false);
      setStartTime(new Date());

      // Create or update progress when opening
      if (!existingProgress && user) {
        createProgressMutation.mutate({
          user_email: user.email,
          module_id: module.id,
          status: 'in_progress',
          started_date: new Date().toISOString(),
          progress_percentage: 0
        });
      }
    }
  }, [open, module?.id]);

  if (!module) return null;

  const handleStartQuiz = () => {
    setCurrentView('quiz');
    if (existingProgress) {
      updateProgressMutation.mutate({
        id: existingProgress.id,
        data: { progress_percentage: 50 }
      });
    }
  };

  const handleSubmitQuiz = () => {
    const correct = answers.filter((ans, idx) => 
      ans === module.quiz_questions[idx].correct_answer
    ).length;
    const score = Math.round((correct / module.quiz_questions.length) * 100);
    const timeSpent = Math.round((new Date() - startTime) / 60000);

    setShowResults(true);

    if (existingProgress) {
      updateProgressMutation.mutate({
        id: existingProgress.id,
        data: {
          status: 'completed',
          progress_percentage: 100,
          quiz_score: score,
          quiz_attempts: (existingProgress.quiz_attempts || 0) + 1,
          quiz_answers: answers,
          completed_date: new Date().toISOString(),
          time_spent_minutes: timeSpent
        }
      });
    }

    if (score >= 70) {
      toast.success(`Congratulations! You scored ${score}%`);
    } else {
      toast.error(`Score: ${score}%. Try again to improve!`);
    }
  };

  const handleRetake = () => {
    setAnswers([]);
    setShowResults(false);
    setCurrentView('quiz');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg">{module.title}</DialogTitle>
        </DialogHeader>

        {currentView === 'content' && (
          <div className="space-y-4 py-4">
            <div className="prose prose-sm max-w-none dark:prose-invert">
              <ReactMarkdown>{module.content}</ReactMarkdown>
            </div>

            {existingProgress && existingProgress.progress_percentage > 0 && (
              <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    Your Progress
                  </span>
                  <span className="text-sm font-semibold text-slate-900 dark:text-white">
                    {existingProgress.progress_percentage}%
                  </span>
                </div>
                <Progress value={existingProgress.progress_percentage} />
              </div>
            )}

            <div className="flex justify-end gap-2 pt-4 border-t">
              <Button variant="outline" onClick={onClose}>
                Close
              </Button>
              <Button
                onClick={handleStartQuiz}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                Start Quiz
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        )}

        {currentView === 'quiz' && !showResults && (
          <div className="space-y-6 py-4">
            {module.quiz_questions.map((q, idx) => (
              <div key={idx} className="space-y-3">
                <h4 className="font-semibold text-slate-900 dark:text-white">
                  {idx + 1}. {q.question}
                </h4>
                <RadioGroup
                  value={answers[idx]?.toString()}
                  onValueChange={(val) => {
                    const newAnswers = [...answers];
                    newAnswers[idx] = parseInt(val);
                    setAnswers(newAnswers);
                  }}
                >
                  {q.options.map((option, optIdx) => (
                    <div key={optIdx} className="flex items-center space-x-2">
                      <RadioGroupItem value={optIdx.toString()} id={`q${idx}-opt${optIdx}`} />
                      <Label htmlFor={`q${idx}-opt${optIdx}`} className="cursor-pointer">
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            ))}

            <div className="flex justify-end gap-2 pt-4 border-t">
              <Button variant="outline" onClick={() => setCurrentView('content')}>
                Back to Content
              </Button>
              <Button
                onClick={handleSubmitQuiz}
                disabled={answers.length !== module.quiz_questions.length}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                Submit Quiz
              </Button>
            </div>
          </div>
        )}

        {showResults && (
          <div className="space-y-4 py-4">
            <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-6 text-center">
              <div className="text-4xl font-bold text-emerald-600 dark:text-emerald-400 mb-2">
                {Math.round((answers.filter((ans, idx) => ans === module.quiz_questions[idx].correct_answer).length / module.quiz_questions.length) * 100)}%
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                {answers.filter((ans, idx) => ans === module.quiz_questions[idx].correct_answer).length} out of {module.quiz_questions.length} correct
              </p>
            </div>

            {module.quiz_questions.map((q, idx) => {
              const isCorrect = answers[idx] === q.correct_answer;
              return (
                <div key={idx} className="border dark:border-slate-700 rounded-lg p-4">
                  <div className="flex items-start gap-2 mb-2">
                    {isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <h4 className="font-semibold text-slate-900 dark:text-white mb-2">
                        {idx + 1}. {q.question}
                      </h4>
                      <div className="space-y-1 text-sm">
                        <p className="text-slate-600 dark:text-slate-300">
                          Your answer: <span className={isCorrect ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}>
                            {q.options[answers[idx]]}
                          </span>
                        </p>
                        {!isCorrect && (
                          <p className="text-slate-600 dark:text-slate-300">
                            Correct answer: <span className="text-emerald-600 dark:text-emerald-400">
                              {q.options[q.correct_answer]}
                            </span>
                          </p>
                        )}
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                          {q.explanation}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}

            <div className="flex justify-end gap-2 pt-4 border-t">
              <Button variant="outline" onClick={handleRetake}>
                <RotateCcw className="w-4 h-4 mr-2" />
                Retake Quiz
              </Button>
              <Button onClick={onClose} className="bg-emerald-600 hover:bg-emerald-700">
                Complete
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}