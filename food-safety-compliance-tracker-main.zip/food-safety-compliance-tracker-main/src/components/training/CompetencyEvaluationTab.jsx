import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  Plus, Search, CheckCircle2, XCircle, Clock, AlertTriangle,
  User, Calendar, Award, Pencil, Trash2, ShieldCheck, Droplets, RefreshCw
} from "lucide-react";
import { toast } from "sonner";
import { format, differenceInDays } from "date-fns";

const TRAINING_TYPES = [
  { value: "hygiene_induction", label: "Hygiene Induction", icon: Droplets, color: "bg-blue-100 text-blue-800" },
  { value: "hygiene_refresher", label: "Hygiene Refresher", icon: Droplets, color: "bg-cyan-100 text-cyan-800" },
  { value: "ccp_awareness", label: "CCP Awareness", icon: ShieldCheck, color: "bg-red-100 text-red-800" },
  { value: "allergen_awareness", label: "Allergen Awareness", icon: AlertTriangle, color: "bg-orange-100 text-orange-800" },
  { value: "annual_refresher", label: "Annual Refresher", icon: RefreshCw, color: "bg-purple-100 text-purple-800" },
  { value: "gmp_training", label: "GMP Training", icon: Award, color: "bg-emerald-100 text-emerald-800" },
  { value: "haccp_training", label: "HACCP Training", icon: ShieldCheck, color: "bg-amber-100 text-amber-800" },
  { value: "food_safety_culture", label: "Food Safety Culture", icon: Award, color: "bg-indigo-100 text-indigo-800" },
  { value: "custom", label: "Custom", icon: Award, color: "bg-slate-100 text-slate-700" },
];

const TRAINING_MAP = Object.fromEntries(TRAINING_TYPES.map(t => [t.value, t]));

const RESULT_CONFIG = {
  pass: { label: "Pass", color: "bg-emerald-100 text-emerald-800", icon: CheckCircle2 },
  fail: { label: "Fail", color: "bg-red-100 text-red-800", icon: XCircle },
  pending: { label: "Pending", color: "bg-slate-100 text-slate-600", icon: Clock },
  retraining_required: { label: "Retraining Required", color: "bg-amber-100 text-amber-800", icon: AlertTriangle },
};

const EMPTY_FORM = {
  staff_name: "", staff_email: "", department: "",
  training_type: "hygiene_induction", custom_training_name: "",
  evaluation_date: new Date().toISOString().slice(0, 10),
  due_date: "", evaluator: "", method: "written_test",
  score: "", pass_mark: 75, result: "pending",
  observations: "", corrective_training: "",
  signed_off_by: "", signed_off_date: "",
};

export default function CompetencyEvaluationTab() {
  const qc = useQueryClient();
  const [dialog, setDialog] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [resultFilter, setResultFilter] = useState("all");

  const { data: records = [], isLoading } = useQuery({
    queryKey: ["staff-competency"],
    queryFn: () => base44.entities.StaffCompetency.list("-evaluation_date", 500),
  });

  const createMut = useMutation({
    mutationFn: data => base44.entities.StaffCompetency.create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["staff-competency"] }); toast.success("Record saved"); },
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.StaffCompetency.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["staff-competency"] }); toast.success("Updated"); },
  });
  const deleteMut = useMutation({
    mutationFn: id => base44.entities.StaffCompetency.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["staff-competency"] }); toast.success("Deleted"); },
  });

  const openNew = () => { setEditing(null); setForm(EMPTY_FORM); setDialog(true); };
  const openEdit = (r) => { setEditing(r); setForm({ ...EMPTY_FORM, ...r }); setDialog(true); };
  const set = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const handleSave = () => {
    const payload = { ...form };
    if (form.score !== "" && form.score != null) {
      payload.result = Number(form.score) >= Number(form.pass_mark) ? "pass" : "fail";
    }
    if (editing?.id) updateMut.mutate({ id: editing.id, data: payload });
    else createMut.mutate(payload);
    setDialog(false);
  };

  const filtered = useMemo(() => records.filter(r => {
    const q = search.toLowerCase();
    const matchSearch = !search || r.staff_name?.toLowerCase().includes(q) || r.department?.toLowerCase().includes(q) || r.staff_email?.toLowerCase().includes(q);
    const matchType = typeFilter === "all" || r.training_type === typeFilter;
    const matchResult = resultFilter === "all" || r.result === resultFilter;
    return matchSearch && matchType && matchResult;
  }), [records, search, typeFilter, resultFilter]);

  // Summary stats
  const stats = useMemo(() => {
    const today = new Date();
    const overdue = records.filter(r => r.due_date && differenceInDays(new Date(r.due_date), today) < 0 && r.result !== "fail").length;
    const dueSoon = records.filter(r => {
      if (!r.due_date) return false;
      const d = differenceInDays(new Date(r.due_date), today);
      return d >= 0 && d <= 30;
    }).length;
    const passRate = records.length > 0
      ? Math.round(records.filter(r => r.result === "pass").length / records.filter(r => r.result !== "pending").length * 100) || 0
      : 0;
    return {
      total: records.length,
      pass: records.filter(r => r.result === "pass").length,
      fail: records.filter(r => r.result === "fail" || r.result === "retraining_required").length,
      pending: records.filter(r => r.result === "pending").length,
      overdue, dueSoon, passRate,
    };
  }, [records]);

  // Group by training type for overview
  const byType = useMemo(() => TRAINING_TYPES.map(t => {
    const recs = records.filter(r => r.training_type === t.value);
    return { ...t, count: recs.length, passed: recs.filter(r => r.result === "pass").length };
  }).filter(t => t.count > 0), [records]);

  return (
    <div className="space-y-6">
      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        {[
          { label: "Total Records", val: stats.total, color: "text-slate-800" },
          { label: "Passed", val: stats.pass, color: "text-emerald-600" },
          { label: "Failed / Retraining", val: stats.fail, color: "text-red-600" },
          { label: "Pending", val: stats.pending, color: "text-slate-500" },
          { label: "Pass Rate", val: `${stats.passRate}%`, color: "text-purple-600" },
          { label: "Overdue Refreshers", val: stats.overdue, color: "text-red-600" },
          { label: "Due in 30 days", val: stats.dueSoon, color: "text-amber-600" },
        ].map(s => (
          <Card key={s.label} className="border-0 shadow-sm">
            <CardContent className="p-3 text-center">
              <div className={`text-xl font-bold ${s.color}`}>{s.val}</div>
              <div className="text-[10px] text-slate-500 leading-tight mt-0.5">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Training type coverage */}
      {byType.length > 0 && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Training Coverage by Type</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {byType.map(t => {
                const Icon = t.icon;
                return (
                  <div key={t.value} className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium ${t.color}`}>
                    <Icon className="w-3.5 h-3.5" />
                    {t.label}
                    <span className="font-bold ml-1">{t.passed}/{t.count}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filters + Add */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
          <Input placeholder="Search staff..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-xs" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-44 h-8 text-xs"><SelectValue placeholder="All Types" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {TRAINING_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={resultFilter} onValueChange={setResultFilter}>
          <SelectTrigger className="w-36 h-8 text-xs"><SelectValue placeholder="All Results" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Results</SelectItem>
            {Object.entries(RESULT_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button size="sm" className="h-8 bg-emerald-600 hover:bg-emerald-700 gap-1 ml-auto" onClick={openNew}>
          <Plus className="w-3.5 h-3.5" /> Add Record
        </Button>
      </div>

      {/* Records */}
      {isLoading ? (
        <div className="text-center py-10 text-slate-400">Loading...</div>
      ) : filtered.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="py-12 text-center">
            <Award className="w-12 h-12 text-slate-200 mx-auto mb-3" />
            <p className="text-slate-500 font-medium">No competency records found.</p>
            <p className="text-slate-400 text-sm mb-4">Start tracking staff training — hygiene, CCP awareness, annual refreshers.</p>
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 gap-1" onClick={openNew}>
              <Plus className="w-3.5 h-3.5" /> Add First Record
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map(r => {
            const rc = RESULT_CONFIG[r.result] || RESULT_CONFIG.pending;
            const tc = TRAINING_MAP[r.training_type] || TRAINING_MAP.custom;
            const Icon = rc.icon;
            const today = new Date();
            const daysUntilDue = r.due_date ? differenceInDays(new Date(r.due_date), today) : null;
            const overdue = daysUntilDue !== null && daysUntilDue < 0;
            const dueSoon = daysUntilDue !== null && daysUntilDue >= 0 && daysUntilDue <= 30;

            return (
              <Card key={r.id} className={`border-0 shadow-sm ${overdue ? 'border-l-4 border-l-red-400' : dueSoon ? 'border-l-4 border-l-amber-400' : ''}`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="text-sm font-semibold text-slate-800 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          {r.staff_name}
                        </span>
                        {r.department && <span className="text-xs text-slate-400">{r.department}</span>}
                        <Badge className={tc.color + " text-[10px]"}>{tc.label}</Badge>
                        {r.training_type === "custom" && r.custom_training_name && (
                          <span className="text-xs text-slate-500">— {r.custom_training_name}</span>
                        )}
                        <Badge className={rc.color}>
                          <Icon className="w-3 h-3 mr-1" />{rc.label}
                        </Badge>
                        {r.score != null && r.score !== "" && (
                          <span className={`text-xs font-bold ${r.result === "pass" ? "text-emerald-600" : "text-red-600"}`}>
                            {r.score}% {r.pass_mark ? `(pass mark: ${r.pass_mark}%)` : ""}
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-3 text-xs text-slate-400">
                        {r.evaluation_date && (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" /> Evaluated: {r.evaluation_date}
                          </span>
                        )}
                        {r.evaluator && <span>Evaluator: {r.evaluator}</span>}
                        {r.method && <span>Method: {r.method?.replace(/_/g, " ")}</span>}
                        {r.due_date && (
                          <span className={overdue ? "text-red-500 font-medium" : dueSoon ? "text-amber-500 font-medium" : ""}>
                            {overdue ? `⚠ Overdue (${r.due_date})` : dueSoon ? `Due soon: ${r.due_date} (${daysUntilDue}d)` : `Next due: ${r.due_date}`}
                          </span>
                        )}
                        {r.signed_off_by && <span>Signed off: {r.signed_off_by}</span>}
                      </div>
                      {r.observations && (
                        <p className="text-xs text-slate-500 mt-1 italic">"{r.observations}"</p>
                      )}
                      {r.result === "retraining_required" && r.corrective_training && (
                        <p className="text-xs text-amber-700 mt-1 font-medium">Retraining: {r.corrective_training}</p>
                      )}
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-slate-400 hover:text-indigo-600" onClick={() => openEdit(r)}>
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-slate-400 hover:text-red-600" onClick={() => deleteMut.mutate(r.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Dialog */}
      <Dialog open={dialog} onOpenChange={setDialog}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-600" />
              {editing?.id ? "Edit Competency Record" : "Add Competency Record"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs mb-1 block">Staff Name *</Label>
                <Input value={form.staff_name} onChange={e => set("staff_name", e.target.value)} className="h-8 text-xs" />
              </div>
              <div>
                <Label className="text-xs mb-1 block">Staff Email</Label>
                <Input value={form.staff_email} onChange={e => set("staff_email", e.target.value)} className="h-8 text-xs" type="email" />
              </div>
            </div>
            <div>
              <Label className="text-xs mb-1 block">Department / Area</Label>
              <Input value={form.department} onChange={e => set("department", e.target.value)} className="h-8 text-xs" />
            </div>
            <div>
              <Label className="text-xs mb-1 block">Training Type *</Label>
              <Select value={form.training_type} onValueChange={v => set("training_type", v)}>
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TRAINING_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {form.training_type === "custom" && (
              <div>
                <Label className="text-xs mb-1 block">Custom Training Name</Label>
                <Input value={form.custom_training_name} onChange={e => set("custom_training_name", e.target.value)} className="h-8 text-xs" />
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs mb-1 block">Evaluation Date *</Label>
                <Input type="date" value={form.evaluation_date} onChange={e => set("evaluation_date", e.target.value)} className="h-8 text-xs" />
              </div>
              <div>
                <Label className="text-xs mb-1 block">Next Due Date</Label>
                <Input type="date" value={form.due_date} onChange={e => set("due_date", e.target.value)} className="h-8 text-xs" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs mb-1 block">Evaluator</Label>
                <Input value={form.evaluator} onChange={e => set("evaluator", e.target.value)} className="h-8 text-xs" />
              </div>
              <div>
                <Label className="text-xs mb-1 block">Evaluation Method</Label>
                <Select value={form.method} onValueChange={v => set("method", v)}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[
                      { v: "written_test", l: "Written Test" },
                      { v: "practical_assessment", l: "Practical Assessment" },
                      { v: "observation", l: "Observation" },
                      { v: "verbal_assessment", l: "Verbal Assessment" },
                      { v: "online_module", l: "Online Module" },
                      { v: "combined", l: "Combined" },
                    ].map(m => <SelectItem key={m.v} value={m.v}>{m.l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs mb-1 block">Score (%)</Label>
                <Input type="number" min="0" max="100" value={form.score} onChange={e => set("score", e.target.value)} className="h-8 text-xs" placeholder="0-100" />
              </div>
              <div>
                <Label className="text-xs mb-1 block">Pass Mark (%)</Label>
                <Input type="number" min="0" max="100" value={form.pass_mark} onChange={e => set("pass_mark", e.target.value)} className="h-8 text-xs" />
              </div>
            </div>
            <div>
              <Label className="text-xs mb-1 block">Result</Label>
              <Select value={form.result} onValueChange={v => set("result", v)}>
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(RESULT_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs mb-1 block">Assessor Observations</Label>
              <Textarea value={form.observations} onChange={e => set("observations", e.target.value)} className="text-xs" rows={2} />
            </div>
            {(form.result === "fail" || form.result === "retraining_required") && (
              <div>
                <Label className="text-xs mb-1 block text-amber-700">Required Corrective Training</Label>
                <Textarea value={form.corrective_training} onChange={e => set("corrective_training", e.target.value)} className="text-xs border-amber-200" rows={2} />
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs mb-1 block">Signed Off By</Label>
                <Input value={form.signed_off_by} onChange={e => set("signed_off_by", e.target.value)} className="h-8 text-xs" />
              </div>
              <div>
                <Label className="text-xs mb-1 block">Sign-off Date</Label>
                <Input type="date" value={form.signed_off_date} onChange={e => set("signed_off_date", e.target.value)} className="h-8 text-xs" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setDialog(false)}>Cancel</Button>
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSave}>Save Record</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}