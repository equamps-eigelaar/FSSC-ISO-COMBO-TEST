import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from "@/api/base44Client";
import { Mail, Send, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function SendSummaryEmailDialog({ org, open, onClose, onSent }) {
  const [to, setTo] = useState(org?.contact_email || org?.owner_email || "");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const score = org?.compliance_score;
  const month = format(new Date(), "MMMM yyyy");
  const previewBody = `Hi ${org?.contact_name || "there"},

Here is your monthly compliance summary for ${month}.

✅ Overall Compliance Score: ${score != null ? score + "%" : "Awaiting update"}
📋 Open Action Items: ${org?.open_actions_count || 0}
⚠️  Critical Issues: ${org?.critical_issues_count || 0}

${org?.health_status === "green"
  ? "Great news — your organisation is on track and meeting all key compliance requirements. No immediate action is required this month."
  : "Your organisation is making good progress. Please review any outstanding items in your compliance tracker."
}

${org?.open_actions_count > 0 ? `You have ${org.open_actions_count} open action item(s) that require attention. Please log into the compliance portal to review and close these out.` : ""}

If you have any questions or would like to discuss your compliance status, please don't hesitate to reach out.

Kind regards,
Your Compliance Team`;

  const [body, setBody] = useState(previewBody);

  const handleSend = async () => {
    if (!to) return;
    setSending(true);
    await base44.integrations.Core.SendEmail({
      to,
      subject: `Monthly Compliance Summary — ${org?.name} — ${month}`,
      body: body.replace(/\n/g, "<br>"),
    });
    await base44.entities.Organization.update(org.id, {
      last_monthly_email_sent: new Date().toISOString().slice(0, 10),
    });
    setSending(false);
    setSent(true);
    toast.success(`Monthly summary sent to ${to}`);
    onSent?.();
    setTimeout(onClose, 1500);
  };

  if (!org) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-emerald-600" />
            Monthly Summary Email — {org.name}
          </DialogTitle>
        </DialogHeader>

        {sent ? (
          <div className="py-10 text-center">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
            <p className="font-semibold text-slate-800">Email sent successfully!</p>
            <p className="text-sm text-slate-500 mt-1">Summary delivered to {to}</p>
          </div>
        ) : (
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-xs text-slate-600">Send to</Label>
              <Input
                type="email"
                className="mt-1"
                value={to}
                onChange={e => setTo(e.target.value)}
                placeholder="client@company.com"
              />
            </div>
            <div>
              <Label className="text-xs text-slate-600">Email Body (editable)</Label>
              <Textarea
                className="mt-1 min-h-[260px] text-sm font-mono"
                value={body}
                onChange={e => setBody(e.target.value)}
              />
            </div>
          </div>
        )}

        {!sent && (
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button
              onClick={handleSend}
              disabled={sending || !to}
              className="bg-emerald-600 hover:bg-emerald-700 gap-2"
            >
              <Send className="w-4 h-4" />
              {sending ? "Sending..." : "Send Email"}
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}