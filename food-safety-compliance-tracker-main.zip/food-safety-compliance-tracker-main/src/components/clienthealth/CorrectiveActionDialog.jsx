import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { XCircle, Phone, Calendar, Save, ClipboardList, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

export default function CorrectiveActionDialog({ org, open, onClose, onSaved }) {
  const [form, setForm] = useState({
    organization_id: org?.organization_id || "",
    corrective_actions_summary: org?.corrective_actions_summary || "",
    call_scheduled_date: org?.call_scheduled_date || "",
    call_notes: org?.call_notes || "",
    compliance_score: org?.compliance_score ?? "",
    open_actions_count: org?.open_actions_count ?? 0,
    critical_issues_count: org?.critical_issues_count ?? 0,
    last_review_date: org?.last_review_date || new Date().toISOString().slice(0, 10),
    health_status: org?.health_status || "red",
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await base44.entities.Organization.update(org.id, form);
    toast.success("Client record updated");
    setSaving(false);
    onSaved?.();
    onClose();
  };

  if (!org) return null;

  const statusColor = { green: "text-emerald-600", amber: "text-amber-600", red: "text-rose-600" };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-rose-600" />
            Corrective Actions — {org.name}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {/* Org ID */}
          <div>
            <Label className="text-xs text-slate-600">Organisation ID / Reference Code</Label>
            <Input
              className="mt-1 h-9 font-mono"
              placeholder="e.g. ORG-001, CLIENT-ABC"
              value={form.organization_id}
              onChange={e => setForm(f => ({ ...f, organization_id: e.target.value }))}
            />
          </div>

          {/* Status + Scores */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <Label className="text-xs text-slate-600">Health Status</Label>
              <select
                className="mt-1 w-full border border-slate-200 rounded-md px-3 py-2 text-sm"
                value={form.health_status}
                onChange={e => setForm(f => ({ ...f, health_status: e.target.value }))}
              >
                <option value="green">🟢 Green</option>
                <option value="amber">🟡 Amber</option>
                <option value="red">🔴 Red</option>
              </select>
            </div>
            <div>
              <Label className="text-xs text-slate-600">Compliance Score %</Label>
              <Input
                type="number" min="0" max="100"
                className="mt-1 h-9"
                value={form.compliance_score}
                onChange={e => setForm(f => ({ ...f, compliance_score: Number(e.target.value) }))}
              />
            </div>
            <div>
              <Label className="text-xs text-slate-600">Open Actions</Label>
              <Input
                type="number" min="0"
                className="mt-1 h-9"
                value={form.open_actions_count}
                onChange={e => setForm(f => ({ ...f, open_actions_count: Number(e.target.value) }))}
              />
            </div>
            <div>
              <Label className="text-xs text-slate-600">Critical Issues</Label>
              <Input
                type="number" min="0"
                className="mt-1 h-9"
                value={form.critical_issues_count}
                onChange={e => setForm(f => ({ ...f, critical_issues_count: Number(e.target.value) }))}
              />
            </div>
          </div>

          {/* Corrective Actions List */}
          <div>
            <Label className="text-xs text-slate-600 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
              Corrective Action List (for 15–30 min call review)
            </Label>
            <Textarea
              className="mt-1 min-h-[120px] text-sm"
              placeholder="1. CCP monitoring records missing for Week 12&#10;2. Allergen cleaning verification not completed&#10;3. Supplier audit overdue — ABC Ingredients&#10;4. HACCP plan not reviewed since Q4 2024"
              value={form.corrective_actions_summary}
              onChange={e => setForm(f => ({ ...f, corrective_actions_summary: e.target.value }))}
            />
            <p className="text-xs text-slate-400 mt-1">List each action item on a new line. This will be referenced during the review call.</p>
          </div>

          {/* Schedule Call */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-slate-600 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-blue-500" />
                Schedule Review Call
              </Label>
              <Input
                type="date"
                className="mt-1 h-9"
                value={form.call_scheduled_date}
                onChange={e => setForm(f => ({ ...f, call_scheduled_date: e.target.value }))}
              />
            </div>
            <div>
              <Label className="text-xs text-slate-600 flex items-center gap-1.5">
                <ClipboardList className="w-3.5 h-3.5" />
                Last Review Date
              </Label>
              <Input
                type="date"
                className="mt-1 h-9"
                value={form.last_review_date}
                onChange={e => setForm(f => ({ ...f, last_review_date: e.target.value }))}
              />
            </div>
          </div>

          {/* Call Notes */}
          <div>
            <Label className="text-xs text-slate-600 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-slate-500" />
              Call Notes / Outcomes
            </Label>
            <Textarea
              className="mt-1 min-h-[80px] text-sm"
              placeholder="Notes from the last review call..."
              value={form.call_notes}
              onChange={e => setForm(f => ({ ...f, call_notes: e.target.value }))}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            className="bg-emerald-600 hover:bg-emerald-700 gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}