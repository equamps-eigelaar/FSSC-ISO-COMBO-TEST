import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  CheckCircle2, AlertTriangle, XCircle, Mail, Phone,
  Calendar, ClipboardList, TrendingUp, Clock
} from "lucide-react";
import { format } from "date-fns";

const HEALTH_CONFIG = {
  green: {
    label: "On Track",
    icon: CheckCircle2,
    border: "border-l-emerald-500",
    bg: "bg-emerald-50",
    badge: "bg-emerald-100 text-emerald-800",
    iconColor: "text-emerald-600",
    dot: "bg-emerald-500",
  },
  amber: {
    label: "Needs Attention",
    icon: AlertTriangle,
    border: "border-l-amber-500",
    bg: "bg-amber-50",
    badge: "bg-amber-100 text-amber-800",
    iconColor: "text-amber-600",
    dot: "bg-amber-500",
  },
  red: {
    label: "Critical Issues",
    icon: XCircle,
    border: "border-l-rose-500",
    bg: "bg-rose-50",
    badge: "bg-rose-100 text-rose-800",
    iconColor: "text-rose-600",
    dot: "bg-rose-500",
  },
};

export default function ClientHealthCard({ org, onSendEmail, onViewActions, onUpdateStatus }) {
  const status = org.health_status || "amber";
  const cfg = HEALTH_CONFIG[status];
  const Icon = cfg.icon;

  return (
    <Card className={`border-0 shadow-sm border-l-4 ${cfg.border} hover:shadow-md transition-shadow`}>
      <CardContent className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className={`w-10 h-10 rounded-lg ${cfg.bg} flex items-center justify-center flex-shrink-0`}>
              <Icon className={`w-5 h-5 ${cfg.iconColor}`} />
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-slate-900 truncate">{org.name}</h3>
              <p className="text-xs text-slate-500 truncate">
                {org.organization_id && <span className="font-mono text-slate-400">{org.organization_id} · </span>}
                {org.contact_name || org.owner_email}
                {org.industry && ` · ${org.industry}`}
              </p>
            </div>
          </div>
          <Badge className={`${cfg.badge} flex items-center gap-1 flex-shrink-0 text-xs`}>
            <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
            {cfg.label}
          </Badge>
        </div>

        {/* Score + Stats */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="text-center p-2 rounded-lg bg-slate-50">
            <div className="text-lg font-bold text-slate-800">
              {org.compliance_score != null ? `${org.compliance_score}%` : "—"}
            </div>
            <div className="text-[10px] text-slate-500">Compliance</div>
          </div>
          <div className="text-center p-2 rounded-lg bg-slate-50">
            <div className={`text-lg font-bold ${(org.open_actions_count || 0) > 0 ? "text-amber-600" : "text-slate-800"}`}>
              {org.open_actions_count || 0}
            </div>
            <div className="text-[10px] text-slate-500">Open Actions</div>
          </div>
          <div className="text-center p-2 rounded-lg bg-slate-50">
            <div className={`text-lg font-bold ${(org.critical_issues_count || 0) > 0 ? "text-rose-600" : "text-slate-800"}`}>
              {org.critical_issues_count || 0}
            </div>
            <div className="text-[10px] text-slate-500">Critical</div>
          </div>
        </div>

        {/* Dates */}
        <div className="flex items-center gap-3 text-xs text-slate-500 mb-4">
          {org.last_review_date && (
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Reviewed {format(new Date(org.last_review_date), "dd MMM")}
            </span>
          )}
          {org.call_scheduled_date && (
            <span className="flex items-center gap-1 text-blue-600">
              <Calendar className="w-3 h-3" />
              Call {format(new Date(org.call_scheduled_date), "dd MMM")}
            </span>
          )}
          {org.last_monthly_email_sent && (
            <span className="flex items-center gap-1">
              <Mail className="w-3 h-3" />
              Email {format(new Date(org.last_monthly_email_sent), "dd MMM")}
            </span>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          {status === "green" || status === "amber" ? (
            <Button
              size="sm"
              variant="outline"
              className="flex-1 h-8 text-xs gap-1.5 text-emerald-700 border-emerald-200 hover:bg-emerald-50"
              onClick={() => onSendEmail(org)}
            >
              <Mail className="w-3.5 h-3.5" />
              Send Summary
            </Button>
          ) : null}

          {status === "red" || status === "amber" ? (
            <Button
              size="sm"
              className={`flex-1 h-8 text-xs gap-1.5 ${status === "red" ? "bg-rose-600 hover:bg-rose-700" : "bg-amber-500 hover:bg-amber-600"}`}
              onClick={() => onViewActions(org)}
            >
              <ClipboardList className="w-3.5 h-3.5" />
              {status === "red" ? "Review Actions" : "View Issues"}
            </Button>
          ) : null}

          {status === "green" && (
            <Button
              size="sm"
              className="flex-1 h-8 text-xs gap-1.5 bg-emerald-600 hover:bg-emerald-700"
              onClick={() => onViewActions(org)}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              Details
            </Button>
          )}
        </div>

        {/* Status toggle */}
        <div className="mt-2 flex items-center gap-1">
          {["green", "amber", "red"].map(s => (
            <button
              key={s}
              onClick={() => onUpdateStatus(org, s)}
              className={`flex-1 h-1.5 rounded-full transition-opacity ${
                s === "green" ? "bg-emerald-500" : s === "amber" ? "bg-amber-500" : "bg-rose-500"
              } ${status === s ? "opacity-100" : "opacity-20 hover:opacity-50"}`}
              title={`Set to ${s}`}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}