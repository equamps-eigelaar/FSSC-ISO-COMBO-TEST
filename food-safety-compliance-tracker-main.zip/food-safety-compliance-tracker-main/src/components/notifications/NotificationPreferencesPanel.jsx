import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function NotificationPreferencesPanel() {
  const [user, setUser] = useState(null);
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadPreferences = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);

        const prefs = await base44.entities.NotificationPreference.filter({
          user_email: currentUser.email,
        });

        if (prefs.length > 0) {
          setPreferences(prefs[0]);
        } else {
          setPreferences({
            user_email: currentUser.email,
            requirement_status_changes: true,
            high_priority_risks: true,
            expiring_documents: true,
            assignments: true,
            comments: true,
            documents_pending_review: true,
            overdue_cleaning_tasks: true,
            low_compliance_scores: true,
            reports_ready: true,
            email_digest_frequency: "daily",
            email_digest_time: "09:00",
            notification_sound: true,
          });
        }
      } catch (error) {
        console.error("Error loading preferences:", error);
        toast.error("Failed to load notification preferences");
      } finally {
        setLoading(false);
      }
    };

    loadPreferences();
  }, []);

  const handleToggle = (field) => {
    setPreferences((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  };

  const handleSelectChange = (field, value) => {
    setPreferences((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (preferences.id) {
        await base44.entities.NotificationPreference.update(preferences.id, preferences);
      } else {
        await base44.entities.NotificationPreference.create(preferences);
      }
      toast.success("Notification preferences saved");
    } catch (error) {
      console.error("Error saving preferences:", error);
      toast.error("Failed to save preferences");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8 text-slate-500">Loading preferences...</div>;
  }

  if (!preferences) {
    return null;
  }

  return (
    <div className="space-y-6">
      {/* In-App Notifications */}
      <Card>
        <CardHeader>
          <CardTitle>In-App Notifications</CardTitle>
          <CardDescription>Choose what notifications you want to receive</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2">
              <Label htmlFor="assignments" className="cursor-pointer">
                New Assignments
              </Label>
              <Switch
                id="assignments"
                checked={preferences.assignments}
                onCheckedChange={() => handleToggle("assignments")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="status_changes" className="cursor-pointer">
                Requirement Status Changes
              </Label>
              <Switch
                id="status_changes"
                checked={preferences.requirement_status_changes}
                onCheckedChange={() => handleToggle("requirement_status_changes")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="comments" className="cursor-pointer">
                Comments & Mentions
              </Label>
              <Switch
                id="comments"
                checked={preferences.comments}
                onCheckedChange={() => handleToggle("comments")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="high_priority_risks" className="cursor-pointer">
                High/Critical Risk Assessments
              </Label>
              <Switch
                id="high_priority_risks"
                checked={preferences.high_priority_risks}
                onCheckedChange={() => handleToggle("high_priority_risks")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="expiring_documents" className="cursor-pointer">
                Expiring Documents
              </Label>
              <Switch
                id="expiring_documents"
                checked={preferences.expiring_documents}
                onCheckedChange={() => handleToggle("expiring_documents")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="documents_pending_review" className="cursor-pointer">
                Documents Pending Review
              </Label>
              <Switch
                id="documents_pending_review"
                checked={preferences.documents_pending_review}
                onCheckedChange={() => handleToggle("documents_pending_review")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="overdue_cleaning_tasks" className="cursor-pointer">
                Overdue Cleaning Tasks
              </Label>
              <Switch
                id="overdue_cleaning_tasks"
                checked={preferences.overdue_cleaning_tasks}
                onCheckedChange={() => handleToggle("overdue_cleaning_tasks")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="low_compliance_scores" className="cursor-pointer">
                Low Compliance Scores
              </Label>
              <Switch
                id="low_compliance_scores"
                checked={preferences.low_compliance_scores}
                onCheckedChange={() => handleToggle("low_compliance_scores")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="reports_ready" className="cursor-pointer">
                Reports Ready
              </Label>
              <Switch
                id="reports_ready"
                checked={preferences.reports_ready}
                onCheckedChange={() => handleToggle("reports_ready")}
              />
            </div>

            <div className="flex items-center justify-between py-2">
              <Label htmlFor="notification_sound" className="cursor-pointer">
                Notification Sounds
              </Label>
              <Switch
                id="notification_sound"
                checked={preferences.notification_sound}
                onCheckedChange={() => handleToggle("notification_sound")}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Email Digest Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Email Digest</CardTitle>
          <CardDescription>Receive a summary of your notifications by email</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="digest_frequency" className="mb-2 block">
              Frequency
            </Label>
            <Select
              value={preferences.email_digest_frequency}
              onValueChange={(value) => handleSelectChange("email_digest_frequency", value)}
            >
              <SelectTrigger id="digest_frequency">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Disabled</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {preferences.email_digest_frequency !== "none" && (
            <div>
              <Label htmlFor="digest_time" className="mb-2 block">
                Digest Time (24-hour format)
              </Label>
              <input
                id="digest_time"
                type="time"
                value={preferences.email_digest_time}
                onChange={(e) => handleSelectChange("email_digest_time", e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-md text-sm"
              />
              <p className="text-xs text-slate-500 mt-1">
                {preferences.email_digest_frequency === "daily"
                  ? "Digest will be sent daily at this time"
                  : "Digest will be sent every Monday at this time"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end gap-2">
        <Button variant="outline">Cancel</Button>
        <Button
          className="bg-emerald-600 hover:bg-emerald-700"
          onClick={handleSave}
          disabled={saving}
        >
          {saving ? "Saving..." : "Save Preferences"}
        </Button>
      </div>

      {/* Info */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 flex gap-3">
        <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
        <div className="text-sm text-blue-900 dark:text-blue-300">
          <p className="font-medium mb-1">Email notifications</p>
          <p>Check your spam folder if you don't see digest emails. Email notifications are sent to {user?.email}</p>
        </div>
      </div>
    </div>
  );
}