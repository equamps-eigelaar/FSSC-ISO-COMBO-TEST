import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Bell, Mail, AlertTriangle, FileText, MessageSquare, User } from "lucide-react";
import { toast } from "sonner";

export default function NotificationSettings({ open, onClose, user }) {
  const queryClient = useQueryClient();

  const { data: preferences, isLoading } = useQuery({
    queryKey: ["notification-preferences", user?.email],
    queryFn: async () => {
      const prefs = await base44.entities.NotificationPreference.filter({
        user_email: user.email
      });
      return prefs[0] || null;
    },
    enabled: !!user?.email,
  });

  const [settings, setSettings] = useState({});

  React.useEffect(() => {
    if (preferences) {
      setSettings(preferences);
    } else if (user) {
      setSettings({
        user_email: user.email,
        requirement_status_changes: true,
        high_priority_risks: true,
        expiring_documents: true,
        assignments: true,
        comments: true,
        email_digest_frequency: "daily",
        email_digest_time: "09:00"
      });
    }
  }, [preferences, user]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (preferences?.id) {
        return base44.entities.NotificationPreference.update(preferences.id, data);
      } else {
        return base44.entities.NotificationPreference.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notification-preferences"] });
      toast.success("Notification preferences saved");
      onClose();
    },
  });

  const handleSave = () => {
    const { id, created_date, updated_date, created_by, ...data } = settings;
    saveMutation.mutate(data);
  };

  if (isLoading) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-emerald-600" />
            Notification Preferences
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* In-App Notifications */}
          <div>
            <h3 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Bell className="w-4 h-4" />
              In-App Notifications
            </h3>
            <Card className="border-slate-200">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-slate-400" />
                    <div>
                      <Label className="text-sm font-medium">Requirement Status Changes</Label>
                      <p className="text-xs text-slate-500">Get notified when compliance requirements change status</p>
                    </div>
                  </div>
                  <Switch
                    checked={settings.requirement_status_changes}
                    onCheckedChange={(checked) => 
                      setSettings({ ...settings, requirement_status_changes: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="w-4 h-4 text-slate-400" />
                    <div>
                      <Label className="text-sm font-medium">High Priority Risk Assessments</Label>
                      <p className="text-xs text-slate-500">Get notified about high/critical risk assessments</p>
                    </div>
                  </div>
                  <Switch
                    checked={settings.high_priority_risks}
                    onCheckedChange={(checked) => 
                      setSettings({ ...settings, high_priority_risks: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-slate-400" />
                    <div>
                      <Label className="text-sm font-medium">Expiring Documents</Label>
                      <p className="text-xs text-slate-500">Get notified when documents are about to expire</p>
                    </div>
                  </div>
                  <Switch
                    checked={settings.expiring_documents}
                    onCheckedChange={(checked) => 
                      setSettings({ ...settings, expiring_documents: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <User className="w-4 h-4 text-slate-400" />
                    <div>
                      <Label className="text-sm font-medium">Assignments</Label>
                      <p className="text-xs text-slate-500">Get notified when assigned to requirements or risks</p>
                    </div>
                  </div>
                  <Switch
                    checked={settings.assignments}
                    onCheckedChange={(checked) => 
                      setSettings({ ...settings, assignments: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <MessageSquare className="w-4 h-4 text-slate-400" />
                    <div>
                      <Label className="text-sm font-medium">Comments & Mentions</Label>
                      <p className="text-xs text-slate-500">Get notified when someone mentions you in comments</p>
                    </div>
                  </div>
                  <Switch
                    checked={settings.comments}
                    onCheckedChange={(checked) => 
                      setSettings({ ...settings, comments: checked })
                    }
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Email Digest */}
          <div>
            <h3 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email Digest
            </h3>
            <Card className="border-slate-200">
              <CardContent className="p-4 space-y-4">
                <div>
                  <Label className="text-sm mb-2 block">Digest Frequency</Label>
                  <Select
                    value={settings.email_digest_frequency}
                    onValueChange={(value) => 
                      setSettings({ ...settings, email_digest_frequency: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Email Digest</SelectItem>
                      <SelectItem value="daily">Daily Digest</SelectItem>
                      <SelectItem value="weekly">Weekly Digest</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-slate-500 mt-1">
                    Receive a summary of unread notifications via email
                  </p>
                </div>

                {settings.email_digest_frequency !== "none" && (
                  <div>
                    <Label className="text-sm mb-2 block">Preferred Time</Label>
                    <Select
                      value={settings.email_digest_time}
                      onValueChange={(value) => 
                        setSettings({ ...settings, email_digest_time: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="06:00">6:00 AM</SelectItem>
                        <SelectItem value="09:00">9:00 AM</SelectItem>
                        <SelectItem value="12:00">12:00 PM</SelectItem>
                        <SelectItem value="17:00">5:00 PM</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={handleSave}
            disabled={saveMutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {saveMutation.isPending ? "Saving..." : "Save Preferences"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}