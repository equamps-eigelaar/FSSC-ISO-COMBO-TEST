import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertTriangle, Eye, Trash2 } from "lucide-react";
import { format } from "date-fns";

const REASON_COLORS = {
  harassment: "bg-red-100 text-red-800",
  spam: "bg-gray-100 text-gray-800",
  violence: "bg-rose-100 text-rose-800",
  nudity: "bg-purple-100 text-purple-800",
  misinformation: "bg-orange-100 text-orange-800",
  copyright: "bg-blue-100 text-blue-800",
  hate_speech: "bg-red-100 text-red-800",
  other: "bg-slate-100 text-slate-800",
};

const STATUS_COLORS = {
  pending: "bg-yellow-100 text-yellow-800",
  under_review: "bg-blue-100 text-blue-800",
  resolved: "bg-emerald-100 text-emerald-800",
  dismissed: "bg-slate-100 text-slate-800",
};

const PRIORITY_COLORS = {
  low: "text-slate-500",
  medium: "text-amber-500",
  high: "text-orange-600",
  critical: "text-rose-600",
};

export default function ReportList({ reports, onSelectReport, selectedReportId }) {
  return (
    <div className="space-y-3">
      {reports.length === 0 ? (
        <Card className="p-6 text-center">
          <AlertTriangle className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-slate-500 text-sm">No reports to display</p>
        </Card>
      ) : (
        reports.map((report) => (
          <Card
            key={report.id}
            className={`p-4 cursor-pointer transition-all ${
              selectedReportId === report.id
                ? "ring-2 ring-emerald-500 bg-emerald-50"
                : "hover:shadow-md"
            }`}
            onClick={() => onSelectReport(report.id)}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle
                    className={`w-4 h-4 ${PRIORITY_COLORS[report.priority]}`}
                  />
                  <span className="font-semibold text-sm text-slate-900 truncate">
                    {report.report_type === "user"
                      ? `User Report: ${report.reported_user_email}`
                      : `Content Report: ${report.reported_content_type}`}
                  </span>
                </div>

                <p className="text-xs text-slate-600 mb-2 line-clamp-2">
                  {report.description}
                </p>

                <div className="flex flex-wrap gap-2 items-center">
                  <Badge
                    className={`text-xs ${REASON_COLORS[report.reason]}`}
                    variant="secondary"
                  >
                    {report.reason.replace(/_/g, " ")}
                  </Badge>
                  <Badge
                    className={`text-xs ${STATUS_COLORS[report.status]}`}
                    variant="secondary"
                  >
                    {report.status.replace(/_/g, " ")}
                  </Badge>
                  <span className="text-xs text-slate-500">
                    {format(new Date(report.created_date), "MMM d, HH:mm")}
                  </span>
                </div>
              </div>

              <Button variant="ghost" size="icon" className="flex-shrink-0">
                <Eye className="w-4 h-4 text-slate-400" />
              </Button>
            </div>
          </Card>
        ))
      )}
    </div>
  );
}