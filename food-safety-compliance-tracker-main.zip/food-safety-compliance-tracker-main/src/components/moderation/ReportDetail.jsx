import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, Trash2, Ban, Clock, X } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import ModerationActionDialog from "./ModerationActionDialog";

const REASON_COLORS = {
  harassment: "bg-red-100 text-red-800",
  spam: "bg-gray-100 text-gray-800",
  violence: "bg-rose-100 text-rose-800",
  nudity: "bg-purple-100 text-purple-800",
  misinformation: "bg-orange-100 text-orange-800",
  copyright: "bg-blue-100 text-blue-800",
  hate_speech: "bg-red-100 text-red-800",
  other: "bg-slate-100 text-slate-800",
};

export default function ReportDetail({ report, onClose, onActionTaken }) {
  const [notes, setNotes] = useState(report?.moderation_notes || "");
  const [status, setStatus] = useState(report?.status || "pending");
  const [showActionDialog, setShowActionDialog] = useState(false);
  const [selectedAction, setSelectedAction] = useState(null);
  const [saving, setSaving] = useState(false);

  if (!report) {
    return (
      <Card className="p-6">
        <p className="text-center text-slate-500">Select a report to view details</p>
      </Card>
    );
  }

  const handleSaveNotes = async () => {
    setSaving(true);
    try {
      await base44.entities.UserReport.update(report.id, {
        moderation_notes: notes,
        status,
      });
      toast.success("Report updated");
    } catch (error) {
      toast.error("Failed to update report");
    } finally {
      setSaving(false);
    }
  };

  const handleAction = (action) => {
    setSelectedAction(action);
    setShowActionDialog(true);
  };

  return (
    <div className="space-y-4">
      <Card className="border-l-4 border-l-rose-500">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between mb-4">
            <div>
              <CardTitle className="text-lg">Report #{report.id.substring(0, 8)}</CardTitle>
              <p className="text-xs text-slate-500 mt-1">
                Filed {format(new Date(report.created_date), "PPpp")}
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-slate-400"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge className={`${REASON_COLORS[report.reason]}`}>
              {report.reason.replace(/_/g, " ")}
            </Badge>
            <Badge variant="outline">{report.report_type}</Badge>
            <Badge variant="secondary">{report.priority} priority</Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-slate-500 font-semibold mb-1">Reported By</p>
              <p className="text-sm text-slate-900">{report.reporter_email}</p>
            </div>
            {report.reported_user_email && (
              <div>
                <p className="text-xs text-slate-500 font-semibold mb-1">Reported User</p>
                <p className="text-sm text-slate-900">{report.reported_user_email}</p>
              </div>
            )}
          </div>

          <div>
            <p className="text-xs text-slate-500 font-semibold mb-2">Description</p>
            <p className="text-sm text-slate-700 bg-slate-50 p-3 rounded">
              {report.description}
            </p>
          </div>

          {report.screenshot_urls?.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 font-semibold mb-2">Evidence</p>
              <div className="flex flex-wrap gap-2">
                {report.screenshot_urls.map((url, idx) => (
                  <a
                    key={idx}
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-emerald-600 hover:underline"
                  >
                    Screenshot {idx + 1}
                  </a>
                ))}
              </div>
            </div>
          )}

          <div>
            <p className="text-xs text-slate-500 font-semibold mb-2">Status</p>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="under_review">Under Review</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="dismissed">Dismissed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <p className="text-xs text-slate-500 font-semibold mb-2">Moderation Notes</p>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add internal notes..."
              rows={4}
            />
          </div>

          <Button
            onClick={handleSaveNotes}
            disabled={saving}
            className="w-full bg-slate-600 hover:bg-slate-700"
            size="sm"
          >
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <Card className="p-4">
        <p className="text-xs text-slate-500 font-semibold mb-3">Take Action</p>
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleAction("warning")}
            className="text-amber-600 border-amber-200 hover:bg-amber-50"
          >
            <AlertTriangle className="w-4 h-4 mr-1" />
            Warn User
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleAction("suspend")}
            className="text-orange-600 border-orange-200 hover:bg-orange-50"
          >
            <Clock className="w-4 h-4 mr-1" />
            Suspend
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleAction("ban")}
            className="text-rose-600 border-rose-200 hover:bg-rose-50"
          >
            <Ban className="w-4 h-4 mr-1" />
            Ban User
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleAction("content_removal")}
            className="text-slate-600 border-slate-200 hover:bg-slate-100"
          >
            <Trash2 className="w-4 h-4 mr-1" />
            Remove Content
          </Button>
        </div>
      </Card>

      <ModerationActionDialog
        open={showActionDialog}
        onClose={() => {
          setShowActionDialog(false);
          setSelectedAction(null);
        }}
        report={report}
        actionType={selectedAction}
        onActionCompleted={() => {
          setShowActionDialog(false);
          setSelectedAction(null);
          onActionTaken();
        }}
      />
    </div>
  );
}