import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const ACTION_CONFIGS = {
  warning: {
    title: "Warn User",
    description: "Send a formal warning to the user",
    icon: "⚠️",
  },
  suspend: {
    title: "Suspend User",
    description: "Temporarily suspend user account access",
    icon: "⏸️",
  },
  ban: {
    title: "Ban User",
    description: "Permanently ban user from platform",
    icon: "🚫",
  },
  content_removal: {
    title: "Remove Content",
    description: "Delete the reported content",
    icon: "🗑️",
  },
};

export default function ModerationActionDialog({
  open,
  onClose,
  report,
  actionType,
  onActionCompleted,
}) {
  const [reason, setReason] = useState("");
  const [durationDays, setDurationDays] = useState("7");
  const [notifyUser, setNotifyUser] = useState(true);
  const [loading, setLoading] = useState(false);

  const config = ACTION_CONFIGS[actionType] || {};

  const handleSubmit = async () => {
    if (!reason.trim()) {
      toast.error("Please provide a reason for this action");
      return;
    }

    setLoading(true);
    try {
      // Create moderation action record
      await base44.entities.ModerationAction.create({
        report_id: report.id,
        action_type: actionType,
        target_user_email: report.reported_user_email,
        duration_days: actionType === "suspend" ? parseInt(durationDays) : null,
        reason,
        moderator_email: (await base44.auth.me()).email,
        content_removed: actionType === "content_removal",
        public_notification: notifyUser,
      });

      // Update report status
      await base44.entities.UserReport.update(report.id, {
        status: "resolved",
      });

      toast.success(`User ${actionType === "ban" ? "banned" : actionType === "suspend" ? "suspended" : actionType === "content_removal" ? "content removed" : "warned"}`);
      onActionCompleted();
    } catch (error) {
      toast.error("Failed to execute action: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span>{config.icon}</span>
            {config.title}
          </DialogTitle>
          <DialogDescription>{config.description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Duration for suspension */}
          {actionType === "suspend" && (
            <div>
              <Label className="text-xs text-slate-500">Suspension Duration</Label>
              <Select value={durationDays} onValueChange={setDurationDays}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 day</SelectItem>
                  <SelectItem value="7">7 days</SelectItem>
                  <SelectItem value="30">30 days</SelectItem>
                  <SelectItem value="90">90 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Reason */}
          <div>
            <Label className="text-xs text-slate-500">Reason for Action</Label>
            <Textarea
              placeholder="Explain the reason for this action..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={4}
              className="mt-1"
            />
          </div>

          {/* Notify user */}
          <div className="flex items-center gap-2 p-3 bg-slate-50 rounded">
            <input
              type="checkbox"
              id="notify"
              checked={notifyUser}
              onChange={(e) => setNotifyUser(e.target.checked)}
              className="w-4 h-4 rounded"
            />
            <label htmlFor="notify" className="text-sm text-slate-700">
              Notify user of this action
            </label>
          </div>

          {/* Preview */}
          <div className="p-3 bg-slate-50 rounded border border-slate-200">
            <p className="text-xs text-slate-500 font-semibold mb-2">Action Summary</p>
            <ul className="text-xs text-slate-700 space-y-1">
              <li>
                <strong>User:</strong> {report.reported_user_email}
              </li>
              <li>
                <strong>Action:</strong> {config.title}
              </li>
              {actionType === "suspend" && (
                <li>
                  <strong>Duration:</strong> {durationDays} days
                </li>
              )}
              <li>
                <strong>Reason:</strong> {report.reason}
              </li>
            </ul>
          </div>
        </div>

        <div className="flex gap-2 justify-end">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={loading}
            className="bg-rose-600 hover:bg-rose-700"
          >
            {loading ? "Processing..." : "Confirm Action"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}