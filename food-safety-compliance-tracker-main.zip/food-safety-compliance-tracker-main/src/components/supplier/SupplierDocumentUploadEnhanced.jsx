import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Upload, FileText, Loader2, Sparkles, AlertTriangle, CheckCircle2, X, ChevronDown, ChevronUp } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const DOC_TYPES = [
  { value: "tds", label: "Technical Data Sheet (TDS)", category: "supplier_certificate", icon: "📋" },
  { value: "coa", label: "Certificate of Analysis (CoA)", category: "test_report", icon: "🧪" },
  { value: "allergen", label: "Allergen Statement", category: "compliance_evidence", icon: "⚠️" },
  { value: "haccp", label: "HACCP Summary", category: "risk_analysis", icon: "🛡️" },
];

const SEVERITY_STYLES = {
  critical: "bg-red-50 border-red-200 text-red-700",
  high: "bg-orange-50 border-orange-200 text-orange-700",
  medium: "bg-amber-50 border-amber-200 text-amber-700",
};

const SEVERITY_ICONS = {
  critical: "🔴",
  high: "🟠",
  medium: "🟡",
};

export default function SupplierDocumentUploadEnhanced({ user, onUploaded }) {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState(null);
  const [docTypeKey, setDocTypeKey] = useState("tds");
  const [description, setDescription] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [uploading, setUploading] = useState(false);
  const [analysing, setAnalysing] = useState(false);
  const [result, setResult] = useState(null); // { extracted, flags, document_id }
  const [showExtracted, setShowExtracted] = useState(false);

  const handleUploadAndAnalyse = async (e) => {
    e.preventDefault();
    if (!file) { toast.error("Please select a file"); return; }
    setUploading(true);
    setResult(null);

    try {
      // 1. Upload file
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      const docTypeMeta = DOC_TYPES.find(d => d.value === docTypeKey);

      // 2. Save document record
      const docRecord = await base44.entities.Document.create({
        file_name: file.name,
        file_url,
        file_size: file.size,
        file_type: file.type,
        category: docTypeMeta?.category || "other",
        description,
        expiry_date: expiryDate || undefined,
        uploaded_by: user?.email,
        organization_id: user?.organization_id || null,
        control_status: "uncontrolled",
        tags: [docTypeKey],
      });

      setUploading(false);
      setAnalysing(true);

      // 3. AI extract + validate
      const response = await base44.functions.invoke("extractSupplierDocument", {
        document_id: docRecord.id,
        file_url,
        doc_type: docTypeKey,
      });

      const { extracted, flags } = response.data;
      setResult({ extracted, flags, document_id: docRecord.id, file_name: file.name });

      const criticalCount = flags.filter(f => f.severity === "critical").length;
      const highCount = flags.filter(f => f.severity === "high").length;

      if (criticalCount > 0) {
        toast.error(`Analysis found ${criticalCount} critical issue(s) — review required`);
      } else if (highCount > 0) {
        toast.warning(`Analysis found ${highCount} issue(s) requiring attention`);
      } else {
        toast.success("Document uploaded and verified successfully");
      }

      onUploaded?.();
    } catch (err) {
      toast.error("Upload or analysis failed: " + err.message);
    } finally {
      setUploading(false);
      setAnalysing(false);
    }
  };

  const handleReset = () => {
    setOpen(false);
    setFile(null);
    setDescription("");
    setExpiryDate("");
    setResult(null);
    setShowExtracted(false);
    setDocTypeKey("tds");
  };

  if (!open) {
    return (
      <Card
        className="border-2 border-dashed border-emerald-200 bg-emerald-50/50 shadow-none cursor-pointer hover:border-emerald-400 transition-colors"
        onClick={() => setOpen(true)}
      >
        <CardContent className="p-6 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0">
            <Upload className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="flex-1">
            <p className="font-semibold text-emerald-800 text-sm">Upload Supplier Document</p>
            <p className="text-xs text-emerald-600 mt-0.5">TDS, CoA, Allergen Statements, HACCP Summaries — AI-verified automatically</p>
          </div>
          <Badge className="bg-emerald-100 text-emerald-700 gap-1">
            <Sparkles className="w-3 h-3" /> AI Verified
          </Badge>
        </CardContent>
      </Card>
    );
  }

  // Show analysis result
  if (result) {
    const { flags, extracted, file_name } = result;
    const criticalFlags = flags.filter(f => f.severity === "critical");
    const highFlags = flags.filter(f => f.severity === "high");
    const mediumFlags = flags.filter(f => f.severity === "medium");
    const allClear = flags.length === 0;

    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="py-4 px-5 border-b border-slate-100">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              AI Analysis Result
            </CardTitle>
            <Button size="sm" variant="ghost" onClick={handleReset}><X className="w-4 h-4" /></Button>
          </div>
        </CardHeader>
        <CardContent className="p-5 space-y-4">
          {/* Summary */}
          <div className={`rounded-lg p-4 border flex items-start gap-3 ${allClear ? "bg-emerald-50 border-emerald-200" : criticalFlags.length > 0 ? "bg-red-50 border-red-200" : "bg-amber-50 border-amber-200"}`}>
            {allClear
              ? <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              : <AlertTriangle className={`w-5 h-5 shrink-0 mt-0.5 ${criticalFlags.length > 0 ? "text-red-600" : "text-amber-600"}`} />
            }
            <div>
              <p className={`text-sm font-semibold ${allClear ? "text-emerald-800" : criticalFlags.length > 0 ? "text-red-800" : "text-amber-800"}`}>
                {allClear ? "Document Verified — No Issues Found" : `${flags.length} Issue(s) Detected`}
              </p>
              <p className={`text-xs mt-0.5 ${allClear ? "text-emerald-600" : "text-slate-600"}`}>
                {file_name} · {DOC_TYPES.find(d => d.value === docTypeKey)?.label}
              </p>
            </div>
          </div>

          {/* Flags */}
          {flags.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Issues Found</p>
              {[...criticalFlags, ...highFlags, ...mediumFlags].map((flag, i) => (
                <div key={i} className={`rounded-md border px-3 py-2.5 text-xs flex items-start gap-2 ${SEVERITY_STYLES[flag.severity]}`}>
                  <span className="shrink-0 mt-0.5">{SEVERITY_ICONS[flag.severity]}</span>
                  <div>
                    <span className="font-semibold uppercase text-[10px] tracking-wide">{flag.type.replace(/_/g, " ")} · </span>
                    {flag.message}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Extracted Fields Toggle */}
          <button
            type="button"
            onClick={() => setShowExtracted(v => !v)}
            className="w-full flex items-center justify-between text-xs font-medium text-slate-600 hover:text-slate-800 px-3 py-2 bg-slate-50 rounded-lg border border-slate-200"
          >
            <span>View Extracted Data</span>
            {showExtracted ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {showExtracted && (
            <div className="bg-slate-50 rounded-lg border border-slate-200 p-4 space-y-2">
              {Object.entries(extracted).filter(([, v]) => v !== null && v !== undefined && v !== "").map(([key, value]) => (
                <div key={key} className="flex gap-2 text-xs">
                  <span className="text-slate-500 font-medium min-w-[140px] shrink-0">{key.replace(/_/g, ' ')}</span>
                  <span className="text-slate-800">
                    {Array.isArray(value)
                      ? typeof value[0] === "object"
                        ? `${value.length} item(s)`
                        : value.join(", ")
                      : String(value)}
                  </span>
                </div>
              ))}
            </div>
          )}

          <Button onClick={handleReset} className="w-full bg-emerald-600 hover:bg-emerald-700">
            Upload Another Document
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="py-4 px-5 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Upload className="w-4 h-4 text-emerald-600" />
            Upload & Analyse Document
          </CardTitle>
          <Button size="sm" variant="ghost" onClick={handleReset}><X className="w-4 h-4" /></Button>
        </div>
      </CardHeader>
      <CardContent className="p-5">
        <form onSubmit={handleUploadAndAnalyse} className="space-y-4">
          <div>
            <Label>Document Type *</Label>
            <Select value={docTypeKey} onValueChange={setDocTypeKey}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DOC_TYPES.map(t => (
                  <SelectItem key={t.value} value={t.value}>
                    {t.icon} {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Description (optional)</Label>
              <Input placeholder="Product name or notes" value={description} onChange={e => setDescription(e.target.value)} />
            </div>
            <div>
              <Label>Expiry Date (optional)</Label>
              <Input type="date" value={expiryDate} onChange={e => setExpiryDate(e.target.value)} />
            </div>
          </div>

          <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-slate-200 rounded-lg p-6 cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors">
            {file ? (
              <>
                <FileText className="w-6 h-6 text-emerald-600" />
                <span className="text-sm text-emerald-700 font-medium">{file.name}</span>
                <span className="text-xs text-slate-400">{(file.size / 1024).toFixed(1)} KB — click to change</span>
              </>
            ) : (
              <>
                <Upload className="w-6 h-6 text-slate-400" />
                <span className="text-sm text-slate-500">Click to select file</span>
                <span className="text-xs text-slate-400">PDF, DOCX, XLSX, JPG, PNG</span>
              </>
            )}
            <input type="file" className="hidden" accept=".pdf,.docx,.doc,.xlsx,.xls,.jpg,.jpeg,.png" onChange={e => setFile(e.target.files[0])} />
          </label>

          {/* AI notice */}
          <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 rounded-lg px-3 py-2 border border-slate-200">
            <Sparkles className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            AI will automatically extract key fields and flag missing, expired, or inconsistent data.
          </div>

          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={handleReset} className="flex-1">Cancel</Button>
            <Button type="submit" disabled={uploading || analysing} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              {uploading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Uploading…</>
              ) : analysing ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analysing…</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" />Upload & Analyse</>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}