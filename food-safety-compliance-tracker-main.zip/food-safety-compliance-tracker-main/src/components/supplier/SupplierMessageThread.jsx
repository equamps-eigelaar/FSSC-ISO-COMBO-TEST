import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Send, Loader2, Paperclip } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function SupplierMessageThread({ user, messages = [], supplierEmail, isInternal = false, onSent }) {
  const [text, setText] = useState("");
  const [subject, setSubject] = useState("");
  const [sending, setSending] = useState(false);
  const [attachFile, setAttachFile] = useState(null);
  const bottomRef = useRef();

  // Determine the supplier email: if internal, use supplierEmail prop; if supplier, use user.email
  const resolvedSupplierEmail = isInternal ? supplierEmail : user?.email;

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!text.trim()) return;
    setSending(true);
    try {
      let attachment_url, attachment_name;
      if (attachFile) {
        const res = await base44.integrations.Core.UploadFile({ file: attachFile });
        attachment_url = res.file_url;
        attachment_name = attachFile.name;
      }
      await base44.entities.SupplierMessage.create({
        supplier_email: resolvedSupplierEmail,
        sender_email: user?.email,
        sender_name: user?.full_name || user?.email,
        direction: isInternal ? "internal_to_supplier" : "supplier_to_internal",
        message: text,
        subject: subject || undefined,
        is_read: false,
        attachment_url,
        attachment_name,
      });
      setText("");
      setSubject("");
      setAttachFile(null);
      onSent?.();
      toast.success("Message sent");
    } catch (err) {
      toast.error("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  const sorted = [...messages].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

  return (
    <div className="flex flex-col gap-3">
      {/* Thread */}
      <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
        {sorted.length === 0 ? (
          <div className="text-center py-8 text-sm text-slate-400">No messages yet. Start the conversation below.</div>
        ) : sorted.map(msg => {
          const isFromMe = msg.sender_email === user?.email;
          return (
            <div key={msg.id} className={`flex ${isFromMe ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm ${isFromMe ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-800"}`}>
                {!isFromMe && <p className="text-xs font-semibold mb-1 opacity-70">{msg.sender_name || msg.sender_email}</p>}
                {msg.subject && <p className="text-xs font-semibold mb-1 opacity-80">Re: {msg.subject}</p>}
                <p className="leading-relaxed">{msg.message}</p>
                {msg.attachment_url && (
                  <a href={msg.attachment_url} target="_blank" rel="noopener noreferrer"
                    className={`flex items-center gap-1 mt-1 text-xs underline ${isFromMe ? "text-emerald-100" : "text-emerald-600"}`}>
                    <Paperclip className="w-3 h-3" /> {msg.attachment_name || "Attachment"}
                  </a>
                )}
                <p className={`text-[10px] mt-1 ${isFromMe ? "text-emerald-200" : "text-slate-400"}`}>
                  {new Date(msg.created_date).toLocaleString('en-ZA', { dateStyle: 'short', timeStyle: 'short' })}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Compose */}
      <Card className="border border-slate-200 shadow-none">
        <CardContent className="p-3 space-y-2">
          <Input
            placeholder="Subject (optional)"
            value={subject}
            onChange={e => setSubject(e.target.value)}
            className="text-sm h-8"
          />
          <Textarea
            placeholder="Type your message…"
            value={text}
            onChange={e => setText(e.target.value)}
            rows={3}
            className="resize-none text-sm"
            onKeyDown={e => { if (e.key === "Enter" && e.ctrlKey) handleSend(); }}
          />
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-1.5 cursor-pointer text-xs text-slate-500 hover:text-emerald-600">
              <Paperclip className="w-3.5 h-3.5" />
              {attachFile ? attachFile.name : "Attach file"}
              <input type="file" className="hidden" onChange={e => setAttachFile(e.target.files[0])} />
            </label>
            <Button size="sm" onClick={handleSend} disabled={sending || !text.trim()} className="bg-emerald-600 hover:bg-emerald-700 gap-1.5">
              {sending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              Send
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}