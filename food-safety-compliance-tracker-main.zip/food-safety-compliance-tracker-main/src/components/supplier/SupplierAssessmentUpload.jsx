import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, FileText, Loader2, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function SupplierAssessmentUpload({ user, onCreated }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [file, setFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file || !title || !customerName) { toast.error("Please fill all fields and select a file"); return; }
    setSubmitting(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const assessment = await base44.entities.SupplierSelfAssessment.create({
        title,
        customer_name: customerName,
        assigned_to: user?.email,
        questionnaire_file_url: file_url,
        questionnaire_file_name: file.name,
        status: "draft",
      });
      // Trigger AI analysis
      try {
        await base44.functions.invoke("analyzeSupplierQuestionnaire", { assessment_id: assessment.id });
      } catch (_) {}
      toast.success("Assessment submitted! AI is analysing your questionnaire.");
      setOpen(false);
      setTitle(""); setCustomerName(""); setFile(null);
      onCreated?.();
    } catch (err) {
      toast.error("Submission failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (!open) {
    return (
      <Card className="border-2 border-dashed border-emerald-200 bg-emerald-50/50 shadow-none cursor-pointer hover:border-emerald-400 transition-colors" onClick={() => setOpen(true)}>
        <CardContent className="p-6 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0">
            <Upload className="w-5 h-5 text-emerald-600" />
          </div>
          <div>
            <p className="font-medium text-emerald-800 text-sm">Submit a Self-Assessment Questionnaire</p>
            <p className="text-xs text-emerald-600 mt-0.5">Upload a customer questionnaire (PDF, DOCX, XLSX) for AI-assisted review</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="py-4 px-5 border-b border-slate-100">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-500" /> New Self-Assessment Submission
        </CardTitle>
      </CardHeader>
      <CardContent className="p-5">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label>Assessment Title *</Label>
              <Input placeholder="e.g. Annual Supplier Assessment 2026" value={title} onChange={e => setTitle(e.target.value)} required />
            </div>
            <div>
              <Label>Requesting Customer / Party *</Label>
              <Input placeholder="e.g. Woolworths, Nestlé" value={customerName} onChange={e => setCustomerName(e.target.value)} required />
            </div>
          </div>
          <div>
            <Label>Questionnaire File * (PDF, DOCX, XLSX)</Label>
            <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-slate-200 rounded-lg p-6 cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors mt-1">
              {file ? (
                <>
                  <FileText className="w-6 h-6 text-emerald-600" />
                  <span className="text-sm text-emerald-700 font-medium">{file.name}</span>
                  <span className="text-xs text-slate-400">{(file.size / 1024).toFixed(1)} KB — click to change</span>
                </>
              ) : (
                <>
                  <Upload className="w-6 h-6 text-slate-400" />
                  <span className="text-sm text-slate-500">Click to upload questionnaire</span>
                </>
              )}
              <input type="file" className="hidden" accept=".pdf,.docx,.doc,.xlsx,.xls" onChange={e => setFile(e.target.files[0])} />
            </label>
          </div>
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="flex-1">Cancel</Button>
            <Button type="submit" disabled={submitting} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Submitting…</> : "Submit Assessment"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}