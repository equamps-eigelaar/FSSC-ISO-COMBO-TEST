import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, AlertTriangle, CheckCircle2, ChevronDown, ChevronUp, ExternalLink, Clock, XCircle } from "lucide-react";

const DOC_TYPE_LABELS = {
  tds: "TDS",
  coa: "CoA",
  allergen: "Allergen",
  haccp: "HACCP",
};

const STATUS_CONFIG = {
  compliant: { label: "Verified", icon: CheckCircle2, cls: "bg-emerald-100 text-emerald-700" },
  requires_review: { label: "Needs Review", icon: AlertTriangle, cls: "bg-amber-100 text-amber-700" },
  non_compliant: { label: "Non-Compliant", icon: XCircle, cls: "bg-red-100 text-red-700" },
  insufficient_data: { label: "Pending", icon: Clock, cls: "bg-slate-100 text-slate-600" },
};

const SEVERITY_DOT = {
  critical: "bg-red-500",
  high: "bg-orange-400",
  medium: "bg-amber-400",
};

function DocumentCard({ doc }) {
  const [expanded, setExpanded] = useState(false);
  const analysis = doc.ai_analysis || {};
  const status = STATUS_CONFIG[analysis.compliance_status] || STATUS_CONFIG.insufficient_data;
  const StatusIcon = status.icon;
  const issues = analysis.issues_found || [];
  const extracted = analysis.extracted_data || {};
  const docTypeTag = doc.tags?.[0];
  const typeLabel = DOC_TYPE_LABELS[docTypeTag] || doc.category?.replace(/_/g, ' ') || "Document";

  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${analysis.analyzed ? "bg-emerald-50" : "bg-slate-100"}`}>
            <FileText className={`w-4 h-4 ${analysis.analyzed ? "text-emerald-600" : "text-slate-400"}`} />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 flex-wrap">
              <div className="min-w-0">
                <p className="text-sm font-medium text-slate-800 truncate">{doc.file_name}</p>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0">{typeLabel}</Badge>
                  {analysis.confidence_score != null && (
                    <span className="text-[10px] text-slate-400">{analysis.confidence_score}% confidence</span>
                  )}
                  {doc.expiry_date && (
                    <span className="text-[10px] text-slate-400">Expires {doc.expiry_date}</span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Badge className={`text-xs gap-1 ${status.cls}`}>
                  <StatusIcon className="w-3 h-3" />
                  {status.label}
                </Badge>
                <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                  <Button size="sm" variant="ghost" className="h-7 px-2"><ExternalLink className="w-3.5 h-3.5" /></Button>
                </a>
              </div>
            </div>

            {/* Issues summary dots */}
            {issues.length > 0 && (
              <div className="flex items-center gap-1.5 mt-2">
                {issues.map((issue, i) => (
                  <div key={i} className={`w-2 h-2 rounded-full ${SEVERITY_DOT[issue.severity] || "bg-slate-300"}`} title={issue.message} />
                ))}
                <span className="text-xs text-slate-500 ml-1">{issues.length} issue{issues.length !== 1 ? "s" : ""}</span>
              </div>
            )}

            {/* Expand/Collapse */}
            {(issues.length > 0 || Object.keys(extracted).length > 0) && (
              <button
                className="mt-2 text-xs text-emerald-600 hover:text-emerald-800 flex items-center gap-1"
                onClick={() => setExpanded(v => !v)}
              >
                {expanded ? <><ChevronUp className="w-3 h-3" />Hide details</> : <><ChevronDown className="w-3 h-3" />View details</>}
              </button>
            )}

            {expanded && (
              <div className="mt-3 space-y-3">
                {/* Flags */}
                {issues.length > 0 && (
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Issues</p>
                    {issues.map((issue, i) => (
                      <div key={i} className={`text-xs rounded px-2.5 py-1.5 border flex items-start gap-2 ${
                        issue.severity === "critical" ? "bg-red-50 border-red-200 text-red-700" :
                        issue.severity === "high" ? "bg-orange-50 border-orange-200 text-orange-700" :
                        "bg-amber-50 border-amber-200 text-amber-700"
                      }`}>
                        <span className="shrink-0 mt-0.5">
                          {issue.severity === "critical" ? "🔴" : issue.severity === "high" ? "🟠" : "🟡"}
                        </span>
                        {issue.message}
                      </div>
                    ))}
                  </div>
                )}

                {/* Key extracted fields */}
                {Object.keys(extracted).length > 0 && (
                  <div>
                    <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-1.5">Extracted Fields</p>
                    <div className="bg-slate-50 rounded-lg border border-slate-200 p-3 space-y-1.5">
                      {Object.entries(extracted)
                        .filter(([, v]) => v !== null && v !== undefined && v !== "" && !(Array.isArray(v) && v.length === 0))
                        .slice(0, 8)
                        .map(([key, value]) => (
                          <div key={key} className="flex gap-2 text-xs">
                            <span className="text-slate-500 font-medium min-w-[130px] shrink-0 capitalize">{key.replace(/_/g, ' ')}</span>
                            <span className="text-slate-800 truncate">
                              {Array.isArray(value)
                                ? typeof value[0] === "object" ? `${value.length} item(s)` : value.join(", ")
                                : String(value)}
                            </span>
                          </div>
                        ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function SupplierDocumentList({ documents }) {
  if (documents.length === 0) {
    return (
      <Card className="border-0 shadow-sm">
        <CardContent className="p-10 text-center">
          <FileText className="w-10 h-10 text-slate-200 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">No documents uploaded yet.</p>
          <p className="text-slate-400 text-xs mt-1">Upload TDS, CoA, allergen statements, or HACCP summaries above.</p>
        </CardContent>
      </Card>
    );
  }

  const issues = documents.filter(d => d.ai_analysis?.compliance_status === "non_compliant" || d.ai_analysis?.compliance_status === "requires_review");
  const clear = documents.filter(d => d.ai_analysis?.compliance_status === "compliant");
  const pending = documents.filter(d => !d.ai_analysis?.analyzed);

  return (
    <div className="space-y-4">
      {/* Summary bar */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Verified", count: clear.length, cls: "bg-emerald-50 text-emerald-700 border-emerald-200" },
          { label: "Needs Review", count: issues.length, cls: issues.length > 0 ? "bg-amber-50 text-amber-700 border-amber-200" : "bg-slate-50 text-slate-500 border-slate-200" },
          { label: "Pending", count: pending.length, cls: "bg-slate-50 text-slate-500 border-slate-200" },
        ].map(s => (
          <div key={s.label} className={`rounded-lg border p-3 text-center ${s.cls}`}>
            <div className="text-2xl font-bold">{s.count}</div>
            <div className="text-xs font-medium">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Document list */}
      <div className="space-y-2">
        {documents.map(doc => <DocumentCard key={doc.id} doc={doc} />)}
      </div>
    </div>
  );
}