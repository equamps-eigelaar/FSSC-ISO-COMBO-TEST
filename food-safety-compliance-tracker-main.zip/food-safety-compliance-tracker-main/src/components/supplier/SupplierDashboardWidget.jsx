import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, AlertTriangle, XCircle, Clock, MessageSquare, FileText, CalendarDays, TrendingUp } from "lucide-react";
import { formatDistanceToNow, isPast, differenceInDays } from "date-fns";

const RISK_CONFIG = {
  low:      { label: "Low Risk",      color: "text-emerald-700", bg: "bg-emerald-50 border-emerald-200",  badge: "bg-emerald-100 text-emerald-800", bar: "bg-emerald-500", icon: CheckCircle2 },
  medium:   { label: "Medium Risk",   color: "text-amber-700",   bg: "bg-amber-50 border-amber-200",    badge: "bg-amber-100 text-amber-800",    bar: "bg-amber-500",   icon: AlertTriangle },
  high:     { label: "High Risk",     color: "text-orange-700",  bg: "bg-orange-50 border-orange-200",   badge: "bg-orange-100 text-orange-800",  bar: "bg-orange-500",  icon: AlertTriangle },
  critical: { label: "Critical Risk", color: "text-red-700",     bg: "bg-red-50 border-red-200",      badge: "bg-red-100 text-red-800",        bar: "bg-red-500",     icon: XCircle },
};

export default function SupplierDashboardWidget({ profile, assessments, messages, documents }) {
  const score = profile?.compliance_score ?? assessments[0]?.risk_score ?? null;
  const rating = profile?.compliance_rating ?? assessments[0]?.risk_rating ?? "medium";
  const cfg = RISK_CONFIG[rating] || RISK_CONFIG.medium;
  const RiskIcon = cfg.icon;

  // Upcoming deadlines: assessments with due_date not yet past, sorted ascending
  const upcoming = assessments
    .filter(a => a.due_date && !isPast(new Date(a.due_date)) && a.status !== "completed" && a.status !== "submitted")
    .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
    .slice(0, 3);

  // Overdue
  const overdue = assessments.filter(a => a.due_date && isPast(new Date(a.due_date)) && a.status !== "completed" && a.status !== "submitted");

  // Recent messages (last 3 from internal)
  const recentMessages = [...messages]
    .filter(m => m.direction === "internal_to_supplier")
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 3);

  const unreadCount = messages.filter(m => !m.is_read && m.direction === "internal_to_supplier").length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {/* Compliance Score */}
      <Card className={`border shadow-sm col-span-1 ${cfg.bg}`}>
        <CardHeader className="pb-2 pt-4 px-5">
          <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5" /> Compliance Status
          </CardTitle>
        </CardHeader>
        <CardContent className="px-5 pb-5">
          <div className="flex items-center gap-3 mb-3">
            <RiskIcon className={`w-8 h-8 ${cfg.color} shrink-0`} />
            <div>
              {score != null ? (
                <div className={`text-3xl font-bold ${cfg.color}`}>{score}%</div>
              ) : (
                <div className="text-lg font-semibold text-slate-500">Not yet rated</div>
              )}
              <Badge className={`text-xs mt-0.5 ${cfg.badge}`}>{cfg.label}</Badge>
            </div>
          </div>
          {score != null && (
            <div className="w-full bg-white/60 rounded-full h-2 mt-1">
              <div className={`h-2 rounded-full transition-all ${cfg.bar}`} style={{ width: `${score}%` }} />
            </div>
          )}
          {profile?.next_assessment_due && (
            <p className="text-xs text-slate-500 mt-3 flex items-center gap-1.5">
              <CalendarDays className="w-3.5 h-3.5" />
              Next due: <span className="font-medium">{profile.next_assessment_due}</span>
            </p>
          )}
          <div className="mt-3 grid grid-cols-2 gap-2 text-center">
            <div className="bg-white/60 rounded-lg p-2">
              <div className="text-lg font-bold text-slate-800">{assessments.filter(a => a.status === "completed" || a.status === "submitted").length}</div>
              <div className="text-[10px] text-slate-500">Completed</div>
            </div>
            <div className="bg-white/60 rounded-lg p-2">
              <div className={`text-lg font-bold ${overdue.length > 0 ? "text-red-600" : "text-slate-800"}`}>{overdue.length}</div>
              <div className="text-[10px] text-slate-500">Overdue</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Deadlines */}
      <Card className="border-0 shadow-sm col-span-1">
        <CardHeader className="pb-2 pt-4 px-5">
          <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" /> Upcoming Deadlines
          </CardTitle>
        </CardHeader>
        <CardContent className="px-5 pb-5">
          {overdue.length > 0 && (
            <div className="mb-3 p-2.5 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-xs font-semibold text-red-700 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" /> {overdue.length} overdue assessment{overdue.length > 1 ? "s" : ""}
              </p>
              {overdue.slice(0, 1).map(a => (
                <p key={a.id} className="text-xs text-red-600 mt-1 truncate">{a.title}</p>
              ))}
            </div>
          )}
          {upcoming.length === 0 && overdue.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <CheckCircle2 className="w-8 h-8 text-emerald-300 mb-2" />
              <p className="text-xs text-slate-400">No upcoming deadlines</p>
            </div>
          ) : (
            <div className="space-y-3">
              {upcoming.map(a => {
                const days = differenceInDays(new Date(a.due_date), new Date());
                const urgency = days <= 7 ? "text-orange-600 bg-orange-50" : days <= 14 ? "text-amber-600 bg-amber-50" : "text-slate-600 bg-slate-50";
                return (
                  <div key={a.id} className="flex items-start gap-2.5">
                    <div className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 mt-0.5 ${urgency}`}>
                      {days}d
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-slate-800 truncate">{a.title}</p>
                      <p className="text-[10px] text-slate-400">{a.due_date}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          <div className="mt-3 pt-3 border-t border-slate-100">
            <div className="flex justify-between text-xs text-slate-500">
              <span>{documents.length} document{documents.length !== 1 ? "s" : ""} uploaded</span>
              <span>{assessments.length} total assessment{assessments.length !== 1 ? "s" : ""}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Messages */}
      <Card className="border-0 shadow-sm col-span-1">
        <CardHeader className="pb-2 pt-4 px-5">
          <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
            <MessageSquare className="w-3.5 h-3.5" /> Recent Messages
            {unreadCount > 0 && (
              <span className="ml-auto bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{unreadCount} new</span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="px-5 pb-5">
          {recentMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <MessageSquare className="w-8 h-8 text-slate-200 mb-2" />
              <p className="text-xs text-slate-400">No messages from your compliance team yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentMessages.map(m => (
                <div key={m.id} className={`p-2.5 rounded-lg border text-xs ${!m.is_read ? "bg-blue-50 border-blue-200" : "bg-slate-50 border-slate-100"}`}>
                  {m.subject && <p className="font-semibold text-slate-800 truncate mb-0.5">{m.subject}</p>}
                  <p className="text-slate-600 line-clamp-2">{m.message}</p>
                  <p className="text-[10px] text-slate-400 mt-1">
                    {formatDistanceToNow(new Date(m.created_date), { addSuffix: true })}
                    {!m.is_read && <span className="ml-2 text-blue-600 font-medium">• Unread</span>}
                  </p>
                </div>
              ))}
            </div>
          )}
          {messages.filter(m => m.direction === "supplier_to_internal").length > 0 && (
            <div className="mt-3 pt-3 border-t border-slate-100">
              <p className="text-[10px] text-slate-400 text-center">
                {messages.filter(m => m.direction === "supplier_to_internal").length} message{messages.filter(m => m.direction === "supplier_to_internal").length !== 1 ? "s" : ""} sent by you
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}