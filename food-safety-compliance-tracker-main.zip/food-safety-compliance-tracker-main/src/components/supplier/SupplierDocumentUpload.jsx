import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, FileText, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const DOC_TYPES = [
  { value: "supplier_certificate", label: "Certificate" },
  { value: "safety_data_sheet", label: "Safety Data Sheet" },
  { value: "inspection_report", label: "Inspection Report" },
  { value: "test_report", label: "Test Report" },
  { value: "compliance_evidence", label: "Compliance Evidence" },
  { value: "specification", label: "Specification" },
  { value: "other", label: "Other" },
];

export default function SupplierDocumentUpload({ user, onUploaded }) {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState(null);
  const [docType, setDocType] = useState("supplier_certificate");
  const [description, setDescription] = useState("");
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) { toast.error("Please select a file"); return; }
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.Document.create({
        file_name: file.name,
        file_url,
        file_size: file.size,
        file_type: file.type,
        document_type: docType,
        description,
        uploaded_by: user?.email,
        control_status: "uncontrolled",
      });
      toast.success("Document uploaded successfully");
      setOpen(false);
      setFile(null); setDescription("");
      onUploaded?.();
    } catch (err) {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  if (!open) {
    return (
      <Card className="border-2 border-dashed border-blue-200 bg-blue-50/50 shadow-none cursor-pointer hover:border-blue-400 transition-colors" onClick={() => setOpen(true)}>
        <CardContent className="p-6 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center shrink-0">
            <Upload className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <p className="font-medium text-blue-800 text-sm">Upload Compliance Document</p>
            <p className="text-xs text-blue-600 mt-0.5">Certificates, SDS, inspection reports, test results, etc.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="py-4 px-5 border-b border-slate-100">
        <CardTitle className="text-sm font-semibold">Upload Document</CardTitle>
      </CardHeader>
      <CardContent className="p-5">
        <form onSubmit={handleUpload} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label>Document Type</Label>
              <Select value={docType} onValueChange={setDocType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {DOC_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Description (optional)</Label>
              <Input placeholder="Brief description" value={description} onChange={e => setDescription(e.target.value)} />
            </div>
          </div>
          <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-slate-200 rounded-lg p-6 cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-colors">
            {file ? (
              <>
                <FileText className="w-6 h-6 text-blue-600" />
                <span className="text-sm text-blue-700 font-medium">{file.name}</span>
                <span className="text-xs text-slate-400">{(file.size / 1024).toFixed(1)} KB — click to change</span>
              </>
            ) : (
              <>
                <Upload className="w-6 h-6 text-slate-400" />
                <span className="text-sm text-slate-500">Click to select file</span>
              </>
            )}
            <input type="file" className="hidden" accept=".pdf,.docx,.doc,.xlsx,.xls,.jpg,.jpeg,.png" onChange={e => setFile(e.target.files[0])} />
          </label>
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="flex-1">Cancel</Button>
            <Button type="submit" disabled={uploading} className="flex-1 bg-blue-600 hover:bg-blue-700">
              {uploading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Uploading…</> : "Upload"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}