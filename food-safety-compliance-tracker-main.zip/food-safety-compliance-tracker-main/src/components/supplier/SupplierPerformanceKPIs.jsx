import React, { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell
} from "recharts";
import { TrendingUp, TrendingDown, Minus, Clock, MessageSquare, FileText, CheckCircle2 } from "lucide-react";
import { differenceInDays, parseISO, format, subMonths, startOfMonth } from "date-fns";

function KPICard({ label, value, subtitle, trend, color = "slate", icon: Icon }) {
  const colors = {
    emerald: "text-emerald-600 bg-emerald-50",
    amber: "text-amber-600 bg-amber-50",
    red: "text-red-600 bg-red-50",
    blue: "text-blue-600 bg-blue-50",
    slate: "text-slate-600 bg-slate-50",
  };
  const TrendIcon = trend === "up" ? TrendingUp : trend === "down" ? TrendingDown : Minus;
  const trendColor = trend === "up" ? "text-emerald-500" : trend === "down" ? "text-red-500" : "text-slate-400";

  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-slate-500 mb-1">{label}</p>
            <p className={`text-2xl font-bold ${colors[color].split(" ")[0]}`}>{value}</p>
            {subtitle && <p className="text-xs text-slate-400 mt-0.5 truncate">{subtitle}</p>}
          </div>
          <div className="flex flex-col items-end gap-1 shrink-0">
            {Icon && (
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${colors[color]}`}>
                <Icon className="w-4 h-4" />
              </div>
            )}
            {trend && <TrendIcon className={`w-3.5 h-3.5 ${trendColor}`} />}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div className="bg-white border border-slate-200 rounded-lg shadow-lg px-3 py-2 text-xs">
        <p className="font-medium text-slate-700 mb-1">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }}>{p.name}: <strong>{p.value}{p.unit || ""}</strong></p>
        ))}
      </div>
    );
  }
  return null;
};

export default function SupplierPerformanceKPIs({ assessments = [], messages = [], documents = [], profile = null }) {

  const kpis = useMemo(() => {
    // --- Compliance score trend (last 6 months of assessments) ---
    const now = new Date();
    const months = Array.from({ length: 6 }, (_, i) => {
      const d = subMonths(now, 5 - i);
      return { month: format(d, "MMM yy"), start: startOfMonth(d) };
    });

    const scoreTrend = months.map(({ month, start }) => {
      const end = new Date(start);
      end.setMonth(end.getMonth() + 1);
      const monthAss = assessments.filter(a => {
        const d = new Date(a.created_date);
        return d >= start && d < end && a.risk_score != null;
      });
      const avg = monthAss.length > 0
        ? Math.round(monthAss.reduce((sum, a) => sum + (a.risk_score || 0), 0) / monthAss.length)
        : null;
      return { month, score: avg, count: monthAss.length };
    });

    // --- On-time submission rate ---
    const withDueDate = assessments.filter(a => a.due_date);
    const onTime = withDueDate.filter(a => {
      if (!["completed", "submitted"].includes(a.status)) return false;
      const completed = a.completed_date ? new Date(a.completed_date) : new Date(a.updated_date);
      return completed <= new Date(a.due_date);
    });
    const onTimeRate = withDueDate.length > 0
      ? Math.round((onTime.length / withDueDate.length) * 100)
      : null;

    // --- Overdue assessments ---
    const overdue = assessments.filter(a =>
      a.due_date && !["completed", "submitted"].includes(a.status) && new Date(a.due_date) < now
    ).length;

    // --- Average compliance score ---
    const scored = assessments.filter(a => a.risk_score != null);
    const avgScore = scored.length > 0
      ? Math.round(scored.reduce((s, a) => s + a.risk_score, 0) / scored.length)
      : null;

    // --- Latest vs previous score trend ---
    const sorted = [...scored].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    const latest = sorted[0]?.risk_score ?? null;
    const previous = sorted[1]?.risk_score ?? null;
    const scoreTrendDir = latest != null && previous != null
      ? (latest > previous ? "up" : latest < previous ? "down" : "neutral")
      : "neutral";

    // --- Communication responsiveness ---
    // Average gap between supplier message and internal reply
    const supplierMsgs = messages.filter(m => m.direction === "supplier_to_internal").sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    const internalMsgs = messages.filter(m => m.direction === "internal_to_supplier");
    let totalGap = 0, responsePairs = 0;
    supplierMsgs.forEach(sm => {
      const reply = internalMsgs.find(im => new Date(im.created_date) > new Date(sm.created_date));
      if (reply) {
        totalGap += differenceInDays(new Date(reply.created_date), new Date(sm.created_date));
        responsePairs++;
      }
    });
    const avgResponseDays = responsePairs > 0 ? (totalGap / responsePairs).toFixed(1) : null;

    // --- Document submission by type ---
    const docTypes = {};
    documents.forEach(d => {
      const t = d.document_type?.replace(/_/g, ' ') || "other";
      docTypes[t] = (docTypes[t] || 0) + 1;
    });
    const docBreakdown = Object.entries(docTypes).map(([type, count]) => ({ type, count })).sort((a, b) => b.count - a.count).slice(0, 5);

    // --- Assessment status breakdown ---
    const statusBreakdown = [
      { name: "Submitted", value: assessments.filter(a => a.status === "submitted").length, color: "#8b5cf6" },
      { name: "Completed", value: assessments.filter(a => a.status === "completed").length, color: "#10b981" },
      { name: "In Progress", value: assessments.filter(a => a.status === "in_progress").length, color: "#3b82f6" },
      { name: "Draft", value: assessments.filter(a => a.status === "draft").length, color: "#94a3b8" },
    ].filter(s => s.value > 0);

    return { scoreTrend, onTimeRate, overdue, avgScore, scoreTrendDir, avgResponseDays, docBreakdown, statusBreakdown, totalAssessments: assessments.length, totalMessages: messages.length, totalDocs: documents.length };
  }, [assessments, messages, documents]);

  const scoreColor = kpis.avgScore == null ? "slate" : kpis.avgScore >= 80 ? "emerald" : kpis.avgScore >= 60 ? "amber" : "red";
  const onTimeColor = kpis.onTimeRate == null ? "slate" : kpis.onTimeRate >= 80 ? "emerald" : kpis.onTimeRate >= 60 ? "amber" : "red";
  const responseColor = kpis.avgResponseDays == null ? "slate" : Number(kpis.avgResponseDays) <= 2 ? "emerald" : Number(kpis.avgResponseDays) <= 5 ? "amber" : "red";

  const hasScoreData = kpis.scoreTrend.some(d => d.score != null);

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KPICard
          label="Avg Compliance Score"
          value={kpis.avgScore != null ? `${kpis.avgScore}%` : "—"}
          subtitle={`${kpis.totalAssessments} assessment${kpis.totalAssessments !== 1 ? "s" : ""}`}
          trend={kpis.scoreTrendDir}
          color={scoreColor}
          icon={CheckCircle2}
        />
        <KPICard
          label="On-Time Submission"
          value={kpis.onTimeRate != null ? `${kpis.onTimeRate}%` : "—"}
          subtitle={kpis.overdue > 0 ? `${kpis.overdue} overdue` : "No overdue"}
          color={onTimeColor}
          icon={Clock}
        />
        <KPICard
          label="Avg Response Time"
          value={kpis.avgResponseDays != null ? `${kpis.avgResponseDays}d` : "—"}
          subtitle="Internal reply to messages"
          color={responseColor}
          icon={MessageSquare}
        />
        <KPICard
          label="Documents Submitted"
          value={kpis.totalDocs}
          subtitle={`${kpis.totalMessages} messages total`}
          color="blue"
          icon={FileText}
        />
      </div>

      {/* Compliance Score Trend */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            Compliance Score Trend (Last 6 Months)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!hasScoreData ? (
            <div className="h-48 flex items-center justify-center text-slate-400 text-sm">
              No scored assessments yet to show trend data.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={kpis.scoreTrend} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94a3b8" }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: "#94a3b8" }} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="score"
                  name="Score"
                  unit="%"
                  stroke="#10b981"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: "#10b981", strokeWidth: 0 }}
                  connectNulls={false}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* Assessment Status + Doc Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Assessment status */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-slate-800">Assessment Status Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {kpis.statusBreakdown.length === 0 ? (
              <p className="text-slate-400 text-sm text-center py-6">No assessments yet.</p>
            ) : (
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={kpis.statusBreakdown} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#94a3b8" }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#94a3b8" }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="value" name="Count" radius={[4, 4, 0, 0]}>
                    {kpis.statusBreakdown.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Document types */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-slate-800">Documents by Type</CardTitle>
          </CardHeader>
          <CardContent>
            {kpis.docBreakdown.length === 0 ? (
              <p className="text-slate-400 text-sm text-center py-6">No documents uploaded yet.</p>
            ) : (
              <div className="space-y-2.5 py-1">
                {kpis.docBreakdown.map((d, i) => {
                  const maxCount = Math.max(...kpis.docBreakdown.map(x => x.count));
                  const pct = Math.round((d.count / maxCount) * 100);
                  return (
                    <div key={i}>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-slate-600 capitalize truncate max-w-[70%]">{d.type}</span>
                        <span className="font-medium text-slate-800">{d.count}</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-1.5">
                        <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Profile Info if available */}
      {profile && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-slate-800">Supplier Profile Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              {[
                { label: "Category", value: profile.category?.replace(/_/g, " ") || "—" },
                { label: "Country", value: profile.country || "—" },
                { label: "Status", value: profile.status || "—" },
                { label: "Last Assessment", value: profile.last_assessment_date ? new Date(profile.last_assessment_date).toLocaleDateString("en-ZA") : "—" },
                { label: "Next Due", value: profile.next_assessment_due ? new Date(profile.next_assessment_due).toLocaleDateString("en-ZA") : "—" },
                { label: "Compliance Rating", value: profile.compliance_rating || "—" },
                { label: "Compliance Score", value: profile.compliance_score != null ? `${profile.compliance_score}%` : "—" },
                { label: "Approved By", value: profile.approved_by || "—" },
              ].map(({ label, value }) => (
                <div key={label}>
                  <p className="text-xs text-slate-400">{label}</p>
                  <p className="font-medium text-slate-800 capitalize">{value}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}