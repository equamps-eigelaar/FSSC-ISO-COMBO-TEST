import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertTriangle, XCircle, Clock, MessageSquare, TrendingDown,
  Settings2, Bell, CheckCircle2, ChevronDown, ChevronUp
} from "lucide-react";
import { differenceInDays } from "date-fns";

const DEFAULT_THRESHOLDS = {
  minComplianceScore: 60,        // Alert if avg score below this %
  scoreDropPoints: 10,           // Alert if score dropped by this many points vs previous assessment
  overdueAssessmentDays: 0,      // Alert if assessment overdue by this many days (0 = any overdue)
  maxResponseDays: 5,            // Alert if avg internal response time exceeds this many days
  inactivityDays: 90,            // Alert if no activity (assessment/message) in this many days
};

const SEVERITY_CONFIG = {
  critical: { label: "Critical", color: "bg-red-100 text-red-800", icon: XCircle, iconColor: "text-red-600", border: "border-l-red-500" },
  high:     { label: "High",     color: "bg-orange-100 text-orange-800", icon: AlertTriangle, iconColor: "text-orange-500", border: "border-l-orange-400" },
  medium:   { label: "Medium",   color: "bg-amber-100 text-amber-800", icon: AlertTriangle, iconColor: "text-amber-500", border: "border-l-amber-400" },
};

function computeAlerts(suppliers, assessments, messages, thresholds) {
  const now = new Date();
  const alerts = [];

  suppliers.forEach(supplier => {
    if (supplier.status === "inactive" || supplier.status === "suspended") return;

    const sAss = assessments
      .filter(a => a.assigned_to === supplier.email)
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

    const sMsgs = messages.filter(m => m.supplier_email === supplier.email);

    // 1. Declining compliance score
    const scored = sAss.filter(a => a.risk_score != null);
    if (scored.length >= 2) {
      const latest = scored[0].risk_score;
      const previous = scored[1].risk_score;
      const drop = previous - latest;
      if (drop >= thresholds.scoreDropPoints) {
        alerts.push({
          id: `score-drop-${supplier.id}`,
          supplier,
          severity: drop >= 20 ? "critical" : "high",
          type: "score_decline",
          title: "Declining Compliance Score",
          description: `${supplier.company_name}'s compliance score dropped by ${drop} points (${previous}% → ${latest}%).`,
          action: "Review latest assessment and engage supplier.",
        });
      }
    }

    // 2. Low absolute compliance score
    const avgScore = scored.length > 0
      ? Math.round(scored.slice(0, 3).reduce((s, a) => s + a.risk_score, 0) / Math.min(scored.length, 3))
      : null;
    if (avgScore != null && avgScore < thresholds.minComplianceScore) {
      alerts.push({
        id: `low-score-${supplier.id}`,
        supplier,
        severity: avgScore < 40 ? "critical" : "high",
        type: "low_score",
        title: "Low Compliance Score",
        description: `${supplier.company_name} has an average compliance score of ${avgScore}%, below the threshold of ${thresholds.minComplianceScore}%.`,
        action: "Schedule corrective action review.",
      });
    }

    // 3. Overdue assessments
    const overdueAss = sAss.filter(a => {
      if (!a.due_date || ["completed", "submitted"].includes(a.status)) return false;
      const overdueDays = differenceInDays(now, new Date(a.due_date));
      return overdueDays > thresholds.overdueAssessmentDays;
    });
    if (overdueAss.length > 0) {
      const maxOverdue = Math.max(...overdueAss.map(a => differenceInDays(now, new Date(a.due_date))));
      alerts.push({
        id: `overdue-${supplier.id}`,
        supplier,
        severity: maxOverdue > 30 ? "critical" : maxOverdue > 14 ? "high" : "medium",
        type: "overdue_assessment",
        title: "Overdue Assessment",
        description: `${supplier.company_name} has ${overdueAss.length} overdue assessment${overdueAss.length > 1 ? "s" : ""} (up to ${maxOverdue} days late).`,
        action: "Contact supplier to submit pending assessments.",
      });
    }

    // 4. Slow communication response
    const supplierMsgs = sMsgs.filter(m => m.direction === "supplier_to_internal").sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    const internalReplies = sMsgs.filter(m => m.direction === "internal_to_supplier");
    let totalGap = 0, responsePairs = 0;
    supplierMsgs.forEach(sm => {
      const reply = internalReplies.find(im => new Date(im.created_date) > new Date(sm.created_date));
      if (reply) {
        totalGap += differenceInDays(new Date(reply.created_date), new Date(sm.created_date));
        responsePairs++;
      }
    });
    if (responsePairs > 0) {
      const avgDays = totalGap / responsePairs;
      if (avgDays > thresholds.maxResponseDays) {
        alerts.push({
          id: `slow-response-${supplier.id}`,
          supplier,
          severity: avgDays > thresholds.maxResponseDays * 2 ? "high" : "medium",
          type: "slow_response",
          title: "Slow Communication Response",
          description: `Average internal response time for ${supplier.company_name} is ${avgDays.toFixed(1)} days (threshold: ${thresholds.maxResponseDays} days).`,
          action: "Improve internal follow-up speed for this supplier.",
        });
      }
    }

    // 5. Supplier inactivity
    const allActivity = [
      ...sAss.map(a => new Date(a.created_date)),
      ...sMsgs.map(m => new Date(m.created_date)),
    ];
    if (allActivity.length > 0) {
      const lastActivity = Math.max(...allActivity.map(d => d.getTime()));
      const daysSince = differenceInDays(now, new Date(lastActivity));
      if (daysSince >= thresholds.inactivityDays) {
        alerts.push({
          id: `inactive-${supplier.id}`,
          supplier,
          severity: daysSince >= thresholds.inactivityDays * 2 ? "high" : "medium",
          type: "inactivity",
          title: "Supplier Inactivity",
          description: `No activity from ${supplier.company_name} in ${daysSince} days (threshold: ${thresholds.inactivityDays} days).`,
          action: "Re-engage supplier or review account status.",
        });
      }
    }
  });

  // Sort: critical first, then high, then medium
  const order = { critical: 0, high: 1, medium: 2 };
  return alerts.sort((a, b) => order[a.severity] - order[b.severity]);
}

function AlertCard({ alert, dismissed, onDismiss }) {
  const cfg = SEVERITY_CONFIG[alert.severity];
  const Icon = cfg.icon;
  return (
    <Card className={`border-0 shadow-sm border-l-4 ${cfg.border}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <Icon className={`w-5 h-5 mt-0.5 shrink-0 ${cfg.iconColor}`} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="font-semibold text-sm text-slate-800">{alert.title}</span>
              <Badge className={`text-xs ${cfg.color}`}>{cfg.label}</Badge>
              <span className="text-xs text-slate-400 ml-auto">{alert.supplier.company_name}</span>
            </div>
            <p className="text-xs text-slate-600 mb-1.5">{alert.description}</p>
            <p className="text-xs text-slate-400 italic">→ {alert.action}</p>
          </div>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 shrink-0 text-slate-300 hover:text-slate-500"
            onClick={() => onDismiss(alert.id)}
          >
            ✕
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function ThresholdRow({ label, description, value, onChange, unit, min, max, step = 1 }) {
  return (
    <div className="flex items-center gap-4 py-3 border-b border-slate-100 last:border-0">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-800">{label}</p>
        <p className="text-xs text-slate-400 mt-0.5">{description}</p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <Input
          type="number"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={e => onChange(Number(e.target.value))}
          className="w-20 h-8 text-sm text-right"
        />
        <span className="text-xs text-slate-400 w-8">{unit}</span>
      </div>
    </div>
  );
}

export default function SupplierAlertSystem({ suppliers = [], assessments = [], messages = [] }) {
  const [thresholds, setThresholds] = useState(DEFAULT_THRESHOLDS);
  const [dismissed, setDismissed] = useState(new Set());
  const [showSettings, setShowSettings] = useState(false);
  const [draftThresholds, setDraftThresholds] = useState(thresholds);

  const t = (k, v) => setDraftThresholds(p => ({ ...p, [k]: v }));

  const allAlerts = useMemo(
    () => computeAlerts(suppliers, assessments, messages, thresholds),
    [suppliers, assessments, messages, thresholds]
  );

  const activeAlerts = allAlerts.filter(a => !dismissed.has(a.id));

  const criticalCount = activeAlerts.filter(a => a.severity === "critical").length;
  const highCount = activeAlerts.filter(a => a.severity === "high").length;
  const mediumCount = activeAlerts.filter(a => a.severity === "medium").length;

  const handleSaveSettings = () => {
    setThresholds(draftThresholds);
    setShowSettings(false);
    setDismissed(new Set()); // re-evaluate all after threshold change
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bell className="w-5 h-5 text-slate-600" />
          <div>
            <h3 className="font-semibold text-slate-800">Performance Alerts</h3>
            <p className="text-xs text-slate-400">{activeAlerts.length} active alert{activeAlerts.length !== 1 ? "s" : ""}</p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5 h-8"
          onClick={() => { setDraftThresholds(thresholds); setShowSettings(v => !v); }}
        >
          <Settings2 className="w-3.5 h-3.5" />
          Thresholds
          {showSettings ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </Button>
      </div>

      {/* Summary badges */}
      <div className="flex items-center gap-2 flex-wrap">
        {criticalCount > 0 && <Badge className="bg-red-100 text-red-800">{criticalCount} Critical</Badge>}
        {highCount > 0 && <Badge className="bg-orange-100 text-orange-800">{highCount} High</Badge>}
        {mediumCount > 0 && <Badge className="bg-amber-100 text-amber-800">{mediumCount} Medium</Badge>}
        {activeAlerts.length === 0 && (
          <div className="flex items-center gap-2 text-emerald-600 text-sm">
            <CheckCircle2 className="w-4 h-4" />
            All suppliers within normal thresholds
          </div>
        )}
      </div>

      {/* Threshold Settings Panel */}
      {showSettings && (
        <Card className="border border-slate-200 shadow-sm">
          <CardHeader className="pb-2 pt-4 px-4">
            <CardTitle className="text-sm font-semibold text-slate-800 flex items-center gap-2">
              <Settings2 className="w-4 h-4 text-slate-500" /> Configure Alert Thresholds
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <ThresholdRow
              label="Minimum Compliance Score"
              description="Alert when a supplier's average score falls below this"
              value={draftThresholds.minComplianceScore}
              onChange={v => t("minComplianceScore", v)}
              unit="%"
              min={0} max={100}
            />
            <ThresholdRow
              label="Score Drop Threshold"
              description="Alert when compliance score drops by this many points between assessments"
              value={draftThresholds.scoreDropPoints}
              onChange={v => t("scoreDropPoints", v)}
              unit="pts"
              min={1} max={50}
            />
            <ThresholdRow
              label="Overdue Assessment Grace Period"
              description="Alert when an assessment is overdue by more than this many days (0 = immediately)"
              value={draftThresholds.overdueAssessmentDays}
              onChange={v => t("overdueAssessmentDays", v)}
              unit="days"
              min={0} max={60}
            />
            <ThresholdRow
              label="Max Communication Response Time"
              description="Alert when internal team takes longer than this to reply to a supplier message"
              value={draftThresholds.maxResponseDays}
              onChange={v => t("maxResponseDays", v)}
              unit="days"
              min={1} max={30}
            />
            <ThresholdRow
              label="Supplier Inactivity Period"
              description="Alert when there's been no assessment or message activity for this many days"
              value={draftThresholds.inactivityDays}
              onChange={v => t("inactivityDays", v)}
              unit="days"
              min={30} max={365}
            />
            <div className="flex gap-2 mt-4">
              <Button variant="outline" size="sm" className="flex-1" onClick={() => setShowSettings(false)}>Cancel</Button>
              <Button size="sm" className="flex-1 bg-emerald-600 hover:bg-emerald-700" onClick={handleSaveSettings}>Apply Thresholds</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Alert list */}
      {activeAlerts.length > 0 && (
        <div className="space-y-2">
          {activeAlerts.map(alert => (
            <AlertCard
              key={alert.id}
              alert={alert}
              dismissed={dismissed}
              onDismiss={id => setDismissed(p => new Set([...p, id]))}
            />
          ))}
        </div>
      )}

      {activeAlerts.length === 0 && !showSettings && (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-10 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-300 mx-auto mb-3" />
            <p className="text-slate-500 text-sm">No active alerts. All suppliers are performing within configured thresholds.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}