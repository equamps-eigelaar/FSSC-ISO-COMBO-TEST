import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  CheckCircle2, XCircle, AlertTriangle, Camera, Sparkles, Search,
  ChevronDown, ChevronUp, Download, Trash2, Plus, Filter, X, TrendingUp, FolderOpen
} from "lucide-react";
import { format } from "date-fns";
import CleaningRegisterUpload from "@/components/cleaning/CleaningRegisterUpload";
import CleaningTrendChart from "@/components/cleaning/CleaningTrendChart";
import CleaningDocumentLibrary from "@/components/cleaning/CleaningDocumentLibrary";

const RESULT_CONFIG = {
  pass: { label: "Pass", icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  conditional_pass: { label: "Conditional", icon: AlertTriangle, color: "text-amber-600", bg: "bg-amber-50 text-amber-700 border-amber-200" },
  fail: { label: "Fail", icon: XCircle, color: "text-red-600", bg: "bg-red-50 text-red-700 border-red-200" },
};

function RegisterRow({ register, onDelete }) {
  const [expanded, setExpanded] = useState(false);
  const [showPhotos, setShowPhotos] = useState(false);
  const cfg = RESULT_CONFIG[register.result] || RESULT_CONFIG.pass;
  const Icon = cfg.icon;

  const handleDownload = () => {
    if (!register.photo_urls?.length) return;
    register.photo_urls.forEach((url, i) => {
      const a = document.createElement("a");
      a.href = url;
      a.download = `cleaning-register-${register.area}-${i + 1}.jpg`;
      a.target = "_blank";
      document.body.appendChild(a);
      a.click();
      a.remove();
    });
  };

  return (
    <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-sm text-slate-900 dark:text-white truncate">{register.area}</span>
              <Badge className={`text-xs border shrink-0 ${cfg.bg}`}>
                <Icon className="w-3 h-3 mr-1" />
                {cfg.label}
              </Badge>
              {register.photo_urls?.length > 0 && (
                <Badge variant="outline" className="text-xs gap-1 shrink-0">
                  <Camera className="w-3 h-3" />
                  {register.photo_urls.length} photo(s)
                </Badge>
              )}
              {register.ai_analysis?.analysed && (
                <Badge className="bg-purple-100 text-purple-700 border border-purple-200 text-xs gap-1 shrink-0">
                  <Sparkles className="w-3 h-3" />
                  AI: {register.ai_analysis.compliance_score}%
                </Badge>
              )}
            </div>
            <div className="text-xs text-slate-500 mt-1 flex flex-wrap gap-x-2">
              {register.cleaning_date && <span>{format(new Date(register.cleaning_date), "dd MMM yyyy")}</span>}
              {register.shift && <span className="capitalize">• {register.shift} shift</span>}
              {register.cleaned_by && <span>• By: {register.cleaned_by}</span>}
              {register.verified_by && <span>• Verified: {register.verified_by}</span>}
              {register.cleaning_method && (
                <span className="capitalize">• {register.cleaning_method.replace(/_/g, " ")}</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {register.photo_urls?.length > 0 && (
              <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-blue-600" onClick={handleDownload} title="Download photos">
                <Download className="w-4 h-4" />
              </Button>
            )}
            <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-red-600" onClick={() => onDelete(register.id)} title="Delete">
              <Trash2 className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setExpanded(!expanded)}>
              {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {expanded && (
          <div className="mt-3 space-y-3 border-t border-slate-100 pt-3">
            {register.chemicals_used?.length > 0 && (
              <div>
                <p className="text-xs font-medium text-slate-600 mb-1">Chemicals Used:</p>
                <div className="flex flex-wrap gap-1">
                  {register.chemicals_used.map((c, i) => <Badge key={i} variant="secondary" className="text-xs">{c}</Badge>)}
                </div>
              </div>
            )}
            {register.notes && <p className="text-xs text-slate-600 italic">"{register.notes}"</p>}

            {register.photo_urls?.length > 0 && (
              <div>
                <Button variant="outline" size="sm" className="text-xs gap-1 mb-2" onClick={() => setShowPhotos(!showPhotos)}>
                  <Camera className="w-3 h-3" />
                  {showPhotos ? "Hide" : "View"} Photos ({register.photo_urls.length})
                </Button>
                {showPhotos && (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {register.photo_urls.map((url, i) => (
                      <a key={i} href={url} target="_blank" rel="noopener noreferrer" className="group relative">
                        <img src={url} alt={`Register ${i + 1}`} className="w-full h-24 object-cover rounded-lg border border-slate-200 group-hover:opacity-80 transition-opacity" />
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Download className="w-4 h-4 text-white drop-shadow" />
                        </div>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}

            {register.ai_analysis?.analysed && (
              <div className="border border-purple-200 bg-purple-50 rounded-lg p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-3 h-3 text-purple-600" />
                  <span className="text-xs font-semibold text-purple-800">AI Analysis</span>
                  <Badge className="bg-purple-100 text-purple-700 text-xs ml-auto">{register.ai_analysis.compliance_score}%</Badge>
                </div>
                <p className="text-xs text-slate-700">{register.ai_analysis.overall_assessment}</p>
                {register.ai_analysis.issues_found?.length > 0 && (
                  <div>
                    <p className="text-xs font-medium text-red-700 mb-1">Issues Found:</p>
                    <ul className="text-xs text-slate-600 ml-4 list-disc space-y-0.5">
                      {register.ai_analysis.issues_found.map((issue, i) => <li key={i}>{issue}</li>)}
                    </ul>
                  </div>
                )}
                {register.ai_analysis.recommendations?.length > 0 && (
                  <div>
                    <p className="text-xs font-medium text-blue-700 mb-1">Recommendations:</p>
                    <ul className="text-xs text-slate-600 ml-4 list-disc space-y-0.5">
                      {register.ai_analysis.recommendations.map((r, i) => <li key={i}>{r}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function CleaningRegisters() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterResult, setFilterResult] = useState("all");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");
  const [filterScore, setFilterScore] = useState("all");
  const [filterLocation, setFilterLocation] = useState("all");
  const [showUpload, setShowUpload] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showTrends, setShowTrends] = useState(false);
  const [activeTab, setActiveTab] = useState("registers"); // "registers" | "documents"

  const { data: registers = [], isLoading } = useQuery({
    queryKey: ["cleaning-registers"],
    queryFn: () => base44.entities.CleaningRegister.list("-cleaning_date", 500),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CleaningRegister.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["cleaning-registers"] }),
  });

  // Unique locations for filter dropdown
  const locations = useMemo(() => {
    const areas = [...new Set(registers.map((r) => r.area).filter(Boolean))].sort();
    return areas;
  }, [registers]);

  const filtered = useMemo(() => {
    return registers.filter((r) => {
      if (search && !r.area?.toLowerCase().includes(search.toLowerCase()) && !r.cleaned_by?.toLowerCase().includes(search.toLowerCase()) && !r.verified_by?.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterResult !== "all" && r.result !== filterResult) return false;
      if (filterLocation !== "all" && r.area !== filterLocation) return false;
      if (filterDateFrom && r.cleaning_date) {
        if (new Date(r.cleaning_date) < new Date(filterDateFrom)) return false;
      }
      if (filterDateTo && r.cleaning_date) {
        if (new Date(r.cleaning_date) > new Date(filterDateTo)) return false;
      }
      if (filterScore !== "all") {
        const score = r.ai_analysis?.compliance_score;
        if (filterScore === "high" && (score == null || score < 80)) return false;
        if (filterScore === "medium" && (score == null || score < 50 || score >= 80)) return false;
        if (filterScore === "low" && (score == null || score >= 50)) return false;
        if (filterScore === "no_ai" && r.ai_analysis?.analysed) return false;
      }
      return true;
    });
  }, [registers, search, filterResult, filterLocation, filterDateFrom, filterDateTo, filterScore]);

  const total = registers.length;
  const passRate = total > 0 ? Math.round((registers.filter((r) => r.result === "pass").length / total) * 100) : 0;
  const failures = registers.filter((r) => r.result === "fail").length;
  const aiAnalysed = registers.filter((r) => r.ai_analysis?.analysed);
  const avgScore = aiAnalysed.length > 0
    ? Math.round(aiAnalysed.reduce((s, r) => s + (r.ai_analysis?.compliance_score || 0), 0) / aiAnalysed.length)
    : null;

  const hasActiveFilters = filterResult !== "all" || filterDateFrom || filterDateTo || filterScore !== "all" || filterLocation !== "all";

  const clearFilters = () => {
    setFilterResult("all");
    setFilterDateFrom("");
    setFilterDateTo("");
    setFilterScore("all");
    setFilterLocation("all");
  };

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">Cleaning Registers</h1>
          <p className="text-sm text-slate-500 mt-0.5">{total} register{total !== 1 ? "s" : ""} logged</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2 shrink-0 hidden sm:flex" onClick={() => setShowTrends(!showTrends)}>
            <TrendingUp className="w-4 h-4" />
            {showTrends ? "Hide" : "Show"} Trends
          </Button>
          <Button onClick={() => setShowUpload(true)} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
            <Plus className="w-4 h-4" />
            Upload Register
          </Button>
        </div>
      </div>

      {/* Tab switcher */}
      <div className="flex border-b border-slate-200 dark:border-slate-700">
        <button
          onClick={() => setActiveTab("registers")}
          className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${activeTab === "registers" ? "border-emerald-600 text-emerald-700" : "border-transparent text-slate-500 hover:text-slate-700"}`}
        >
          Registers
        </button>
        <button
          onClick={() => setActiveTab("documents")}
          className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${activeTab === "documents" ? "border-emerald-600 text-emerald-700" : "border-transparent text-slate-500 hover:text-slate-700"}`}
        >
          <FolderOpen className="w-4 h-4" />
          Document Library
          <Badge variant="secondary" className="text-xs">{registers.filter((r) => r.photo_urls?.length > 0).length}</Badge>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-slate-900 dark:text-white">{total}</div>
            <div className="text-xs text-slate-500 mt-1">Total Registers</div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-emerald-600">{passRate}%</div>
            <div className="text-xs text-slate-500 mt-1">Pass Rate</div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-600">{failures}</div>
            <div className="text-xs text-slate-500 mt-1">Failures</div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-purple-600">{avgScore !== null ? `${avgScore}%` : "—"}</div>
            <div className="text-xs text-slate-500 mt-1">Avg AI Score</div>
          </CardContent>
        </Card>
      </div>

      {/* Document Library Tab */}
      {activeTab === "documents" && (
        <CleaningDocumentLibrary registers={registers} />
      )}

      {activeTab === "registers" && (
      <div className="space-y-6">

      {/* Trend Chart */}
      {showTrends && <CleaningTrendChart registers={registers} />}

      {/* Search & Filter Bar */}
      <div className="space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              className="pl-9"
              placeholder="Search by area, person, or verifier..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Button
            variant={showFilters ? "default" : "outline"}
            className="gap-2 shrink-0"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="w-4 h-4" />
            Filters
            {hasActiveFilters && <Badge className="bg-white text-slate-900 text-xs px-1 py-0 min-w-4 h-4">{[filterResult !== "all", filterLocation !== "all", filterDateFrom, filterDateTo, filterScore !== "all"].filter(Boolean).length}</Badge>}
          </Button>
        </div>

        {showFilters && (
          <Card className="border border-slate-200 shadow-sm">
            <CardContent className="p-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-600 mb-1 block">Location / Area</label>
                  <Select value={filterLocation} onValueChange={setFilterLocation}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="All locations" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Locations</SelectItem>
                      {locations.map((loc) => (
                        <SelectItem key={loc} value={loc}>{loc}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600 mb-1 block">Status</label>
                  <Select value={filterResult} onValueChange={setFilterResult}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="All statuses" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="pass">Pass</SelectItem>
                      <SelectItem value="conditional_pass">Conditional Pass</SelectItem>
                      <SelectItem value="fail">Fail</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600 mb-1 block">Date From</label>
                  <input
                    type="date"
                    value={filterDateFrom}
                    onChange={(e) => setFilterDateFrom(e.target.value)}
                    className="w-full h-9 px-3 border border-slate-200 dark:border-slate-700 rounded-md text-sm bg-background"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600 mb-1 block">Date To</label>
                  <input
                    type="date"
                    value={filterDateTo}
                    onChange={(e) => setFilterDateTo(e.target.value)}
                    className="w-full h-9 px-3 border border-slate-200 dark:border-slate-700 rounded-md text-sm bg-background"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-600 mb-1 block">AI Score</label>
                  <Select value={filterScore} onValueChange={setFilterScore}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="All scores" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Scores</SelectItem>
                      <SelectItem value="high">High (≥80%)</SelectItem>
                      <SelectItem value="medium">Medium (50–79%)</SelectItem>
                      <SelectItem value="low">Low (&lt;50%)</SelectItem>
                      <SelectItem value="no_ai">No AI Analysis</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {hasActiveFilters && (
                <div className="mt-3 flex justify-end">
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="text-xs gap-1 text-slate-500 hover:text-red-600">
                    <X className="w-3 h-3" />
                    Clear all filters
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {(search || hasActiveFilters) && (
          <p className="text-xs text-slate-500">
            Showing <strong>{filtered.length}</strong> of {total} registers
          </p>
        )}
      </div>

      {/* Register List */}
      {isLoading ? (
        <div className="text-center py-16 text-slate-400 text-sm">Loading registers...</div>
      ) : filtered.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-16 text-center">
            <div className="text-5xl mb-4">🧹</div>
            <h3 className="text-base font-medium text-slate-700 dark:text-white mb-1">No registers found</h3>
            <p className="text-sm text-slate-400 mb-4">
              {hasActiveFilters || search ? "Try adjusting your search or filters." : "Upload your first cleaning register to get started."}
            </p>
            {!hasActiveFilters && !search && (
              <Button onClick={() => setShowUpload(true)} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                Upload Register
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((r) => (
            <RegisterRow
              key={r.id}
              register={r}
              onDelete={(id) => {
                if (window.confirm("Delete this cleaning register?")) {
                  deleteMutation.mutate(id);
                }
              }}
            />
          ))}
        </div>
      )}

      <CleaningRegisterUpload open={showUpload} onClose={() => setShowUpload(false)} />
      </div>
      )}
    </div>
  );
}