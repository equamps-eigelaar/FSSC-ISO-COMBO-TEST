import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, CheckCircle2, AlertTriangle, Clock, Camera, Upload, FileText } from "lucide-react";
import { format } from "date-fns";
import MonitoringLogDialog from "@/components/monitoring/MonitoringLogDialog";
import MonitoringTemplateManager from "@/components/monitoring/MonitoringTemplateManager";
import CleaningRegisterUpload from "@/components/cleaning/CleaningRegisterUpload";
import CleaningRegisterList from "@/components/cleaning/CleaningRegisterList";
import MeetingNotationDialog from "@/components/monitoring/MeetingNotationDialog";
import { toast } from "sonner";

const LOG_TYPE_CONFIG = {
  temperature: { label: "Temperature", color: "bg-blue-100 text-blue-700", icon: "🌡️" },
  cleaning: { label: "Cleaning", color: "bg-green-100 text-green-700", icon: "🧹" },
  receiving_check: { label: "Receiving", color: "bg-purple-100 text-purple-700", icon: "📦" },
  ccp: { label: "CCP", color: "bg-red-100 text-red-700", icon: "⚠️" },
  oprp: { label: "OPRP", color: "bg-orange-100 text-orange-700", icon: "🔔" },
  pest_control: { label: "Pest Control", color: "bg-yellow-100 text-yellow-700", icon: "🐛" },
  calibration: { label: "Calibration", color: "bg-indigo-100 text-indigo-700", icon: "⚙️" },
  other: { label: "Other", color: "bg-slate-100 text-slate-700", icon: "📋" }
};

export default function DailyMonitoring() {
  const [activeTab, setActiveTab] = useState("monitoring");
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [showLogDialog, setShowLogDialog] = useState(false);
  const [selectedLog, setSelectedLog] = useState(null);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showRegisterUpload, setShowRegisterUpload] = useState(false);
  const [showMeetingNotation, setShowMeetingNotation] = useState(false);
  const queryClient = useQueryClient();

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ['monitoring-logs', selectedDate],
    queryFn: () => base44.entities.MonitoringLog.filter({ log_date: selectedDate }, '-created_date', 100)
  });

  const { data: templates = [] } = useQuery({
    queryKey: ['monitoring-templates'],
    queryFn: () => base44.entities.MonitoringTemplate.filter({ is_active: true })
  });

  const { data: currentUser } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });

  const todayStats = {
    total: logs.length,
    completed: logs.filter(l => l.status === "completed").length,
    pending: logs.filter(l => l.status === "pending").length,
    outOfSpec: logs.filter(l => 
      l.readings?.some(r => r.status === "out_of_spec")
    ).length,
  };

  const groupedLogs = logs.reduce((acc, log) => {
    if (!acc[log.log_type]) acc[log.log_type] = [];
    acc[log.log_type].push(log);
    return acc;
  }, {});

  const isToday = selectedDate === format(new Date(), 'yyyy-MM-dd');

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Daily Monitoring</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Track temperatures, cleaning, checks, and CCPs
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowMeetingNotation(true)}>
              <FileText className="w-4 h-4 mr-2" />
              Meeting Notes
            </Button>
            {activeTab === "cleaning" ? (
              <Button onClick={() => setShowRegisterUpload(true)}>
                <Upload className="w-4 h-4 mr-2" />
                Upload Register
              </Button>
            ) : (
              <>
                <Button variant="outline" onClick={() => setShowTemplates(true)}>Templates</Button>
                <Button onClick={() => { setSelectedLog(null); setShowLogDialog(true); }}>
                  <Plus className="w-4 h-4 mr-2" />
                  New Log
                </Button>
              </>
            )}
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="monitoring">Monitoring Logs</TabsTrigger>
            <TabsTrigger value="cleaning">Cleaning Registers</TabsTrigger>
          </TabsList>

          <TabsContent value="monitoring">
            {/* Date Selector */}
            <Card className="border-0 shadow-sm mb-6">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
                  />
                  {!isToday && (
                    <Button variant="outline" size="sm" onClick={() => setSelectedDate(format(new Date(), 'yyyy-MM-dd'))}>
                      Today
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            {isToday && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                <Card className="border-0 shadow-sm"><CardContent className="p-4"><div className="text-2xl font-bold text-slate-900 dark:text-white mb-1">{todayStats.total}</div><div className="text-xs text-slate-500 font-medium">Total Logs</div></CardContent></Card>
                <Card className="border-0 shadow-sm"><CardContent className="p-4"><div className="text-2xl font-bold text-emerald-600 mb-1">{todayStats.completed}</div><div className="text-xs text-slate-500 font-medium">Completed</div></CardContent></Card>
                <Card className="border-0 shadow-sm"><CardContent className="p-4"><div className="text-2xl font-bold text-amber-600 mb-1">{todayStats.pending}</div><div className="text-xs text-slate-500 font-medium">Pending</div></CardContent></Card>
                <Card className="border-0 shadow-sm"><CardContent className="p-4"><div className="text-2xl font-bold text-red-600 mb-1">{todayStats.outOfSpec}</div><div className="text-xs text-slate-500 font-medium">Out of Spec</div></CardContent></Card>
              </div>
            )}

            {/* Logs by Type */}
            <div className="space-y-6">
              {Object.entries(groupedLogs).map(([type, typeLogs]) => {
                const config = LOG_TYPE_CONFIG[type] || LOG_TYPE_CONFIG.other;
                return (
                  <Card key={type} className="border-0 shadow-sm">
                    <CardHeader className="border-b border-slate-100 dark:border-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{config.icon}</span>
                        <CardTitle className="text-sm font-semibold">{config.label}</CardTitle>
                        <Badge variant="secondary">{typeLogs.length}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        {typeLogs.map(log => {
                          const hasIssues = log.readings?.some(r => r.status === "out_of_spec");
                          return (
                            <div
                              key={log.id}
                              onClick={() => { setSelectedLog(log); setShowLogDialog(true); }}
                              className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-900 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                            >
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-sm font-medium text-slate-900 dark:text-white">
                                    {log.location || "General"}
                                  </span>
                                  {hasIssues && (
                                    <Badge variant="destructive" className="text-xs">
                                      <AlertTriangle className="w-3 h-3 mr-1" />
                                      Out of Spec
                                    </Badge>
                                  )}
                                  {log.photo_evidence?.length > 0 && (
                                    <Camera className="w-3 h-3 text-slate-400" />
                                  )}
                                </div>
                                <div className="text-xs text-slate-500 dark:text-slate-400">
                                  {log.shift && <span className="capitalize">{log.shift} • </span>}
                                  {format(new Date(log.created_date), 'HH:mm')}
                                  {log.created_by && <span> • {log.created_by}</span>}
                                </div>
                                {log.readings && log.readings.length > 0 && (
                                  <div className="flex gap-2 mt-2 flex-wrap">
                                    {log.readings.slice(0, 3).map((reading, idx) => (
                                      <span key={idx} className="text-xs text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-800 px-2 py-1 rounded">
                                        {reading.parameter}: {reading.value}{reading.unit}
                                      </span>
                                    ))}
                                    {log.readings.length > 3 && (
                                      <span className="text-xs text-slate-400">+{log.readings.length - 3} more</span>
                                    )}
                                  </div>
                                )}
                              </div>
                              <div className="flex items-center gap-2">
                                {log.status === "completed" ? (
                                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                                ) : (
                                  <Clock className="w-5 h-5 text-amber-600" />
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

              {logs.length === 0 && (
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-12 text-center">
                    <div className="text-4xl mb-4">📋</div>
                    <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">
                      No logs for {format(new Date(selectedDate), 'MMMM d, yyyy')}
                    </h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                      Create your first monitoring log to start tracking
                    </p>
                    <Button onClick={() => setShowLogDialog(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Log
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="cleaning">
            <CleaningRegisterList />
          </TabsContent>
        </Tabs>

        {/* Dialogs */}
        <MonitoringLogDialog
          open={showLogDialog}
          onClose={() => { setShowLogDialog(false); setSelectedLog(null); }}
          log={selectedLog}
          templates={templates}
        />

        <MonitoringTemplateManager
          open={showTemplates}
          onClose={() => setShowTemplates(false)}
        />

        <CleaningRegisterUpload
          open={showRegisterUpload}
          onClose={() => setShowRegisterUpload(false)}
        />

        <MeetingNotationDialog
          open={showMeetingNotation}
          onOpenChange={setShowMeetingNotation}
        />
      </div>
    </div>
  );
}