import React, { useState, useEffect } from "react";
import { format } from "date-fns";
import { RefreshCw, Factory } from "lucide-react";
import PendingTasksWidget from "@/components/sitemanufacturing/PendingTasksWidget";
import ExpiringCertificationsWidget from "@/components/sitemanufacturing/ExpiringCertificationsWidget";
import WasteScheduleWidget from "@/components/sitemanufacturing/WasteScheduleWidget";

export default function SiteManufacturingDashboard() {
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setLastUpdated(new Date()), 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-6 space-y-6 min-h-screen bg-slate-50">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center">
            <Factory className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Site Manufacturing Dashboard</h1>
            <p className="text-sm text-slate-500">Real-time quality tasks · training certifications · waste schedules</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-400 bg-white border border-slate-200 rounded-lg px-3 py-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
          <span>Live · Updated {format(lastUpdated, "HH:mm:ss")}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <PendingTasksWidget />
        <ExpiringCertificationsWidget />
        <WasteScheduleWidget />
      </div>
    </div>
  );
}