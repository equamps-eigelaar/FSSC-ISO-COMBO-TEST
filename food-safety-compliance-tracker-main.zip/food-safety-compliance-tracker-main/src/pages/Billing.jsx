import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DollarSign, Plus, Download, RefreshCw } from "lucide-react";
import BillingDialog from "@/components/billing/BillingDialog.jsx";
import BillingStats from "@/components/billing/BillingStats.jsx";
import BillingTable from "@/components/billing/BillingTable.jsx";
import RecurringBillingDialog from "@/components/billing/RecurringBillingDialog.jsx";
import RecurringBillingTable from "@/components/billing/RecurringBillingTable.jsx";
import EditRecurringDialog from "@/components/billing/EditRecurringDialog.jsx";
import UpcomingBillingAlerts from "@/components/billing/UpcomingBillingAlerts.jsx";
import XeroPanel from "@/components/billing/XeroPanel.jsx";

export default function Billing() {
  const [showDialog, setShowDialog] = useState(false);
  const [showRecurringDialog, setShowRecurringDialog] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState(null);
  const [activeTab, setActiveTab] = useState("records");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [filterCustomer, setFilterCustomer] = useState("all");
  const [runningNow, setRunningNow] = useState(false);

  const queryClient = useQueryClient();

  const { data: records = [], isLoading } = useQuery({
    queryKey: ["billingRecords"],
    queryFn: () => base44.entities.BillingRecord.list(),
  });

  const { data: recurringSchedules = [], isLoading: isLoadingRecurring } = useQuery({
    queryKey: ["recurringBilling"],
    queryFn: () => base44.entities.RecurringBilling.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.BillingRecord.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["billingRecords"] });
      setShowDialog(false);
    },
  });

  const createRecurringMutation = useMutation({
    mutationFn: (data) => base44.entities.RecurringBilling.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["recurringBilling"] });
      setShowRecurringDialog(false);
    },
  });

  const updateRecurringMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.RecurringBilling.update(id, { status }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["recurringBilling"] }),
  });

  const editRecurringMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RecurringBilling.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["recurringBilling"] });
      setEditingSchedule(null);
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status, invoiceNumber, invoiceDate }) =>
      base44.entities.BillingRecord.update(id, {
        billing_status: status,
        invoice_number: invoiceNumber,
        invoice_date: invoiceDate,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["billingRecords"] });
    },
  });

  const handleRunNow = async () => {
    setRunningNow(true);
    // Fire and forget — function may take longer than request timeout
    base44.functions.invoke("processRecurringBilling", {}).catch(() => {});
    // Wait a few seconds then refresh data
    setTimeout(() => {
      queryClient.invalidateQueries({ queryKey: ["billingRecords"] });
      queryClient.invalidateQueries({ queryKey: ["recurringBilling"] });
      setRunningNow(false);
    }, 5000);
  };

  const filteredRecords = records.filter((record) => {
    const matchesSearch =
      record.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.entity_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = filterStatus === "all" || record.billing_status === filterStatus;
    const matchesType = filterType === "all" || record.billable_type === filterType;
    const matchesCustomer = filterCustomer === "all" || record.customer_type === filterCustomer;

    return matchesSearch && matchesStatus && matchesType && matchesCustomer;
  });

  const stats = {
    pending: records.filter((r) => r.billing_status === "pending").reduce((sum, r) => sum + (r.total_cost || 0), 0),
    invoiced: records.filter((r) => r.billing_status === "invoiced").reduce((sum, r) => sum + (r.total_cost || 0), 0),
    paid: records.filter((r) => r.billing_status === "paid").reduce((sum, r) => sum + (r.total_cost || 0), 0),
    total: records.reduce((sum, r) => sum + (r.total_cost || 0), 0),
  };

  const handleExportCSV = () => {
    const headers = ["Transaction Date", "Type", "Customer", "Customer Type", "Description", "Unit Cost", "Quantity", "Total Cost", "Status", "Invoice #"];
    const rows = filteredRecords.map((r) => [
      r.transaction_date,
      r.billable_type.replace("_", " "),
      r.customer_name,
      r.customer_type,
      r.entity_name,
      r.unit_cost,
      r.quantity,
      r.total_cost,
      r.billing_status,
      r.invoice_number || "-",
    ]);

    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `billing-export-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const dueCount = recurringSchedules.filter(
    (r) => r.status === "active" && r.next_billing_date <= new Date().toISOString().split("T")[0]
  ).length;

  if (isLoading) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 bg-slate-200 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Billing & Costs</h1>
          <p className="text-slate-600 mt-1">Track audits, template usage costs, and recurring billing cycles</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={() => setShowRecurringDialog(true)} className="gap-2">
            <RefreshCw className="w-4 h-4" />
            New Recurring Schedule
          </Button>
          <Button onClick={() => setShowDialog(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            Add Billing Record
          </Button>
        </div>
      </div>

      <BillingStats stats={stats} />

      <UpcomingBillingAlerts schedules={recurringSchedules} />

      <XeroPanel
        pendingCount={records.filter(r => r.billing_status === "pending").length}
        onSyncComplete={() => {
          queryClient.invalidateQueries({ queryKey: ["billingRecords"] });
          queryClient.invalidateQueries({ queryKey: ["recurringBilling"] });
        }}
      />

      <BillingDialog open={showDialog} onOpenChange={setShowDialog} onSubmit={createMutation.mutate} isLoading={createMutation.isPending} />
      <RecurringBillingDialog open={showRecurringDialog} onOpenChange={setShowRecurringDialog} onSubmit={createRecurringMutation.mutate} isLoading={createRecurringMutation.isPending} />
      <EditRecurringDialog
        open={!!editingSchedule}
        onOpenChange={(v) => { if (!v) setEditingSchedule(null); }}
        schedule={editingSchedule}
        onSubmit={editRecurringMutation.mutate}
        isLoading={editRecurringMutation.isPending}
      />

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="records">Billing Records</TabsTrigger>
          <TabsTrigger value="recurring" className="relative">
            Recurring Schedules
            {dueCount > 0 && (
              <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5">{dueCount}</span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="records">
          <Card>
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <CardTitle>Billing Records</CardTitle>
                <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-2">
                  <Download className="w-4 h-4" />
                  Export CSV
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4 mb-6">
                <div className="flex gap-4 flex-wrap">
                  <div className="flex-1 min-w-64">
                    <Input placeholder="Search customer, template, or invoice..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="h-10" />
                  </div>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-40 h-10"><SelectValue placeholder="Status" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="invoiced">Invoiced</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-40 h-10"><SelectValue placeholder="Type" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="audit">Audits</SelectItem>
                      <SelectItem value="template_usage">Templates</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterCustomer} onValueChange={setFilterCustomer}>
                    <SelectTrigger className="w-40 h-10"><SelectValue placeholder="Customer" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Customers</SelectItem>
                      <SelectItem value="internal">Internal</SelectItem>
                      <SelectItem value="external">External</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {filteredRecords.length === 0 ? (
                <div className="text-center py-12">
                  <DollarSign className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-600">No billing records found</p>
                </div>
              ) : (
                <BillingTable
                  records={filteredRecords}
                  onUpdateStatus={updateStatusMutation.mutate}
                  isUpdating={updateStatusMutation.isPending}
                  onRefresh={() => queryClient.invalidateQueries({ queryKey: ["billingRecords"] })}
                />
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recurring">
          <Card>
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Recurring Billing Schedules</CardTitle>
                  <p className="text-sm text-slate-500 mt-1">Auto-generates pending billing records on each cycle date</p>
                </div>
                {dueCount > 0 && (
                  <Button onClick={handleRunNow} disabled={runningNow} className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                    <RefreshCw className={`w-4 h-4 ${runningNow ? "animate-spin" : ""}`} />
                    {runningNow ? "Processing..." : `Process ${dueCount} Due Now`}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              {recurringSchedules.length === 0 ? (
                <div className="text-center py-12">
                  <RefreshCw className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-600 mb-4">No recurring billing schedules yet</p>
                  <Button variant="outline" onClick={() => setShowRecurringDialog(true)} className="gap-2">
                    <Plus className="w-4 h-4" />
                    Create First Schedule
                  </Button>
                </div>
              ) : (
                <RecurringBillingTable
                  schedules={recurringSchedules}
                  onUpdateStatus={updateRecurringMutation.mutate}
                  isUpdating={updateRecurringMutation.isPending}
                  onEdit={setEditingSchedule}
                />
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}