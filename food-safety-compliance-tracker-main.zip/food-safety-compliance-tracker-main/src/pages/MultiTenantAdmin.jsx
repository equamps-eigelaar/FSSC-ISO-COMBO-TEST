import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Building2, Users, Link2, CheckCircle2, AlertCircle, RefreshCw, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

export default function MultiTenantAdmin() {
  const [search, setSearch] = useState('');
  const [selectedOrg, setSelectedOrg] = useState({});
  const queryClient = useQueryClient();

  const { data: orgs = [], isLoading: orgsLoading } = useQuery({
    queryKey: ['orgs-all'],
    queryFn: () => base44.entities.Organization.list('-created_date', 100),
  });

  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ['users-all'],
    queryFn: () => base44.entities.User.list('-created_date', 200),
  });

  const assignMutation = useMutation({
    mutationFn: async ({ user_email, organization_id, organization_name }) => {
      return base44.functions.invoke('assignUserOrganization', { user_email, organization_id, organization_name });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users-all'] });
      toast.success('User assigned to organization');
    },
    onError: (e) => toast.error('Failed: ' + (e?.response?.data?.error || e.message)),
  });

  const filtered = users.filter(u =>
    !search ||
    u.email?.toLowerCase().includes(search.toLowerCase()) ||
    u.full_name?.toLowerCase().includes(search.toLowerCase())
  );

  const orgMap = Object.fromEntries(orgs.map(o => [o.id, o]));

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
            <Building2 className="w-5 h-5 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Multi-Tenant Setup</h1>
            <p className="text-slate-500 text-sm">Assign users to organizations to enable data isolation</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="text-2xl font-bold text-slate-900">{orgs.length}</div>
            <div className="text-slate-500 text-sm mt-1">Organizations</div>
          </div>
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="text-2xl font-bold text-slate-900">{users.length}</div>
            <div className="text-slate-500 text-sm mt-1">Total Users</div>
          </div>
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="text-2xl font-bold text-amber-600">{users.filter(u => !u.organization_id).length}</div>
            <div className="text-slate-500 text-sm mt-1">Unassigned Users</div>
          </div>
        </div>

        {/* User assignment table */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between gap-4">
            <h2 className="font-semibold text-slate-800 flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-400" /> User → Organization Assignment
            </h2>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search users..."
                className="pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 w-52"
              />
            </div>
          </div>

          {usersLoading || orgsLoading ? (
            <div className="flex items-center justify-center py-16 text-slate-400">
              <RefreshCw className="w-5 h-5 animate-spin mr-2" /> Loading...
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-slate-500 uppercase">User</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Role</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Current Org</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Assign To</th>
                  <th className="px-5 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map(u => {
                  const currentOrg = u.organization_id ? orgMap[u.organization_id] : null;
                  const pendingOrg = selectedOrg[u.id];

                  return (
                    <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-medium text-slate-900">{u.full_name || '—'}</div>
                        <div className="text-slate-500 text-xs">{u.email}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <Badge variant="outline" className="text-xs capitalize">{u.role || 'user'}</Badge>
                      </td>
                      <td className="px-5 py-3.5">
                        {currentOrg ? (
                          <div className="flex items-center gap-1.5 text-emerald-600">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span className="text-sm font-medium">{currentOrg.name}</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 text-amber-500">
                            <AlertCircle className="w-3.5 h-3.5" />
                            <span className="text-xs">Unassigned</span>
                          </div>
                        )}
                      </td>
                      <td className="px-5 py-3.5">
                        <select
                          value={pendingOrg || u.organization_id || ''}
                          onChange={e => setSelectedOrg(s => ({ ...s, [u.id]: e.target.value }))}
                          className="border border-slate-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                        >
                          <option value="">— select org —</option>
                          {orgs.map(o => (
                            <option key={o.id} value={o.id}>{o.name}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-5 py-3.5">
                        <Button
                          size="sm"
                          disabled={!pendingOrg || pendingOrg === u.organization_id || assignMutation.isPending}
                          onClick={() => {
                            const org = orgMap[pendingOrg];
                            assignMutation.mutate({
                              user_email: u.email,
                              organization_id: pendingOrg,
                              organization_name: org?.name || '',
                            });
                          }}
                          className="bg-emerald-600 hover:bg-emerald-700 gap-1.5"
                        >
                          <Link2 className="w-3.5 h-3.5" /> Assign
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Info callout */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl px-5 py-4 text-sm text-blue-700">
          <strong>How it works:</strong> Once a user is assigned to an organization, they can only see and create records tagged with their <code className="bg-blue-100 px-1 rounded">organization_id</code>. Admins retain full cross-org visibility.
          New records created by a user automatically inherit their org via the <code className="bg-blue-100 px-1 rounded">useOrgContext</code> hook.
        </div>
      </div>
    </div>
  );
}