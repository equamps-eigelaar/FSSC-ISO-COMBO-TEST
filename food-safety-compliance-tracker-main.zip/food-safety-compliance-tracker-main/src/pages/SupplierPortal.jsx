import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ShieldCheck, FileText, MessageSquare, Upload, CheckCircle2,
  AlertTriangle, XCircle, Clock, Loader2, Plus, RefreshCw
} from "lucide-react";
import { toast } from "sonner";
import SupplierAssessmentUpload from "@/components/supplier/SupplierAssessmentUpload";
import SupplierMessageThread from "@/components/supplier/SupplierMessageThread";
import SupplierDocumentUpload from "@/components/supplier/SupplierDocumentUpload";
import SupplierDocumentUploadEnhanced from "@/components/supplier/SupplierDocumentUploadEnhanced";
import SupplierDocumentList from "@/components/supplier/SupplierDocumentList";
import SupplierDashboardWidget from "@/components/supplier/SupplierDashboardWidget";
import SupplierPerformanceKPIs from "@/components/supplier/SupplierPerformanceKPIs";
import SupplierAlertSystem from "@/components/supplier/SupplierAlertSystem";
import { LayoutDashboard, BarChart2, Bell } from "lucide-react";

const RISK_CONFIG = {
  low:      { label: "Low Risk",      color: "text-emerald-700", bg: "bg-emerald-50",  badge: "bg-emerald-100 text-emerald-800", icon: CheckCircle2 },
  medium:   { label: "Medium Risk",   color: "text-amber-700",   bg: "bg-amber-50",    badge: "bg-amber-100 text-amber-800",    icon: AlertTriangle },
  high:     { label: "High Risk",     color: "text-orange-700",  bg: "bg-orange-50",   badge: "bg-orange-100 text-orange-800",  icon: AlertTriangle },
  critical: { label: "Critical Risk", color: "text-red-700",     bg: "bg-red-50",      badge: "bg-red-100 text-red-800",        icon: XCircle },
};

const STATUS_LABELS = {
  draft: "Draft", in_progress: "In Progress", completed: "Completed", submitted: "Submitted"
};

export default function SupplierPortal() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setLoadingUser(false);
    }).catch(() => {
      setLoadingUser(false);
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: profiles = [] } = useQuery({
    queryKey: ["supplier-profile", user?.email],
    queryFn: () => base44.entities.SupplierProfile.filter({ email: user.email }),
    enabled: !!user?.email,
  });

  useEffect(() => {
    if (profiles.length > 0) setProfile(profiles[0]);
  }, [profiles]);

  const { data: assessments = [], isLoading: loadingAssessments } = useQuery({
    queryKey: ["supplier-assessments", user?.email],
    queryFn: () => base44.entities.SupplierSelfAssessment.filter({ assigned_to: user.email }, "-created_date", 50),
    enabled: !!user?.email,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ["supplier-messages", user?.email],
    queryFn: () => base44.entities.SupplierMessage.filter({ supplier_email: user.email }, "-created_date", 100),
    enabled: !!user?.email,
  });

  const { data: documents = [] } = useQuery({
    queryKey: ["supplier-docs", user?.email],
    queryFn: () => base44.entities.Document.filter({ uploaded_by: user.email }, "-created_date", 50),
    enabled: !!user?.email,
  });

  const unreadCount = messages.filter(m => !m.is_read && m.direction === "internal_to_supplier").length;
  const latestAssessment = assessments[0];
  const riskCfg = RISK_CONFIG[profile?.compliance_rating || latestAssessment?.risk_rating] || RISK_CONFIG.medium;
  const RiskIcon = riskCfg.icon;

  if (loadingUser) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-emerald-50/30">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 shadow-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-900 leading-tight">Supplier Compliance Portal</h1>
              <p className="text-xs text-slate-400">{profile?.company_name || user?.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {profile?.status && (
              <Badge className={profile.status === "active" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}>
                {profile.status === "active" ? "Active Supplier" : profile.status}
              </Badge>
            )}
            <Button variant="ghost" size="sm" onClick={() => base44.auth.logout()} className="text-slate-500 text-xs">
              Sign out
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Main Tabs */}
        <Tabs defaultValue="assessments">
          <TabsList className="w-full grid grid-cols-5">
            <TabsTrigger value="overview" className="gap-1.5">
              <LayoutDashboard className="w-3.5 h-3.5" /> Overview
            </TabsTrigger>
            <TabsTrigger value="performance" className="gap-1.5">
              <BarChart2 className="w-3.5 h-3.5" /> Performance
            </TabsTrigger>
            <TabsTrigger value="assessments" className="gap-1.5">
              <FileText className="w-3.5 h-3.5" /> Assessments
            </TabsTrigger>
            <TabsTrigger value="documents" className="gap-1.5">
              <Upload className="w-3.5 h-3.5" /> Documents
            </TabsTrigger>
            <TabsTrigger value="messages" className="gap-1.5 relative">
              <MessageSquare className="w-3.5 h-3.5" /> Messages
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* OVERVIEW */}
          <TabsContent value="overview" className="mt-4 space-y-4">
            <SupplierDashboardWidget
              profile={profile}
              assessments={assessments}
              messages={messages}
              documents={documents}
            />
            <SupplierDocumentUpload user={user} onUploaded={() => queryClient.invalidateQueries({ queryKey: ["supplier-docs", user?.email] })} />
          </TabsContent>

          {/* PERFORMANCE */}
          <TabsContent value="performance" className="mt-4 space-y-6">
            <SupplierAlertSystem
              suppliers={profile ? [profile] : []}
              assessments={assessments}
              messages={messages}
            />
            <SupplierPerformanceKPIs
              assessments={assessments}
              messages={messages}
              documents={documents}
              profile={profile}
            />
          </TabsContent>

          {/* ASSESSMENTS */}
          <TabsContent value="assessments" className="mt-4 space-y-4">
            <SupplierAssessmentUpload user={user} onCreated={() => queryClient.invalidateQueries({ queryKey: ["supplier-assessments", user?.email] })} />
            <div className="space-y-3">
              {loadingAssessments ? (
                <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
              ) : assessments.length === 0 ? (
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-10 text-center">
                    <FileText className="w-10 h-10 text-slate-200 mx-auto mb-3" />
                    <p className="text-slate-500 text-sm">No assessments yet. Submit your first questionnaire above.</p>
                  </CardContent>
                </Card>
              ) : assessments.map(a => (
                <AssessmentStatusCard key={a.id} assessment={a} />
              ))}
            </div>
          </TabsContent>

          {/* DOCUMENTS */}
          <TabsContent value="documents" className="mt-4 space-y-4">
            <SupplierDocumentUploadEnhanced user={user} onUploaded={() => queryClient.invalidateQueries({ queryKey: ["supplier-docs", user?.email] })} />
            <SupplierDocumentList documents={documents} />
          </TabsContent>

          {/* MESSAGES */}
          <TabsContent value="messages" className="mt-4">
            <SupplierMessageThread user={user} messages={messages} onSent={() => queryClient.invalidateQueries({ queryKey: ["supplier-messages", user?.email] })} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function SummaryCard({ icon: Icon, label, value, color }) {
  const colors = {
    blue:    "bg-blue-50 text-blue-600",
    emerald: "bg-emerald-50 text-emerald-600",
    purple:  "bg-purple-50 text-purple-600",
    amber:   "bg-amber-50 text-amber-600",
    slate:   "bg-slate-50 text-slate-400",
  };
  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4 flex flex-col items-center text-center gap-1">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${colors[color]}`}>
          <Icon className="w-4 h-4" />
        </div>
        <span className="text-xl font-bold text-slate-900">{value}</span>
        <span className="text-xs text-slate-500">{label}</span>
      </CardContent>
    </Card>
  );
}

function AssessmentStatusCard({ assessment }) {
  const riskCfg = RISK_CONFIG[assessment.risk_rating] || {};
  const statusColor = {
    draft: "bg-slate-100 text-slate-600",
    in_progress: "bg-blue-100 text-blue-700",
    completed: "bg-emerald-100 text-emerald-700",
    submitted: "bg-purple-100 text-purple-700",
  }[assessment.status] || "bg-slate-100 text-slate-600";

  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <p className="font-medium text-slate-900 text-sm truncate">{assessment.title}</p>
            <p className="text-xs text-slate-500 mt-0.5">{assessment.customer_name}</p>
            {assessment.ai_summary && (
              <p className="text-xs text-slate-600 mt-2 line-clamp-2">{assessment.ai_summary}</p>
            )}
            {assessment.ai_gaps?.length > 0 && (
              <div className="mt-2">
                <p className="text-xs font-medium text-slate-700 mb-1">Gaps identified:</p>
                <ul className="space-y-0.5">
                  {assessment.ai_gaps.slice(0, 3).map((g, i) => (
                    <li key={i} className="text-xs text-slate-500 flex items-start gap-1">
                      <span className="text-amber-500 shrink-0 mt-0.5">•</span>{g}
                    </li>
                  ))}
                  {assessment.ai_gaps.length > 3 && (
                    <li className="text-xs text-slate-400">+{assessment.ai_gaps.length - 3} more gaps…</li>
                  )}
                </ul>
              </div>
            )}
          </div>
          <div className="flex flex-col items-end gap-2 shrink-0">
            <Badge className={`text-xs ${statusColor}`}>{STATUS_LABELS[assessment.status] || assessment.status}</Badge>
            {assessment.risk_score != null && (
              <div className="text-right">
                <div className={`text-lg font-bold ${riskCfg.color || "text-slate-700"}`}>{assessment.risk_score}%</div>
                {assessment.risk_rating && (
                  <div className={`text-xs ${riskCfg.color || "text-slate-500"}`}>{riskCfg.label || assessment.risk_rating}</div>
                )}
              </div>
            )}
          </div>
        </div>
        {assessment.ai_recommendations?.length > 0 && (
          <div className="mt-3 pt-3 border-t border-slate-100">
            <p className="text-xs font-medium text-slate-700 mb-1">Recommended actions:</p>
            <ul className="space-y-0.5">
              {assessment.ai_recommendations.slice(0, 2).map((r, i) => (
                <li key={i} className="text-xs text-slate-500 flex items-start gap-1">
                  <span className="text-emerald-500 shrink-0 mt-0.5">→</span>{r}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}