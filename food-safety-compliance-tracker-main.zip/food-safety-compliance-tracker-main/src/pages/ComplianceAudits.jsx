import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Sparkles, 
  Play, 
  AlertTriangle, 
  CheckCircle,
  TrendingUp,
  Calendar,
  FileText,
  Loader2,
  Clock
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { usePermissions } from "@/components/permissions/usePermissions";
import AuditDetailDialog from "@/components/audits/AuditDetailDialog";
import PullToRefresh from "@/components/mobile/PullToRefresh";

export default function ComplianceAudits() {
  const { permissions } = usePermissions();
  const queryClient = useQueryClient();
  const [selectedAudit, setSelectedAudit] = useState(null);

  const { data: audits = [], isLoading, refetch } = useQuery({
    queryKey: ['compliance-audits'],
    queryFn: () => base44.entities.ComplianceAudit.list("-audit_date", 50)
  });

  const handleRefresh = async () => {
    await refetch();
  };

  const runAuditMutation = useMutation({
    mutationFn: () => base44.functions.invoke('runAIComplianceAudit'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['compliance-audits'] });
      toast.success("AI Compliance Audit completed");
    },
    onError: (error) => {
      toast.error("Failed to run audit");
      console.error(error);
    }
  });

  const getScoreColor = (score) => {
    if (score >= 85) return "text-emerald-600 bg-emerald-50";
    if (score >= 70) return "text-blue-600 bg-blue-50";
    if (score >= 50) return "text-amber-600 bg-amber-50";
    return "text-rose-600 bg-rose-50";
  };

  const latestAudit = audits[0];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-purple-600" />
              AI Compliance Audits
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Automated compliance scanning and discrepancy detection
            </p>
          </div>
          {permissions.canManageAudits && (
            <Button 
              onClick={() => runAuditMutation.mutate()}
              disabled={runAuditMutation.isPending}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {runAuditMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Running Audit...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Run New Audit
                </>
              )}
            </Button>
          )}
        </div>

        {/* Latest Audit Summary */}
        {latestAudit && latestAudit.status === 'completed' && (
          <div className="grid gap-4 md:grid-cols-4 mb-6">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-purple-600" />
                  <span className="text-xs text-slate-500">Overall Score</span>
                </div>
                <div className={`text-3xl font-bold ${getScoreColor(latestAudit.overall_score)}`}>
                  {latestAudit.overall_score}
                </div>
                <div className="text-xs text-slate-400 mt-1">out of 100</div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs text-slate-500">Compliant</span>
                </div>
                <div className="text-3xl font-bold text-emerald-700">
                  {latestAudit.metrics?.compliant || 0}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  of {latestAudit.metrics?.total_requirements || 0}
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  <span className="text-xs text-slate-500">Findings</span>
                </div>
                <div className="text-3xl font-bold text-rose-700">
                  {latestAudit.findings?.length || 0}
                </div>
                <div className="text-xs text-slate-400 mt-1">issues identified</div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span className="text-xs text-slate-500">Overdue</span>
                </div>
                <div className="text-3xl font-bold text-amber-700">
                  {latestAudit.metrics?.overdue || 0}
                </div>
                <div className="text-xs text-slate-400 mt-1">requirements</div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Audit History */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="w-5 h-5 text-slate-600" />
              Audit History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {audits.length === 0 ? (
              <div className="text-center py-12">
                <Sparkles className="w-16 h-16 text-purple-200 mx-auto mb-4" />
                <p className="text-slate-600 mb-2">No audits have been run yet</p>
                <p className="text-sm text-slate-400 mb-4">
                  Run your first AI compliance audit to identify gaps and risks
                </p>
                {permissions.canManageAudits && (
                  <Button 
                    onClick={() => runAuditMutation.mutate()}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Run First Audit
                  </Button>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {audits.map((audit) => (
                  <Card key={audit.id} className="border-slate-200 hover:border-purple-300 transition-colors cursor-pointer"
                    onClick={() => setSelectedAudit(audit)}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge variant="outline" className="shrink-0">
                              {audit.status === 'completed' ? (
                                <CheckCircle className="w-3 h-3 mr-1 text-emerald-600" />
                              ) : audit.status === 'in_progress' ? (
                                <Loader2 className="w-3 h-3 mr-1 animate-spin text-blue-600" />
                              ) : (
                                <AlertTriangle className="w-3 h-3 mr-1 text-rose-600" />
                              )}
                              {audit.status}
                            </Badge>
                            <div className="flex items-center gap-2 text-xs text-slate-500">
                              <Calendar className="w-3 h-3" />
                              {format(new Date(audit.audit_date), "MMM d, yyyy 'at' h:mm a")}
                            </div>
                            {audit.overall_score !== undefined && (
                              <Badge className={getScoreColor(audit.overall_score)}>
                                Score: {audit.overall_score}/100
                              </Badge>
                            )}
                          </div>
                          {audit.summary && (
                            <p className="text-sm text-slate-600 line-clamp-2">{audit.summary}</p>
                          )}
                          {audit.findings?.length > 0 && (
                            <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
                              <span>{audit.findings.length} findings</span>
                              <span>•</span>
                              <span>{audit.recommendations?.length || 0} recommendations</span>
                              <span>•</span>
                              <span>{audit.discrepancies?.length || 0} discrepancies</span>
                            </div>
                          )}
                        </div>
                        <Button variant="ghost" size="sm">
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
        </div>
      </div>

      {selectedAudit && (
        <AuditDetailDialog
          open={!!selectedAudit}
          onClose={() => setSelectedAudit(null)}
          audit={selectedAudit}
        />
      )}
    </PullToRefresh>
  );
}