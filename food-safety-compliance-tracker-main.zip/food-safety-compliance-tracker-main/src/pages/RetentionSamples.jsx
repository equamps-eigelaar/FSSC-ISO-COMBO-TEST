import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import {
  Plus, Search, FlaskConical, Package, MapPin, Calendar, ChevronDown, ChevronRight, Trash2, Pencil, AlertTriangle
} from "lucide-react";
import { format, isPast, isWithinInterval, addDays } from "date-fns";
import RetentionSampleDialog from "@/components/retention/RetentionSampleDialog";
import SampleTestsPanel from "@/components/retention/SampleTestsPanel";

const STATUS_COLORS = {
  active: "bg-emerald-100 text-emerald-700 border-emerald-300",
  tested: "bg-blue-100 text-blue-700 border-blue-300",
  disposed: "bg-slate-100 text-slate-500 border-slate-300",
  expired: "bg-red-100 text-red-700 border-red-300",
};

const REASON_LABELS = {
  routine: "Routine",
  customer_complaint: "Customer Complaint",
  regulatory: "Regulatory",
  shelf_life_study: "Shelf Life Study",
  internal_investigation: "Internal Investigation",
  other: "Other",
};

function expiryWarning(expiryDate) {
  if (!expiryDate) return null;
  const exp = new Date(expiryDate);
  if (isPast(exp)) return "expired";
  if (isWithinInterval(new Date(), { start: new Date(), end: addDays(new Date(), 14) }) && exp <= addDays(new Date(), 14)) return "expiring_soon";
  return null;
}

export default function RetentionSamples() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showDialog, setShowDialog] = useState(false);
  const [editSample, setEditSample] = useState(null);
  const [expanded, setExpanded] = useState({});

  const { data: samples = [], isLoading } = useQuery({
    queryKey: ["retention_samples"],
    queryFn: () => base44.entities.RetentionSample.list("-sample_date"),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.RetentionSample.create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["retention_samples"] }); setShowDialog(false); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RetentionSample.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["retention_samples"] }); setEditSample(null); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RetentionSample.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["retention_samples"] }),
  });

  const handleSave = (form) => {
    if (editSample) {
      updateMutation.mutate({ id: editSample.id, data: form });
    } else {
      createMutation.mutate(form);
    }
  };

  const filtered = samples.filter((s) => {
    const matchSearch =
      s.sample_code?.toLowerCase().includes(search.toLowerCase()) ||
      s.batch_number?.toLowerCase().includes(search.toLowerCase()) ||
      s.product_name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || s.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const toggleExpand = (id) => setExpanded((e) => ({ ...e, [id]: !e[id] }));

  const stats = {
    active: samples.filter((s) => s.status === "active").length,
    expiring: samples.filter((s) => expiryWarning(s.expiry_date) === "expiring_soon" && s.status === "active").length,
    expired: samples.filter((s) => s.status === "expired" || expiryWarning(s.expiry_date) === "expired").length,
    tested: samples.filter((s) => s.status === "tested").length,
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Retention Samples</h1>
          <p className="text-sm text-slate-500 mt-0.5">Track retained samples and record testing results</p>
        </div>
        <Button onClick={() => setShowDialog(true)} className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2">
          <Plus className="w-4 h-4" /> Register Sample
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Active", value: stats.active, color: "text-emerald-700 bg-emerald-50 border-emerald-200" },
          { label: "Expiring Soon", value: stats.expiring, color: "text-amber-700 bg-amber-50 border-amber-200" },
          { label: "Expired", value: stats.expired, color: "text-red-700 bg-red-50 border-red-200" },
          { label: "Tested", value: stats.tested, color: "text-blue-700 bg-blue-50 border-blue-200" },
        ].map((s) => (
          <div key={s.label} className={`rounded-xl border p-4 ${s.color}`}>
            <p className="text-2xl font-bold">{s.value}</p>
            <p className="text-xs font-medium mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by code, batch, product..." className="pl-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36"><SelectValue placeholder="All Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="tested">Tested</SelectItem>
            <SelectItem value="disposed">Disposed</SelectItem>
            <SelectItem value="expired">Expired</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Sample List */}
      {isLoading ? (
        <div className="text-center py-12 text-slate-400">Loading samples...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-slate-400">
          <FlaskConical className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p>No retention samples found.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((sample) => {
            const warning = expiryWarning(sample.expiry_date);
            const open = !!expanded[sample.id];
            return (
              <Card key={sample.id} className={`border ${warning === "expired" ? "border-red-200" : warning === "expiring_soon" ? "border-amber-200" : "border-slate-200"}`}>
                <CardContent className="p-0">
                  {/* Row header */}
                  <div
                    className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-slate-50 rounded-t-xl"
                    onClick={() => toggleExpand(sample.id)}
                  >
                    {open ? <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold text-slate-800">{sample.sample_code}</span>
                        <span className="text-xs text-slate-500">· {sample.product_name}</span>
                        <span className="text-xs text-slate-400">Batch: {sample.batch_number}</span>
                        {warning === "expiring_soon" && (
                          <Badge className="bg-amber-100 text-amber-700 border border-amber-300 text-[11px] gap-1">
                            <AlertTriangle className="w-2.5 h-2.5" /> Expiring Soon
                          </Badge>
                        )}
                        {warning === "expired" && (
                          <Badge className="bg-red-100 text-red-700 border border-red-300 text-[11px] gap-1">
                            <AlertTriangle className="w-2.5 h-2.5" /> Expired
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 mt-1 flex-wrap">
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> Sampled: {sample.sample_date}
                        </span>
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> Expires: {sample.expiry_date}
                        </span>
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> {sample.storage_location}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge className={`text-[11px] border ${STATUS_COLORS[sample.status]}`}>{sample.status}</Badge>
                      <span className="text-[11px] text-slate-400">{REASON_LABELS[sample.reason_for_retention] || sample.reason_for_retention}</span>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); setEditSample(sample); }}>
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7 text-red-400" onClick={(e) => { e.stopPropagation(); deleteMutation.mutate(sample.id); }}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>

                  {/* Expanded: test panel */}
                  {open && (
                    <div className="border-t border-slate-100 px-5 py-4 bg-slate-50 rounded-b-xl">
                      <SampleTestsPanel sample={sample} />
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {(showDialog || editSample) && (
        <RetentionSampleDialog
          open={!!(showDialog || editSample)}
          onClose={() => { setShowDialog(false); setEditSample(null); }}
          onSave={handleSave}
          sample={editSample}
        />
      )}
    </div>
  );
}