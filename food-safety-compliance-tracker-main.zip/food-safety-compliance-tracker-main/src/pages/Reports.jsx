import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, ShieldCheck, Activity, CheckCircle, Users, Zap } from "lucide-react";
import { usePermissions } from "@/components/permissions/usePermissions";
import ComplianceReportTab from "@/components/reports/ComplianceReportTab.jsx";
import ActionItemsReportTab from "@/components/reports/ActionItemsReportTab.jsx";
import RiskReportTab from "@/components/reports/RiskReportTab.jsx";
import UserActivityReportTab from "@/components/reports/UserActivityReportTab.jsx";
import GeneratedReportsView from "@/components/reports/GeneratedReportsView.jsx";
import ScheduleAutomatedReports from "@/components/reports/ScheduleAutomatedReports.jsx";

const TABS = [
  { id: "generated", label: "Generated Reports", icon: Zap, color: "text-yellow-600" },
  { id: "automation", label: "Automated Schedules", icon: Activity, color: "text-blue-600" },
  { id: "compliance", label: "Compliance Status", icon: ShieldCheck, color: "text-emerald-600" },
  { id: "actions", label: "Action Items", icon: CheckCircle, color: "text-blue-600" },
  { id: "risks", label: "Risk Assessments", icon: Activity, color: "text-rose-600" },
  { id: "activity", label: "User Activity", icon: Users, color: "text-purple-600" },
];

export default function Reports() {
  const { permissions } = usePermissions();
  const [activeTab, setActiveTab] = useState("compliance");

  if (!permissions.canGenerateReports && !permissions.canViewReports) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-slate-900 mb-2">Access Restricted</h2>
            <p className="text-sm text-slate-500">You don't have permission to view reports.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Reports</h1>
          <p className="text-sm text-slate-500 mt-1">Generate, filter, sort, and export compliance reports</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
           <TabsList className="bg-white border border-slate-200 mb-6 flex-wrap h-auto gap-1 p-1">
             {TABS.map(tab => (
               <TabsTrigger key={tab.id} value={tab.id} className="flex items-center gap-2 text-xs sm:text-sm">
                 <tab.icon className={`w-4 h-4 ${tab.color}`} />
                 <span className="hidden sm:inline">{tab.label}</span>
                 <span className="sm:hidden">{tab.label.split(" ")[0]}</span>
               </TabsTrigger>
             ))}
           </TabsList>

           <TabsContent value="generated"><GeneratedReportsView /></TabsContent>
           <TabsContent value="automation"><ScheduleAutomatedReports /></TabsContent>
           <TabsContent value="compliance"><ComplianceReportTab /></TabsContent>
           <TabsContent value="actions"><ActionItemsReportTab /></TabsContent>
           <TabsContent value="risks"><RiskReportTab /></TabsContent>
           <TabsContent value="activity"><UserActivityReportTab /></TabsContent>
         </Tabs>
      </div>
    </div>
  );
}