import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Building2, Users, Mail, Plus, Trash2, UserPlus, Shield,
  CheckCircle, Clock, XCircle, RefreshCw
} from "lucide-react";
import { format } from "date-fns";
import CreateOrganizationDialog from "@/components/organizations/CreateOrganizationDialog";
import InviteMemberDialog from "@/components/organizations/InviteMemberDialog";

const ROLE_COLORS = {
  org_admin: "bg-purple-100 text-purple-800",
  compliance_manager: "bg-blue-100 text-blue-800",
  auditor: "bg-amber-100 text-amber-800",
  viewer: "bg-slate-100 text-slate-600",
};

const ROLE_LABELS = {
  org_admin: "Org Admin",
  compliance_manager: "Compliance Manager",
  auditor: "Auditor",
  viewer: "Viewer",
};

const STATUS_CONFIG = {
  pending: { label: "Pending", icon: Clock, cls: "bg-amber-100 text-amber-700" },
  accepted: { label: "Accepted", icon: CheckCircle, cls: "bg-emerald-100 text-emerald-700" },
  expired: { label: "Expired", icon: XCircle, cls: "bg-slate-100 text-slate-500" },
  cancelled: { label: "Cancelled", icon: XCircle, cls: "bg-rose-100 text-rose-700" },
};

export default function OrganizationSettings() {
  const [showCreate, setShowCreate] = useState(false);
  const [showInvite, setShowInvite] = useState(false);
  const [selectedOrg, setSelectedOrg] = useState(null);
  const queryClient = useQueryClient();

  const { data: organizations = [], isLoading: loadingOrgs } = useQuery({
    queryKey: ["organizations"],
    queryFn: () => base44.entities.Organization.list("-created_date", 50),
  });

  const { data: members = [] } = useQuery({
    queryKey: ["org-members"],
    queryFn: () => base44.entities.OrganizationMember.list("-created_date", 200),
  });

  const { data: invitations = [] } = useQuery({
    queryKey: ["org-invitations"],
    queryFn: () => base44.entities.OrganizationInvitation.list("-created_date", 200),
  });

  const refetchAll = () => {
    queryClient.invalidateQueries({ queryKey: ["organizations"] });
    queryClient.invalidateQueries({ queryKey: ["org-members"] });
    queryClient.invalidateQueries({ queryKey: ["org-invitations"] });
  };

  const handleDeleteOrg = async (id) => {
    if (!window.confirm("Delete this organization? This cannot be undone.")) return;
    await base44.entities.Organization.delete(id);
    refetchAll();
  };

  const handleRemoveMember = async (id) => {
    if (!window.confirm("Remove this member?")) return;
    await base44.entities.OrganizationMember.delete(id);
    queryClient.invalidateQueries({ queryKey: ["org-members"] });
  };

  const handleCancelInvite = async (id) => {
    await base44.entities.OrganizationInvitation.update(id, { status: "cancelled" });
    queryClient.invalidateQueries({ queryKey: ["org-invitations"] });
  };

  const handleResendInvite = async (invite) => {
    await base44.integrations.Core.SendEmail({
      to: invite.invited_email,
      subject: `Reminder: You've been invited to join ${invite.organization_name} on Compliance Tracker`,
      body: `<h2>Invitation Reminder</h2><p>You have a pending invitation to join <strong>${invite.organization_name}</strong> as <strong>${ROLE_LABELS[invite.role]}</strong>. Please log in to accept.</p>`,
    });
    alert("Invitation resent successfully!");
  };

  const openInvite = (org) => { setSelectedOrg(org); setShowInvite(true); };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Organization Management</h1>
            <p className="text-sm text-slate-500 mt-1">Manage organizations and invite members to collaborate</p>
          </div>
          <Button onClick={() => setShowCreate(true)} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-2" />
            New Organization
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <Building2 className="w-9 h-9 p-2 rounded-lg bg-emerald-50 text-emerald-600" />
              <div>
                <div className="text-2xl font-bold text-slate-800">{organizations.length}</div>
                <div className="text-xs text-slate-500">Organizations</div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <Users className="w-9 h-9 p-2 rounded-lg bg-blue-50 text-blue-600" />
              <div>
                <div className="text-2xl font-bold text-slate-800">{members.length}</div>
                <div className="text-xs text-slate-500">Total Members</div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <Mail className="w-9 h-9 p-2 rounded-lg bg-amber-50 text-amber-600" />
              <div>
                <div className="text-2xl font-bold text-slate-800">
                  {invitations.filter(i => i.status === "pending").length}
                </div>
                <div className="text-xs text-slate-500">Pending Invites</div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="organizations">
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="organizations">Organizations</TabsTrigger>
            <TabsTrigger value="members">Members</TabsTrigger>
            <TabsTrigger value="invitations">Invitations</TabsTrigger>
          </TabsList>

          {/* Organizations Tab */}
          <TabsContent value="organizations" className="mt-4 space-y-4">
            {loadingOrgs ? (
              <div className="p-12 text-center text-slate-500">Loading...</div>
            ) : organizations.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-12 text-center">
                  <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500 mb-2">No organizations yet</p>
                  <p className="text-xs text-slate-400 mb-4">Create an organization to start inviting team members</p>
                  <Button onClick={() => setShowCreate(true)} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="w-4 h-4 mr-2" /> Create First Organization
                  </Button>
                </CardContent>
              </Card>
            ) : (
              organizations.map(org => {
                const orgMembers = members.filter(m => m.organization_id === org.id);
                const pendingInvites = invitations.filter(i => i.organization_id === org.id && i.status === "pending");
                return (
                  <Card key={org.id} className="border-0 shadow-sm">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-emerald-600 flex items-center justify-center flex-shrink-0">
                            <Building2 className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="font-semibold text-slate-900">{org.name}</h3>
                              {org.organization_id && (
                                <span className="text-xs font-mono bg-slate-100 text-slate-500 px-2 py-0.5 rounded">{org.organization_id}</span>
                              )}
                              <Badge className={org.is_active ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}>
                                {org.is_active ? "Active" : "Inactive"}
                              </Badge>
                            </div>
                            {org.description && <p className="text-sm text-slate-500 mt-0.5">{org.description}</p>}
                            <div className="flex flex-wrap gap-3 mt-2 text-xs text-slate-500">
                              {org.domain && <span>🌐 {org.domain}</span>}
                              {org.industry && <span>🏭 {org.industry}</span>}
                              {org.country && <span>📍 {org.country}</span>}
                              <span>👤 Owner: {org.owner_email}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Button size="sm" variant="outline" onClick={() => openInvite(org)}>
                            <UserPlus className="w-3.5 h-3.5 mr-1.5" /> Invite
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => handleDeleteOrg(org.id)} className="text-rose-500 hover:text-rose-700 hover:bg-rose-50">
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>

                      {/* Org stats */}
                      <div className="flex gap-4 mt-4 pt-4 border-t border-slate-100 text-xs text-slate-500">
                        <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> {orgMembers.length} members</span>
                        <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {pendingInvites.length} pending invites</span>
                        <span className="flex items-center gap-1"><Shield className="w-3.5 h-3.5" /> Max {org.max_members} members</span>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </TabsContent>

          {/* Members Tab */}
          <TabsContent value="members" className="mt-4">
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-slate-700">All Organization Members</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {members.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-sm">No members yet</div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {members.map(m => (
                      <div key={m.id} className="flex items-center justify-between px-5 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-semibold text-sm">
                            {(m.user_name || m.user_email)?.[0]?.toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-medium text-slate-800">{m.user_name || m.user_email}</p>
                            <p className="text-xs text-slate-500">{m.user_email} · {m.organization_name}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={ROLE_COLORS[m.role] || "bg-slate-100"}>{ROLE_LABELS[m.role] || m.role}</Badge>
                          <Badge className={m.status === "active" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}>
                            {m.status}
                          </Badge>
                          <button onClick={() => handleRemoveMember(m.id)} className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Invitations Tab */}
          <TabsContent value="invitations" className="mt-4">
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-slate-700">All Invitations</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {invitations.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-sm">No invitations sent yet</div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {invitations.map(inv => {
                      const statusCfg = STATUS_CONFIG[inv.status] || STATUS_CONFIG.pending;
                      const StatusIcon = statusCfg.icon;
                      return (
                        <div key={inv.id} className="flex items-center justify-between px-5 py-3">
                          <div className="flex items-center gap-3">
                            <Mail className="w-5 h-5 text-slate-400 flex-shrink-0" />
                            <div>
                              <p className="text-sm font-medium text-slate-800">{inv.invited_email}</p>
                              <p className="text-xs text-slate-500">
                                {inv.organization_name} · {ROLE_LABELS[inv.role]} · Invited by {inv.invited_by}
                                {inv.expires_at && ` · Expires ${format(new Date(inv.expires_at), "dd MMM yyyy")}`}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={`${statusCfg.cls} flex items-center gap-1`}>
                              <StatusIcon className="w-3 h-3" /> {statusCfg.label}
                            </Badge>
                            {inv.status === "pending" && (
                              <>
                                <button onClick={() => handleResendInvite(inv)} className="p-1.5 rounded hover:bg-blue-50 text-slate-400 hover:text-blue-600" title="Resend">
                                  <RefreshCw className="w-3.5 h-3.5" />
                                </button>
                                <button onClick={() => handleCancelInvite(inv.id)} className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600" title="Cancel">
                                  <XCircle className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <CreateOrganizationDialog
        open={showCreate}
        onClose={() => setShowCreate(false)}
        onCreated={refetchAll}
      />

      {selectedOrg && (
        <InviteMemberDialog
          open={showInvite}
          onClose={() => { setShowInvite(false); setSelectedOrg(null); }}
          organization={selectedOrg}
          onInvited={refetchAll}
        />
      )}
    </div>
  );
}