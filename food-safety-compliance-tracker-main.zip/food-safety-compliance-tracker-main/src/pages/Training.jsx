import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  GraduationCap, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  Play, 
  Loader2,
  BookOpen,
  Award,
  ClipboardList
} from "lucide-react";
import { toast } from "sonner";
import TrainingModuleDialog from "@/components/training/TrainingModuleDialog";
import CompetencyEvaluationTab from "@/components/training/CompetencyEvaluationTab";

const CATEGORY_CONFIG = {
  hazard_control: { label: "Hazard Control", color: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400" },
  documentation: { label: "Documentation", color: "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400" },
  process_improvement: { label: "Process Improvement", color: "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400" },
  risk_management: { label: "Risk Management", color: "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400" },
  quality_assurance: { label: "Quality Assurance", color: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-400" },
  regulatory_compliance: { label: "Regulatory Compliance", color: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/20 dark:text-indigo-400" }
};

const DIFFICULTY_CONFIG = {
  beginner: { label: "Beginner", color: "bg-green-100 text-green-800" },
  intermediate: { label: "Intermediate", color: "bg-yellow-100 text-yellow-800" },
  advanced: { label: "Advanced", color: "bg-red-100 text-red-800" }
};

export default function Training() {
  const [generating, setGenerating] = useState(false);
  const [selectedModule, setSelectedModule] = useState(null);
  const queryClient = useQueryClient();

  const { data: modules = [], isLoading } = useQuery({
    queryKey: ['training-modules'],
    queryFn: () => base44.entities.TrainingModule.filter({ is_published: true }, '-created_date', 50)
  });

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });

  const { data: progress = [] } = useQuery({
    queryKey: ['training-progress', user?.email],
    queryFn: () => base44.entities.UserTrainingProgress.filter({ user_email: user.email }),
    enabled: !!user
  });

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const response = await base44.functions.invoke('generateTrainingModule', {});
      queryClient.invalidateQueries({ queryKey: ['training-modules'] });
      toast.success('New training module generated');
    } catch (error) {
      toast.error('Failed to generate training');
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  const getModuleProgress = (moduleId) => {
    return progress.find(p => p.module_id === moduleId);
  };

  const completedCount = progress.filter(p => p.status === 'completed').length;
  const inProgressCount = progress.filter(p => p.status === 'in_progress').length;
  const avgScore = progress.length > 0 
    ? Math.round(progress.reduce((sum, p) => sum + (p.quiz_score || 0), 0) / progress.length)
    : 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <Tabs defaultValue="modules">
          <TabsList className="mb-6 border-b border-slate-200 bg-transparent p-0 h-auto justify-start rounded-none w-full">
            <TabsTrigger value="modules" className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> Training Modules
            </TabsTrigger>
            <TabsTrigger value="competency" className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent flex items-center gap-2">
              <ClipboardList className="w-4 h-4" /> Staff Competency Evaluations
            </TabsTrigger>
          </TabsList>

          <TabsContent value="competency">
            <CompetencyEvaluationTab />
          </TabsContent>

          <TabsContent value="modules">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
                Compliance Training
              </h1>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Personalized training based on your compliance gaps
              </p>
            </div>
          </div>
          <Button
            onClick={handleGenerate}
            disabled={generating}
            className="bg-emerald-600 hover:bg-emerald-700 min-h-[44px]"
          >
            {generating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate New Module
              </>
            )}
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{modules.length}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Available</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{completedCount}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Completed</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-yellow-50 dark:bg-yellow-900/20 flex items-center justify-center">
                  <Play className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{inProgressCount}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">In Progress</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-50 dark:bg-purple-900/20 flex items-center justify-center">
                  <Award className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{avgScore}%</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Avg Score</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Modules */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {modules.map(module => {
            const moduleProgress = getModuleProgress(module.id);
            const categoryConfig = CATEGORY_CONFIG[module.category] || {};
            const difficultyConfig = DIFFICULTY_CONFIG[module.difficulty] || {};

            return (
              <Card 
                key={module.id}
                className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setSelectedModule(module)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <CardTitle className="text-sm font-semibold text-slate-900 dark:text-white line-clamp-2">
                      {module.title}
                    </CardTitle>
                    {moduleProgress?.status === 'completed' && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Badge className={categoryConfig.color}>
                      {categoryConfig.label}
                    </Badge>
                    <Badge variant="outline" className={difficultyConfig.color}>
                      {difficultyConfig.label}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                    {module.description}
                  </p>
                  
                  <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <Clock className="w-3 h-3" />
                    <span>{module.estimated_minutes} min</span>
                    {module.quiz_questions && (
                      <>
                        <span>•</span>
                        <span>{module.quiz_questions.length} questions</span>
                      </>
                    )}
                  </div>

                  {moduleProgress && (
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-600 dark:text-slate-300">Progress</span>
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {moduleProgress.progress_percentage}%
                        </span>
                      </div>
                      <Progress value={moduleProgress.progress_percentage} className="h-1.5" />
                    </div>
                  )}

                  <Button 
                    className="w-full min-h-[44px]"
                    variant={moduleProgress?.status === 'completed' ? 'outline' : 'default'}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedModule(module);
                    }}
                  >
                    {moduleProgress?.status === 'completed' ? 'Review' : 
                     moduleProgress?.status === 'in_progress' ? 'Continue' : 'Start'}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {modules.length === 0 && (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-12 text-center">
              <GraduationCap className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
              <p className="text-slate-500 dark:text-slate-400 mb-4">
                No training modules yet. Generate one based on your compliance gaps.
              </p>
              <Button onClick={handleGenerate} disabled={generating} className="bg-emerald-600 hover:bg-emerald-700">
                <Sparkles className="w-4 h-4 mr-2" />
                Generate First Module
              </Button>
            </CardContent>
          </Card>
        )}

        <TrainingModuleDialog
          module={selectedModule}
          open={!!selectedModule}
          onClose={() => setSelectedModule(null)}
        />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}