import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ShieldCheck, CheckCircle2, Loader2 } from "lucide-react";

export default function RequestAccess() {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({ full_name: "", email: "", company: "" });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    base44.auth.me().then(u => {
      if (u) {
        setUser(u);
        setFormData(f => ({ ...f, full_name: u.full_name || "", email: u.email || "" }));
      }
    }).catch(() => {});
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await base44.functions.invoke("handleSignupRequest", {
        email: formData.email,
        full_name: formData.full_name,
        company: formData.company,
      });
      setSubmitted(true);
    } catch (err) {
      setError(err?.response?.data?.error || err.message || "Failed to submit request.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900">Request Access</h1>
              <p className="text-xs text-slate-500">FSMS Compliance Tracker</p>
            </div>
          </div>

          {submitted ? (
            <div className="text-center py-6 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <h2 className="text-lg font-semibold text-slate-900">Request Submitted!</h2>
              <p className="text-sm text-slate-500">
                Your access request has been received. You'll get an email once the admin reviews and approves it.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-sm text-slate-500 mb-4">
                Your account is awaiting approval. Complete the form below to request access.
              </p>

              <div className="space-y-1">
                <Label htmlFor="full_name">Full Name</Label>
                <Input
                  id="full_name"
                  required
                  value={formData.full_name}
                  onChange={e => setFormData(f => ({ ...f, full_name: e.target.value }))}
                  placeholder="Jane Smith"
                />
              </div>

              <div className="space-y-1">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={formData.email}
                  readOnly={!!user?.email}
                  onChange={e => setFormData(f => ({ ...f, email: e.target.value }))}
                  placeholder="jane@company.com"
                  className={user?.email ? "bg-slate-50 text-slate-500" : ""}
                />
              </div>

              <div className="space-y-1">
                <Label htmlFor="company">Company / Organisation</Label>
                <Input
                  id="company"
                  value={formData.company}
                  onChange={e => setFormData(f => ({ ...f, company: e.target.value }))}
                  placeholder="Acme Foods (Pty) Ltd"
                />
              </div>

              {error && (
                <p className="text-sm text-rose-600 bg-rose-50 rounded-lg px-3 py-2">{error}</p>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
              >
                {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Submitting...</> : "Submit Access Request"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}