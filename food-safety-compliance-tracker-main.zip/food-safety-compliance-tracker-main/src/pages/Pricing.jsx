import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Star, Zap, Building2 } from "lucide-react";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

const TIER_ICONS = {
  basic: Zap,
  pro: Star,
  enterprise: Building2,
};

const TIER_COLORS = {
  basic: "border-slate-200 bg-white",
  pro: "border-emerald-400 bg-emerald-50 ring-2 ring-emerald-400",
  enterprise: "border-slate-200 bg-white",
};

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState("monthly");
  const [loading, setLoading] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [currentSub, setCurrentSub] = useState(null);

  React.useEffect(() => {
    const load = async () => {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
        const res = await base44.functions.invoke("subscriptionBilling", {
          action: "get_subscription",
          user_email: user.email,
        });
        setCurrentSub(res.data?.subscription || null);
      } catch {
        // not logged in
      }
    };
    load();
  }, []);

  const { data: plans = [] } = useQuery({
    queryKey: ["price-plans"],
    queryFn: () => base44.entities.PricePlan.filter({ is_active: true }, "sort_order", 10),
  });

  const handleSubscribe = async (plan) => {
    if (!currentUser) {
      base44.auth.redirectToLogin(createPageUrl("Pricing"));
      return;
    }
    setLoading(plan.id);
    try {
      const res = await base44.functions.invoke("subscriptionBilling", {
        action: "create_subscription",
        plan_id: plan.id,
        billing_cycle: billingCycle,
        customer_name: currentUser.full_name || currentUser.email,
        customer_email: currentUser.email,
      });
      if (res.data?.success) {
        setCurrentSub(res.data.subscription);
        toast.success(`Subscribed to ${plan.name}! Invoice created in Xero.`);
      } else {
        toast.error("Failed to subscribe. Please try again.");
      }
    } catch {
      toast.error("Subscription failed. Please try again.");
    } finally {
      setLoading(null);
    }
  };

  const getPrice = (plan) =>
    billingCycle === "annual"
      ? plan.price_annual || plan.price_monthly * 12
      : plan.price_monthly;

  const getSaving = (plan) => {
    if (!plan.price_annual || billingCycle !== "annual") return null;
    const saving = plan.price_monthly * 12 - plan.price_annual;
    return saving > 0 ? saving : null;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-emerald-50/30 py-16 px-4">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">
          Simple, Transparent Pricing
        </h1>
        <p className="text-lg text-slate-500 max-w-xl mx-auto">
          Choose the plan that fits your compliance needs. All plans include core features with no hidden fees.
        </p>

        {/* Billing Toggle */}
        <div className="flex items-center justify-center gap-3 mt-8">
          <span className={`text-sm font-medium ${billingCycle === "monthly" ? "text-slate-900" : "text-slate-400"}`}>Monthly</span>
          <button
            onClick={() => setBillingCycle(c => c === "monthly" ? "annual" : "monthly")}
            className={`relative w-12 h-6 rounded-full transition-colors ${billingCycle === "annual" ? "bg-emerald-600" : "bg-slate-300"}`}
          >
            <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-transform ${billingCycle === "annual" ? "translate-x-7" : "translate-x-1"}`} />
          </button>
          <span className={`text-sm font-medium ${billingCycle === "annual" ? "text-slate-900" : "text-slate-400"}`}>
            Annual
            <Badge className="ml-2 bg-emerald-100 text-emerald-700 text-xs">Save up to 20%</Badge>
          </span>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => {
          const Icon = TIER_ICONS[plan.tier] || Star;
          const price = getPrice(plan);
          const saving = getSaving(plan);
          const isCurrentPlan = currentSub?.plan_id === plan.id;

          return (
            <div
              key={plan.id}
              className={`relative rounded-2xl border-2 p-8 flex flex-col ${TIER_COLORS[plan.tier]} transition-shadow hover:shadow-lg`}
            >
              {plan.is_popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge className="bg-emerald-600 text-white px-4 py-1 text-sm font-semibold shadow">
                    Most Popular
                  </Badge>
                </div>
              )}

              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${plan.tier === "pro" ? "bg-emerald-600" : "bg-slate-100"}`}>
                  <Icon className={`w-5 h-5 ${plan.tier === "pro" ? "text-white" : "text-slate-600"}`} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">{plan.name}</h3>
                  {plan.tagline && <p className="text-xs text-slate-500">{plan.tagline}</p>}
                </div>
              </div>

              <div className="mb-6">
              <div className="flex items-end gap-1">
                <span className="text-xs text-slate-500 mt-1">{plan.currency}</span>
                <span className="text-4xl font-bold text-slate-900">
                  {billingCycle === "annual"
                    ? Math.round(price / 12).toLocaleString()
                    : price?.toLocaleString()}
                </span>
                <span className="text-sm text-slate-400 mb-1">/mo</span>
              </div>
              {billingCycle === "annual" && (
                <p className="text-xs text-slate-500 mt-1">
                  Billed annually ({plan.currency} {price?.toLocaleString()}/yr)
                  {saving && <span className="text-emerald-600 font-semibold"> · Save {plan.currency} {saving.toLocaleString()}</span>}
                </p>
              )}
              {billingCycle === "monthly" && plan.price_annual && (
                <p className="text-xs text-emerald-600 mt-1">
                  Save {plan.currency} {Math.round(plan.price_monthly * 12 - plan.price_annual).toLocaleString()} with annual billing
                </p>
              )}
              </div>

              <ul className="space-y-2.5 mb-8 flex-1">
                {(plan.features || []).map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
                {plan.max_users && (
                  <li className="flex items-start gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    Up to {plan.max_users} users
                  </li>
                )}
              </ul>

              {isCurrentPlan ? (
                <Button className="w-full" variant="outline" disabled>
                  Current Plan
                </Button>
              ) : (
                <Button
                  className={`w-full ${plan.tier === "pro" ? "bg-emerald-600 hover:bg-emerald-700" : ""}`}
                  variant={plan.tier === "pro" ? "default" : "outline"}
                  onClick={() => handleSubscribe(plan)}
                  disabled={loading === plan.id}
                >
                  {loading === plan.id ? "Processing..." : `Get ${plan.name}`}
                </Button>
              )}
            </div>
          );
        })}
      </div>

      {plans.length === 0 && (
        <div className="text-center text-slate-500 py-12">Loading plans...</div>
      )}

      {/* Current subscription info */}
      {currentSub && (
        <div className="mt-10 text-center">
          <Badge className="bg-emerald-100 text-emerald-700 text-sm px-4 py-2">
            You're on the {currentSub.plan_name} plan · {currentSub.billing_cycle} · Next billing: {currentSub.next_billing_date}
          </Badge>
        </div>
      )}
    </div>
  );
}