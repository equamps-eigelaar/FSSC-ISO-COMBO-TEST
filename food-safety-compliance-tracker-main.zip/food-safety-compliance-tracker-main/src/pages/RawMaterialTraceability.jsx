import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Package, 
  Search, 
  Plus, 
  Download, 
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle
} from "lucide-react";
import { usePermissions } from "@/components/permissions/usePermissions";
import AddBatchDialog from "@/components/traceability/AddBatchDialog";
import BatchDetailDialog from "@/components/traceability/BatchDetailDialog";
import { toast } from "sonner";
import PullToRefresh from "@/components/mobile/PullToRefresh";

const STATUS_CONFIG = {
  pending_inspection: { 
    label: "Pending Inspection", 
    icon: Clock, 
    className: "bg-amber-50 text-amber-700 border-amber-200" 
  },
  approved: { 
    label: "Approved", 
    icon: CheckCircle, 
    className: "bg-emerald-50 text-emerald-700 border-emerald-200" 
  },
  rejected: { 
    label: "Rejected", 
    icon: XCircle, 
    className: "bg-rose-50 text-rose-700 border-rose-200" 
  },
  in_use: { 
    label: "In Use", 
    icon: Package, 
    className: "bg-blue-50 text-blue-700 border-blue-200" 
  },
  depleted: { 
    label: "Depleted", 
    icon: AlertCircle, 
    className: "bg-slate-100 text-slate-500 border-slate-200" 
  },
};

export default function RawMaterialTraceability() {
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [generatingDoc, setGeneratingDoc] = useState(null);

  const { permissions } = usePermissions();
  const queryClient = useQueryClient();

  const { data: batches = [], isLoading, refetch } = useQuery({
    queryKey: ["raw-material-batches"],
    queryFn: () => base44.entities.RawMaterialBatch.list("-created_date", 200),
  });

  const handleRefresh = async () => {
    await refetch();
  };

  const generateCertificate = async (batch) => {
    setGeneratingDoc("certificate");
    try {
      const response = await base44.functions.invoke("generateCertificateOfCompliance", {
        batch_id: batch.id,
      });
      
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Certificate_${batch.batch_number}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      
      toast.success("Certificate generated");
    } catch (error) {
      toast.error("Failed to generate certificate");
    } finally {
      setGeneratingDoc(null);
    }
  };

  const generateTDS = async (batch) => {
    setGeneratingDoc("tds");
    try {
      const response = await base44.functions.invoke("generateTechnicalDataSheet", {
        batch_id: batch.id,
      });
      
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `TDS_${batch.batch_number}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      
      toast.success("Technical data sheet generated");
    } catch (error) {
      toast.error("Failed to generate TDS");
    } finally {
      setGeneratingDoc(null);
    }
  };

  const filteredBatches = batches.filter(b =>
    b.batch_number?.toLowerCase().includes(search.toLowerCase()) ||
    b.po_number?.toLowerCase().includes(search.toLowerCase()) ||
    b.material_name?.toLowerCase().includes(search.toLowerCase()) ||
    b.supplier?.toLowerCase().includes(search.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Raw Material Traceability
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              {filteredBatches.length} batch{filteredBatches.length !== 1 ? "es" : ""} tracked
            </p>
          </div>
          {permissions.canEditAll && (
            <Button onClick={() => setShowAdd(true)} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Batch
            </Button>
          )}
        </div>

        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by batch, PO, material, or supplier..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 border-slate-200"
              />
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4">
          {filteredBatches.map(batch => {
            const statusConfig = STATUS_CONFIG[batch.status] || STATUS_CONFIG.pending_inspection;
            const StatusIcon = statusConfig.icon;

            return (
              <Card key={batch.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-sm font-semibold text-slate-900">
                          {batch.material_name}
                        </h3>
                        <Badge variant="outline" className={statusConfig.className}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {statusConfig.label}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2 text-xs">
                        <div>
                          <span className="text-slate-500">Batch:</span>
                          <span className="ml-1 font-mono font-medium text-slate-900">
                            {batch.batch_number}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500">PO:</span>
                          <span className="ml-1 font-medium text-slate-900">
                            {batch.po_number}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500">Supplier:</span>
                          <span className="ml-1 text-slate-700">
                            {batch.supplier}
                          </span>
                        </div>
                        {batch.quantity && (
                          <div>
                            <span className="text-slate-500">Qty:</span>
                            <span className="ml-1 text-slate-700">
                              {batch.quantity} {batch.unit}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => generateCertificate(batch)}
                        disabled={generatingDoc === "certificate" || batch.status !== "approved"}
                        className="gap-1.5 min-h-[44px]"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        Certificate
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => generateTDS(batch)}
                        disabled={generatingDoc === "tds" || batch.status !== "approved"}
                        className="gap-1.5 min-h-[44px]"
                      >
                        <Download className="w-3.5 h-3.5" />
                        TDS
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelectedBatch(batch)}
                        className="min-h-[44px]"
                      >
                        View
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {filteredBatches.length === 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <Package className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No batches found</p>
              </CardContent>
            </Card>
          )}
        </div>
        </div>
      </div>

      <AddBatchDialog open={showAdd} onClose={() => setShowAdd(false)} />
      {selectedBatch && (
        <BatchDetailDialog
          batch={selectedBatch}
          open={!!selectedBatch}
          onClose={() => setSelectedBatch(null)}
        />
      )}
    </PullToRefresh>
  );
}