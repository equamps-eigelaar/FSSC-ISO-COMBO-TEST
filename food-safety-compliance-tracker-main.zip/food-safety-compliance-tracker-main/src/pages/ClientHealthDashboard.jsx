import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  CheckCircle2, AlertTriangle, XCircle, Mail, RefreshCw,
  Building2, Search, SendHorizontal, Filter
} from "lucide-react";
import ClientHealthCard from "@/components/clienthealth/ClientHealthCard";
import CorrectiveActionDialog from "@/components/clienthealth/CorrectiveActionDialog";
import SendSummaryEmailDialog from "@/components/clienthealth/SendSummaryEmailDialog";
import { toast } from "sonner";

const FILTERS = [
  { key: "all", label: "All Clients", icon: Building2, color: "bg-slate-100 text-slate-700" },
  { key: "green", label: "On Track", icon: CheckCircle2, color: "bg-emerald-100 text-emerald-700" },
  { key: "amber", label: "Attention", icon: AlertTriangle, color: "bg-amber-100 text-amber-700" },
  { key: "red", label: "Critical", icon: XCircle, color: "bg-rose-100 text-rose-700" },
];

export default function ClientHealthDashboard() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [actionOrg, setActionOrg] = useState(null);
  const [emailOrg, setEmailOrg] = useState(null);
  const [batchSending, setBatchSending] = useState(false);

  const { data: organizations = [], isLoading } = useQuery({
    queryKey: ["organizations-health"],
    queryFn: () => base44.entities.Organization.list("-created_date", 200),
  });

  const refetch = () => queryClient.invalidateQueries({ queryKey: ["organizations-health"] });

  const handleUpdateStatus = async (org, status) => {
    await base44.entities.Organization.update(org.id, { health_status: status });
    toast.success(`${org.name} marked as ${status}`);
    refetch();
  };

  const handleBatchSendGreen = async () => {
    const greenOrgs = organizations.filter(o => o.health_status === "green" && (o.contact_email || o.owner_email));
    if (greenOrgs.length === 0) {
      toast.info("No green clients with email addresses found.");
      return;
    }
    setBatchSending(true);
    const month = new Date().toLocaleString("default", { month: "long", year: "numeric" });
    let sent = 0;
    for (const org of greenOrgs) {
      const to = org.contact_email || org.owner_email;
      const body = `Hi ${org.contact_name || "there"},<br><br>
Here is your monthly compliance summary for <strong>${month}</strong>.<br><br>
✅ <strong>Compliance Score:</strong> ${org.compliance_score != null ? org.compliance_score + "%" : "Awaiting update"}<br>
📋 <strong>Open Action Items:</strong> ${org.open_actions_count || 0}<br>
⚠️ <strong>Critical Issues:</strong> ${org.critical_issues_count || 0}<br><br>
Great news — your organisation is on track and meeting all key compliance requirements. No immediate action is required this month.<br><br>
If you have any questions, please don't hesitate to reach out.<br><br>
Kind regards,<br>Your Compliance Team`;
      await base44.integrations.Core.SendEmail({
        to,
        subject: `Monthly Compliance Summary — ${org.name} — ${month}`,
        body,
      });
      await base44.entities.Organization.update(org.id, {
        last_monthly_email_sent: new Date().toISOString().slice(0, 10),
      });
      sent++;
    }
    setBatchSending(false);
    toast.success(`Monthly summaries sent to ${sent} green client(s)`);
    refetch();
  };

  const filtered = organizations.filter(org => {
    const matchesFilter = filter === "all" || org.health_status === filter;
    const matchesSearch = !search ||
      org.name.toLowerCase().includes(search.toLowerCase()) ||
      (org.contact_name || "").toLowerCase().includes(search.toLowerCase()) ||
      (org.industry || "").toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const greenCount = organizations.filter(o => o.health_status === "green").length;
  const amberCount = organizations.filter(o => o.health_status === "amber").length;
  const redCount = organizations.filter(o => o.health_status === "red").length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Client Health Dashboard</h1>
            <p className="text-sm text-slate-500 mt-0.5">Monitor compliance status across all client organisations</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={refetch}
              className="gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Refresh
            </Button>
            <Button
              size="sm"
              onClick={handleBatchSendGreen}
              disabled={batchSending || greenCount === 0}
              className="bg-emerald-600 hover:bg-emerald-700 gap-1.5"
            >
              <SendHorizontal className="w-3.5 h-3.5" />
              {batchSending ? "Sending..." : `Batch Email Green (${greenCount})`}
            </Button>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 flex items-center gap-3">
              <Building2 className="w-9 h-9 p-2 rounded-lg bg-slate-100 text-slate-600" />
              <div>
                <div className="text-2xl font-bold text-slate-800">{organizations.length}</div>
                <div className="text-xs text-slate-500">Total Clients</div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm border-l-4 border-l-emerald-500">
            <CardContent className="p-4 flex items-center gap-3">
              <CheckCircle2 className="w-9 h-9 p-2 rounded-lg bg-emerald-50 text-emerald-600" />
              <div>
                <div className="text-2xl font-bold text-emerald-700">{greenCount}</div>
                <div className="text-xs text-slate-500">On Track</div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm border-l-4 border-l-amber-500">
            <CardContent className="p-4 flex items-center gap-3">
              <AlertTriangle className="w-9 h-9 p-2 rounded-lg bg-amber-50 text-amber-600" />
              <div>
                <div className="text-2xl font-bold text-amber-700">{amberCount}</div>
                <div className="text-xs text-slate-500">Needs Attention</div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm border-l-4 border-l-rose-500">
            <CardContent className="p-4 flex items-center gap-3">
              <XCircle className="w-9 h-9 p-2 rounded-lg bg-rose-50 text-rose-600" />
              <div>
                <div className="text-2xl font-bold text-rose-700">{redCount}</div>
                <div className="text-xs text-slate-500">Critical</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters + Search */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 mb-6">
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="w-4 h-4 text-slate-400" />
            {FILTERS.map(f => {
              const Icon = f.icon;
              return (
                <button
                  key={f.key}
                  onClick={() => setFilter(f.key)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                    filter === f.key ? f.color + " ring-2 ring-offset-1 ring-slate-300" : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {f.label}
                </button>
              );
            })}
          </div>
          <div className="relative flex-1 max-w-xs">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input
              className="pl-9 h-8 text-sm"
              placeholder="Search clients..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </div>

        {/* Red clients alert banner */}
        {redCount > 0 && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-3">
            <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-rose-800">{redCount} client{redCount > 1 ? "s" : ""} require immediate attention</p>
              <p className="text-xs text-rose-600 mt-0.5">Schedule 15–30 min review calls and assign corrective actions</p>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="border-rose-300 text-rose-700 hover:bg-rose-100 flex-shrink-0"
              onClick={() => setFilter("red")}
            >
              View Critical
            </Button>
          </div>
        )}

        {/* Client Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-16 text-center">
              <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 mb-1">
                {organizations.length === 0 ? "No client organisations yet" : "No clients match the current filter"}
              </p>
              <p className="text-xs text-slate-400">
                {organizations.length === 0
                  ? "Add organisations in Organization Settings to track their health"
                  : "Try adjusting the filter or search"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(org => (
              <ClientHealthCard
                key={org.id}
                org={org}
                onSendEmail={setEmailOrg}
                onViewActions={setActionOrg}
                onUpdateStatus={handleUpdateStatus}
              />
            ))}
          </div>
        )}
      </div>

      <CorrectiveActionDialog
        org={actionOrg}
        open={!!actionOrg}
        onClose={() => setActionOrg(null)}
        onSaved={refetch}
      />

      <SendSummaryEmailDialog
        org={emailOrg}
        open={!!emailOrg}
        onClose={() => setEmailOrg(null)}
        onSent={refetch}
      />
    </div>
  );
}