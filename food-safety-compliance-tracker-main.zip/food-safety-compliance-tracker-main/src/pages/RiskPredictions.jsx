import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  Play, 
  AlertTriangle, 
  Target,
  Sparkles,
  Clock,
  Loader2,
  CheckCircle,
  Eye
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { usePermissions } from "@/components/permissions/usePermissions";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function RiskPredictions() {
  const { permissions } = usePermissions();
  const queryClient = useQueryClient();
  const [filterStatus, setFilterStatus] = useState("active");

  const { data: predictions = [], isLoading } = useQuery({
    queryKey: ['risk-predictions', filterStatus],
    queryFn: async () => {
      if (filterStatus === "all") {
        return base44.entities.RiskPrediction.list("-prediction_date", 100);
      }
      return base44.entities.RiskPrediction.filter({ status: filterStatus }, "-prediction_date", 100);
    }
  });

  const runPredictionMutation = useMutation({
    mutationFn: () => base44.functions.invoke('predictFutureRisks'),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ['risk-predictions'] });
      toast.success(`Generated ${response.data.predictions_count} risk predictions`);
    },
    onError: () => toast.error("Failed to generate predictions")
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.RiskPrediction.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['risk-predictions'] });
      toast.success("Status updated");
    }
  });

  const getLikelihoodColor = (likelihood) => {
    const colors = {
      very_high: "bg-rose-100 text-rose-800 border-rose-300",
      high: "bg-orange-100 text-orange-800 border-orange-300",
      medium: "bg-amber-100 text-amber-800 border-amber-300",
      low: "bg-blue-100 text-blue-800 border-blue-300"
    };
    return colors[likelihood] || "bg-slate-100 text-slate-800";
  };

  const getSeverityColor = (severity) => {
    const colors = {
      critical: "bg-rose-50 text-rose-700 border-rose-200",
      high: "bg-orange-50 text-orange-700 border-orange-200",
      medium: "bg-amber-50 text-amber-700 border-amber-200",
      low: "bg-blue-50 text-blue-700 border-blue-200"
    };
    return colors[severity] || "bg-slate-50 text-slate-700";
  };

  const activePredictions = predictions.filter(p => p.status === 'active');
  const highPriority = activePredictions.filter(p => p.priority_score >= 70).length;
  const avgConfidence = activePredictions.length > 0 
    ? (activePredictions.reduce((sum, p) => sum + (p.confidence || 0), 0) / activePredictions.length).toFixed(1)
    : 0;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-indigo-600" />
              AI Risk Predictions
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Predictive analytics for proactive risk management
            </p>
          </div>
          {permissions.canManageAudits && (
            <Button 
              onClick={() => runPredictionMutation.mutate()}
              disabled={runPredictionMutation.isPending}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              {runPredictionMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing...</>
              ) : (
                <><Play className="w-4 h-4 mr-2" />Generate Predictions</>
              )}
            </Button>
          )}
        </div>

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-4 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-indigo-600" />
                <span className="text-xs text-slate-500">Active Predictions</span>
              </div>
              <div className="text-3xl font-bold text-indigo-700">{activePredictions.length}</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span className="text-xs text-slate-500">High Priority</span>
              </div>
              <div className="text-3xl font-bold text-rose-700">{highPriority}</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-purple-600" />
                <span className="text-xs text-slate-500">Avg Confidence</span>
              </div>
              <div className="text-3xl font-bold text-purple-700">{avgConfidence}%</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span className="text-xs text-slate-500">Mitigated</span>
              </div>
              <div className="text-3xl font-bold text-emerald-700">
                {predictions.filter(p => p.status === 'mitigated').length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 mb-4">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active Predictions</SelectItem>
              <SelectItem value="monitoring">Monitoring</SelectItem>
              <SelectItem value="mitigated">Mitigated</SelectItem>
              <SelectItem value="occurred">Occurred</SelectItem>
              <SelectItem value="all">All</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Predictions List */}
        <div className="space-y-4">
          {predictions.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <TrendingUp className="w-16 h-16 text-indigo-200 mx-auto mb-4" />
                <p className="text-slate-600 mb-2">No predictions available</p>
                <p className="text-sm text-slate-400 mb-4">
                  Run AI analysis to generate predictive insights
                </p>
                {permissions.canManageAudits && (
                  <Button onClick={() => runPredictionMutation.mutate()} className="bg-indigo-600">
                    <Play className="w-4 h-4 mr-2" />
                    Generate Predictions
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            predictions.map((pred) => (
              <Card key={pred.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <CardTitle className="text-base font-semibold text-slate-900 mb-2">
                        {pred.risk_area}
                      </CardTitle>
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline" className={getLikelihoodColor(pred.likelihood)}>
                          {pred.likelihood} likelihood
                        </Badge>
                        <Badge variant="outline" className={getSeverityColor(pred.severity)}>
                          {pred.severity} severity
                        </Badge>
                        <Badge variant="outline" className="bg-purple-50 text-purple-700">
                          {pred.confidence}% confidence
                        </Badge>
                        <Badge variant="outline">
                          <Clock className="w-3 h-3 mr-1" />
                          {pred.timeframe}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-indigo-700 mb-1">
                        {pred.priority_score}
                      </div>
                      <div className="text-xs text-slate-500">Priority Score</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-slate-600">{pred.description}</p>

                  {pred.indicators?.length > 0 && (
                    <div>
                      <h4 className="text-xs font-semibold text-slate-900 mb-2">Trend Indicators</h4>
                      <div className="flex flex-wrap gap-2">
                        {pred.indicators.map((ind, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            <Eye className="w-3 h-3 mr-1" />
                            {ind}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {pred.recommended_actions?.length > 0 && (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                      <h4 className="text-xs font-semibold text-emerald-900 mb-2">Recommended Actions</h4>
                      <ul className="space-y-1">
                        {pred.recommended_actions.map((action, idx) => (
                          <li key={idx} className="text-xs text-emerald-800 flex items-start gap-2">
                            <div className="w-1 h-1 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                            {action}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-3 border-t">
                    <div className="text-xs text-slate-500">
                      Predicted: {format(new Date(pred.prediction_date), "MMM d, yyyy")}
                    </div>
                    {permissions.canManageAudits && (
                      <Select 
                        value={pred.status} 
                        onValueChange={(status) => updateStatusMutation.mutate({ id: pred.id, status })}
                      >
                        <SelectTrigger className="w-32 h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="monitoring">Monitoring</SelectItem>
                          <SelectItem value="mitigated">Mitigated</SelectItem>
                          <SelectItem value="occurred">Occurred</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}