import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTheme } from '@/components/theme/ThemeProvider';
import { Sun, Moon, Trash2, Bell, Settings as SettingsIcon, Monitor, LogOut } from 'lucide-react';
import { toast } from 'sonner';
import NotificationPreferencesPanel from '@/components/notifications/NotificationPreferencesPanel';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    try {
      const user = await base44.auth.me();
      if (user) {
        // Use service role to delete the user account
        await base44.asServiceRole.entities.User.delete(user.id);
        // Logout and redirect
        await base44.auth.logout('/');
        toast.success('Account deleted successfully');
      }
    } catch (error) {
      console.error('Delete account error:', error);
      toast.error('Failed to delete account. Please contact support.');
      setIsDeleting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 overflow-y-auto">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8 pb-24">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <SettingsIcon className="w-6 h-6" />
            Settings
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage your preferences and account
          </p>
        </div>

        <Tabs defaultValue="appearance" className="w-full">
          <TabsList className="grid w-full grid-cols-2 dark:bg-slate-800">
            <TabsTrigger value="appearance" className="dark:text-slate-300">Appearance</TabsTrigger>
            <TabsTrigger value="notifications" className="dark:text-slate-300">Notifications</TabsTrigger>
          </TabsList>

          <TabsContent value="appearance" className="space-y-4 mt-4">
            <Card className="border-0 shadow-sm dark:bg-slate-900 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-base dark:text-white">Appearance</CardTitle>
              </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {theme === 'dark' ? (
                    <Moon className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                  ) : (
                    <Sun className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                  )}
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-white">Dark Mode</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {theme === 'dark' ? 'Enabled' : 'Disabled'}
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                  className="min-h-[44px] select-none dark:bg-slate-800 dark:text-white dark:border-slate-700"
                >
                  Toggle Theme
                </Button>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <LogOut className="w-5 h-5 text-rose-600" />
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-white">Log Out</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Sign out of your account</p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  onClick={() => base44.auth.logout()}
                  className="min-h-[44px] select-none text-rose-600 border-rose-200 hover:bg-rose-50"
                >
                  Log Out
                </Button>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <Monitor className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-white">Remote Support</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Download AnyDesk for remote assistance
                    </p>
                  </div>
                </div>
                <a href="https://anydesk.com/en/downloads" target="_blank" rel="noopener noreferrer">
                  <Button
                    variant="outline"
                    className="min-h-[44px] select-none text-blue-600 border-blue-200 hover:bg-blue-50"
                  >
                    AnyDesk
                  </Button>
                </a>
              </div>
            </CardContent>
            </Card>
            </TabsContent>

            <TabsContent value="notifications" className="mt-4">
            <Card className="border-0 shadow-sm dark:bg-slate-900 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-base dark:text-white flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Notification Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <NotificationPreferencesPanel />
              </CardContent>
            </Card>
            </TabsContent>

            <TabsContent value="appearance" className="space-y-4 mt-4">
            <Card className="border-0 shadow-sm dark:bg-slate-900 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-base text-rose-600 dark:text-rose-400">Danger Zone</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Trash2 className="w-5 h-5 text-rose-600" />
                    <div>
                      <p className="text-sm font-medium text-slate-900 dark:text-white">Delete Account</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Permanently delete your account and all data
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="destructive"
                    onClick={() => setShowDeleteDialog(true)}
                    className="min-h-[44px] select-none"
                  >
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
            </TabsContent>
            </Tabs>
            </div>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="dark:bg-slate-900 dark:border-slate-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="dark:text-white">Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription className="dark:text-slate-400">
              This action cannot be undone. This will permanently delete your account and remove all 
              your data from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="min-h-[44px] dark:bg-slate-800 dark:text-white dark:border-slate-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteAccount}
              disabled={isDeleting}
              className="min-h-[44px] bg-rose-600 hover:bg-rose-700"
            >
              {isDeleting ? 'Deleting...' : 'Delete Account'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}