import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lock } from "lucide-react";

export default function ConfidentialityAgreement() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <Lock className="w-8 h-8 text-emerald-600" />
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
              Confidentiality & Non-Disclosure Agreement
            </h1>
          </div>
          <p className="text-sm text-slate-500">
            Effective date: 11 March 2026 — applies to all authorised users of the FSMS Compliance Tracker platform.
          </p>
        </div>

        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-6">
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
              This Confidentiality and Non-Disclosure Agreement ("<strong>Agreement</strong>") is entered into between{" "}
              <strong>CTP Flexibles (Pty) Ltd</strong> and its authorised personnel ("<strong>Disclosing Party</strong>") and 
              each authorised user of the <strong>FSMS Compliance Tracker</strong> platform ("<strong>Receiving Party</strong>"). 
              By accessing or using the platform, you agree to be legally bound by this Agreement.
            </p>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <NDASection
            number="1"
            title="Definition of Confidential Information"
            content={
              <>
                <p className="mb-3">
                  "<strong>Confidential Information</strong>" means all non-public information disclosed through or accessible via 
                  the FSMS Compliance Tracker platform, including but not limited to:
                </p>
                <ul className="list-disc pl-6 space-y-1 mb-3">
                  <li>Food safety management system (FSMS) documentation, procedures, and policies</li>
                  <li>HACCP plans, CCP/OPRP records, risk assessments, and hazard analyses</li>
                  <li>Supplier profiles, assessments, questionnaires, and audit findings</li>
                  <li>Compliance records, audit results, corrective actions, and evidence files</li>
                  <li>Raw material and food batch traceability records</li>
                  <li>Temperature logs, cleaning registers, and monitoring data</li>
                  <li>Internal processes, workflows, and proprietary compliance methodologies</li>
                  <li>Commercial terms, pricing, customer lists, and business strategies</li>
                  <li>All data stored, processed, or generated within the platform</li>
                  <li>The platform's software, algorithms, AI models, features, and source code ("<strong>Intellectual Property</strong>")</li>
                </ul>
                <p className="text-sm italic text-slate-500">
                  Information is deemed Confidential whether or not it is marked as such, provided it is of a nature that a 
                  reasonable person would consider proprietary or sensitive.
                </p>
              </>
            }
          />

          <NDASection
            number="2"
            title="Obligations of the Receiving Party"
            content={
              <>
                <p className="mb-3">Each authorised user agrees to:</p>
                <ul className="list-disc pl-6 space-y-1 mb-3">
                  <li>Hold all Confidential Information in strict confidence and treat it with at least the same degree of care as they protect their own confidential information (but no less than reasonable care)</li>
                  <li>Use Confidential Information <strong>solely</strong> for the purpose of performing their authorised duties within the organisation</li>
                  <li>Not disclose, publish, share, copy, or distribute any Confidential Information to any third party without prior written consent from the Disclosing Party</li>
                  <li>Not use any Confidential Information for personal gain, competitive advantage, or any purpose outside the scope of authorised use</li>
                  <li>Promptly notify the Disclosing Party upon becoming aware of any unauthorised disclosure or breach of this Agreement</li>
                  <li>Not reverse-engineer, decompile, or attempt to derive the source code or underlying algorithms of the platform</li>
                </ul>
              </>
            }
          />

          <NDASection
            number="3"
            title="Intellectual Property Rights"
            content={
              <>
                <p className="mb-3">
                  The FSMS Compliance Tracker platform, including all software, code, AI models, features, user interface designs, 
                  methodologies, templates, and generated content, is the exclusive intellectual property of the Disclosing Party 
                  and its licensors.
                </p>
                <ul className="list-disc pl-6 space-y-1 mb-3">
                  <li>No licence, ownership right, or intellectual property right is transferred to the Receiving Party by virtue of accessing or using the platform</li>
                  <li>Authorised users are granted a <strong>limited, non-exclusive, non-transferable licence</strong> to use the platform solely for internal compliance management purposes</li>
                  <li>Any feedback, suggestions, or improvements contributed by users become the property of the Disclosing Party</li>
                  <li>The Receiving Party must not reproduce, distribute, sublicence, sell, or create derivative works based on the platform or its content</li>
                </ul>
              </>
            }
          />

          <NDASection
            number="4"
            title="Permitted Disclosures"
            content={
              <>
                <p className="mb-3">The obligations in this Agreement do not apply to information that:</p>
                <ul className="list-disc pl-6 space-y-1 mb-3">
                  <li>Was already in the public domain at the time of disclosure, without breach of this Agreement</li>
                  <li>Was independently developed by the Receiving Party without use of Confidential Information</li>
                  <li>Was received from a third party who was lawfully entitled to disclose it</li>
                  <li>Is required to be disclosed by applicable law, court order, or regulatory authority — in which case the Receiving Party shall provide advance notice to the Disclosing Party where legally permissible</li>
                </ul>
                <p className="mb-3">Notwithstanding the above, the following <strong>authorised disclosures</strong> are permitted:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Sharing compliance records with <strong>authorised certification bodies or third-party auditors</strong> as part of a formal FSSC 22000 or equivalent audit process</li>
                  <li>Submission of documentation to <strong>regulatory authorities</strong> as required by South African food safety law</li>
                  <li>Sharing with internal personnel who have a legitimate need-to-know for compliance purposes</li>
                </ul>
              </>
            }
          />

          <NDASection
            number="5"
            title="Data Ownership"
            content={
              <>
                <p className="mb-3">
                  All compliance data, records, documents, and information entered into the platform by an organisation 
                  remain the <strong>property of that organisation</strong>. The platform provider does not claim ownership 
                  of client-generated data.
                </p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Client data is logically isolated per organisation through row-level security controls</li>
                  <li>No organisation can access another organisation's data</li>
                  <li>Upon termination of access, organisations may request export of their data</li>
                  <li>The platform provider processes client data solely to deliver the platform's services and as described in the Privacy Policy</li>
                </ul>
              </>
            }
          />

          <NDASection
            number="6"
            title="Term and Survival"
            content={
              <p>
                This Agreement takes effect upon the Receiving Party's first access to the platform and remains in force 
                for the duration of their authorised access. The confidentiality obligations in <strong>Sections 1, 2, and 3</strong> survive 
                termination of access and remain binding for a period of <strong>five (5) years</strong> following the date of last access 
                or such longer period as required by applicable food safety record-retention regulations.
              </p>
            }
          />

          <NDASection
            number="7"
            title="Consequences of Breach"
            content={
              <>
                <p className="mb-3">
                  A breach of this Agreement may result in:
                </p>
                <ul className="list-disc pl-6 space-y-1 mb-3">
                  <li>Immediate suspension or termination of platform access</li>
                  <li>Civil liability for damages, including consequential and reputational losses</li>
                  <li>Disciplinary action in accordance with the organisation's policies</li>
                  <li>Legal proceedings under applicable South African law, including the{" "}
                    <em>Protection of Personal Information Act (POPIA)</em>,{" "}
                    <em>Electronic Communications and Transactions Act (ECTA)</em>, and common law</li>
                </ul>
                <p className="text-sm italic text-slate-500">
                  The Receiving Party acknowledges that a breach may cause irreparable harm for which monetary damages may be 
                  inadequate, and the Disclosing Party shall be entitled to seek injunctive relief without the requirement to 
                  post bond.
                </p>
              </>
            }
          />

          <NDASection
            number="8"
            title="Governing Law"
            content={
              <p>
                This Agreement is governed by the laws of the <strong>Republic of South Africa</strong>. 
                Any dispute arising from or related to this Agreement shall be subject to the exclusive jurisdiction 
                of the South African courts. The parties agree to attempt to resolve disputes through good-faith 
                negotiation before initiating formal proceedings.
              </p>
            }
          />

          <NDASection
            number="9"
            title="Acceptance"
            content={
              <p>
                By accessing and using the FSMS Compliance Tracker platform, you confirm that you have read, 
                understood, and agree to be bound by this Confidentiality and Non-Disclosure Agreement. 
                This Agreement is electronically accepted and constitutes a legally binding agreement in 
                accordance with the <strong>Electronic Communications and Transactions Act 25 of 2002 (ECTA)</strong>.
              </p>
            }
          />
        </div>
      </div>
    </div>
  );
}

function NDASection({ number, title, content }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold text-slate-900 dark:text-white">
          {number}. {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
        {content}
      </CardContent>
    </Card>
  );
}