import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Plus, Calendar, ClipboardList, User, RefreshCw, Search,
  ChevronRight, ArrowLeft, CheckCircle2, Clock, XCircle
} from "lucide-react";
import { format } from "date-fns";
import ScheduleAuditDialog from "@/components/audits/ScheduleAuditDialog";
import AuditChecklistPanel from "@/components/audits/AuditChecklistPanel";

const STATUS_CONFIG = {
  suggested:   { label: "Suggested",   color: "bg-slate-100 text-slate-600" },
  approved:    { label: "Approved",    color: "bg-blue-100 text-blue-700" },
  scheduled:   { label: "Scheduled",   color: "bg-indigo-100 text-indigo-700" },
  in_progress: { label: "In Progress", color: "bg-amber-100 text-amber-700" },
  completed:   { label: "Completed",   color: "bg-emerald-100 text-emerald-700" },
  cancelled:   { label: "Cancelled",   color: "bg-rose-100 text-rose-700" },
};

const PRIORITY_CONFIG = {
  low:      "bg-slate-100 text-slate-500",
  medium:   "bg-blue-100 text-blue-700",
  high:     "bg-orange-100 text-orange-700",
  critical: "bg-rose-100 text-rose-700",
};

export default function InternalAudits() {
  const [showSchedule, setShowSchedule] = useState(false);
  const [selectedAudit, setSelectedAudit] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [search, setSearch] = useState("");

  const { data: audits = [], isLoading, refetch } = useQuery({
    queryKey: ["audit-plans"],
    queryFn: () => base44.entities.AuditPlan.filter({ audit_type: "internal" }, "-suggested_date", 100),
  });

  const filtered = audits.filter(a => {
    const matchStatus = statusFilter === "all" || a.status === statusFilter;
    const matchSearch = !search || a.title?.toLowerCase().includes(search.toLowerCase()) || a.assigned_auditor?.includes(search);
    return matchStatus && matchSearch;
  });

  const stats = {
    scheduled: audits.filter(a => a.status === "scheduled").length,
    in_progress: audits.filter(a => a.status === "in_progress").length,
    completed: audits.filter(a => a.status === "completed").length,
  };

  if (selectedAudit) {
    const checklistProgress = selectedAudit.checklist?.length
      ? Math.round((selectedAudit.checklist.filter(i => i.status !== "not_checked").length / selectedAudit.checklist.length) * 100)
      : 0;

    return (
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
          <button
            onClick={() => setSelectedAudit(null)}
            className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 hover:bg-slate-100 px-3 py-2 rounded-lg mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Audits
          </button>

          <div className="mb-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Badge className={STATUS_CONFIG[selectedAudit.status]?.color}>{STATUS_CONFIG[selectedAudit.status]?.label}</Badge>
                  {selectedAudit.recurrence !== "none" && (
                    <Badge className="bg-violet-100 text-violet-700 gap-1">
                      <RefreshCw className="w-2.5 h-2.5" /> {selectedAudit.recurrence}
                    </Badge>
                  )}
                </div>
                <h1 className="text-xl font-bold text-slate-900">{selectedAudit.title}</h1>
                <div className="flex flex-wrap gap-3 mt-2 text-xs text-slate-500">
                  {selectedAudit.suggested_date && (
                    <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{format(new Date(selectedAudit.suggested_date), "d MMM yyyy")}</span>
                  )}
                  {selectedAudit.assigned_auditor && (
                    <span className="flex items-center gap-1"><User className="w-3.5 h-3.5" />{selectedAudit.assigned_auditor}</span>
                  )}
                  {selectedAudit.checklist?.length > 0 && (
                    <span className="flex items-center gap-1"><ClipboardList className="w-3.5 h-3.5" />{selectedAudit.checklist.length} items • {checklistProgress}% done</span>
                  )}
                </div>
              </div>
            </div>
            {selectedAudit.scope && (
              <p className="text-sm text-slate-600 mt-3 bg-white rounded-lg p-3 border border-slate-100">{selectedAudit.scope}</p>
            )}
          </div>

          {selectedAudit.checklist?.length > 0 ? (
            <AuditChecklistPanel
              audit={selectedAudit}
              onSaved={() => {
                refetch().then(res => {
                  const updated = res.data?.find(a => a.id === selectedAudit.id);
                  if (updated) setSelectedAudit(updated);
                });
              }}
            />
          ) : (
            <Card className="border-0 shadow-sm">
              <CardContent className="py-12 text-center text-slate-400">
                <ClipboardList className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">No checklist items for this audit.</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-start justify-between mb-6 gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Internal Audits</h1>
            <p className="text-sm text-slate-500 mt-1">Schedule recurring internal audits and manage checklists</p>
          </div>
          <Button className="bg-emerald-600 hover:bg-emerald-700 shrink-0" onClick={() => setShowSchedule(true)}>
            <Plus className="w-4 h-4 mr-2" /> Schedule Audit
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          {[
            { label: "Scheduled", value: stats.scheduled, icon: Calendar, color: "text-indigo-600", bg: "bg-indigo-50" },
            { label: "In Progress", value: stats.in_progress, icon: Clock, color: "text-amber-600", bg: "bg-amber-50" },
            { label: "Completed", value: stats.completed, icon: CheckCircle2, color: "text-emerald-600", bg: "bg-emerald-50" },
          ].map(s => (
            <Card key={s.label} className="border-0 shadow-sm">
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`p-2 rounded-lg ${s.bg}`}><s.icon className={`w-5 h-5 ${s.color}`} /></div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{s.value}</p>
                  <p className="text-xs text-slate-500">{s.label}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
            <Input placeholder="Search audits…" className="pl-8 h-9 text-sm" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {Object.entries(STATUS_CONFIG).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Audit list */}
        {isLoading ? (
          <div className="py-16 flex justify-center"><div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" /></div>
        ) : filtered.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-16 text-center">
              <Calendar className="w-12 h-12 mx-auto text-slate-200 mb-3" />
              <p className="text-slate-500 font-medium">No internal audits yet</p>
              <p className="text-sm text-slate-400 mt-1 mb-4">Schedule your first audit to get started</p>
              <Button onClick={() => setShowSchedule(true)} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-2" /> Schedule Audit
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filtered.map(audit => {
              const progress = audit.checklist?.length
                ? Math.round((audit.checklist.filter(i => i.status !== "not_checked").length / audit.checklist.length) * 100)
                : 0;
              const nonCompliant = audit.checklist?.filter(i => i.status === "non_compliant").length || 0;

              return (
                <Card key={audit.id} className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelectedAudit(audit)}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className="font-semibold text-slate-900 text-sm">{audit.title}</span>
                          <Badge className={`text-[10px] px-1.5 py-0 ${STATUS_CONFIG[audit.status]?.color}`}>{STATUS_CONFIG[audit.status]?.label}</Badge>
                          {audit.priority && audit.priority !== "medium" && (
                            <Badge className={`text-[10px] px-1.5 py-0 ${PRIORITY_CONFIG[audit.priority]}`}>{audit.priority}</Badge>
                          )}
                          {audit.recurrence !== "none" && (
                            <Badge className="text-[10px] px-1.5 py-0 bg-violet-100 text-violet-700 gap-1">
                              <RefreshCw className="w-2.5 h-2.5" /> {audit.recurrence}
                            </Badge>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-3 text-xs text-slate-500 mb-2">
                          {audit.suggested_date && (
                            <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{format(new Date(audit.suggested_date), "d MMM yyyy")}</span>
                          )}
                          {audit.assigned_auditor && (
                            <span className="flex items-center gap-1"><User className="w-3 h-3" />{audit.assigned_auditor}</span>
                          )}
                          {audit.checklist?.length > 0 && (
                            <span className="flex items-center gap-1"><ClipboardList className="w-3 h-3" />{audit.checklist.length} requirements</span>
                          )}
                        </div>
                        {audit.checklist?.length > 0 && (
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-slate-100 rounded-full h-1.5">
                              <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${progress}%` }} />
                            </div>
                            <span className="text-[10px] text-slate-500 shrink-0">{progress}%</span>
                            {nonCompliant > 0 && (
                              <span className="text-[10px] text-rose-600 flex items-center gap-0.5"><XCircle className="w-3 h-3" />{nonCompliant} issues</span>
                            )}
                          </div>
                        )}
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 mt-1" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <ScheduleAuditDialog
        open={showSchedule}
        onClose={() => setShowSchedule(false)}
        onCreated={refetch}
      />
    </div>
  );
}