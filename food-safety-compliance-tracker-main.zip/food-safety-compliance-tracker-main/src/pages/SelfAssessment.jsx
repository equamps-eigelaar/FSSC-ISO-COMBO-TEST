import React, { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Plus, ArrowLeft, Printer, Mail, Loader2, Sparkles, Save,
  CheckCircle2, FileText, RefreshCw
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import AssessmentList from "@/components/selfassessment/AssessmentList";
import NewAssessmentDialog from "@/components/selfassessment/NewAssessmentDialog";
import AssessmentScoreCard from "@/components/selfassessment/AssessmentScoreCard";
import AssessmentQuestionsEditor from "@/components/selfassessment/AssessmentQuestionsEditor";
import EmailAssessmentDialog from "@/components/selfassessment/EmailAssessmentDialog";

const RISK_COLORS = {
  low: "text-emerald-600", medium: "text-amber-600", high: "text-orange-600", critical: "text-red-600"
};

function calculateScore(sections) {
  let total = 0, count = 0;
  (sections || []).forEach(s => {
    (s.questions || []).forEach(q => {
      const ans = q.user_answer || q.ai_answer;
      if (ans === "na") return;
      count++;
      if (ans === "yes") total += 100;
      else if (ans === "partial") total += 50;
    });
  });
  return count === 0 ? 0 : Math.round(total / count);
}

function getRating(score) {
  if (score >= 80) return "low";
  if (score >= 60) return "medium";
  if (score >= 40) return "high";
  return "critical";
}

export default function SelfAssessment() {
  const [selected, setSelected] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [showEmail, setShowEmail] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [localSections, setLocalSections] = useState(null);
  const printRef = useRef();
  const queryClient = useQueryClient();

  const { data: assessments = [], isLoading } = useQuery({
    queryKey: ["self-assessments"],
    queryFn: () => base44.entities.SupplierSelfAssessment.list("-created_date", 100),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SupplierSelfAssessment.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["self-assessments"] }); toast.success("Deleted"); },
  });

  const handleSelect = (a) => {
    setSelected(a);
    setLocalSections(a.sections || []);
  };

  const handleCreated = async (assessment) => {
    setSelected(assessment);
    setLocalSections([]);
    queryClient.invalidateQueries({ queryKey: ["self-assessments"] });
    // Auto-trigger AI analysis
    await runAnalysis(assessment.id);
  };

  const runAnalysis = async (id) => {
    setAnalyzing(true);
    try {
      const res = await base44.functions.invoke("analyzeSupplierQuestionnaire", { assessment_id: id || selected?.id });
      const data = res.data;
      const updated = { ...selected, ...data };
      setSelected(prev => ({ ...prev, ...data }));
      setLocalSections(data.sections || []);
      queryClient.invalidateQueries({ queryKey: ["self-assessments"] });
      toast.success("AI analysis complete!");
    } catch (err) {
      toast.error("AI analysis failed. Please try again.");
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    const score = calculateScore(localSections);
    const rating = getRating(score);
    try {
      await base44.entities.SupplierSelfAssessment.update(selected.id, {
        sections: localSections,
        risk_score: score,
        risk_rating: rating,
        status: "completed",
        completed_date: new Date().toISOString(),
      });
      setSelected(prev => ({ ...prev, sections: localSections, risk_score: score, risk_rating: rating, status: "completed" }));
      queryClient.invalidateQueries({ queryKey: ["self-assessments"] });
      toast.success("Assessment saved!");
    } catch (err) {
      toast.error("Save failed");
    } finally {
      setSaving(false);
    }
  };

  const handlePrint = () => {
    const score = calculateScore(localSections);
    const rating = getRating(score);
    const ratingColors = { low: '#16a34a', medium: '#d97706', high: '#ea580c', critical: '#dc2626' };
    const color = ratingColors[rating] || '#6b7280';

    const sectionsHtml = (localSections || []).map(section => {
      const rows = (section.questions || []).map(q => {
        const ans = q.user_answer || q.ai_answer || '-';
        const label = { yes: '✅ Yes', no: '❌ No', partial: '⚠️ Partial', na: '➖ N/A' }[ans] || ans;
        return `<tr>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;">${q.question}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;text-align:center;">${label}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:11px;color:#64748b;">${q.evidence_notes || q.comments || ''}</td>
        </tr>`;
      }).join('');
      return `<div style="margin-bottom:24px;">
        <h3 style="background:#f8fafc;padding:8px 12px;border-left:4px solid ${color};margin:0 0 0;font-size:14px;color:#1e293b;">${section.section_title}</h3>
        <table style="width:100%;border-collapse:collapse;">
          <thead><tr style="background:#f1f5f9;">
            <th style="padding:6px 10px;text-align:left;font-size:12px;color:#475569;">Question</th>
            <th style="padding:6px 10px;text-align:center;font-size:12px;color:#475569;width:90px;">Answer</th>
            <th style="padding:6px 10px;text-align:left;font-size:12px;color:#475569;">Evidence / Notes</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`;
    }).join('');

    const gapsHtml = (selected?.ai_gaps || []).map(g => `<li>${g}</li>`).join('');
    const recsHtml = (selected?.ai_recommendations || []).map(r => `<li>${r}</li>`).join('');

    const win = window.open('', '_blank');
    win.document.write(`<!DOCTYPE html><html><head>
      <title>Approved Supplier Questionnaire — ${selected?.title}</title>
      <style>
        body { font-family: Arial, sans-serif; color: #0f172a; margin: 0; padding: 24px; }
        @media print { body { padding: 0; } }
        h1 { font-size: 20px; margin-bottom: 4px; }
        h2 { font-size: 15px; margin: 20px 0 8px; color: #1e293b; }
        ul { padding-left: 20px; margin: 0; }
        li { margin-bottom: 4px; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 4px; }
      </style>
    </head><body>
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px;padding-bottom:16px;border-bottom:2px solid #e2e8f0;">
        <div>
          <h1 style="margin:0 0 2px;">Supplier Self-Assessment Report</h1>
          <p style="margin:0;color:#64748b;font-size:13px;">${selected?.customer_name} — ${selected?.title}</p>
        </div>
        <div style="text-align:right;">
          <div style="font-size:32px;font-weight:bold;color:${color};">${score}%</div>
          <div style="font-size:12px;text-transform:uppercase;color:${color};font-weight:600;">${rating} Risk</div>
          <div style="font-size:11px;color:#94a3b8;margin-top:4px;">Printed: ${new Date().toLocaleDateString('en-ZA', { year:'numeric', month:'long', day:'numeric' })}</div>
        </div>
      </div>
      ${selected?.ai_summary ? `<div style="background:#f0fdf4;border-left:4px solid #16a34a;padding:12px;margin-bottom:20px;font-size:13px;">${selected.ai_summary}</div>` : ''}
      ${gapsHtml ? `<h2>Key Compliance Gaps</h2><ul>${gapsHtml}</ul>` : ''}
      ${recsHtml ? `<h2>Recommendations</h2><ul style="margin-bottom:20px;">${recsHtml}</ul>` : ''}
      <h2>Detailed Assessment</h2>
      ${sectionsHtml}
      <p style="text-align:center;font-size:10px;color:#94a3b8;margin-top:24px;">CTP Flexibles Compliance Tracker · ${new Date().toISOString()}</p>
    </body></html>`);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); }, 400);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  // === DETAIL VIEW ===
  if (selected) {
    const liveScore = calculateScore(localSections);
    const liveRating = getRating(liveScore);
    const displayAssessment = { ...selected, sections: localSections, risk_score: liveScore, risk_rating: liveRating };

    return (
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <Button variant="ghost" size="sm" onClick={() => { setSelected(null); setLocalSections(null); }}>
              <ArrowLeft className="w-4 h-4 mr-1" /> Back
            </Button>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl font-bold text-slate-900 truncate">{selected.title}</h1>
              <p className="text-sm text-slate-500">{selected.customer_name}</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap justify-end">
              <Button variant="outline" size="sm" onClick={() => runAnalysis()} disabled={analyzing}>
                {analyzing ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-1" />}
                Re-analyse
              </Button>
              <Button variant="outline" size="sm" onClick={handlePrint}>
                <Printer className="w-4 h-4 mr-1" /> Print
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowEmail(true)}>
                <Mail className="w-4 h-4 mr-1" /> Email
              </Button>
              <Button size="sm" onClick={handleSave} disabled={saving} className="bg-emerald-600 hover:bg-emerald-700">
                {saving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Save className="w-4 h-4 mr-1" />}
                Save
              </Button>
            </div>
          </div>

          {/* Analysing state */}
          {analyzing && (
            <Card className="border-0 shadow-sm mb-6 bg-purple-50">
              <CardContent className="p-6 flex items-center gap-4">
                <Sparkles className="w-8 h-8 text-purple-600 animate-pulse" />
                <div>
                  <p className="font-semibold text-purple-900">AI is analysing the questionnaire…</p>
                  <p className="text-sm text-purple-700">Comparing against your compliance profile and pre-filling answers. This may take 30-60 seconds.</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Score card */}
          {(localSections?.length > 0 || selected.risk_score != null) && (
            <AssessmentScoreCard assessment={displayAssessment} />
          )}

          {/* AI Summary */}
          {selected.ai_summary && (
            <Card className="border-0 shadow-sm mb-4 bg-gradient-to-r from-purple-50 to-indigo-50">
              <CardContent className="p-4 flex items-start gap-3">
                <Sparkles className="w-4 h-4 text-purple-600 mt-0.5 shrink-0" />
                <p className="text-sm text-slate-700">{selected.ai_summary}</p>
              </CardContent>
            </Card>
          )}

          {/* Questions */}
          {localSections?.length > 0 ? (
            <AssessmentQuestionsEditor sections={localSections} onChange={setLocalSections} />
          ) : !analyzing && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-10 text-center">
                <Sparkles className="w-10 h-10 text-purple-300 mx-auto mb-3" />
                <p className="text-slate-500">Waiting for AI analysis to complete…</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Email dialog */}
        {showEmail && (
          <EmailAssessmentDialog
            open={showEmail}
            onClose={() => setShowEmail(false)}
            assessment={selected}
            onSent={() => { queryClient.invalidateQueries({ queryKey: ["self-assessments"] }); }}
          />
        )}
      </div>
    );
  }

  // === LIST VIEW ===
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Approved Supplier Questionnaire</h1>
            <p className="text-sm text-slate-500 mt-1">Upload customer questionnaires · AI pre-fills answers · Review & score</p>
          </div>
          <Button onClick={() => setShowNew(true)} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-2" /> New Assessment
          </Button>
        </div>

        <AssessmentList
          assessments={assessments}
          onSelect={handleSelect}
          onNew={() => setShowNew(true)}
          onDelete={(id) => deleteMutation.mutate(id)}
        />
      </div>

      <NewAssessmentDialog
        open={showNew}
        onClose={() => setShowNew(false)}
        onCreated={handleCreated}
      />
    </div>
  );
}