import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Package, ArrowRight, Calendar, Factory, AlertCircle } from "lucide-react";
import BatchDocumentButtons from "@/components/food/BatchDocumentButtons";

export default function FoodBatchTraceability() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBatch, setSelectedBatch] = useState(null);

  const { data: batches = [], isLoading } = useQuery({
    queryKey: ["food-batches-traceability"],
    queryFn: () => base44.entities.FoodBatchRecord.list("-production_date", 100),
  });

  const { data: rawMaterialDetails = [], isLoading: loadingRawMaterials } = useQuery({
    queryKey: ["raw-material-details", selectedBatch?.id],
    queryFn: async () => {
      if (!selectedBatch?.raw_material_batches?.length) return [];
      
      const materialIds = selectedBatch.raw_material_batches
        .map(rm => rm.raw_material_batch_id)
        .filter(Boolean);
      
      if (materialIds.length === 0) return [];

      const materials = await Promise.all(
        materialIds.map(id => base44.entities.RawMaterialBatch.get(id).catch(() => null))
      );
      
      return materials.filter(Boolean);
    },
    enabled: !!selectedBatch,
  });

  const filteredBatches = batches.filter(batch =>
    batch.batch_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    batch.product_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const statusColors = {
    in_production: "bg-blue-50 text-blue-700 border-blue-200",
    completed: "bg-slate-50 text-slate-700 border-slate-200",
    quality_hold: "bg-amber-50 text-amber-700 border-amber-200",
    released: "bg-emerald-50 text-emerald-700 border-emerald-200",
    rejected: "bg-red-50 text-red-700 border-red-200",
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-slate-900">Food Batch Traceability</h1>
          <p className="text-slate-600 mt-1">Track ingredients from raw materials to finished products</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Left: Batch Selection */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Select Batch</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search batch number or product..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>

                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {filteredBatches.map((batch) => (
                    <div
                      key={batch.id}
                      onClick={() => setSelectedBatch(batch)}
                      className={`p-3 border rounded-lg cursor-pointer transition-all ${
                        selectedBatch?.id === batch.id
                          ? "border-emerald-500 bg-emerald-50"
                          : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-slate-900">{batch.product_name}</p>
                          <p className="text-sm text-slate-600">Batch: {batch.batch_number}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            <span className="text-xs text-slate-500">
                              {new Date(batch.production_date).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <Badge variant="outline" className={statusColors[batch.status]}>
                          {batch.status.replace(/_/g, " ")}
                        </Badge>
                      </div>
                    </div>
                  ))}

                  {filteredBatches.length === 0 && (
                    <div className="text-center py-8 text-slate-500">
                      <Package className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                      <p>No batches found</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right: Traceability Details */}
          <div>
            {selectedBatch ? (
              <div className="space-y-4">
                {/* Finished Product */}
                <Card className="border-emerald-200 bg-emerald-50">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Factory className="w-5 h-5 text-emerald-600" />
                      <CardTitle className="text-lg">Finished Product</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div>
                        <p className="text-sm font-medium text-slate-600">Product</p>
                        <p className="text-lg font-semibold text-slate-900">{selectedBatch.product_name}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-slate-600">Batch Number</p>
                          <p className="font-medium text-slate-900">{selectedBatch.batch_number}</p>
                        </div>
                        <div>
                          <p className="text-slate-600">Production Date</p>
                          <p className="font-medium text-slate-900">
                            {new Date(selectedBatch.production_date).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-600">Quantity</p>
                          <p className="font-medium text-slate-900">
                            {selectedBatch.quantity_produced} {selectedBatch.unit}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-600">Line</p>
                          <p className="font-medium text-slate-900">{selectedBatch.production_line || "—"}</p>
                        </div>
                      </div>
                      {selectedBatch.allergens_present?.length > 0 && (
                        <div className="pt-2 border-t border-emerald-200">
                          <p className="text-sm text-slate-600 mb-1">Allergens Present</p>
                          <div className="flex flex-wrap gap-1">
                            {selectedBatch.allergens_present.map((allergen, idx) => (
                                    <Badge key={idx} variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                                      {allergen}
                                    </Badge>
                                  ))}
                                </div>
                                <div className="pt-3 border-t border-emerald-200 mt-3">
                                  <BatchDocumentButtons batch={selectedBatch} />
                                </div>
                              </div>
                            )}
                            </div>
                            </CardContent>
                            </Card>

                {/* Arrow */}
                <div className="flex justify-center">
                  <div className="flex items-center gap-2 text-slate-400">
                    <div className="w-px h-8 bg-slate-300"></div>
                    <ArrowRight className="w-5 h-5" />
                    <div className="w-px h-8 bg-slate-300"></div>
                  </div>
                </div>

                {/* Raw Materials */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Package className="w-5 h-5 text-blue-600" />
                      <CardTitle className="text-lg">Raw Materials Used</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {loadingRawMaterials ? (
                      <p className="text-sm text-slate-500">Loading raw material details...</p>
                    ) : rawMaterialDetails.length > 0 ? (
                      <div className="space-y-3">
                        {rawMaterialDetails.map((material) => (
                          <div key={material.id} className="p-3 border border-slate-200 rounded-lg bg-white">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <p className="font-medium text-slate-900">{material.material_name}</p>
                                <p className="text-sm text-slate-600">Batch: {material.batch_number}</p>
                              </div>
                              <Badge variant="outline" className={
                                material.status === 'approved' ? 'bg-emerald-50 text-emerald-700' :
                                material.status === 'in_use' ? 'bg-blue-50 text-blue-700' :
                                'bg-slate-50 text-slate-700'
                              }>
                                {material.status}
                              </Badge>
                            </div>
                            <div className="grid grid-cols-2 gap-2 text-xs">
                              <div>
                                <p className="text-slate-500">Supplier</p>
                                <p className="font-medium text-slate-900">{material.supplier}</p>
                              </div>
                              <div>
                                <p className="text-slate-500">Received</p>
                                <p className="font-medium text-slate-900">
                                  {material.received_date ? new Date(material.received_date).toLocaleDateString() : "—"}
                                </p>
                              </div>
                              {material.expiry_date && (
                                <div className="col-span-2">
                                  <p className="text-slate-500">Expiry Date</p>
                                  <p className="font-medium text-slate-900">
                                    {new Date(material.expiry_date).toLocaleDateString()}
                                  </p>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : selectedBatch.raw_material_batches?.length > 0 ? (
                      <div className="space-y-2">
                        {selectedBatch.raw_material_batches.map((rm, idx) => (
                          <div key={idx} className="p-3 border border-amber-200 rounded-lg bg-amber-50">
                            <div className="flex items-center gap-2">
                              <AlertCircle className="w-4 h-4 text-amber-600" />
                              <div>
                                <p className="font-medium text-amber-900">{rm.material_name}</p>
                                <p className="text-sm text-amber-700">Batch: {rm.batch_number}</p>
                                <p className="text-xs text-amber-600 mt-1">Detailed information not available</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Package className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                        <p className="text-slate-500">No raw materials linked to this batch</p>
                        <p className="text-xs text-slate-400 mt-1">Link materials when creating or editing the batch</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="border-dashed">
                <CardContent className="text-center py-16">
                  <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500 text-lg">Select a batch to view traceability</p>
                  <p className="text-slate-400 text-sm mt-2">
                    Track ingredients from raw materials to finished products
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}