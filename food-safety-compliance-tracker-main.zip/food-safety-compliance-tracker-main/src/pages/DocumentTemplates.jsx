import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Search, Copy, Download, Sparkles, Pencil, Send, Clock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ReactMarkdown from "react-markdown";
import { toast } from "sonner";
import DocumentEvaluator from "@/components/templates/DocumentEvaluator";
import TemplateFieldEditor from "@/components/templates/TemplateFieldEditor";
import ApprovalPanel, { ApprovalStatusBadge } from "@/components/templates/ApprovalPanel";

const CATEGORIES = [
  { value: "prp", label: "PRP Programs" },
  { value: "haccp_plan", label: "HACCP Plans" },
  { value: "policy", label: "Policies" },
  { value: "procedure", label: "Procedures" },
  { value: "work_instruction", label: "Work Instructions" },
  { value: "form", label: "Forms" },
  { value: "specification", label: "Specifications" }
];

function downloadMasterRecordList(templates) {
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-ZA', { year: 'numeric', month: 'long', day: 'numeric' });

  const rows = templates.map((t, i) => {
    const catLabel = CATEGORIES.find(c => c.value === t.category)?.label || t.category;
    return `<tr>
      <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;">${i + 1}</td>
      <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;font-weight:500;">${t.name}</td>
      <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;">${catLabel}</td>
      <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;">${t.current_version || 'Rev 1'}</td>
      <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;">${t.tags?.join(', ') || '—'}</td>
      <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;">${t.is_published ? 'Published' : 'Draft'}</td>
      <td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-size:12px;">${t.usage_count || 0}</td>
    </tr>`;
  }).join('');

  const html = `<!DOCTYPE html><html><head>
    <title>Master Records List — CTP Flexibles</title>
    <style>
      body { font-family: Arial, sans-serif; color: #0f172a; margin: 0; padding: 24px; }
      @media print { body { padding: 0; } .no-print { display: none; } }
      table { width: 100%; border-collapse: collapse; }
      th { background: #f8fafc; padding: 8px 10px; text-align: left; font-size: 12px; color: #475569; border-bottom: 2px solid #e2e8f0; }
    </style>
  </head><body>
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px;padding-bottom:16px;border-bottom:2px solid #e2e8f0;">
      <div>
        <h1 style="margin:0 0 4px;font-size:20px;">Master Records List</h1>
        <p style="margin:0;color:#64748b;font-size:13px;">CTP Flexibles — All current document revisions</p>
      </div>
      <div style="text-align:right;font-size:12px;color:#94a3b8;">
        <div>Generated: ${dateStr}</div>
        <div>${templates.length} documents</div>
      </div>
    </div>
    <table>
      <thead><tr>
        <th>#</th><th>Document Name</th><th>Category</th><th>Revision</th><th>Tags</th><th>Status</th><th>Uses</th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <p style="text-align:center;font-size:10px;color:#94a3b8;margin-top:24px;">CTP Flexibles Document Control · ${now.toISOString()}</p>
    <script>window.onload = function() { window.print(); }</script>
  </body></html>`;

  const win = window.open('', '_blank');
  win.document.write(html);
  win.document.close();
}

export default function DocumentTemplates() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showFieldEditor, setShowFieldEditor] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [mainTab, setMainTab] = useState("templates");
  const [currentUser, setCurrentUser] = useState(null);
  const queryClient = useQueryClient();

  React.useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const isAdmin = currentUser?.role === 'admin';

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ['document-templates'],
    queryFn: () => base44.entities.DocumentTemplate.list('-usage_count', 200)
  });

  const updateUsageMutation = useMutation({
    mutationFn: ({ id, count }) =>
      base44.entities.DocumentTemplate.update(id, { usage_count: count + 1 }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['document-templates'] })
  });

  const submitForApprovalMutation = useMutation({
    mutationFn: ({ id }) => base44.entities.DocumentTemplate.update(id, {
      approval_status: 'pending_approval',
      submitted_for_approval_by: currentUser?.email,
      submitted_for_approval_date: new Date().toISOString(),
      is_published: false,
    }),
    onSuccess: async (_, { templateName }) => {
      queryClient.invalidateQueries({ queryKey: ['document-templates'] });
      await base44.functions.invoke('documentApprovalNotify', {
        action: 'submitted',
        templateName,
        submitterEmail: currentUser?.email,
      });
      toast.success("Submitted for manager approval");
    }
  });

  const pendingCount = templates.filter(t => t.approval_status === 'pending_approval').length;

  const filtered = templates.filter(t => {
    const matchSearch = search === "" ||
      t.name?.toLowerCase().includes(search.toLowerCase()) ||
      t.description?.toLowerCase().includes(search.toLowerCase());
    const matchCategory = selectedCategory === "all" || t.category === selectedCategory;
    return matchSearch && matchCategory;
  });

  const groupedByCategory = CATEGORIES.reduce((acc, cat) => {
    acc[cat.value] = filtered.filter(t => t.category === cat.value);
    return acc;
  }, {});

  const handleUseTemplate = (template) => {
    updateUsageMutation.mutate({ id: template.id, count: template.usage_count || 0 });
    navigator.clipboard.writeText(template.content);
    toast.success("Template copied to clipboard");
  };

  const handleEditFields = (template, e) => {
    e?.stopPropagation();
    setEditingTemplate(template);
    setShowFieldEditor(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Document Templates</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Pre-built templates · Compliance evaluator · Master records
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => downloadMasterRecordList(templates)}
            className="gap-2"
          >
            <Download className="w-4 h-4" />
            Master Records List
          </Button>
        </div>

        {/* Main tabs */}
        <Tabs value={mainTab} onValueChange={setMainTab} className="mb-6">
          <TabsList>
            <TabsTrigger value="templates" className="gap-1.5">
              <FileText className="w-3.5 h-3.5" /> Templates
            </TabsTrigger>
            <TabsTrigger value="evaluator" className="gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> Compliance Evaluator
            </TabsTrigger>
            <TabsTrigger value="approvals" className="gap-1.5 relative">
              <Clock className="w-3.5 h-3.5" /> Approvals
              {pendingCount > 0 && isAdmin && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {pendingCount}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* ── TEMPLATES TAB ── */}
          <TabsContent value="templates" className="mt-4">
            <Card className="border-0 shadow-sm mb-4">
              <CardContent className="p-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search templates..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </CardContent>
            </Card>

            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList className="mb-5 flex-wrap h-auto">
                <TabsTrigger value="all">All</TabsTrigger>
                {CATEGORIES.map(cat => (
                  <TabsTrigger key={cat.value} value={cat.value}>{cat.label}</TabsTrigger>
                ))}
              </TabsList>

              <TabsContent value={selectedCategory} className="space-y-5">
                {selectedCategory === "all" ? (
                  Object.entries(groupedByCategory).map(([category, categoryTemplates]) => {
                    if (categoryTemplates.length === 0) return null;
                    const catInfo = CATEGORIES.find(c => c.value === category);
                    return (
                      <Card key={category} className="border-0 shadow-sm">
                        <CardHeader className="border-b border-slate-100 dark:border-slate-800 py-3">
                          <CardTitle className="text-sm font-semibold">{catInfo?.label}</CardTitle>
                        </CardHeader>
                        <CardContent className="p-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {categoryTemplates.map(template => (
                             <TemplateCard
                               key={template.id}
                               template={template}
                               onPreview={() => { setSelectedTemplate(template); setShowPreview(true); }}
                               onUse={() => handleUseTemplate(template)}
                               onEditFields={(e) => handleEditFields(template, e)}
                               onSubmitForApproval={() => submitForApprovalMutation.mutate({ id: template.id, templateName: template.name })}
                               isAdmin={isAdmin}
                             />
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filtered.map(template => (
                      <TemplateCard
                        key={template.id}
                        template={template}
                        onPreview={() => { setSelectedTemplate(template); setShowPreview(true); }}
                        onUse={() => handleUseTemplate(template)}
                        onEditFields={(e) => handleEditFields(template, e)}
                        onSubmitForApproval={() => submitForApprovalMutation.mutate({ id: template.id, templateName: template.name })}
                        isAdmin={isAdmin}
                      />
                    ))}
                  </div>
                )}

                {filtered.length === 0 && (
                  <Card className="border-0 shadow-sm">
                    <CardContent className="p-12 text-center">
                      <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                      <p className="text-slate-500 dark:text-slate-400">No templates found</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </TabsContent>

          {/* ── EVALUATOR TAB ── */}
          <TabsContent value="evaluator" className="mt-4">
            <DocumentEvaluator />
          </TabsContent>

          {/* ── APPROVALS TAB ── */}
          <TabsContent value="approvals" className="mt-4">
            <ApprovalPanel user={currentUser} isAdmin={isAdmin} />
          </TabsContent>
        </Tabs>

        {/* Preview Dialog */}
        <Dialog open={showPreview} onOpenChange={setShowPreview}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedTemplate?.name}</DialogTitle>
            </DialogHeader>
            {selectedTemplate && (
              <div className="space-y-4">
                <p className="text-sm text-slate-600 dark:text-slate-400">{selectedTemplate.description}</p>
                {selectedTemplate.guidance_notes && (
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <h4 className="text-sm font-semibold text-blue-900 dark:text-blue-200 mb-2">📘 Guidance</h4>
                    <p className="text-sm text-blue-800 dark:text-blue-300 whitespace-pre-line">{selectedTemplate.guidance_notes}</p>
                  </div>
                )}
                {selectedTemplate.fields?.length > 0 && (
                  <div className="p-4 bg-slate-50 rounded-lg">
                    <h4 className="text-sm font-semibold text-slate-700 mb-2">Document Fields</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedTemplate.fields.map((f, i) => (
                        <span key={i} className="text-xs bg-white border border-slate-200 px-2 py-1 rounded">
                          {f.name} {f.required && <span className="text-red-500">*</span>}
                          <span className="text-slate-400 ml-1">({f.type})</span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  <ReactMarkdown>{selectedTemplate.content}</ReactMarkdown>
                </div>
                <div className="flex justify-end gap-2 pt-4 border-t">
                  <Button variant="outline" onClick={() => { handleEditFields(selectedTemplate); setShowPreview(false); }}>
                    <Pencil className="w-4 h-4 mr-2" /> Edit Fields
                  </Button>
                  <Button variant="outline" onClick={() => setShowPreview(false)}>Close</Button>
                  <Button onClick={() => { handleUseTemplate(selectedTemplate); setShowPreview(false); }}>
                    <Copy className="w-4 h-4 mr-2" /> Use Template
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Field Editor Dialog */}
        {showFieldEditor && (
          <TemplateFieldEditor
            open={showFieldEditor}
            onClose={() => { setShowFieldEditor(false); setEditingTemplate(null); }}
            template={editingTemplate}
            onUpdated={() => queryClient.invalidateQueries({ queryKey: ['document-templates'] })}
          />
        )}
      </div>
    </div>
  );
}

function TemplateCard({ template, onPreview, onUse, onEditFields, onSubmitForApproval, isAdmin }) {
  const status = template.approval_status || (template.is_published ? 'approved' : 'draft');
  const canSubmit = (status === 'draft' || status === 'rejected') && !isAdmin;
  const canUse = status === 'approved';

  return (
    <div className="p-4 border border-slate-200 dark:border-slate-800 rounded-lg hover:border-emerald-300 dark:hover:border-emerald-700 transition-colors">
      <div className="flex items-start justify-between mb-2">
        <h4 className="font-medium text-slate-900 dark:text-white text-sm">{template.name}</h4>
        <div className="flex items-center gap-1.5 shrink-0 ml-2">
          {template.current_version && (
            <Badge variant="secondary" className="text-xs">{template.current_version}</Badge>
          )}
          <ApprovalStatusBadge template={template} />
        </div>
      </div>
      <p className="text-xs text-slate-600 dark:text-slate-400 mb-3 line-clamp-2">{template.description}</p>
      {template.rejection_reason && (
        <p className="text-xs text-red-500 mb-2 line-clamp-1">⚠ {template.rejection_reason}</p>
      )}
      {template.tags && template.tags.length > 0 && (
        <div className="flex gap-1 flex-wrap mb-3">
          {template.tags.slice(0, 3).map((tag, idx) => (
            <span key={idx} className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded">
              {tag}
            </span>
          ))}
        </div>
      )}
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={onPreview} className="flex-1">Preview</Button>
        {isAdmin && (
          <Button size="sm" variant="outline" onClick={onEditFields} className="px-2" title="Edit Fields">
            <Pencil className="w-3.5 h-3.5" />
          </Button>
        )}
        {canSubmit && (
          <Button size="sm" variant="outline" onClick={onSubmitForApproval} className="flex-1 text-amber-600 border-amber-200 hover:bg-amber-50">
            <Send className="w-3 h-3 mr-1" /> Submit
          </Button>
        )}
        {canUse && (
          <Button size="sm" onClick={onUse} className="flex-1">
            <Copy className="w-3 h-3 mr-1" /> Use
          </Button>
        )}
        {isAdmin && (
          <Button size="sm" onClick={onUse} className="flex-1">
            <Copy className="w-3 h-3 mr-1" /> Use
          </Button>
        )}
      </div>
    </div>
  );
}