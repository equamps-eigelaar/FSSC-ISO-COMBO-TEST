import React, { useState, useMemo } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useOfflineQuery } from "@/components/offline/useOfflineQuery";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Plus } from "lucide-react";
import RequirementRow from "@/components/requirements/RequirementRow";
import AddRequirementDialog from "@/components/requirements/AddRequirementDialog";
import { usePermissions } from "@/components/permissions/usePermissions";
import { useSectionAccess } from "@/components/permissions/useSectionAccess";
import PullToRefresh from "@/components/mobile/PullToRefresh";
import MobileSelect from "@/components/mobile/MobileSelect";
import { useAuditLog } from "@/components/audit/useAuditLog";

const STATUS_OPTIONS = [
  { value: "all", label: "All Statuses" },
  { value: "not_started", label: "Not Started" },
  { value: "in_progress", label: "In Progress" },
  { value: "partial", label: "Partial" },
  { value: "compliant", label: "Compliant" },
  { value: "non_compliant", label: "Non-Compliant" },
];

const PRIORITY_OPTIONS = [
  { value: "all", label: "All Priorities" },
  { value: "critical", label: "Critical" },
  { value: "high", label: "High" },
  { value: "medium", label: "Medium" },
  { value: "low", label: "Low" },
];

function sectionShortLabel(section) {
  if (section.startsWith("TS 22002-4")) return section.replace("TS 22002-4 - ", "TS ");
  return section.split(" - ")[0];
}

export default function Requirements() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [showAdd, setShowAdd] = useState(false);
  const [activeTab, setActiveTab] = useState(null);

  const { permissions, isAdmin } = usePermissions();
  const { canEditSection, canApproveSection, loading: sectionLoading } = useSectionAccess();
  const { logAction } = useAuditLog();
  const queryClient = useQueryClient();

  const { data: requirements = [], isLoading, refetch } = useOfflineQuery(
    ["compliance-requirements"],
    "ComplianceRequirement",
    () => base44.entities.ComplianceRequirement.list("clause_number", 200)
  );

  const updateMutation = useMutation({
    mutationFn: ({ id, status }) =>
      base44.entities.ComplianceRequirement.update(id, { status }),
    onMutate: async ({ id, status }) => {
      await queryClient.cancelQueries({ queryKey: ["compliance-requirements"] });
      const prev = queryClient.getQueryData(["compliance-requirements"]);
      queryClient.setQueryData(["compliance-requirements"], (old) =>
        old?.map((req) => (req.id === id ? { ...req, status } : req))
      );
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      queryClient.setQueryData(["compliance-requirements"], ctx.prev);
    },
    onSuccess: (_data, variables) => {
      logAction("status_changed", `Status changed for ${variables.label}: ${variables.oldStatus} → ${variables.status}`, {
        entity_type: "ComplianceRequirement",
        entity_id: variables.id,
        entity_label: variables.label,
        field_changes: [{ field: "status", old_value: variables.oldStatus, new_value: variables.status }],
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-requirements"] });
    },
  });

  const filtered = useMemo(() => {
    return requirements.filter((r) => {
      const matchSearch =
        search === "" ||
        r.clause_number?.toLowerCase().includes(search.toLowerCase()) ||
        r.clause_title?.toLowerCase().includes(search.toLowerCase()) ||
        r.description?.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "all" || r.status === statusFilter;
      const matchPriority = priorityFilter === "all" || r.priority === priorityFilter;
      return matchSearch && matchStatus && matchPriority;
    });
  }, [requirements, search, statusFilter, priorityFilter]);

  const grouped = useMemo(() => {
    const groups = {};
    filtered.forEach((r) => {
      if (!groups[r.section]) groups[r.section] = [];
      groups[r.section].push(r);
    });
    return groups;
  }, [filtered]);

  const sortedSections = useMemo(
    () =>
      Object.keys(grouped).sort((a, b) => {
        const numA = parseInt(a.split(" ")[0]);
        const numB = parseInt(b.split(" ")[0]);
        return numA - numB;
      }),
    [grouped]
  );

  const currentTab = activeTab && sortedSections.includes(activeTab) ? activeTab : sortedSections[0] ?? "";

  if (isLoading || sectionLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={refetch}>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
        {/* Sticky Header */}
        <div className="sticky top-0 z-20 bg-slate-50 dark:bg-slate-950 border-b border-slate-100 dark:border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 pb-3">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Requirements</h1>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  {filtered.length} of {requirements.length} requirements
                </p>
              </div>
              {(permissions.canEditRequirements || isAdmin) && (
                <Button
                  onClick={() => setShowAdd(true)}
                  className="bg-emerald-600 hover:bg-emerald-700 min-h-[44px]"
                >
                  <Plus className="w-4 h-4 mr-1.5" />
                  Add
                </Button>
              )}
            </div>

            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search clauses..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white min-h-[44px]"
                />
              </div>
              <MobileSelect
                value={statusFilter}
                onValueChange={setStatusFilter}
                placeholder="Status"
                label="Select Status"
                triggerClassName="w-full sm:w-40 border-slate-200 dark:border-slate-700 min-h-[44px]"
              >
                {STATUS_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </MobileSelect>
              <MobileSelect
                value={priorityFilter}
                onValueChange={setPriorityFilter}
                placeholder="Priority"
                label="Select Priority"
                triggerClassName="w-full sm:w-36 border-slate-200 dark:border-slate-700 min-h-[44px]"
              >
                {PRIORITY_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </MobileSelect>
            </div>
          </div>
        </div>

        {/* Sidebar + Content */}
        <div className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-4">
          {sortedSections.length === 0 ? (
            <div className="text-center py-20">
              <Search className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 dark:text-slate-400">No requirements match your filters</p>
            </div>
          ) : (
            <div className="flex gap-4">
              {/* Desktop: Vertical Section Sidebar */}
              <aside className="hidden sm:flex flex-col w-52 shrink-0 gap-1 self-start sticky top-32 max-h-[calc(100vh-10rem)] overflow-y-auto overscroll-contain scrollbar-hide">
                <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl shadow-sm p-2">
                  {sortedSections.map((section) => {
                    const items = grouped[section];
                    const compliantCount = items.filter((r) => r.status === "compliant").length;
                    const isActive = currentTab === section;
                    const allDone = compliantCount === items.length;
                    return (
                      <button
                        key={section}
                        onClick={() => setActiveTab(section)}
                        className={`w-full text-left flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors min-h-[44px] mb-0.5
                          ${isActive
                            ? "bg-emerald-600 text-white"
                            : "text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                          }`}
                      >
                        <span className="truncate">{section.split(" - ")[1] || section}</span>
                        <span className={`shrink-0 text-[10px] font-semibold px-1.5 py-0.5 rounded-full
                          ${isActive
                            ? "bg-white/20 text-white"
                            : allDone
                              ? "bg-emerald-100 text-emerald-700"
                              : "bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400"
                          }`}
                        >
                          {compliantCount}/{items.length}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </aside>

              {/* Mobile + Content column */}
              <div className="flex-1 min-w-0 flex flex-col gap-4">
                {/* Mobile: vertical stacked tabs */}
                <div className="sm:hidden w-full">
                  <div className="flex flex-col gap-1 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl p-1 shadow-sm">
                    {sortedSections.map((section) => {
                      const items = grouped[section];
                      const compliantCount = items.filter((r) => r.status === "compliant").length;
                      const isActive = currentTab === section;
                      return (
                        <button
                          key={section}
                          onClick={() => setActiveTab(section)}
                          className={`w-full text-left flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors min-h-[44px]
                            ${isActive ? "bg-emerald-600 text-white" : "text-slate-600 hover:bg-slate-50"}`}
                        >
                          <span>{sectionShortLabel(section)}</span>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${isActive ? "bg-white/20 text-white" : "bg-slate-100 text-slate-500"}`}>
                            {compliantCount}/{items.length}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Content Panel */}
                {currentTab && grouped[currentTab] && (
                  <>
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-semibold text-slate-700 dark:text-slate-300">{currentTab}</h2>
                      <Badge variant="secondary" className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-500">
                        {grouped[currentTab].length} items
                      </Badge>
                    </div>
                    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-y-auto max-h-[calc(100vh-16rem)] overscroll-contain">
                      <div className="divide-y divide-slate-50 dark:divide-slate-800">
                        {grouped[currentTab]
                          .sort((a, b) =>
                            (a.clause_number || "").localeCompare(b.clause_number || "", undefined, { numeric: true })
                          )
                          .map((req) => {
                            const canEditThis = isAdmin || (permissions.canEditRequirements && canEditSection(req.section));
                            const canApproveThis = canApproveSection(req.section);
                            return (
                              <RequirementRow
                                key={req.id}
                                requirement={req}
                                onStatusChange={(newStatus) =>
                                  updateMutation.mutate({
                                    id: req.id,
                                    status: newStatus,
                                    oldStatus: req.status,
                                    label: `${req.clause_number} ${req.clause_title}`,
                                  })
                                }
                                canEdit={canEditThis}
                                canApprove={canApproveThis}
                                isHidden={false}
                              />
                            );
                          })}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <AddRequirementDialog open={showAdd} onClose={() => setShowAdd(false)} />
    </PullToRefresh>
  );
}