import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";
import { Download, TrendingUp, AlertTriangle, Package, FileText, Calendar } from "lucide-react";
import { format, subMonths, startOfMonth, endOfMonth, parseISO } from "date-fns";
import { toast } from "sonner";

const RISK_COLORS = {
  low: "#10b981",
  medium: "#f59e0b",
  high: "#ef4444",
  critical: "#dc2626",
};

const STATUS_COLORS = {
  not_started: "#94a3b8",
  in_progress: "#3b82f6",
  partial: "#f59e0b",
  compliant: "#10b981",
  non_compliant: "#ef4444",
};

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("6m");
  const [exportLoading, setExportLoading] = useState(false);

  const { data: requirements = [], isLoading: reqLoading } = useQuery({
    queryKey: ["compliance-requirements"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-created_date", 500),
  });

  const { data: risks = [], isLoading: riskLoading } = useQuery({
    queryKey: ["risk-assessments"],
    queryFn: () => base44.entities.RiskAssessment.list("-created_date", 500),
  });

  const { data: batches = [], isLoading: batchLoading } = useQuery({
    queryKey: ["raw-material-batches"],
    queryFn: () => base44.entities.RawMaterialBatch.list("-created_date", 500),
  });

  const { data: documents = [], isLoading: docLoading } = useQuery({
    queryKey: ["documents-all"],
    queryFn: () => base44.entities.Document.list("-created_date", 500),
  });

  const isLoading = reqLoading || riskLoading || batchLoading || docLoading;

  // Calculate date range
  const months = timeRange === "3m" ? 3 : timeRange === "6m" ? 6 : 12;
  const dateRange = useMemo(() => {
    const dates = [];
    for (let i = months - 1; i >= 0; i--) {
      dates.push(subMonths(new Date(), i));
    }
    return dates;
  }, [months]);

  // Compliance Trend Data
  const complianceTrend = useMemo(() => {
    return dateRange.map(date => {
      const monthStart = startOfMonth(date);
      const monthEnd = endOfMonth(date);
      
      const monthReqs = requirements.filter(r => {
        const created = new Date(r.created_date);
        return created >= monthStart && created <= monthEnd;
      });

      const compliant = monthReqs.filter(r => r.status === "compliant").length;
      const total = monthReqs.length || 1;

      return {
        month: format(date, "MMM yy"),
        compliance: Math.round((compliant / total) * 100),
        total: monthReqs.length,
      };
    });
  }, [requirements, dateRange]);

  // Status Distribution
  const statusDistribution = useMemo(() => {
    const dist = {
      not_started: 0,
      in_progress: 0,
      partial: 0,
      compliant: 0,
      non_compliant: 0,
    };
    requirements.forEach(r => {
      if (dist[r.status] !== undefined) dist[r.status]++;
    });
    return Object.entries(dist).map(([status, count]) => ({
      name: status.replace(/_/g, " "),
      value: count,
      color: STATUS_COLORS[status],
    }));
  }, [requirements]);

  // Risk Distribution by Level
  const riskByLevel = useMemo(() => {
    const dist = { low: 0, medium: 0, high: 0, critical: 0 };
    risks.forEach(r => {
      if (dist[r.risk_level] !== undefined) dist[r.risk_level]++;
    });
    return Object.entries(dist).map(([level, count]) => ({
      name: level,
      value: count,
      color: RISK_COLORS[level],
    }));
  }, [risks]);

  // Risk Distribution by Module
  const riskByModule = useMemo(() => {
    const moduleMap = {};
    risks.forEach(risk => {
      const req = requirements.find(r => r.id === risk.requirement_id);
      if (req) {
        const section = req.section?.split(" - ")[0] || "Other";
        moduleMap[section] = (moduleMap[section] || 0) + 1;
      }
    });
    return Object.entries(moduleMap)
      .map(([module, count]) => ({ module, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);
  }, [risks, requirements]);

  // Batch Quality Overview
  const batchQuality = useMemo(() => {
    const dist = {
      pending_inspection: 0,
      approved: 0,
      rejected: 0,
      in_use: 0,
      depleted: 0,
    };
    batches.forEach(b => {
      if (dist[b.status] !== undefined) dist[b.status]++;
    });
    return Object.entries(dist).map(([status, count]) => ({
      status: status.replace(/_/g, " "),
      count,
    }));
  }, [batches]);

  // Document Expiry Timeline
  const docExpiry = useMemo(() => {
    const now = new Date();
    const categories = {
      expired: 0,
      "< 30 days": 0,
      "30-90 days": 0,
      "> 90 days": 0,
      "no expiry": 0,
    };

    documents.forEach(doc => {
      if (!doc.expiry_date) {
        categories["no expiry"]++;
        return;
      }
      const expiry = new Date(doc.expiry_date);
      const daysUntil = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));

      if (daysUntil < 0) categories.expired++;
      else if (daysUntil < 30) categories["< 30 days"]++;
      else if (daysUntil < 90) categories["30-90 days"]++;
      else categories["> 90 days"]++;
    });

    return Object.entries(categories).map(([category, count]) => ({
      category,
      count,
    }));
  }, [documents]);

  // Key Metrics
  const metrics = useMemo(() => {
    const compliantReqs = requirements.filter(r => r.status === "compliant").length;
    const complianceRate = requirements.length ? Math.round((compliantReqs / requirements.length) * 100) : 0;
    
    const highRisks = risks.filter(r => r.risk_level === "high" || r.risk_level === "critical").length;
    const approvedBatches = batches.filter(b => b.status === "approved").length;
    const expiredDocs = documents.filter(d => d.expiry_date && new Date(d.expiry_date) < new Date()).length;

    return {
      complianceRate,
      highRisks,
      approvedBatches,
      expiredDocs,
    };
  }, [requirements, risks, batches, documents]);

  const handleExport = () => {
    setExportLoading(true);
    try {
      const csvData = [
        ["Analytics Dashboard Export", format(new Date(), "yyyy-MM-dd HH:mm")],
        [""],
        ["KEY METRICS"],
        ["Compliance Rate", `${metrics.complianceRate}%`],
        ["High/Critical Risks", metrics.highRisks],
        ["Approved Batches", metrics.approvedBatches],
        ["Expired Documents", metrics.expiredDocs],
        [""],
        ["COMPLIANCE STATUS DISTRIBUTION"],
        ["Status", "Count"],
        ...statusDistribution.map(s => [s.name, s.value]),
        [""],
        ["RISK DISTRIBUTION BY LEVEL"],
        ["Level", "Count"],
        ...riskByLevel.map(r => [r.name, r.value]),
        [""],
        ["BATCH QUALITY STATUS"],
        ["Status", "Count"],
        ...batchQuality.map(b => [b.status, b.count]),
        [""],
        ["DOCUMENT EXPIRY TIMELINE"],
        ["Category", "Count"],
        ...docExpiry.map(d => [d.category, d.count]),
      ];

      const csv = csvData.map(row => row.join(",")).join("\n");
      const blob = new Blob([csv], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `analytics-${format(new Date(), "yyyy-MM-dd")}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      toast.success("Analytics exported");
    } catch (error) {
      toast.error("Failed to export data");
    } finally {
      setExportLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Analytics Dashboard</h1>
            <p className="text-sm text-slate-500 mt-1">Comprehensive insights across all modules</p>
          </div>
          <div className="flex items-center gap-3">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3m">Last 3 Months</SelectItem>
                <SelectItem value="6m">Last 6 Months</SelectItem>
                <SelectItem value="12m">Last 12 Months</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={handleExport}
              disabled={exportLoading}
              variant="outline"
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Export
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900">{metrics.complianceRate}%</div>
                  <div className="text-xs text-slate-500 font-medium">Compliance Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-rose-50 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-rose-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900">{metrics.highRisks}</div>
                  <div className="text-xs text-slate-500 font-medium">High/Critical Risks</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                  <Package className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900">{metrics.approvedBatches}</div>
                  <div className="text-xs text-slate-500 font-medium">Approved Batches</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900">{metrics.expiredDocs}</div>
                  <div className="text-xs text-slate-500 font-medium">Expired Documents</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          {/* Compliance Trend */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="text-sm font-semibold">Compliance Status Trend</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={complianceTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#64748b" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#64748b" />
                  <Tooltip />
                  <Area type="monotone" dataKey="compliance" stroke="#10b981" fill="#10b981" fillOpacity={0.2} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Status Distribution */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="text-sm font-semibold">Compliance Status Distribution</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={90}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Risk by Level */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="text-sm font-semibold">Risk Distribution by Level</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={riskByLevel}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#64748b" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#64748b" />
                  <Tooltip />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                    {riskByLevel.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Risk by Module */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="text-sm font-semibold">Risk Distribution by Module</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={riskByModule} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis type="number" tick={{ fontSize: 11 }} stroke="#64748b" />
                  <YAxis type="category" dataKey="module" tick={{ fontSize: 11 }} stroke="#64748b" width={80} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3b82f6" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Batch Quality */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="text-sm font-semibold">Raw Material Batch Quality</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={batchQuality}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="status" tick={{ fontSize: 11 }} stroke="#64748b" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#64748b" />
                  <Tooltip />
                  <Bar dataKey="count" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Document Expiry */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="text-sm font-semibold">Document Expiry Timeline</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={docExpiry}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="category" tick={{ fontSize: 11 }} stroke="#64748b" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#64748b" />
                  <Tooltip />
                  <Bar dataKey="count" fill="#f59e0b" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}