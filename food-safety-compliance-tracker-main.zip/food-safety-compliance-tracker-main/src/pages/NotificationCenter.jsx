import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bell,
  BellOff,
  CheckCircle2,
  Settings,
  Trash2,
  AlertTriangle,
  FileText,
  MessageSquare,
  User as UserIcon,
  Package,
} from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import NotificationSettings from "@/components/notifications/NotificationSettings";

const NOTIFICATION_ICONS = {
  assignment: UserIcon,
  comment: MessageSquare,
  status_change: CheckCircle2,
  high_priority_risk: AlertTriangle,
  expiring_document: FileText,
  due_soon: AlertTriangle,
};

const NOTIFICATION_COLORS = {
  assignment: "text-blue-600 bg-blue-50",
  comment: "text-purple-600 bg-purple-50",
  status_change: "text-emerald-600 bg-emerald-50",
  high_priority_risk: "text-rose-600 bg-rose-50",
  expiring_document: "text-amber-600 bg-amber-50",
  due_soon: "text-orange-600 bg-orange-50",
};

export default function NotificationCenter() {
  const [showSettings, setShowSettings] = useState(false);
  const [filter, setFilter] = useState("all");
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: user } = useQuery({
    queryKey: ["current-user"],
    queryFn: () => base44.auth.me(),
  });

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["all-notifications", user?.email],
    queryFn: () => base44.entities.Notification.filter({ recipient_email: user.email }, "-created_date", 200),
    enabled: !!user?.email,
  });

  useEffect(() => {
    if (!user?.email) return;
    
    const unsubscribe = base44.entities.Notification.subscribe((event) => {
      if (event.data?.recipient_email === user.email) {
        queryClient.invalidateQueries({ queryKey: ["all-notifications"] });
      }
    });
    
    return unsubscribe;
  }, [user?.email, queryClient]);

  const markAsReadMutation = useMutation({
    mutationFn: (notificationId) => 
      base44.entities.Notification.update(notificationId, { is_read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["all-notifications"] });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifications = notifications.filter(n => !n.is_read);
      await Promise.all(
        unreadNotifications.map(n => 
          base44.entities.Notification.update(n.id, { is_read: true })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["all-notifications"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (notificationId) => base44.entities.Notification.delete(notificationId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["all-notifications"] });
    },
  });

  const handleNotificationClick = (notification) => {
    if (!notification.is_read) {
      markAsReadMutation.mutate(notification.id);
    }
    if (notification.action_url) {
      navigate(notification.action_url);
    }
  };

  const filteredNotifications = notifications.filter(n => {
    if (filter === "all") return true;
    if (filter === "unread") return !n.is_read;
    return n.type === filter;
  });

  const unreadCount = notifications.filter(n => !n.is_read).length;

  const stats = {
    total: notifications.length,
    unread: unreadCount,
    highPriority: notifications.filter(n => n.type === "high_priority_risk").length,
    expiring: notifications.filter(n => n.type === "expiring_document").length,
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <Bell className="w-7 h-7 text-emerald-600" />
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Notification Center</h1>
            </div>
            <p className="text-slate-500 text-sm ml-10">
              {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}
            </p>
          </div>
          <div className="flex gap-2">
            {unreadCount > 0 && (
              <Button
                variant="outline"
                onClick={() => markAllAsReadMutation.mutate()}
                disabled={markAllAsReadMutation.isPending}
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Mark All Read
              </Button>
            )}
            <Button onClick={() => setShowSettings(true)} className="bg-emerald-600 hover:bg-emerald-700">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center">
                  <Bell className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-emerald-700">{stats.total}</div>
                  <div className="text-xs text-slate-500">Total</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                  <BellOff className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-700">{stats.unread}</div>
                  <div className="text-xs text-slate-500">Unread</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-rose-50 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-rose-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-rose-700">{stats.highPriority}</div>
                  <div className="text-xs text-slate-500">High Priority</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-amber-700">{stats.expiring}</div>
                  <div className="text-xs text-slate-500">Expiring</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Tabs defaultValue="all" className="space-y-6" onValueChange={setFilter}>
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="unread">Unread</TabsTrigger>
            <TabsTrigger value="high_priority_risk">High Risk</TabsTrigger>
            <TabsTrigger value="expiring_document">Expiring</TabsTrigger>
            <TabsTrigger value="assignment">Assignments</TabsTrigger>
          </TabsList>

          <TabsContent value={filter}>
            <div className="space-y-3">
              {filteredNotifications.length === 0 ? (
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-12 text-center">
                    <Bell className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p className="text-slate-500">No notifications found</p>
                  </CardContent>
                </Card>
              ) : (
                filteredNotifications.map((notification) => {
                  const Icon = NOTIFICATION_ICONS[notification.type] || Bell;
                  const colorClass = NOTIFICATION_COLORS[notification.type] || "text-slate-600 bg-slate-50";

                  return (
                    <Card
                      key={notification.id}
                      className={`border-0 shadow-sm transition-all ${
                        notification.is_read ? "bg-white" : "bg-blue-50 border-l-4 border-l-blue-500"
                      } hover:shadow-md cursor-pointer`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className={`w-10 h-10 rounded-lg ${colorClass} flex items-center justify-center shrink-0`}>
                            <Icon className="w-5 h-5" />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-3 mb-1">
                              <h3 className={`text-sm font-semibold ${notification.is_read ? "text-slate-900" : "text-slate-900"}`}>
                                {notification.title}
                              </h3>
                              <span className="text-xs text-slate-400 shrink-0">
                                {format(new Date(notification.created_date), "MMM d, h:mm a")}
                              </span>
                            </div>
                            <p className="text-sm text-slate-600">{notification.message}</p>
                            
                            <div className="flex items-center gap-2 mt-2">
                              <Badge variant="outline" className="text-xs">
                                {notification.type.replace(/_/g, " ")}
                              </Badge>
                              {notification.entity_type && (
                                <Badge variant="outline" className="text-xs">
                                  {notification.entity_type}
                                </Badge>
                              )}
                            </div>
                          </div>

                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteMutation.mutate(notification.id);
                            }}
                            className="shrink-0"
                          >
                            <Trash2 className="w-4 h-4 text-slate-400 hover:text-rose-600" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <NotificationSettings
        open={showSettings}
        onClose={() => setShowSettings(false)}
        user={user}
      />
    </div>
  );
}