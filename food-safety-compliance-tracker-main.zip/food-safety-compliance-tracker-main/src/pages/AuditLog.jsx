import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  Shield,
  Activity,
  Search,
  Filter,
  Clock,
  User,
  CheckCircle,
  AlertTriangle,
  Trash2,
  Upload,
  Edit3
} from "lucide-react";
import { format } from "date-fns";
import PullToRefresh from "@/components/mobile/PullToRefresh";
import MobileSelect from "@/components/mobile/MobileSelect";

const ACTIVITY_ICONS = {
  requirement_created: FileText,
  requirement_updated: Edit3,
  requirement_deleted: Trash2,
  compliancerequirement_created: FileText,
  compliancerequirement_updated: Edit3,
  compliancerequirement_deleted: Trash2,
  status_changed: CheckCircle,
  risk_added: Shield,
  risk_updated: AlertTriangle,
  riskassessment_created: Shield,
  riskassessment_updated: AlertTriangle,
  riskassessment_deleted: Trash2,
  rawmaterialbatch_created: Upload,
  rawmaterialbatch_updated: Edit3,
  rawmaterialbatch_deleted: Trash2,
  evidence_uploaded: Upload,
  review_completed: Activity
};

const ACTIVITY_COLORS = {
  requirement_created: "text-emerald-600 bg-emerald-50",
  requirement_updated: "text-blue-600 bg-blue-50",
  requirement_deleted: "text-rose-600 bg-rose-50",
  compliancerequirement_created: "text-emerald-600 bg-emerald-50",
  compliancerequirement_updated: "text-blue-600 bg-blue-50",
  compliancerequirement_deleted: "text-rose-600 bg-rose-50",
  status_changed: "text-purple-600 bg-purple-50",
  risk_added: "text-amber-600 bg-amber-50",
  risk_updated: "text-orange-600 bg-orange-50",
  riskassessment_created: "text-amber-600 bg-amber-50",
  riskassessment_updated: "text-orange-600 bg-orange-50",
  riskassessment_deleted: "text-rose-600 bg-rose-50",
  rawmaterialbatch_created: "text-cyan-600 bg-cyan-50",
  rawmaterialbatch_updated: "text-blue-600 bg-blue-50",
  rawmaterialbatch_deleted: "text-rose-600 bg-rose-50",
  evidence_uploaded: "text-cyan-600 bg-cyan-50",
  review_completed: "text-green-600 bg-green-50"
};

export default function AuditLog() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterEntity, setFilterEntity] = useState("all");
  const [dateRange, setDateRange] = useState("all");

  const { data: activities = [], isLoading, refetch } = useQuery({
    queryKey: ["activity-logs"],
    queryFn: () => base44.entities.ActivityLog.list("-created_date", 500),
  });

  const handleRefresh = async () => {
    await refetch();
  };

  const { data: requirements = [] } = useQuery({
    queryKey: ["compliance-requirements"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-created_date", 200),
  });

  const { data: risks = [] } = useQuery({
    queryKey: ["risk-assessments-all"],
    queryFn: () => base44.entities.RiskAssessment.list("-created_date", 200),
  });

  // Filter activities
  const filteredActivities = activities.filter(activity => {
    const matchesSearch = activity.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         activity.user_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         activity.entity_id?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || activity.activity_type === filterType;
    const matchesEntity = filterEntity === "all" || activity.entity_type === filterEntity;
    
    // Date range filter
    let matchesDate = true;
    if (dateRange !== "all") {
      const activityDate = new Date(activity.created_date);
      const now = new Date();
      if (dateRange === "today") {
        matchesDate = activityDate.toDateString() === now.toDateString();
      } else if (dateRange === "week") {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        matchesDate = activityDate >= weekAgo;
      } else if (dateRange === "month") {
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        matchesDate = activityDate >= monthAgo;
      }
    }
    
    return matchesSearch && matchesType && matchesEntity && matchesDate;
  });

  // Group by date
  const groupedActivities = filteredActivities.reduce((groups, activity) => {
    const date = format(new Date(activity.created_date), "yyyy-MM-dd");
    if (!groups[date]) groups[date] = [];
    groups[date].push(activity);
    return groups;
  }, {});

  // Statistics
  const stats = {
    total: activities.length,
    today: activities.filter(a => {
      const today = new Date().toDateString();
      return new Date(a.created_date).toDateString() === today;
    }).length,
    requirements: activities.filter(a => a.entity_type === "ComplianceRequirement").length,
    risks: activities.filter(a => a.entity_type === "RiskAssessment").length
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 text-sm">Loading audit logs...</p>
        </div>
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            <Activity className="w-7 h-7 text-emerald-600" />
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Audit Trail</h1>
          </div>
          <p className="text-slate-500 text-sm ml-10">
            Complete history of all compliance activities and changes
          </p>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center">
                  <Activity className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-emerald-700">{stats.total}</div>
                  <div className="text-xs text-slate-500">Total Activities</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-700">{stats.today}</div>
                  <div className="text-xs text-slate-500">Today</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-700">{stats.requirements}</div>
                  <div className="text-xs text-slate-500">Requirement Changes</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-amber-700">{stats.risks}</div>
                  <div className="text-xs text-slate-500">Risk Changes</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search activities..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <MobileSelect value={filterEntity} onValueChange={setFilterEntity} placeholder="Entity" label="Filter by Entity" triggerClassName="min-h-[44px]">
                <SelectItem value="all">All Entities</SelectItem>
                <SelectItem value="ComplianceRequirement">Requirements</SelectItem>
                <SelectItem value="RiskAssessment">Risk Assessments</SelectItem>
                <SelectItem value="RawMaterialBatch">Material Batches</SelectItem>
              </MobileSelect>

              <MobileSelect value={filterType} onValueChange={setFilterType} placeholder="Action" label="Filter by Action" triggerClassName="min-h-[44px]">
                <SelectItem value="all">All Actions</SelectItem>
                <SelectItem value="compliancerequirement_created">Requirement Created</SelectItem>
                <SelectItem value="compliancerequirement_updated">Requirement Updated</SelectItem>
                <SelectItem value="compliancerequirement_deleted">Requirement Deleted</SelectItem>
                <SelectItem value="riskassessment_created">Risk Created</SelectItem>
                <SelectItem value="riskassessment_updated">Risk Updated</SelectItem>
                <SelectItem value="riskassessment_deleted">Risk Deleted</SelectItem>
                <SelectItem value="rawmaterialbatch_created">Batch Created</SelectItem>
                <SelectItem value="rawmaterialbatch_updated">Batch Updated</SelectItem>
                <SelectItem value="rawmaterialbatch_deleted">Batch Deleted</SelectItem>
              </MobileSelect>

              <MobileSelect value={dateRange} onValueChange={setDateRange} placeholder="Time Range" label="Filter by Time" triggerClassName="min-h-[44px]">
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">Last 7 Days</SelectItem>
                <SelectItem value="month">Last 30 Days</SelectItem>
              </MobileSelect>
            </div>
          </CardContent>
        </Card>

        {/* Activity Timeline */}
        <div className="space-y-6">
          {Object.entries(groupedActivities).map(([date, dayActivities]) => (
            <div key={date}>
              <div className="flex items-center gap-3 mb-4">
                <div className="text-sm font-semibold text-slate-900">
                  {format(new Date(date), "EEEE, MMMM d, yyyy")}
                </div>
                <div className="flex-1 h-px bg-slate-200" />
              </div>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-0">
                  <div className="divide-y divide-slate-100">
                    {dayActivities.map((activity, index) => {
                      const Icon = ACTIVITY_ICONS[activity.activity_type] || Activity;
                      const colorClass = ACTIVITY_COLORS[activity.activity_type] || "text-slate-600 bg-slate-50";

                      return (
                        <div key={activity.id} className="p-4 hover:bg-slate-50 transition-colors">
                          <div className="flex items-start gap-4">
                            <div className={`w-10 h-10 rounded-lg ${colorClass} flex items-center justify-center shrink-0`}>
                              <Icon className="w-5 h-5" />
                            </div>

                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-3 mb-1">
                                <p className="text-sm font-medium text-slate-900">
                                  {activity.description}
                                </p>
                                <span className="text-xs text-slate-400 shrink-0">
                                  {format(new Date(activity.created_date), "h:mm a")}
                                </span>
                              </div>

                              <div className="flex items-center gap-3 text-xs text-slate-500">
                                <div className="flex items-center gap-1">
                                  <User className="w-3 h-3" />
                                  {activity.user_email || "System"}
                                </div>
                                <span>•</span>
                                <Badge variant="outline" className="text-xs">
                                  {activity.entity_type}
                                </Badge>
                              </div>

                              {activity.metadata && (
                                <div className="mt-2 space-y-2">
                                  {activity.metadata.changes && activity.metadata.changes.length > 0 && (
                                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                                      <div className="text-xs font-semibold text-slate-700 mb-2">
                                        {activity.metadata.change_count} field{activity.metadata.change_count !== 1 ? 's' : ''} changed:
                                      </div>
                                      <div className="space-y-1">
                                        {activity.metadata.changes.map((change, idx) => (
                                          <div key={idx} className="text-xs text-slate-600">
                                            <span className="font-medium text-slate-800">
                                              {change.field.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}:
                                            </span>
                                            {' '}
                                            <span className="text-slate-500">
                                              {typeof change.old_value === 'object' ? '[Object]' : String(change.old_value || 'empty').substring(0, 30)}
                                            </span>
                                            {' → '}
                                            <span className="text-emerald-700 font-medium">
                                              {typeof change.new_value === 'object' ? '[Object]' : String(change.new_value || 'empty').substring(0, 30)}
                                            </span>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                  {activity.metadata.old_status && activity.metadata.new_status && (
                                    <div className="p-2 bg-slate-50 rounded text-xs">
                                      Status: <span className="font-medium">{activity.metadata.old_status}</span> → <span className="font-medium">{activity.metadata.new_status}</span>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}

          {filteredActivities.length === 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <Activity className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">No activities found matching your filters</p>
              </CardContent>
            </Card>
          )}
        </div>
        </div>
      </div>
    </PullToRefresh>
  );
}