import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, Users, CheckCircle2, XCircle, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const EMPTY_PLAN = {
  name: "",
  tier: "basic",
  tagline: "",
  price_monthly: 0,
  price_annual: 0,
  currency: "USD",
  features: [],
  is_active: true,
  is_popular: false,
  xero_account_code: "200",
  max_users: null,
  sort_order: 0,
};

export default function PlanManagement() {
  const queryClient = useQueryClient();
  const [editPlan, setEditPlan] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [featureInput, setFeatureInput] = useState("");
  const [savingId, setSavingId] = useState(null);
  const [renewingId, setRenewingId] = useState(null);

  const { data: plans = [], refetch: refetchPlans } = useQuery({
    queryKey: ["plans-admin"],
    queryFn: () => base44.entities.PricePlan.list("sort_order", 20),
  });

  const { data: subscriptions = [], refetch: refetchSubs } = useQuery({
    queryKey: ["subscriptions-admin"],
    queryFn: async () => {
      const res = await base44.functions.invoke("subscriptionBilling", { action: "list_subscriptions" });
      return res.data?.subscriptions || [];
    },
  });

  const handleSavePlan = async () => {
    if (!editPlan.name || !editPlan.monthly_price) {
      toast.error("Name and monthly price are required");
      return;
    }
    setSavingId("saving");
    try {
      if (editPlan.id) {
        await base44.entities.PricePlan.update(editPlan.id, editPlan);
      } else {
        await base44.entities.PricePlan.create(editPlan);
      }
      toast.success("Plan saved");
      refetchPlans();
      setShowDialog(false);
      setEditPlan(null);
    } catch {
      toast.error("Failed to save plan");
    } finally {
      setSavingId(null);
    }
  };

  const handleDeletePlan = async (id) => {
    if (!confirm("Delete this plan?")) return;
    await base44.entities.PricePlan.delete(id);
    refetchPlans();
    toast.success("Plan deleted");
  };

  const handleCancelSubscription = async (id) => {
    if (!confirm("Cancel this subscription?")) return;
    await base44.functions.invoke("subscriptionBilling", { action: "cancel_subscription", subscription_id: id });
    refetchSubs();
    toast.success("Subscription cancelled");
  };

  const handleRenewSubscription = async (id) => {
    setRenewingId(id);
    const res = await base44.functions.invoke("subscriptionBilling", { action: "renew_subscription", subscription_id: id });
    if (res.data?.success) {
      toast.success("Renewal invoice created in Xero");
      refetchSubs();
    } else {
      toast.error("Renewal failed");
    }
    setRenewingId(null);
  };

  const openNew = () => {
    setEditPlan({ ...EMPTY_PLAN });
    setFeatureInput("");
    setShowDialog(true);
  };

  const openEdit = (plan) => {
    setEditPlan({ ...plan });
    setFeatureInput("");
    setShowDialog(true);
  };

  const addFeature = () => {
    if (!featureInput.trim()) return;
    setEditPlan(p => ({ ...p, features: [...(p.features || []), featureInput.trim()] }));
    setFeatureInput("");
  };

  const removeFeature = (i) => {
    setEditPlan(p => ({ ...p, features: p.features.filter((_, idx) => idx !== i) }));
  };

  const STATUS_COLORS = {
    active: "bg-green-100 text-green-800",
    cancelled: "bg-red-100 text-red-800",
    past_due: "bg-orange-100 text-orange-800",
    trialing: "bg-blue-100 text-blue-800",
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Plan Management</h1>
            <p className="text-sm text-slate-500 mt-1">Manage subscription plans and subscriber billing via Xero</p>
          </div>
          <Button onClick={openNew} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-1" /> New Plan
          </Button>
        </div>

        {/* Plans */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Price Plans ({plans.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {plans.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-6">No plans yet. Create your first plan.</p>
            ) : (
              <div className="space-y-3">
                {plans.map((plan) => (
                  <div key={plan.id} className="flex items-center justify-between p-4 border border-slate-200 rounded-lg bg-white">
                    <div className="flex items-center gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900">{plan.name}</span>
                          {plan.is_popular && <Badge className="bg-emerald-100 text-emerald-700 text-xs">Popular</Badge>}
                          {!plan.is_active && <Badge variant="outline" className="text-xs text-slate-400">Inactive</Badge>}
                        </div>
                        <p className="text-sm text-slate-500">{plan.currency} {plan.price_monthly}/mo · {plan.currency} {plan.price_annual || plan.price_monthly * 12}/yr</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline" onClick={() => openEdit(plan)}>
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" className="text-red-500 hover:text-red-700" onClick={() => handleDeletePlan(plan.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Subscriptions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="w-4 h-4" />
              Active Subscriptions ({subscriptions.filter(s => s.status === 'active').length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {subscriptions.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-6">No subscriptions yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-slate-500 border-b border-slate-100">
                      <th className="pb-2 font-medium">User</th>
                      <th className="pb-2 font-medium">Plan</th>
                      <th className="pb-2 font-medium">Cycle</th>
                      <th className="pb-2 font-medium">Amount</th>
                      <th className="pb-2 font-medium">Status</th>
                      <th className="pb-2 font-medium">Next Billing</th>
                      <th className="pb-2 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {subscriptions.map((sub) => (
                      <tr key={sub.id} className="py-2">
                        <td className="py-3 text-slate-900 font-medium">{sub.user_email}</td>
                        <td className="py-3">{sub.plan_name}</td>
                        <td className="py-3 capitalize">{sub.billing_cycle}</td>
                        <td className="py-3">{sub.currency} {sub.amount?.toLocaleString()}</td>
                        <td className="py-3">
                          <Badge className={`text-xs ${STATUS_COLORS[sub.status]}`}>{sub.status}</Badge>
                        </td>
                        <td className="py-3 text-slate-500">{sub.next_billing_date || '—'}</td>
                        <td className="py-3">
                          <div className="flex gap-1">
                            {sub.status === 'active' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-7 text-xs"
                                  disabled={renewingId === sub.id}
                                  onClick={() => handleRenewSubscription(sub.id)}
                                >
                                  <RefreshCw className="w-3 h-3 mr-1" />
                                  {renewingId === sub.id ? "..." : "Renew"}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-7 text-xs text-red-500"
                                  onClick={() => handleCancelSubscription(sub.id)}
                                >
                                  Cancel
                                </Button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Edit/Create Dialog */}
      <Dialog open={showDialog} onOpenChange={(v) => { if (!v) { setShowDialog(false); setEditPlan(null); } }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editPlan?.id ? "Edit Plan" : "New Plan"}</DialogTitle>
          </DialogHeader>
          {editPlan && (
            <div className="space-y-4 mt-2">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Plan Name *</label>
                  <Input value={editPlan.name} onChange={e => setEditPlan(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Pro" />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Tier *</label>
                  <Select value={editPlan.tier} onValueChange={v => setEditPlan(p => ({ ...p, tier: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic</SelectItem>
                      <SelectItem value="pro">Pro</SelectItem>
                      <SelectItem value="enterprise">Enterprise</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Tagline</label>
                <Input value={editPlan.tagline || ""} onChange={e => setEditPlan(p => ({ ...p, tagline: e.target.value }))} placeholder="Short description" />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Monthly Price *</label>
                  <Input type="number" value={editPlan.price_monthly} onChange={e => setEditPlan(p => ({ ...p, price_monthly: parseFloat(e.target.value) || 0 }))} />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Annual Price</label>
                  <Input type="number" value={editPlan.price_annual || ""} onChange={e => setEditPlan(p => ({ ...p, price_annual: parseFloat(e.target.value) || null }))} placeholder="Leave blank to auto-calc" />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Currency</label>
                  <Input value={editPlan.currency} onChange={e => setEditPlan(p => ({ ...p, currency: e.target.value }))} placeholder="USD" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Max Users</label>
                  <Input type="number" value={editPlan.max_users || ""} onChange={e => setEditPlan(p => ({ ...p, max_users: parseInt(e.target.value) || null }))} placeholder="Unlimited" />
                </div>
                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">Xero Account Code</label>
                  <Input value={editPlan.xero_account_code || "200"} onChange={e => setEditPlan(p => ({ ...p, xero_account_code: e.target.value }))} />
                </div>
              </div>

              {/* Features */}
              <div>
                <label className="text-xs font-medium text-slate-700 block mb-1">Features</label>
                <div className="flex gap-2 mb-2">
                  <Input
                    value={featureInput}
                    onChange={e => setFeatureInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && addFeature()}
                    placeholder="Add a feature..."
                  />
                  <Button size="sm" variant="outline" onClick={addFeature}>Add</Button>
                </div>
                <div className="space-y-1.5">
                  {(editPlan.features || []).map((f, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm bg-slate-50 px-3 py-1.5 rounded">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                      <span className="flex-1">{f}</span>
                      <button onClick={() => removeFeature(i)} className="text-slate-400 hover:text-red-500">
                        <XCircle className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Toggles */}
              <div className="flex gap-6">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={editPlan.is_active} onChange={e => setEditPlan(p => ({ ...p, is_active: e.target.checked }))} className="rounded" />
                  Active (visible publicly)
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={editPlan.is_popular} onChange={e => setEditPlan(p => ({ ...p, is_popular: e.target.checked }))} className="rounded" />
                  Mark as Popular
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => { setShowDialog(false); setEditPlan(null); }}>Cancel</Button>
                <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSavePlan} disabled={savingId === "saving"}>
                  {savingId === "saving" ? "Saving..." : "Save Plan"}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}