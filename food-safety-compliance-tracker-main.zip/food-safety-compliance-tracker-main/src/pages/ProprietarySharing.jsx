import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Lock, Plus, Share2, Trash2, Eye, Download } from "lucide-react";
import { usePermissions } from "@/components/permissions/usePermissions";
import ProprietaryUploadDialog from "@/components/proprietary/ProprietaryUploadDialog";
import ProprietaryDocumentsList from "@/components/proprietary/ProprietaryDocumentsList";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ProprietarySharing() {
  const { permissions, user } = usePermissions();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [deleteDoc, setDeleteDoc] = useState(null);
  const queryClient = useQueryClient();

  // Check if user has access
  const hasAccess = user?.role === "admin" || user?.role === "auditor";

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-slate-50 p-6">
        <div className="max-w-4xl mx-auto">
          <Card className="border-rose-200 bg-rose-50">
            <CardContent className="p-6 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-rose-900">Access Restricted</h3>
                <p className="text-sm text-rose-800 mt-1">
                  This section is only accessible to administrators and auditors.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-4 sm:p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-8">
          <div className="flex items-start gap-3">
            <div className="bg-amber-100 p-3 rounded-lg">
              <Lock className="w-6 h-6 text-amber-700" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Proprietary Information Management</h1>
              <p className="text-slate-600 text-sm mt-1">
                Securely upload, manage, and share sensitive proprietary information with controlled access
              </p>
            </div>
          </div>
          <Button onClick={() => setUploadOpen(true)} className="bg-emerald-600 hover:bg-emerald-700 gap-2 whitespace-nowrap">
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Upload Document</span>
            <span className="sm:hidden">Upload</span>
          </Button>
        </div>

        {/* Access Control Info */}
        <Card className="border-0 shadow-sm mb-6 bg-amber-50 border-l-4 border-amber-600">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Lock className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
              <div className="text-sm text-amber-800">
                <strong>Restricted Access:</strong> This section is only accessible to users with administrator or auditor roles. 
                All documents are encrypted and audit trails are maintained.
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Documents List */}
        <ProprietaryDocumentsList onDelete={setDeleteDoc} />

        {/* Upload Dialog */}
        <ProprietaryUploadDialog open={uploadOpen} onClose={() => setUploadOpen(false)} />

        {/* Delete Confirmation */}
        <AlertDialog open={!!deleteDoc} onOpenChange={(open) => !open && setDeleteDoc(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Proprietary Document</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{deleteDoc?.file_name}"? This action cannot be undone and will remove all associated sharing records.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogAction
              onClick={async () => {
                try {
                  await base44.entities.Document.delete(deleteDoc.id);
                  await base44.functions.invoke('logActivity', {
                    activity_type: 'document_deleted',
                    entity_type: 'Document',
                    entity_id: deleteDoc.id,
                    entity_label: deleteDoc.file_name,
                    description: `Proprietary document "${deleteDoc.file_name}" deleted by ${user?.email}`
                  });
                  queryClient.invalidateQueries({ queryKey: ['proprietary-documents'] });
                  setDeleteDoc(null);
                } catch (error) {
                  console.error('Error deleting document:', error);
                }
              }}
              className="bg-rose-600 hover:bg-rose-700"
            >
              Delete
            </AlertDialogAction>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}