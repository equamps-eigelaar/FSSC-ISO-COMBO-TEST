import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navigation, MapPin, Share2 } from "lucide-react";
import LocationMap from "@/components/location/LocationMap";
import LocationListView from "@/components/location/LocationListView";
import LocationSharingManager from "@/components/location/LocationSharingManager";
import { toast } from "sonner";

export default function LocationSharing() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [sharingEnabled, setSharingEnabled] = useState(false);

  // Load current user
  useEffect(() => {
    const loadUser = async () => {
      const user = await base44.auth.me();
      setCurrentUser(user);
    };
    loadUser();
  }, []);

  // Fetch shared locations visible to current user
  const { data: sharedLocations = [], refetch } = useQuery({
    queryKey: ["shared-locations", currentUser?.email],
    enabled: !!currentUser?.email,
    queryFn: async () => {
      const shares = await base44.entities.LocationShare.filter({
        shared_with_email: currentUser.email,
        status: "accepted",
      });

      const userEmails = shares.map((s) => s.owner_email);
      if (userEmails.length === 0) return [];

      const locations = await base44.entities.UserLocation.filter({
        user_email: { $in: userEmails },
      });

      return locations.sort((a, b) => 
        new Date(b.created_date) - new Date(a.created_date)
      );
    },
  });

  // Get current user's location
  const handleShareCurrentLocation = () => {
    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported by your browser");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        
        try {
          // Reverse geocode to get address (using a simple service)
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          const data = await response.json();

          await base44.entities.UserLocation.create({
            user_email: currentUser.email,
            latitude,
            longitude,
            accuracy,
            address: data.address?.city || data.address?.town || "Unknown Location",
            location_type: "snapshot",
            shared_with: [],
          });

          setCurrentLocation({ latitude, longitude, address: data.address?.city || "Unknown" });
          toast.success("Location snapshot shared");
          refetch();
        } catch (error) {
          toast.error("Failed to share location");
        }
      },
      (error) => {
        toast.error("Failed to get your location");
      }
    );
  };

  const handleStartLiveTracking = () => {
    if (!navigator.geolocation) {
      toast.error("Geolocation is not supported");
      return;
    }

    setSharingEnabled(true);
    toast.success("Live tracking started - your location will update every 30 seconds");

    const watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude, longitude, accuracy } = position.coords;

        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          const data = await response.json();

          await base44.entities.UserLocation.create({
            user_email: currentUser.email,
            latitude,
            longitude,
            accuracy,
            address: data.address?.city || "Unknown Location",
            location_type: "live",
            is_active: true,
            shared_with: [],
          });

          setCurrentLocation({ latitude, longitude, address: data.address?.city || "Unknown" });
        } catch (error) {
          console.error("Failed to update location", error);
        }
      },
      (error) => {
        setSharingEnabled(false);
        toast.error("Failed to access location");
      },
      { enableHighAccuracy: true, maximumAge: 0, timeout: 30000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  };

  const handleStopLiveTracking = () => {
    setSharingEnabled(false);
    toast.success("Live tracking stopped");
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Navigation className="w-6 h-6 text-emerald-600" />
            <h1 className="text-3xl font-bold text-slate-900">Location Sharing</h1>
          </div>
          <p className="text-sm text-slate-600">
            Share your location with invited friends and view their locations
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sidebar - Sharing Manager & Controls */}
          <div className="lg:col-span-1 space-y-4">
            {/* Share Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Share Your Location</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  onClick={handleShareCurrentLocation}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                  size="sm"
                >
                  <MapPin className="w-4 h-4 mr-1" />
                  Share Snapshot
                </Button>
                <Button
                  onClick={sharingEnabled ? handleStopLiveTracking : handleStartLiveTracking}
                  variant={sharingEnabled ? "destructive" : "outline"}
                  className="w-full"
                  size="sm"
                >
                  <Navigation className="w-4 h-4 mr-1" />
                  {sharingEnabled ? "Stop Tracking" : "Start Live Tracking"}
                </Button>
              </CardContent>
            </Card>

            {/* Location Sharing Manager */}
            <LocationSharingManager
              connections={currentUser?.invited_users || []}
            />
          </div>

          {/* Main Content - Map & List */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="map" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="map">Map View</TabsTrigger>
                <TabsTrigger value="list">List View</TabsTrigger>
              </TabsList>

              <TabsContent value="map" className="mt-4">
                <LocationMap
                  locations={sharedLocations}
                  currentUserLocation={currentLocation}
                />
              </TabsContent>

              <TabsContent value="list" className="mt-4">
                <LocationListView
                  locations={sharedLocations}
                  currentUserLocation={currentLocation}
                />
              </TabsContent>
            </Tabs>

            {/* Status Card */}
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-xs text-slate-500 font-semibold mb-1">Live Tracking</p>
                    <p className="text-lg font-bold text-slate-900">
                      {sharingEnabled ? "🔴 Active" : "⚪ Off"}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-semibold mb-1">Your Location</p>
                    <p className="text-sm text-slate-700 truncate">
                      {currentLocation?.address || "Not shared"}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-semibold mb-1">Visible To</p>
                    <p className="text-lg font-bold text-slate-900">{sharedLocations.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}