import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { CheckCircle2, XCircle, Clock, Zap, Copy, CreditCard, RefreshCw } from "lucide-react";

const STATUS_CONFIG = {
  pending: { badge: "bg-amber-100 text-amber-800", icon: Clock, label: "Pending" },
  approved: { badge: "bg-emerald-100 text-emerald-800", icon: CheckCircle2, label: "Approved" },
  trial_active: { badge: "bg-blue-100 text-blue-800", icon: Zap, label: "Trial Active" },
  payment_pending: { badge: "bg-orange-100 text-orange-800", icon: CreditCard, label: "Invoice Sent" },
  rejected: { badge: "bg-rose-100 text-rose-800", icon: XCircle, label: "Rejected" },
  active: { badge: "bg-emerald-100 text-emerald-800", icon: CheckCircle2, label: "Active" },
};

export default function UserApprovalDashboard() {
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [actionType, setActionType] = useState(null); // "approve" or "reject"
  const [notes, setNotes] = useState("");
  const [selectedPlanId, setSelectedPlanId] = useState("");
  const [billingCycle, setBillingCycle] = useState("monthly");
  const [checkingPayments, setCheckingPayments] = useState(false);
  const queryClient = useQueryClient();

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["user-access-requests"],
    queryFn: () => base44.asServiceRole.entities.UserAccessRequest.list("-created_date", 200),
  });

  const { data: plans = [] } = useQuery({
    queryKey: ["price-plans"],
    queryFn: () => base44.entities.PricePlan.filter({ is_active: true }),
  });

  const selectedPlan = plans.find(p => p.id === selectedPlanId);
  const planAmount = selectedPlan
    ? (billingCycle === "annual" ? (selectedPlan.price_annual || Math.round(selectedPlan.price_monthly * 0.85 * 12)) : selectedPlan.price_monthly)
    : 0;

  const handleCheckPayments = async () => {
    setCheckingPayments(true);
    try {
      const res = await base44.functions.invoke("grantAccessOnXeroPayment", {});
      toast.success(`Checked payments: ${res.data?.activated || 0} user(s) activated`);
      queryClient.invalidateQueries({ queryKey: ["user-access-requests"] });
    } catch (e) {
      toast.error("Failed to check payments: " + e.message);
    } finally {
      setCheckingPayments(false);
    }
  };

  const approveMutation = useMutation({
    mutationFn: (requestId) =>
      base44.functions.invoke("approveUserAccess", {
        request_id: requestId,
        approval_notes: notes,
        plan_id: (selectedPlanId && selectedPlanId !== "none") ? selectedPlanId : null,
        plan_name: (selectedPlanId && selectedPlanId !== "none") ? selectedPlan?.name : null,
        plan_amount: (selectedPlanId && selectedPlanId !== "none") ? planAmount : null,
        billing_cycle: billingCycle,
      }),
    onSuccess: (res) => {
      queryClient.invalidateQueries({ queryKey: ["user-access-requests"] });
      const status = res.data?.status;
      toast.success(status === "payment_pending" ? "Invoice sent via Xero — awaiting payment" : "User approved and trial activated");
      setSelectedRequest(null);
      setActionType(null);
      setNotes("");
      setSelectedPlanId("");
    },
    onError: () => toast.error("Failed to approve request"),
  });

  const rejectMutation = useMutation({
    mutationFn: (requestId) =>
      base44.functions.invoke("rejectUserAccess", { request_id: requestId, rejection_reason: notes }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-access-requests"] });
      toast.success("User request rejected");
      setSelectedRequest(null);
      setActionType(null);
      setNotes("");
    },
    onError: () => toast.error("Failed to reject request"),
  });

  const pendingCount = requests.filter((r) => r.status === "pending").length;
  const trialCount = requests.filter((r) => r.status === "trial_active").length;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-500">Loading access requests...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">User Access Approvals</h1>
            <p className="text-slate-500">Review requests, send Xero invoices, and grant access upon payment</p>
          </div>
          <Button onClick={handleCheckPayments} disabled={checkingPayments} variant="outline" className="gap-2">
            <RefreshCw className={`w-4 h-4 ${checkingPayments ? "animate-spin" : ""}`} />
            {checkingPayments ? "Checking..." : "Check Xero Payments"}
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="text-3xl font-bold text-amber-600">{pendingCount}</div>
              <p className="text-sm text-slate-600 mt-1">Pending Review</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-3xl font-bold text-blue-600">{trialCount}</div>
              <p className="text-sm text-slate-600 mt-1">On Trial</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-3xl font-bold text-emerald-600">{requests.filter((r) => r.status === "active").length}</div>
              <p className="text-sm text-slate-600 mt-1">Active Users</p>
            </CardContent>
          </Card>
        </div>

        {/* Requests Table */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">All Requests</CardTitle>
          </CardHeader>
          <CardContent>
            {requests.length === 0 ? (
              <p className="text-slate-400 text-center py-6">No access requests yet</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b border-slate-200">
                    <tr>
                      <th className="text-left py-3 px-4 font-semibold text-slate-700">Name</th>
                      <th className="text-left py-3 px-4 font-semibold text-slate-700">Email</th>
                      <th className="text-left py-3 px-4 font-semibold text-slate-700">Company</th>
                      <th className="text-left py-3 px-4 font-semibold text-slate-700">Status</th>
                      <th className="text-left py-3 px-4 font-semibold text-slate-700">Requested</th>
                      <th className="text-right py-3 px-4 font-semibold text-slate-700">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {requests.map((req) => {
                      const config = STATUS_CONFIG[req.status];
                      const Icon = config.icon;
                      return (
                        <tr key={req.id} className="border-b border-slate-100 hover:bg-slate-50">
                          <td className="py-3 px-4 font-medium text-slate-900">{req.full_name}</td>
                          <td className="py-3 px-4 text-slate-600">{req.email}</td>
                          <td className="py-3 px-4 text-slate-600">{req.company || "—"}</td>
                          <td className="py-3 px-4">
                            <Badge className={config.badge}>
                              <Icon className="w-3 h-3 mr-1" />
                              {config.label}
                            </Badge>
                          </td>
                          <td className="py-3 px-4 text-slate-500 text-xs">
                            {new Date(req.created_date).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-4 text-right">
                            {req.status === "pending" && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setSelectedRequest(req);
                                  setActionType(null);
                                }}
                              >
                                Review
                              </Button>
                            )}
                            {req.status === "rejected" && (
                              <span className="text-xs text-slate-400">Declined</span>
                            )}
                            {req.status === "trial_active" && (
                              <span className="text-xs text-blue-600 font-medium">
                                Trial ends: {req.trial_end_date}
                              </span>
                            )}
                            {req.status === "payment_pending" && (
                              <span className="text-xs text-orange-600 font-medium">
                                Invoice: {req.xero_invoice_number || "Sent"}
                              </span>
                            )}
                            {req.status === "active" && (
                              <span className="text-xs text-emerald-600 font-medium">Active</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Review Dialog */}
        <Dialog open={!!selectedRequest} onOpenChange={() => setSelectedRequest(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Review Access Request</DialogTitle>
            </DialogHeader>
            {selectedRequest && (
              <div className="space-y-4 py-4">
                <div>
                  <Label className="text-xs font-semibold text-slate-700">Name</Label>
                  <p className="text-sm text-slate-900 mt-1">{selectedRequest.full_name}</p>
                </div>
                <div>
                  <Label className="text-xs font-semibold text-slate-700">Email</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-sm text-slate-900 break-all">{selectedRequest.email}</p>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        navigator.clipboard.writeText(selectedRequest.email);
                        toast.success("Copied");
                      }}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label className="text-xs font-semibold text-slate-700">Company</Label>
                  <p className="text-sm text-slate-900 mt-1">{selectedRequest.company || "—"}</p>
                </div>
                <div>
                  <Label className="text-xs font-semibold text-slate-700">Requested</Label>
                  <p className="text-sm text-slate-600 mt-1">
                    {new Date(selectedRequest.created_date).toLocaleString()}
                  </p>
                </div>

                {!actionType && (
                  <div className="space-y-4 pt-2">
                    {/* Plan selection */}
                    <div>
                      <Label className="text-xs font-semibold text-slate-700">Subscription Plan</Label>
                      <Select value={selectedPlanId} onValueChange={setSelectedPlanId}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select a plan to invoice..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No invoice — trial only</SelectItem>
                          {plans.map(p => (
                            <SelectItem key={p.id} value={p.id}>
                              {p.name} — R{p.price_monthly?.toLocaleString()}/mo
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {selectedPlanId && selectedPlanId !== "none" && (
                      <div>
                        <Label className="text-xs font-semibold text-slate-700">Billing Cycle</Label>
                        <Select value={billingCycle} onValueChange={setBillingCycle}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="monthly">Monthly — R{selectedPlan?.price_monthly?.toLocaleString()}</SelectItem>
                            <SelectItem value="annual">Annual — R{(selectedPlan?.price_annual || Math.round((selectedPlan?.price_monthly || 0) * 0.85 * 12))?.toLocaleString()}</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-slate-500 mt-1">
                          Xero invoice will be created for <strong>R{planAmount?.toLocaleString()} ZAR</strong>. Access granted automatically when paid.
                        </p>
                      </div>
                    )}
                    <div className="flex gap-2">
                      <Button onClick={() => setActionType("approve")} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
                        <CheckCircle2 className="w-4 h-4 mr-1" />
                        {selectedPlanId && selectedPlanId !== "none" ? "Send Invoice" : "Approve (Trial)"}
                      </Button>
                      <Button onClick={() => setActionType("reject")} variant="outline" className="flex-1">
                        <XCircle className="w-4 h-4 mr-1" /> Reject
                      </Button>
                    </div>
                  </div>
                )}

                {actionType && (
                  <>
                    <div>
                      <Label className="text-xs font-semibold text-slate-700">
                        {actionType === "approve" ? "Approval Notes (Optional)" : "Rejection Reason (Required)"}
                      </Label>
                      <Textarea
                        placeholder={actionType === "approve" ? "e.g. Verified with HR team" : "e.g. Does not meet criteria"}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <DialogFooter className="gap-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setActionType(null);
                          setNotes("");
                        }}
                      >
                        Back
                      </Button>
                      <Button
                        onClick={() => {
                          if (actionType === "approve") {
                            approveMutation.mutate(selectedRequest.id);
                          } else {
                            if (!notes.trim()) {
                              toast.error("Rejection reason is required");
                              return;
                            }
                            rejectMutation.mutate(selectedRequest.id);
                          }
                        }}
                        disabled={approveMutation.isPending || rejectMutation.isPending}
                        className={actionType === "approve" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-rose-600 hover:bg-rose-700"}
                      >
                        {approveMutation.isPending || rejectMutation.isPending ? "Processing..." : (actionType === "approve" ? "Approve" : "Reject")}
                      </Button>
                    </DialogFooter>
                  </>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}