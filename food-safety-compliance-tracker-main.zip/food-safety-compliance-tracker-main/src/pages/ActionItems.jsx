import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useOfflineQuery } from "@/components/offline/useOfflineQuery";
import { useOfflineMutation } from "@/components/offline/useOfflineMutation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  CheckCircle, Clock, AlertTriangle, Play, Sparkles, Loader2,
  TrendingUp, Plus, Printer, User, Filter, LayoutGrid, List, Video
} from "lucide-react";
import TeamsMeetingDialog from "@/components/actions/TeamsMeetingDialog";
import { format } from "date-fns";
import { toast } from "sonner";
import PullToRefresh from "@/components/mobile/PullToRefresh";
import MobileSelect from "@/components/mobile/MobileSelect";
import KanbanBoard from "@/components/actions/KanbanBoard.jsx";
import ActionDetailDialog from "@/components/actions/ActionDetailDialog.jsx";

const PRIORITY_COLORS = {
  critical: "bg-rose-50 text-rose-700 border-rose-200",
  high: "bg-orange-50 text-orange-700 border-orange-200",
  medium: "bg-amber-50 text-amber-700 border-amber-200",
  low: "bg-blue-50 text-blue-700 border-blue-200",
};

const STATUS_COLORS = {
  completed: "bg-emerald-100 text-emerald-700",
  in_progress: "bg-blue-100 text-blue-700",
  blocked: "bg-rose-100 text-rose-700",
  pending: "bg-amber-100 text-amber-700",
};

function isOverdue(action) {
  if (!action.due_date || action.status === "completed") return false;
  return new Date(action.due_date) < new Date();
}

export default function ActionItems() {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("pending");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [personFilter, setPersonFilter] = useState("all");
  const [clauseFilter, setClauseFilter] = useState("all");
  const [urgencyFilter, setUrgencyFilter] = useState("all");
  const [selectedAction, setSelectedAction] = useState(null);
  const [showSummary, setShowSummary] = useState(false);
  const [summary, setSummary] = useState(null);
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [viewMode, setViewMode] = useState("list"); // "list" | "kanban"
  const [showMeetingDialog, setShowMeetingDialog] = useState(false);

  const { data: allActions = [], isLoading, refetch } = useOfflineQuery(
    ["action-items", "all"],
    "ActionItem",
    () => base44.entities.ActionItem.list("-created_date", 500)
  );

  // Derive unique responsible persons from data
  const allPersons = useMemo(() => {
    const persons = new Set();
    allActions.forEach(a => { if (a.assigned_to) persons.add(a.assigned_to); });
    return Array.from(persons).sort();
  }, [allActions]);

  // Derive unique clause numbers from data
  const allClauses = useMemo(() => {
    const clauses = new Set();
    allActions.forEach(a => { if (a.clause_reference) clauses.add(a.clause_reference); });
    return Array.from(clauses).sort();
  }, [allActions]);

  // Apply filters client-side
  const actions = useMemo(() => {
    const now = new Date();
    const in7Days = new Date(now); in7Days.setDate(now.getDate() + 7);
    return allActions.filter(a => {
      if (statusFilter !== "all" && a.status !== statusFilter) return false;
      if (priorityFilter !== "all" && a.priority !== priorityFilter) return false;
      if (personFilter !== "all" && a.assigned_to !== personFilter) return false;
      if (clauseFilter !== "all" && a.clause_reference !== clauseFilter) return false;
      if (urgencyFilter !== "all") {
        if (urgencyFilter === "overdue" && !isOverdue(a)) return false;
        if (urgencyFilter === "due_soon" && (isOverdue(a) || !a.due_date || new Date(a.due_date) > in7Days || a.status === "completed")) return false;
        if (urgencyFilter === "critical" && a.priority !== "critical") return false;
        if (urgencyFilter === "high_or_critical" && !["critical", "high"].includes(a.priority)) return false;
      }
      return true;
    });
  }, [allActions, statusFilter, priorityFilter, personFilter, clauseFilter, urgencyFilter]);

  const trackActionsMutation = useMutation({
    mutationFn: () => base44.functions.invoke("trackActionItems"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["action-items"] });
      toast.success("Actions tracked from AI recommendations");
    },
  });

  const createActionMutation = useMutation({
    mutationFn: (data) => base44.entities.ActionItem.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["action-items"] });
      toast.success("Action item created");
      setShowAddDialog(false);
    },
  });

  const updateActionMutation = useOfflineMutation("ActionItem", "update", ["action-items"]);

  const generateSummary = async () => {
    setLoadingSummary(true);
    try {
      const response = await base44.functions.invoke("generateActionProgressSummary");
      setSummary(response.data);
      setShowSummary(true);
    } catch {
      toast.error("Failed to generate summary");
    } finally {
      setLoadingSummary(false);
    }
  };

  const handlePrint = () => {
    const printContent = actions.map(a =>
      `${a.title} | Priority: ${a.priority} | Status: ${a.status} | Assigned: ${a.assigned_to || "—"} | Due: ${a.due_date ? format(new Date(a.due_date), "MMM d, yyyy") : "—"}`
    ).join("\n");

    const win = window.open("", "_blank");
    win.document.write(`
      <html><head><title>Action Items</title>
      <style>
        body { font-family: sans-serif; padding: 20px; }
        h1 { font-size: 18px; margin-bottom: 4px; }
        p { font-size: 12px; color: #666; margin-bottom: 16px; }
        table { width: 100%; border-collapse: collapse; font-size: 12px; }
        th { background: #f1f5f9; text-align: left; padding: 8px; border: 1px solid #e2e8f0; }
        td { padding: 8px; border: 1px solid #e2e8f0; vertical-align: top; }
        .overdue { color: #dc2626; font-weight: bold; }
      </style></head><body>
      <h1>Action Items</h1>
      <p>Printed ${format(new Date(), "MMM d, yyyy h:mm a")} — ${actions.length} item(s) shown</p>
      <table>
        <thead><tr>
          <th>Title</th><th>Priority</th><th>Status</th><th>Assigned To</th><th>Due Date</th>
        </tr></thead>
        <tbody>
          ${actions.map(a => `<tr>
            <td>${a.title}${a.description ? `<br/><small style="color:#64748b">${a.description}</small>` : ""}</td>
            <td>${a.priority || "—"}</td>
            <td>${a.status?.replace(/_/g, " ") || "—"}</td>
            <td>${a.assigned_to || "—"}</td>
            <td class="${isOverdue(a) ? "overdue" : ""}">${a.due_date ? format(new Date(a.due_date), "MMM d, yyyy") : "—"}${isOverdue(a) ? " ⚠" : ""}</td>
          </tr>`).join("")}
        </tbody>
      </table>
      </body></html>
    `);
    win.document.close();
    win.print();
  };

  const pending = allActions.filter(a => a.status === "pending").length;
  const inProgress = allActions.filter(a => a.status === "in_progress").length;
  const completed = allActions.filter(a => a.status === "completed").length;
  const overdue = allActions.filter(isOverdue).length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={refetch}>
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Action Items</h1>
              <p className="text-sm text-slate-500 mt-1">Track and manage compliance actions</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={() => setShowMeetingDialog(true)} className="text-blue-600 border-blue-200 hover:bg-blue-50">
                <Video className="w-4 h-4 mr-2" />
                Teams Meeting
              </Button>
              <Button variant="outline" onClick={handlePrint} title="Print filtered list">
                <Printer className="w-4 h-4 mr-2" />
                Print
              </Button>
              <Button onClick={generateSummary} disabled={loadingSummary} variant="outline">
                {loadingSummary ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <TrendingUp className="w-4 h-4 mr-2" />}
                Progress Summary
              </Button>
              <Button onClick={() => trackActionsMutation.mutate()} disabled={trackActionsMutation.isPending} variant="outline">
                {trackActionsMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
                Track AI Actions
              </Button>
              <Button onClick={() => setShowAddDialog(true)} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Action
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid gap-4 md:grid-cols-4 mb-6">
            {[
              { label: "Pending", count: pending, icon: Clock, color: "text-amber-600", bold: "text-amber-700" },
              { label: "In Progress", count: inProgress, icon: Play, color: "text-blue-600", bold: "text-blue-700" },
              { label: "Completed", count: completed, icon: CheckCircle, color: "text-emerald-600", bold: "text-emerald-700" },
              { label: "Overdue", count: overdue, icon: AlertTriangle, color: "text-rose-600", bold: "text-rose-700" },
            ].map(({ label, count, icon: Icon, color, bold }) => (
              <Card key={label} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Icon className={`w-4 h-4 ${color}`} />
                    <span className="text-xs text-slate-500">{label}</span>
                  </div>
                  <div className={`text-3xl font-bold ${bold}`}>{count}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* View Toggle */}
          <div className="flex items-center justify-end mb-3 gap-2">
            <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-white shadow-sm">
              <button
                onClick={() => setViewMode("list")}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium transition-colors ${viewMode === "list" ? "bg-emerald-600 text-white" : "text-slate-500 hover:bg-slate-50"}`}
              >
                <List className="w-3.5 h-3.5" /> List
              </button>
              <button
                onClick={() => setViewMode("kanban")}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium transition-colors ${viewMode === "kanban" ? "bg-emerald-600 text-white" : "text-slate-500 hover:bg-slate-50"}`}
              >
                <LayoutGrid className="w-3.5 h-3.5" /> Kanban
              </button>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-4 items-center">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />

            <MobileSelect value={statusFilter} onValueChange={setStatusFilter} placeholder="Status" triggerClassName="w-36 min-h-[44px]">
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="blocked">Blocked</SelectItem>
            </MobileSelect>

            <MobileSelect value={priorityFilter} onValueChange={setPriorityFilter} placeholder="Priority" triggerClassName="w-36 min-h-[44px]">
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </MobileSelect>

            <MobileSelect value={urgencyFilter} onValueChange={setUrgencyFilter} placeholder="Urgency" triggerClassName="w-40 min-h-[44px]">
              <SelectItem value="all">All Urgency</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
              <SelectItem value="due_soon">Due This Week</SelectItem>
              <SelectItem value="critical">Critical Priority</SelectItem>
              <SelectItem value="high_or_critical">High + Critical</SelectItem>
            </MobileSelect>

            {allClauses.length > 0 && (
              <MobileSelect value={clauseFilter} onValueChange={setClauseFilter} placeholder="Clause" triggerClassName="w-44 min-h-[44px]">
                <SelectItem value="all">All Clauses</SelectItem>
                {allClauses.map(c => (
                  <SelectItem key={c} value={c}>Clause {c}</SelectItem>
                ))}
              </MobileSelect>
            )}

            {allPersons.length > 0 && (
              <MobileSelect value={personFilter} onValueChange={setPersonFilter} placeholder="Assigned To" triggerClassName="w-48 min-h-[44px]">
                <SelectItem value="all">All People</SelectItem>
                {allPersons.map(p => (
                  <SelectItem key={p} value={p}>{p}</SelectItem>
                ))}
              </MobileSelect>
            )}

            {(statusFilter !== "pending" || priorityFilter !== "all" || personFilter !== "all" || clauseFilter !== "all" || urgencyFilter !== "all") && (
              <Button variant="ghost" size="sm" className="text-slate-500 min-h-[44px]" onClick={() => { setStatusFilter("pending"); setPriorityFilter("all"); setPersonFilter("all"); setClauseFilter("all"); setUrgencyFilter("all"); }}>
                Clear filters
              </Button>
            )}

            <span className="text-xs text-slate-400 ml-auto">{actions.length} item{actions.length !== 1 ? "s" : ""}</span>
          </div>

          {/* List / Kanban */}
          {viewMode === "kanban" ? (
            <KanbanBoard
              actions={actions}
              allActions={allActions}
              onCardClick={setSelectedAction}
              onStatusChange={(action, newStatus) => {
                const data = { status: newStatus };
                if (newStatus === "completed") data.completed_date = new Date().toISOString();
                updateActionMutation.mutate({ entityId: action.id, data });
              }}
            />
          ) : (
            <div className="space-y-3 pb-4 overflow-y-auto" style={{ WebkitOverflowScrolling: "touch" }}>
              {actions.length === 0 ? (
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-12 text-center text-slate-400">
                    <CheckCircle className="w-10 h-10 mx-auto mb-3 text-slate-300" />
                    No action items match the selected filters.
                  </CardContent>
                </Card>
              ) : (
                actions.map((action) => {
                  const subtasks = action.subtasks || [];
                  const completedSub = subtasks.filter(s => s.completed).length;
                  const blockedDeps = (action.depends_on || []).some(id => {
                    const dep = allActions.find(a => a.id === id);
                    return dep && dep.status !== "completed";
                  });
                  return (
                    <Card
                      key={action.id}
                      className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => setSelectedAction(action)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-2 mb-1">
                              <h3 className="text-sm font-semibold text-slate-900">{action.title}</h3>
                              {isOverdue(action) && (
                                <Badge variant="outline" className="bg-rose-50 text-rose-700 border-rose-200 text-xs">
                                  <AlertTriangle className="w-3 h-3 mr-1" />Overdue
                                </Badge>
                              )}
                              {blockedDeps && (
                                <Badge variant="outline" className="bg-rose-50 text-rose-600 border-rose-200 text-xs">Dep. pending</Badge>
                              )}
                            </div>
                            <p className="text-sm text-slate-600 line-clamp-2 mb-2">{action.description}</p>
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge variant="outline" className={`text-xs ${PRIORITY_COLORS[action.priority] || ""}`}>{action.priority}</Badge>
                              <Badge variant="outline" className="text-xs">{action.source_type?.replace(/_/g, " ")}</Badge>
                              {action.clause_reference && (
                                <Badge variant="outline" className="text-xs bg-slate-50 text-slate-600 border-slate-200">Clause {action.clause_reference}</Badge>
                              )}
                              {action.assigned_to && (
                                <span className="flex items-center gap-1 text-xs text-slate-500">
                                  <User className="w-3 h-3" />{action.assigned_to}
                                </span>
                              )}
                              {action.due_date && (
                                <Badge variant="outline" className="text-xs">
                                  <Clock className="w-3 h-3 mr-1" />Due {format(new Date(action.due_date), "MMM d")}
                                </Badge>
                              )}
                              {subtasks.length > 0 && (
                                <span className="text-xs text-slate-500">{completedSub}/{subtasks.length} subtasks</span>
                              )}
                            </div>
                            {subtasks.length > 0 && (
                              <div className="mt-2 h-1 bg-slate-100 rounded-full overflow-hidden w-32">
                                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${(completedSub / subtasks.length) * 100}%` }} />
                              </div>
                            )}
                          </div>
                          <Badge className={`text-xs shrink-0 ${STATUS_COLORS[action.status] || ""}`}>
                            {action.status?.replace(/_/g, " ")}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          )}
        </div>

        {selectedAction && (
          <ActionDetailDialog
            action={selectedAction}
            onClose={() => setSelectedAction(null)}
            onUpdate={(data) => updateActionMutation.mutate(data)}
            allActions={allActions}
          />
        )}

        {showAddDialog && (
          <AddActionDialog
            onClose={() => setShowAddDialog(false)}
            onSave={(data) => createActionMutation.mutate(data)}
            isSaving={createActionMutation.isPending}
          />
        )}

        {showSummary && summary && (
          <ProgressSummaryDialog summary={summary} onClose={() => setShowSummary(false)} />
        )}

        {showMeetingDialog && (
          <TeamsMeetingDialog
            onClose={() => setShowMeetingDialog(false)}
            defaultSubject="Compliance Action Items Review"
          />
        )}
      </div>
    </PullToRefresh>
  );
}

function AddActionDialog({ onClose, onSave, isSaving }) {
  const [form, setForm] = useState({
    title: "",
    description: "",
    priority: "medium",
    status: "pending",
    assigned_to: "",
    due_date: "",
    source_type: "manual",
  });

  const handleSave = () => {
    if (!form.title.trim()) { toast.error("Title is required"); return; }
    onSave({ ...form, due_date: form.due_date || undefined });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-4 h-4 text-emerald-600" />
            Add Action Item
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label className="text-xs">Title *</Label>
            <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Action title" />
          </div>
          <div>
            <Label className="text-xs">Description</Label>
            <Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} placeholder="Describe the action..." />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Priority</Label>
              <Select value={form.priority} onValueChange={v => setForm({ ...form, priority: v })}>
                <SelectTrigger className="min-h-[44px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                <SelectTrigger className="min-h-[44px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Assigned To (email)</Label>
              <Input value={form.assigned_to} onChange={e => setForm({ ...form, assigned_to: e.target.value })} placeholder="user@email.com" />
            </div>
            <div>
              <Label className="text-xs">Due Date</Label>
              <Input type="date" value={form.due_date} onChange={e => setForm({ ...form, due_date: e.target.value })} />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSave} disabled={isSaving} className="bg-emerald-600 hover:bg-emerald-700">
              {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Create Action
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}


function ProgressSummaryDialog({ summary, onClose }) {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            AI Progress Summary
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3"><CardTitle className="text-sm">Executive Summary</CardTitle></CardHeader>
            <CardContent><p className="text-sm text-slate-600">{summary.summary.executive_summary}</p></CardContent>
          </Card>
          {summary.summary.key_concerns?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3"><CardTitle className="text-sm">Key Concerns</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {summary.summary.key_concerns.map((concern, idx) => (
                    <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-600 mt-0.5 shrink-0" />{concern}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
          {summary.summary.recommendations?.length > 0 && (
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3"><CardTitle className="text-sm">Recommendations</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {summary.summary.recommendations.map((rec, idx) => (
                    <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />{rec}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
          <Button onClick={onClose} className="w-full">Close</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}