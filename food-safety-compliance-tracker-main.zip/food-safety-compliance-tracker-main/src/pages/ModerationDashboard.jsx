import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, Shield, TrendingUp, Clock } from "lucide-react";
import ReportList from "@/components/moderation/ReportList";
import ReportDetail from "@/components/moderation/ReportDetail";
import { usePermissions } from "@/components/permissions/usePermissions";

export default function ModerationDashboard() {
  const { permissions, isAdmin } = usePermissions();
  const [selectedReportId, setSelectedReportId] = useState(null);
  const [statusFilter, setStatusFilter] = useState("pending");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [refreshKey, setRefreshKey] = useState(0);

  // Check admin access
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card className="p-6 max-w-md">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-6 h-6 text-rose-500" />
            <h2 className="text-lg font-semibold text-slate-900">Access Denied</h2>
          </div>
          <p className="text-sm text-slate-600">
            Only administrators and moderators can access the moderation dashboard.
          </p>
        </Card>
      </div>
    );
  }

  // Fetch reports
  const { data: allReports = [], isLoading, refetch } = useQuery({
    queryKey: ["user-reports", statusFilter, priorityFilter, refreshKey],
    queryFn: async () => {
      const reports = await base44.entities.UserReport.list("-created_date", 100);
      return reports
        .filter((r) => statusFilter === "all" || r.status === statusFilter)
        .filter((r) => priorityFilter === "all" || r.priority === priorityFilter);
    },
  });

  // Statistics
  const stats = {
    pending: allReports.filter((r) => r.status === "pending").length,
    critical: allReports.filter((r) => r.priority === "critical").length,
    resolved: allReports.filter((r) => r.status === "resolved").length,
  };

  const selectedReport = allReports.find((r) => r.id === selectedReportId);

  const handleActionTaken = () => {
    setRefreshKey((k) => k + 1);
    setSelectedReportId(null);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-6 h-6 text-emerald-600" />
            <h1 className="text-3xl font-bold text-slate-900">Moderation Dashboard</h1>
          </div>
          <p className="text-sm text-slate-600">
            Review reported content and users, manage enforcement actions
          </p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-semibold mb-1">Pending Reports</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.pending}</p>
                </div>
                <Clock className="w-8 h-8 text-amber-500 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-semibold mb-1">Critical Priority</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.critical}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-rose-500 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-semibold mb-1">Resolved</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.resolved}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-emerald-500 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-semibold mb-1">Total Reports</p>
                  <p className="text-2xl font-bold text-slate-900">{allReports.length}</p>
                </div>
                <Shield className="w-8 h-8 text-slate-500 opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Report List */}
          <div className="lg:col-span-1">
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3 border-b border-slate-100">
                <CardTitle className="text-sm font-semibold">Reports</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-3 mb-4">
                  <div>
                    <label className="text-xs text-slate-500 font-semibold block mb-2">
                      Status
                    </label>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="under_review">Under Review</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-xs text-slate-500 font-semibold block mb-2">
                      Priority
                    </label>
                    <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                      <SelectTrigger className="text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Priorities</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    onClick={() => refetch()}
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    Refresh
                  </Button>
                </div>

                {isLoading ? (
                  <div className="text-center py-4">
                    <div className="w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
                  </div>
                ) : (
                  <ReportList
                    reports={allReports}
                    onSelectReport={setSelectedReportId}
                    selectedReportId={selectedReportId}
                  />
                )}
              </CardContent>
            </Card>
          </div>

          {/* Report Detail */}
          <div className="lg:col-span-2">
            <ReportDetail
              report={selectedReport}
              onClose={() => setSelectedReportId(null)}
              onActionTaken={handleActionTaken}
            />
          </div>
        </div>
      </div>
    </div>
  );
}