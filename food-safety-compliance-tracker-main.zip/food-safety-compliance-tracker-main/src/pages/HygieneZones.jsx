import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import HygieneZoneDialog from "@/components/food/HygieneZoneDialog";

export default function HygieneZones() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingZone, setEditingZone] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [classificationFilter, setClassificationFilter] = useState("all");

  const { data: zones = [], isLoading } = useQuery({
    queryKey: ["hygiene-zones"],
    queryFn: () => base44.entities.HygieneZone.list("-created_date", 100),
  });

  const filteredZones = zones.filter(zone => {
    const matchesSearch = zone.zone_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      zone.location?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClassification = classificationFilter === "all" || zone.zone_classification === classificationFilter;
    return matchesSearch && matchesClassification;
  });

  const classificationColors = {
    high_care: "bg-emerald-50 text-emerald-700 border-emerald-200",
    high_risk: "bg-red-50 text-red-700 border-red-200",
    low_care: "bg-blue-50 text-blue-700 border-blue-200",
    low_risk: "bg-slate-50 text-slate-700 border-slate-200",
    ambient: "bg-amber-50 text-amber-700 border-amber-200",
  };

  const handleEdit = (zone) => {
    setEditingZone(zone);
    setShowDialog(true);
  };

  const handleClose = () => {
    setShowDialog(false);
    setEditingZone(null);
  };

  if (isLoading) {
    return <div className="p-6 text-slate-500">Loading hygiene zones...</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Hygiene Zones</h1>
            <p className="text-slate-600 mt-1">Manage hygiene zoning and environmental controls</p>
          </div>
          <Button onClick={() => setShowDialog(true)} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Hygiene Zone
          </Button>
        </div>

        <div className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search zones or locations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={classificationFilter} onValueChange={setClassificationFilter}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Classifications</SelectItem>
              <SelectItem value="high_care">High Care</SelectItem>
              <SelectItem value="high_risk">High Risk</SelectItem>
              <SelectItem value="low_care">Low Care</SelectItem>
              <SelectItem value="low_risk">Low Risk</SelectItem>
              <SelectItem value="ambient">Ambient</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {filteredZones.map((zone) => (
            <Card key={zone.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleEdit(zone)}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <ShieldCheck className="w-5 h-5 text-emerald-600" />
                      <CardTitle className="text-xl">{zone.zone_name}</CardTitle>
                    </div>
                    <p className="text-sm text-slate-600">{zone.location}</p>
                  </div>
                  <Badge variant="outline" className={classificationColors[zone.zone_classification]}>
                    {zone.zone_classification.replace(/_/g, " ")}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs font-medium text-slate-500 mb-1">Cleaning Frequency</p>
                    <p className="text-sm text-slate-900 capitalize">{zone.cleaning_frequency?.replace(/_/g, " ") || "—"}</p>
                  </div>
                  {zone.activities?.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-slate-500 mb-1">Activities</p>
                      <div className="flex flex-wrap gap-1">
                        {zone.activities.slice(0, 3).map((activity, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">{activity}</Badge>
                        ))}
                        {zone.activities.length > 3 && (
                          <Badge variant="outline" className="text-xs">+{zone.activities.length - 3} more</Badge>
                        )}
                      </div>
                    </div>
                  )}
                  {zone.next_audit_date && (
                    <p className="text-xs text-slate-500">
                      Next audit: {new Date(zone.next_audit_date).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredZones.length === 0 && (
            <Card className="md:col-span-2">
              <CardContent className="text-center py-12">
                <ShieldCheck className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">No hygiene zones found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {showDialog && (
        <HygieneZoneDialog
          open={showDialog}
          onClose={handleClose}
          zone={editingZone}
        />
      )}
    </div>
  );
}