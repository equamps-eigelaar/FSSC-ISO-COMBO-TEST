import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  CheckCircle2, ArrowLeft, Building2, FileText, Loader2,
  Mail, ExternalLink, Clock
} from "lucide-react";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

export default function Checkout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [plan, setPlan] = useState(null);
  const [billingCycle, setBillingCycle] = useState("monthly");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [invoiceResult, setInvoiceResult] = useState(null);

  const [formData, setFormData] = useState({
    company_name: "",
    contact_name: "",
    email: "",
    phone: "",
    address: "",
  });

  useEffect(() => {
    base44.auth.me().then(u => {
      if (u?.email) setFormData(prev => ({ ...prev, email: u.email, contact_name: u.full_name || "" }));
    }).catch(() => {});

    const state = location.state;
    if (state?.plan) {
      setPlan(state.plan);
      setBillingCycle(state.billingCycle || "monthly");
    } else {
      toast.error("No plan selected");
      navigate(createPageUrl("PricingPlans"));
    }
  }, [location.state, navigate]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.company_name || !formData.contact_name || !formData.email) {
      toast.error("Please fill in all required fields");
      return;
    }

    setLoading(true);
    try {
      const response = await base44.functions.invoke("createSubscriptionInvoice", {
        customerName: formData.company_name,
        customerEmail: formData.email,
        planId: plan.id,
        billingCycle,
      });

      if (response.data.success) {
        setInvoiceResult(response.data);
        setSubmitted(true);
        toast.success("Invoice created! Check your email.");
      } else {
        toast.error(response.data.error || "Failed to create invoice");
      }
    } catch (error) {
      toast.error(error.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  if (!plan) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  const price = billingCycle === "monthly" ? plan.price_monthly : plan.price_annual;
  const totalPrice = price || 0;

  // ── Success / Invoice Pending Screen ──────────────────────────────────────
  if (submitted) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center py-12 px-4">
        <div className="max-w-lg w-full">
          <Card className="text-center shadow-lg">
            <CardContent className="pt-10 pb-8 px-8 space-y-5">
              <div className="flex justify-center">
                <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center">
                  <FileText className="w-8 h-8 text-emerald-600" />
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-slate-900">Invoice Sent!</h2>
                <p className="text-slate-500 mt-2 text-sm leading-relaxed">
                  Your Xero invoice has been created and emailed to{" "}
                  <strong>{formData.email}</strong>. Your account will be activated
                  automatically once payment is confirmed.
                </p>
              </div>

              {invoiceResult?.xeroInvoice?.number && (
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-left space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Invoice Number</span>
                    <span className="font-semibold text-slate-900">{invoiceResult.xeroInvoice.number}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Plan</span>
                    <span className="font-semibold text-slate-900">{plan.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Amount Due</span>
                    <span className="font-semibold text-slate-900">
                      {plan.currency || "ZAR"} {totalPrice.toLocaleString()}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-lg p-3 text-left">
                <Clock className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-amber-800">
                  <strong>Next step:</strong> Pay the Xero invoice sent to your email.
                  Access is granted automatically once payment is received — usually within minutes.
                </p>
              </div>

              {invoiceResult?.xeroInvoice?.url && (
                <a
                  href={invoiceResult.xeroInvoice.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 w-full justify-center bg-emerald-600 hover:bg-emerald-700 text-white font-medium py-2.5 px-4 rounded-lg transition-colors text-sm"
                >
                  <ExternalLink className="w-4 h-4" />
                  View &amp; Pay Invoice in Xero
                </a>
              )}

              <Button
                variant="outline"
                className="w-full"
                onClick={() => navigate(createPageUrl("PricingPlans"))}
              >
                Back to Plans
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // ── Checkout Form ─────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl("PricingPlans"))}
            className="mb-4 gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Plans
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">Complete Your Subscription</h1>
          <p className="text-slate-600 mt-2">
            An invoice will be created in Xero and sent to your email. Access is activated on payment.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-emerald-600" />
                  Company Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="company_name">Company Name *</Label>
                    <Input
                      id="company_name"
                      value={formData.company_name}
                      onChange={(e) => handleInputChange("company_name", e.target.value)}
                      placeholder="Acme Manufacturing Ltd"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="contact_name">Contact Name *</Label>
                    <Input
                      id="contact_name"
                      value={formData.contact_name}
                      onChange={(e) => handleInputChange("contact_name", e.target.value)}
                      placeholder="John Smith"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="john@acme.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      placeholder="+27 11 123 4567"
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Business Address</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                      placeholder="123 Business Street, Johannesburg"
                    />
                  </div>

                  <Separator className="my-4" />

                  {/* Xero payment info */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
                    <Mail className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div className="text-sm text-blue-800">
                      <strong>Paid via Xero Invoice</strong>
                      <p className="mt-1 text-blue-700 leading-relaxed">
                        Submitting will generate an authorised invoice in Xero and send it to your email.
                        Your account activates automatically once payment is received.
                      </p>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 gap-2"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Creating Invoice...
                      </>
                    ) : (
                      <>
                        <FileText className="w-4 h-4" />
                        Generate Xero Invoice
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle className="text-lg">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-semibold text-slate-900">{plan.name}</h3>
                      <p className="text-xs text-slate-500 mt-1">{plan.tagline}</p>
                    </div>
                    {plan.is_popular && (
                      <Badge className="bg-emerald-100 text-emerald-700">Popular</Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-3">
                    <Badge variant="outline" className="text-xs">
                      {billingCycle === "monthly" ? "Monthly" : "Annual"}
                    </Badge>
                    {plan.max_users > 0 && (
                      <Badge variant="outline" className="text-xs">
                        Up to {plan.max_users} users
                      </Badge>
                    )}
                  </div>
                </div>

                <Separator />

                <div className="flex justify-between items-baseline">
                  <span className="text-lg font-semibold text-slate-900">Total</span>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-slate-900">
                      {plan.currency || "ZAR"} {totalPrice.toLocaleString()}
                    </div>
                    <div className="text-xs text-slate-500">
                      {billingCycle === "monthly" ? "per month" : "per year"}
                    </div>
                  </div>
                </div>

                <div className="bg-emerald-50 rounded-lg p-3">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                    <div className="text-xs text-emerald-800">
                      <strong>Xero Invoice:</strong> Created instantly and emailed to you.
                      Access activates automatically on payment — no manual steps needed.
                    </div>
                  </div>
                </div>

                {plan.features && plan.features.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900 mb-2">Included Features</h4>
                      <ul className="space-y-1.5 text-xs text-slate-600">
                        {plan.features.slice(0, 5).map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600 mt-0.5 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                        {plan.features.length > 5 && (
                          <li className="text-slate-400 italic">+{plan.features.length - 5} more features</li>
                        )}
                      </ul>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}