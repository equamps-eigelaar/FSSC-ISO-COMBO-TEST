import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Clock,
  XCircle,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  BarChart3,
  FileText,
  Download,
  Sparkles,
  DatabaseZap,
  UserPlus,
  ChevronDown,
  Users,
  Monitor,
  LogOut
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import SectionProgressChart from "@/components/dashboard/SectionProgressChart";
import StatusBreakdown from "@/components/dashboard/StatusBreakdown";
import RecentActivity from "@/components/dashboard/RecentActivity";
import ComplianceScoreRing from "@/components/dashboard/ComplianceScoreRing";
import ComplianceTrendChart from "@/components/dashboard/ComplianceTrendChart";
import RiskBreakdownChart from "@/components/dashboard/RiskBreakdownChart";
import CompletionRateWidget from "@/components/dashboard/CompletionRateWidget";
import OutstandingActions from "@/components/dashboard/OutstandingActions";
import ReportDialog from "@/components/reports/ReportDialog";
import ScheduleReportDialog from "@/components/reports/ScheduleReportDialog";
import AIReportDialog from "@/components/reports/AIReportDialog";
import AISuggestedActions from "@/components/actions/AISuggestedActions";
import AuditPlanSuggestions from "@/components/audit/AuditPlanSuggestions";
import MobileQuickActions from "@/components/mobile/MobileQuickActions";
import GlobalSearch from "@/components/dashboard/GlobalSearch";
import BugReportDialog from "@/components/support/BugReportDialog";
import ComplianceAlertsWidget from "@/components/dashboard/ComplianceAlertsWidget";
import OnboardingChecklist from "@/components/onboarding/OnboardingChecklist";

const sections = [
"4 - Context of the Organization",
"5 - Leadership",
"6 - Planning",
"7 - Support",
"8 - Operation",
"9 - Performance Evaluation",
"10 - Improvement",
"TS 22002-4 - Establishment",
"TS 22002-4 - Utilities",
"TS 22002-4 - Equipment",
"TS 22002-4 - Hygiene",
"TS 22002-4 - Personnel",
"TS 22002-4 - Transportation",
"TS 22002-4 - Product Information",
"TS 22002-4 - Other Requirements"];


export default function Dashboard() {
  const [showReportDialog, setShowReportDialog] = React.useState(false);
  const [showScheduleDialog, setShowScheduleDialog] = React.useState(false);
  const [showAIReportDialog, setShowAIReportDialog] = React.useState(false);
  const [isDownloadingSnapshot, setIsDownloadingSnapshot] = React.useState(false);
  const [showInviteDialog, setShowInviteDialog] = React.useState(false);
  const [showBugReport, setShowBugReport] = React.useState(false);
  const [currentUser, setCurrentUser] = React.useState(null);
  const [inviteEmail, setInviteEmail] = React.useState("");
  const [inviteRole, setInviteRole] = React.useState("contributor");
  const [isInviting, setIsInviting] = React.useState(false);

  React.useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const handleInviteUser = async () => {
    if (!inviteEmail) return;
    setIsInviting(true);
    try {
      await base44.users.inviteUser(inviteEmail, "user");
      toast.success(`Invitation sent to ${inviteEmail}`, {
        description: "They will receive an email to join the application.",
      });
      setShowInviteDialog(false);
      setInviteEmail("");
      setInviteRole("contributor");
    } catch {
      toast.error("Failed to send invitation. Please try again.");
    } finally {
      setIsInviting(false);
    }
  };

  const { data: requirements = [], isLoading } = useQuery({
    queryKey: ["compliance-requirements"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-created_date", 200)
  });

  const { data: risks = [] } = useQuery({
    queryKey: ["risk-assessments-all"],
    queryFn: () => base44.entities.RiskAssessment.list("-created_date", 200)
  });

  const total = requirements.length;
  const compliant = requirements.filter((r) => r.status === "compliant").length;
  const inProgress = requirements.filter((r) => r.status === "in_progress").length;
  const partial = requirements.filter((r) => r.status === "partial").length;
  const notStarted = requirements.filter((r) => r.status === "not_started").length;
  const nonCompliant = requirements.filter((r) => r.status === "non_compliant").length;
  const overallScore = total > 0 ? Math.round(compliant / total * 100) : 0;
  const progressScore = total > 0 ? Math.round((compliant + partial * 0.5 + inProgress * 0.25) / total * 100) : 0;

  const criticalItems = requirements.filter((r) => r.priority === "critical" && r.status !== "compliant");

  const handleDownloadSnapshot = async () => {
    setIsDownloadingSnapshot(true);
    try {
      const escape = (v) => {
        if (v == null) return "";
        const s = String(v).replace(/"/g, '""');
        return /[",\n\r]/.test(s) ? `"${s}"` : s;
      };
      const toCSV = (headers, rows) =>
        [headers.join(","), ...rows.map(r => headers.map(h => escape(r[h])).join(","))].join("\r\n");

      const reqHeaders = ["clause_number","clause_title","section","status","priority","responsible_person","due_date","completion_percentage","findings","corrective_actions","evidence_notes"];
      const reqRows = requirements.map(r => ({
        clause_number: r.clause_number,
        clause_title: r.clause_title,
        section: r.section,
        status: r.status,
        priority: r.priority,
        responsible_person: r.responsible_person,
        due_date: r.due_date,
        completion_percentage: r.completion_percentage,
        findings: r.findings,
        corrective_actions: r.corrective_actions,
        evidence_notes: r.evidence_notes,
      }));

      const riskHeaders = ["hazard_type","hazard_description","likelihood","severity","risk_level","residual_risk","status","workflow_status","assigned_to","review_date"];
      const riskRows = risks.map(r => ({
        hazard_type: r.hazard_type,
        hazard_description: r.hazard_description,
        likelihood: r.likelihood,
        severity: r.severity,
        risk_level: r.risk_level,
        residual_risk: r.residual_risk,
        status: r.status,
        workflow_status: r.workflow_status,
        assigned_to: r.assigned_to,
        review_date: r.review_date,
      }));

      const summaryCSV = [
        "Summary",
        `Generated,${new Date().toISOString()}`,
        `Total Requirements,${total}`,
        `Compliant,${compliant}`,
        `In Progress,${inProgress}`,
        `Partial,${partial}`,
        `Not Started,${notStarted}`,
        `Non-Compliant,${nonCompliant}`,
        `Overall Score %,${overallScore}`,
        `Progress Score %,${progressScore}`,
        `Total Risks,${risks.length}`,
        `Critical Items,${criticalItems.length}`,
        "",
        "Requirements",
        toCSV(reqHeaders, reqRows),
        "",
        "Risks",
        toCSV(riskHeaders, riskRows),
      ].join("\r\n");

      const blob = new Blob(["\uFEFF" + summaryCSV], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `compliance-snapshot-${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      a.remove();
    } finally {
      setIsDownloadingSnapshot(false);
    }
  };
  const upcomingDue = requirements.
  filter((r) => r.due_date && r.status !== "compliant").
  sort((a, b) => new Date(a.due_date) - new Date(b.due_date)).
  slice(0, 5);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 text-sm">Loading compliance data...</p>
        </div>
      </div>);

  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight leading-tight">
                Package Manufacturing Compliance
              </h1>
            </div>
            <div className="flex flex-wrap gap-1.5 justify-start">
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownloadSnapshot}
                disabled={isDownloadingSnapshot}
                className="gap-1.5 px-2 sm:px-3 h-8 text-xs sm:text-sm"
                title="Download compliance snapshot as Excel/CSV"
              >
                <DatabaseZap className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Export Excel</span>
                <span className="sm:hidden">XLS</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAIReportDialog(true)}
                className="gap-1.5 px-2 sm:px-3 h-8 text-xs sm:text-sm bg-gradient-to-r from-emerald-50 to-blue-50 border-emerald-200 hover:from-emerald-100 hover:to-blue-100">
                <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600" />
                <span className="hidden sm:inline">AI Report</span>
                <span className="sm:hidden">AI</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowReportDialog(true)}
                className="gap-1.5 px-2 sm:px-3 h-8 text-xs sm:text-sm">
                <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Standard Report</span>
                <span className="sm:hidden">Report</span>
              </Button>

              {/* Users Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1.5 px-2 sm:px-3 h-8 text-xs sm:text-sm">
                    <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Users</span>
                    <ChevronDown className="w-3 h-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => setShowInviteDialog(true)} className="cursor-pointer">
                    <UserPlus className="w-4 h-4 mr-2 text-emerald-600" />
                    Invite User
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to={createPageUrl("UserManagement")} className="cursor-pointer flex items-center">
                      <Users className="w-4 h-4 mr-2 text-slate-500" />
                      Manage Users
                    </Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowBugReport(true)}
                className="gap-1.5 px-2 sm:px-3 h-8 text-xs sm:text-sm text-amber-600 border-amber-200 hover:bg-amber-50"
              >
                <AlertCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Customer Complaint</span>
                <span className="sm:hidden">Complaint</span>
              </Button>


            </div>
          </div>
        </div>

        {/* Onboarding Checklist */}
        {currentUser?.email && <OnboardingChecklist userEmail={currentUser.email} />}

        {/* Global Search */}
        <div className="mb-6">
          <GlobalSearch requirements={requirements} risks={risks} />
        </div>

        {/* Mobile Quick Actions */}
        <div className="mb-4">
          <MobileQuickActions />
        </div>

        {/* Compliance Alerts Widget */}
        <div className="mb-8">
          <ComplianceAlertsWidget />
        </div>

        {/* Score + Stats Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
          <div className="lg:col-span-4">
            <Card className="h-full border-0 shadow-sm bg-white">
              <CardContent className="p-6 flex items-center justify-center">
                <ComplianceScoreRing score={overallScore} progressScore={progressScore} total={total} compliant={compliant} />
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-4">
            <StatCard
              label="Compliant"
              count={compliant}
              total={total}
              icon={CheckCircle2}
              color="emerald" />

            <StatCard
              label="In Progress"
              count={inProgress}
              total={total}
              icon={Clock}
              color="blue" />

            <StatCard
              label="Partial"
              count={partial}
              total={total}
              icon={TrendingUp}
              color="amber" />

            <StatCard
              label="Non-Compliant"
              count={nonCompliant}
              total={total}
              icon={XCircle}
              color="rose" />

          </div>
        </div>

        {/* Trend & Status Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <ComplianceTrendChart requirements={requirements} />
          <StatusBreakdown requirements={requirements} />
          <OutstandingActions risks={risks} />
        </div>

        {/* Risk Analysis + Completion Rate */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <RiskBreakdownChart risks={risks} />
          <SectionProgressChart requirements={requirements} sections={sections} />
          <CompletionRateWidget requirements={requirements} />
        </div>

        {/* AI Features */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <AISuggestedActions />
          <AuditPlanSuggestions />
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Critical Items */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-500" />
                  Critical Items Needing Attention
                </CardTitle>
                <Badge variant="secondary" className="bg-rose-50 text-rose-700 text-xs">
                  {criticalItems.length}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              {criticalItems.length === 0 ?
              <p className="text-sm text-slate-400 py-4 text-center">No critical items outstanding</p> :

              <div className="space-y-2">
                  {criticalItems.slice(0, 5).map((item) =>
                <Link
                  key={item.id}
                  to={createPageUrl("RequirementDetail") + `?id=${item.id}`}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 transition-colors group">

                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-xs font-mono font-bold text-slate-400 shrink-0">{item.clause_number}</span>
                        <span className="text-sm text-slate-700 truncate">{item.clause_title}</span>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 shrink-0" />
                    </Link>
                )}
                </div>
              }
            </CardContent>
          </Card>

          <RecentActivity requirements={upcomingDue} />
        </div>

        <ReportDialog
          open={showReportDialog}
          onClose={() => setShowReportDialog(false)}
          defaultType="compliance" />


        <ScheduleReportDialog
          open={showScheduleDialog}
          onClose={() => setShowScheduleDialog(false)} />


        <AIReportDialog
          open={showAIReportDialog}
          onClose={() => setShowAIReportDialog(false)} />

        <BugReportDialog
          open={showBugReport}
          onOpenChange={setShowBugReport} />

        {/* Invite User Dialog */}
        <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-600" />
                Invite User
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <p className="text-sm text-slate-500">
                Invite a colleague to access this compliance application. They will receive an email with a link to register and join.
              </p>
              <div>
                <Label className="text-xs font-medium text-slate-700">Email Address</Label>
                <Input
                  type="email"
                  placeholder="colleague@company.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  className="mt-1"
                  onKeyDown={(e) => e.key === "Enter" && handleInviteUser()}
                />
              </div>
              <div>
                <Label className="text-xs font-medium text-slate-700">Role</Label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="administrator">Administrator – Full access</SelectItem>
                    <SelectItem value="compliance_officer">Compliance Officer</SelectItem>
                    <SelectItem value="auditor">Auditor – View & audit</SelectItem>
                    <SelectItem value="quality_manager">Quality Manager</SelectItem>
                    <SelectItem value="contributor">Contributor – Edit assigned items</SelectItem>
                    <SelectItem value="read_only">Read-Only – View only</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-400 mt-1.5">
                  All actions are tracked per user — you'll see who captured what data.
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowInviteDialog(false)}>Cancel</Button>
              <Button
                onClick={handleInviteUser}
                disabled={!inviteEmail || isInviting}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {isInviting ? "Sending..." : "Send Invitation"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

      </div>
    </div>);

}

function StatCard({ label, count, total, icon: Icon, color }) {
  const colorMap = {
    emerald: { bg: "bg-emerald-50", text: "text-emerald-700", icon: "text-emerald-500" },
    blue: { bg: "bg-blue-50", text: "text-blue-700", icon: "text-blue-500" },
    amber: { bg: "bg-amber-50", text: "text-amber-700", icon: "text-amber-500" },
    rose: { bg: "bg-rose-50", text: "text-rose-700", icon: "text-rose-500" }
  };
  const c = colorMap[color];

  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="opacity-50 rounded-none">
        <div className={`w-9 h-9 rounded-lg ${c.bg} flex items-center justify-center mb-3`}>
          <Icon className={`w-4.5 h-4.5 ${c.icon}`} />
        </div>
        <div className="text-amber-700 mt-1 mr-1 text-2xl font-bold">{count}</div>
        <div className="text-xs text-slate-400 font-medium">{label}</div>
      </CardContent>
    </Card>);

}