import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Plus, Search, AlertTriangle, CheckCircle2, Clock, ShieldCheck, Filter, TrendingUp } from "lucide-react";
import CAPADetailDialog from "@/components/capa/CAPADetailDialog";

const STATUS_CONFIG = {
  open: { label: "Open", color: "bg-blue-100 text-blue-800" },
  root_cause_analysis: { label: "RCA", color: "bg-purple-100 text-purple-800" },
  action_planning: { label: "Planning", color: "bg-yellow-100 text-yellow-800" },
  implementation: { label: "Implementation", color: "bg-orange-100 text-orange-800" },
  verification: { label: "Verification", color: "bg-cyan-100 text-cyan-800" },
  pending_signoff: { label: "Pending Sign-off", color: "bg-amber-100 text-amber-800" },
  closed: { label: "Closed", color: "bg-green-100 text-green-800" },
  cancelled: { label: "Cancelled", color: "bg-slate-100 text-slate-600" },
};

const PRIORITY_CONFIG = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
};

const EMPTY_FORM = {
  title: "", description: "", capa_type: "corrective", source_type: "manual",
  priority: "medium", problem_statement: "", assigned_to: "", due_date: "",
};

export default function CAPAManagement() {
  const qc = useQueryClient();
  const [currentUser, setCurrentUser] = useState(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [selectedCAPA, setSelectedCAPA] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newForm, setNewForm] = useState(EMPTY_FORM);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: capas = [], isLoading } = useQuery({
    queryKey: ["capas"],
    queryFn: () => base44.entities.CAPA.list("-created_date", 200),
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const existing = await base44.entities.CAPA.list("-created_date", 1);
      const lastNum = existing.length > 0
        ? parseInt(existing[0].capa_number?.split("-").pop() || "0", 10)
        : 0;
      const num = String(lastNum + 1).padStart(3, "0");
      const year = new Date().getFullYear();
      return base44.entities.CAPA.create({ ...data, capa_number: `CAPA-${year}-${num}` });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["capas"] });
      toast.success("CAPA created successfully");
      setShowCreate(false);
      setNewForm(EMPTY_FORM);
    },
    onError: () => toast.error("Failed to create CAPA"),
  });

  const filtered = capas.filter(c => {
    const matchSearch = !search ||
      c.capa_number?.toLowerCase().includes(search.toLowerCase()) ||
      c.title?.toLowerCase().includes(search.toLowerCase()) ||
      c.assigned_to?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || c.status === statusFilter;
    const matchPriority = priorityFilter === "all" || c.priority === priorityFilter;
    return matchSearch && matchStatus && matchPriority;
  });

  const stats = {
    total: capas.length,
    open: capas.filter(c => c.status !== "closed" && c.status !== "cancelled").length,
    critical: capas.filter(c => c.priority === "critical" && c.status !== "closed").length,
    overdue: capas.filter(c => c.due_date && c.status !== "closed" && new Date(c.due_date) < new Date()).length,
    closed: capas.filter(c => c.status === "closed").length,
  };

  if (isLoading) return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center">
      <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
              CAPA Management
            </h1>
            <p className="text-sm text-slate-500 mt-1">Corrective & Preventive Action tracking with sign-off workflows</p>
          </div>
          <Button onClick={() => setShowCreate(true)} className="bg-emerald-600 hover:bg-emerald-700 gap-2 self-start sm:self-auto">
            <Plus className="w-4 h-4" /> New CAPA
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          {[
            { label: "Total", value: stats.total, icon: TrendingUp, color: "text-slate-600" },
            { label: "Active", value: stats.open, icon: Clock, color: "text-blue-600" },
            { label: "Critical", value: stats.critical, icon: AlertTriangle, color: "text-red-600" },
            { label: "Overdue", value: stats.overdue, icon: AlertTriangle, color: "text-orange-600" },
            { label: "Closed", value: stats.closed, icon: CheckCircle2, color: "text-emerald-600" },
          ].map(s => (
            <Card key={s.label} className="border-0 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-medium">{s.label}</p>
                  <p className="text-2xl font-bold text-slate-900">{s.value}</p>
                </div>
                <s.icon className={`w-8 h-8 opacity-20 ${s.color}`} />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input placeholder="Search CAPAs..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-44"><SelectValue placeholder="All Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  {Object.entries(STATUS_CONFIG).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger className="w-36"><SelectValue placeholder="All Priority" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* CAPA Table */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="border-b border-slate-100 py-4">
            <CardTitle className="text-sm font-semibold">CAPAs ({filtered.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-slate-50">
              {filtered.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-sm">
                  No CAPAs found. Create one or wait for auto-generation from audits.
                </div>
              ) : (
                filtered.map(capa => {
                  const isOverdue = capa.due_date && capa.status !== "closed" && new Date(capa.due_date) < new Date();
                  const corrActionsTotal = capa.corrective_actions?.length || 0;
                  const corrActionsComplete = capa.corrective_actions?.filter(a => a.completed).length || 0;
                  return (
                    <div
                      key={capa.id}
                      onClick={() => setSelectedCAPA(capa)}
                      className="p-4 hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="text-xs font-mono font-bold text-slate-400">{capa.capa_number}</span>
                            <Badge className={PRIORITY_CONFIG[capa.priority]}>{capa.priority}</Badge>
                            <Badge className={STATUS_CONFIG[capa.status]?.color}>{STATUS_CONFIG[capa.status]?.label}</Badge>
                            {capa.source_type !== "manual" && (
                              <Badge variant="outline" className="text-xs">{capa.source_type.replace(/_/g, " ")}</Badge>
                            )}
                          </div>
                          <p className="text-sm font-medium text-slate-900 truncate">{capa.title}</p>
                          {capa.assigned_to && (
                            <p className="text-xs text-slate-500 mt-0.5">Assigned: {capa.assigned_to}</p>
                          )}
                        </div>
                        <div className="text-right shrink-0 text-xs">
                          {capa.due_date && (
                            <p className={`font-medium ${isOverdue ? "text-red-600" : "text-slate-500"}`}>
                              {isOverdue ? "⚠ Overdue" : `Due: ${new Date(capa.due_date).toLocaleDateString()}`}
                            </p>
                          )}
                          {corrActionsTotal > 0 && (
                            <p className="text-slate-400 mt-1">{corrActionsComplete}/{corrActionsTotal} actions</p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Create CAPA Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>New CAPA</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-xs">Title *</Label>
              <Input value={newForm.title} onChange={e => setNewForm(f => ({ ...f, title: e.target.value }))} className="mt-1" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Type</Label>
                <Select value={newForm.capa_type} onValueChange={v => setNewForm(f => ({ ...f, capa_type: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="corrective">Corrective</SelectItem>
                    <SelectItem value="preventive">Preventive</SelectItem>
                    <SelectItem value="both">Both</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Priority</Label>
                <Select value={newForm.priority} onValueChange={v => setNewForm(f => ({ ...f, priority: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Source</Label>
                <Select value={newForm.source_type} onValueChange={v => setNewForm(f => ({ ...f, source_type: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manual">Manual</SelectItem>
                    <SelectItem value="compliance_audit">Compliance Audit</SelectItem>
                    <SelectItem value="risk_assessment">Risk Assessment</SelectItem>
                    <SelectItem value="customer_complaint">Customer Complaint</SelectItem>
                    <SelectItem value="internal_audit">Internal Audit</SelectItem>
                    <SelectItem value="supplier_issue">Supplier Issue</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Due Date</Label>
                <Input type="date" value={newForm.due_date} onChange={e => setNewForm(f => ({ ...f, due_date: e.target.value }))} className="mt-1" />
              </div>
            </div>
            <div>
              <Label className="text-xs">Assigned To (email)</Label>
              <Input value={newForm.assigned_to} onChange={e => setNewForm(f => ({ ...f, assigned_to: e.target.value }))} placeholder="user@company.com" className="mt-1" />
            </div>
            <div>
              <Label className="text-xs">Problem Statement</Label>
              <Textarea value={newForm.problem_statement} onChange={e => setNewForm(f => ({ ...f, problem_statement: e.target.value }))} rows={3} className="mt-1" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button
              onClick={() => createMutation.mutate(newForm)}
              disabled={!newForm.title || createMutation.isPending}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {createMutation.isPending ? "Creating..." : "Create CAPA"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* CAPA Detail Dialog */}
      {selectedCAPA && (
        <CAPADetailDialog
          capa={selectedCAPA}
          currentUser={currentUser}
          onClose={() => setSelectedCAPA(null)}
        />
      )}
    </div>
  );
}