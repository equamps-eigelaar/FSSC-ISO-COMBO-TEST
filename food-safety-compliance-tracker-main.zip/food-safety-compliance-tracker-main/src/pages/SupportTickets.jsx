import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, AlertCircle, Clock, DollarSign, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

const STATUS_COLORS = {
  open: "bg-blue-50 text-blue-700 border-blue-200",
  in_progress: "bg-yellow-50 text-yellow-700 border-yellow-200",
  on_hold: "bg-orange-50 text-orange-700 border-orange-200",
  resolved: "bg-green-50 text-green-700 border-green-200",
  closed: "bg-slate-50 text-slate-700 border-slate-200",
  reopened: "bg-red-50 text-red-700 border-red-200",
};

const PRIORITY_COLORS = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
};

export default function SupportTickets() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedTicket, setSelectedTicket] = useState(null);
  const queryClient = useQueryClient();

  const { data: tickets = [], isLoading } = useQuery({
    queryKey: ["tickets"],
    queryFn: () => base44.entities.SupportTicket.list("-created_date", 100),
  });

  const updateTicketMutation = useMutation({
    mutationFn: ({ ticketId, data }) =>
      base44.entities.SupportTicket.update(ticketId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tickets"] });
      toast.success("Ticket updated");
      setSelectedTicket(null);
    },
    onError: () => toast.error("Failed to update ticket"),
  });

  const filteredTickets = tickets.filter(t => {
    const matchesSearch = t.ticket_number?.includes(search.toUpperCase()) ||
      t.title?.toLowerCase().includes(search.toLowerCase()) ||
      t.reporter_email?.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === "all" || t.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalBillable = tickets
    .filter(t => t.billable && t.billing_status !== "paid")
    .reduce((sum, t) => sum + (t.total_billable_amount || 0), 0);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Customer Complaints</h1>
          <p className="text-sm text-slate-500 mt-1">Manage customer complaints and non-conformance reports</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-medium mb-1">Total Tickets</p>
                  <p className="text-2xl font-bold text-slate-900">{tickets.length}</p>
                </div>
                <AlertCircle className="w-8 h-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-medium mb-1">Open</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {tickets.filter(t => t.status === "open").length}
                  </p>
                </div>
                <Clock className="w-8 h-8 text-yellow-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-medium mb-1">Resolved</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {tickets.filter(t => t.status === "resolved").length}
                  </p>
                </div>
                <CheckCircle2 className="w-8 h-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-slate-500 font-medium mb-1">Billable</p>
                  <p className="text-2xl font-bold text-slate-900">${totalBillable.toFixed(2)}</p>
                </div>
                <DollarSign className="w-8 h-8 text-emerald-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search tickets..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="on_hold">On Hold</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                  <SelectItem value="reopened">Reopened</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tickets List */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="text-sm font-semibold">
              Tickets ({filteredTickets.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-slate-50">
              {filteredTickets.map(ticket => (
                <div
                  key={ticket.id}
                  className="p-4 hover:bg-slate-50 transition-colors cursor-pointer"
                  onClick={() => setSelectedTicket(ticket)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div>
                        <p className="text-sm font-medium text-slate-900">
                          {ticket.ticket_number}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">{ticket.title}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant="outline"
                        className={STATUS_COLORS[ticket.status]}
                      >
                        {ticket.status}
                      </Badge>
                      <Badge className={PRIORITY_COLORS[ticket.priority]}>
                        {ticket.priority}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{ticket.reporter_email}</span>
                    <div className="flex items-center gap-4">
                      {ticket.time_spent_hours > 0 && (
                        <span>Time: {ticket.time_spent_hours}h</span>
                      )}
                      {ticket.billable && ticket.total_billable_amount > 0 && (
                        <span className="font-medium text-emerald-600">
                          ${ticket.total_billable_amount.toFixed(2)}
                        </span>
                      )}
                      <span className="text-slate-400">
                        {new Date(ticket.created_date).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
              ))}

              {filteredTickets.length === 0 && (
                <div className="p-8 text-center text-slate-500 text-sm">
                  No tickets found
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Ticket Detail Modal */}
        {selectedTicket && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <CardHeader className="border-b border-slate-100">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{selectedTicket.ticket_number}</CardTitle>
                    <p className="text-sm text-slate-500 mt-1">{selectedTicket.title}</p>
                  </div>
                  <Button
                    variant="ghost"
                    onClick={() => setSelectedTicket(null)}
                    className="h-8 w-8 p-0"
                  >
                    ✕
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="p-6 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-slate-500 font-medium mb-1">Status</p>
                    <Select
                      value={selectedTicket.status}
                      onValueChange={(newStatus) =>
                        updateTicketMutation.mutate({
                          ticketId: selectedTicket.id,
                          data: { status: newStatus },
                        })
                      }
                    >
                      <SelectTrigger className="text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="on_hold">On Hold</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                        <SelectItem value="reopened">Reopened</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <p className="text-xs text-slate-500 font-medium mb-1">Priority</p>
                    <Select
                      value={selectedTicket.priority}
                      onValueChange={(newPriority) =>
                        updateTicketMutation.mutate({
                          ticketId: selectedTicket.id,
                          data: { priority: newPriority },
                        })
                      }
                    >
                      <SelectTrigger className="text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <p className="text-xs text-slate-500 font-medium mb-2">Description</p>
                  <p className="text-sm text-slate-700 bg-slate-50 p-3 rounded">
                    {selectedTicket.description}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-slate-500 font-medium mb-1">Reporter</p>
                    <p className="text-sm text-slate-700">{selectedTicket.reporter_email}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-medium mb-1">Created</p>
                    <p className="text-sm text-slate-700">
                      {new Date(selectedTicket.created_date).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {selectedTicket.billable && (
                  <div className="grid grid-cols-3 gap-4 bg-emerald-50 p-4 rounded-lg border border-emerald-200">
                    <div>
                      <p className="text-xs text-slate-500 font-medium mb-1">Time Spent</p>
                      <p className="text-sm font-semibold text-slate-900">
                        {selectedTicket.time_spent_hours}h
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-medium mb-1">Rate</p>
                      <p className="text-sm font-semibold text-slate-900">
                        ${selectedTicket.hourly_rate}/hr
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-medium mb-1">Amount</p>
                      <p className="text-sm font-semibold text-emerald-700">
                        ${selectedTicket.total_billable_amount?.toFixed(2) || '0.00'}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}