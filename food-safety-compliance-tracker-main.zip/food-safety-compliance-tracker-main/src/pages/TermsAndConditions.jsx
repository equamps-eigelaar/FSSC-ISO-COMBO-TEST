import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, AlertCircle, Shield, Flag, Ban } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <Link
          to={createPageUrl("Dashboard")}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-sm text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Terms and Conditions</h1>
          <p className="text-sm text-slate-500">Last updated: {new Date().toLocaleDateString()}</p>
        </div>

        <div className="space-y-6">
          {/* Section 1: Content Policies */}
          <Card className="border-0 shadow-sm p-6">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-5 h-5 text-rose-500 mt-1 flex-shrink-0" />
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">1. Content and Conduct Policies</h2>
                <div className="space-y-4 text-slate-700 text-sm">
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-2">Prohibited Content - Nudity</h3>
                    <p>
                      We prohibit the public sharing of nudity on our platform. This includes explicit images, videos, or other content of a sexual nature. Violations of this policy may result in content removal, account suspension, or permanent termination.
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-200">
                    <h3 className="font-semibold text-slate-900 mb-2">Prohibited Content - Graphic Violence</h3>
                    <p>
                      We do not permit the public sharing of real-world, graphic violence outside of a newsworthy context. Content depicting gore, extreme injury, or violent acts is prohibited unless it serves legitimate news or educational purposes and includes appropriate context. Any graphic violence content must be clearly labeled and flagged.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Section 2: User Control Tools */}
          <Card className="border-0 shadow-sm p-6">
            <div className="flex items-start gap-3 mb-4">
              <Shield className="w-5 h-5 text-emerald-500 mt-1 flex-shrink-0" />
              <div className="flex-1">
                <h2 className="text-lg font-semibold text-slate-900 mb-4">2. User Safety and Control Features</h2>
                <div className="space-y-4 text-slate-700 text-sm">
                  <div>
                    <h3 className="font-semibold text-slate-900 mb-2">Blocking Users and Content</h3>
                    <p>
                      Users have the ability to block other users or user-generated content that they find inappropriate, harmful, or unwanted. Blocked users will not be able to:
                    </p>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>View your profile or content</li>
                      <li>Send you messages or collaboration requests</li>
                      <li>Interact with your posts or comments</li>
                      <li>See your activity or presence</li>
                    </ul>
                    <p className="mt-3">You can manage your blocked list at any time in your account settings and unblock users if desired.</p>
                  </div>

                  <div className="pt-3 border-t border-slate-200">
                    <h3 className="font-semibold text-slate-900 mb-2">Reporting Users and Content</h3>
                    <p>
                      We encourage all users to report content or user behavior that violates our policies. You can report:
                    </p>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>Inappropriate or offensive user-generated content</li>
                      <li>Harassment, bullying, or threatening behavior</li>
                      <li>Violations of our content policies (nudity, graphic violence, etc.)</li>
                      <li>Spam, scams, or malicious activity</li>
                      <li>Copyright or intellectual property violations</li>
                    </ul>
                    <p className="mt-3">
                      To report, click the report icon on any content or user profile. Our moderation team reviews all reports and takes appropriate action, which may include content removal, user warnings, or account suspension. You can expect acknowledgment of your report within 24 hours.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Section 3: Chat Moderation */}
          <Card className="border-0 shadow-sm p-6">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-5 h-5 text-blue-500 mt-1 flex-shrink-0" />
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">3. Chat Moderation</h2>
                <div className="space-y-3 text-slate-700 text-sm">
                  <p>
                    All chat messages and communications are subject to automated and manual moderation to ensure compliance with our community standards. Our moderation systems monitor for:
                  </p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Harassment, threats, or abusive language</li>
                    <li>Spam, scams, or malicious links</li>
                    <li>Violations of content policies</li>
                    <li>Inappropriate or explicit content</li>
                  </ul>
                  <p>
                    Messages may be flagged, filtered, or removed. Repeated violations may result in chat suspension or account termination. Users retain the right to report concerning messages directly.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Section 4: Interaction Restrictions */}
          <Card className="border-0 shadow-sm p-6">
            <div className="flex items-start gap-3 mb-4">
              <Shield className="w-5 h-5 text-indigo-500 mt-1 flex-shrink-0" />
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">4. Interactions Limited to Invited Friends</h2>
                <p className="text-slate-700 text-sm mb-3">
                  For security and privacy, interactions on this platform are limited to invited friends and trusted connections only. This means:
                </p>
                <ul className="list-disc pl-5 space-y-2 text-slate-700 text-sm">
                  <li>You can only message users who have accepted your friend request or invitation</li>
                  <li>Non-friends cannot view your private content or profile details</li>
                  <li>Only invited connections can collaborate on projects or documents</li>
                  <li>You control who can see your activity and presence status</li>
                </ul>
                <p className="text-slate-700 text-sm mt-3">
                  This closed-network approach helps maintain a safe and controlled environment for all users.
                </p>
              </div>
            </div>
          </Card>

          {/* Section 5: Content Promotion */}
          <Card className="border-0 shadow-sm p-6">
            <div className="flex items-start gap-3 mb-4">
              <AlertCircle className="w-5 h-5 text-purple-500 mt-1 flex-shrink-0" />
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">5. Content Promotion</h2>
                <p className="text-slate-700 text-sm mb-3">
                  Users have the option to promote their content to increase visibility and reach. Content promotion must comply with all platform policies:
                </p>
                <ul className="list-disc pl-5 space-y-2 text-slate-700 text-sm">
                  <li>Promoted content must not violate any conduct policies</li>
                  <li>Spam or misleading promotion is strictly prohibited</li>
                  <li>All promoted content is subject to review before distribution</li>
                  <li>Promotion does not override moderation or safety standards</li>
                </ul>
                <p className="text-slate-700 text-sm mt-3">
                  Violations of content promotion policies may result in demotion, removal, or account suspension.
                </p>
              </div>
            </div>
          </Card>

          {/* Section 6: Violent Material Warnings */}
          <Card className="border-0 shadow-sm p-6 border-l-4 border-l-rose-500">
            <div className="flex items-start gap-3 mb-4">
              <Flag className="w-5 h-5 text-rose-500 mt-1 flex-shrink-0" />
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">6. Warnings for Violent Material</h2>
                <p className="text-slate-700 text-sm mb-3">
                  Content depicting violence, injury, or disturbing imagery is subject to strict moderation and must include clear warnings:
                </p>
                <ul className="list-disc pl-5 space-y-2 text-slate-700 text-sm">
                  <li>Graphic violence content must be appropriately flagged with content warnings</li>
                  <li>Users must provide context for news or educational violent content</li>
                  <li>Extreme violence may be restricted to authorized users only</li>
                  <li>Warnings must be visible before content is displayed</li>
                </ul>
                <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 mt-3">
                  <p className="text-xs font-semibold text-rose-900 mb-1">⚠️ Content Warning</p>
                  <p className="text-xs text-rose-800">
                    This platform may contain content with violence or graphic material. Users are responsible for exercising caution and using content filters as needed.
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Section 7: Enforcement */}
          <Card className="border-0 shadow-sm p-6">
            <div className="flex items-start gap-3 mb-4">
              <Ban className="w-5 h-5 text-amber-500 mt-1 flex-shrink-0" />
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">7. Enforcement and Consequences</h2>
                <p className="text-slate-700 text-sm mb-3">
                  Violations of these policies may result in:
                </p>
                <ul className="space-y-2 text-slate-700 text-sm list-disc pl-5">
                  <li>Content removal or flagging</li>
                  <li>Warning or suspension from certain features</li>
                  <li>Temporary account suspension (24 hours to 30 days)</li>
                  <li>Permanent account termination for severe or repeated violations</li>
                  <li>Legal action if applicable</li>
                </ul>
                <p className="text-slate-700 text-sm mt-3">
                  We reserve the right to investigate reports and take appropriate action at our discretion. Users who believe their content was removed in error may submit an appeal through their account settings.
                </p>
              </div>
            </div>
          </Card>

          {/* Section 8: Agreement */}
          <Card className="border-0 shadow-sm p-6 bg-emerald-50">
            <p className="text-sm text-slate-700 mb-4">
              By using this platform, you agree to comply with all policies outlined in these Terms and Conditions. We are committed to maintaining a safe, respectful community for all users.
            </p>
            <p className="text-xs text-slate-600">
              For questions or concerns about these policies, please contact our support team at support@example.com.
            </p>
          </Card>

          {/* Footer Navigation */}
          <div className="flex gap-3 pt-6 border-t border-slate-200">
            <Link to={createPageUrl("PrivacyPolicy")}>
              <Button variant="outline" size="sm">
                Privacy Policy
              </Button>
            </Link>
            <Link to={createPageUrl("Dashboard")}>
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700">
                Agree & Continue
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}