import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { jsPDF } from "jspdf";
import { FileText, Download, Loader2, RefreshCw, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import SLADropZone from "@/components/sla/SLADropZone";
import ReactMarkdown from "react-markdown";

async function gatherComplianceContext() {
  const [requirements, ccps, products, audits, actions] = await Promise.allSettled([
    base44.entities.ComplianceRequirement.list("-updated_date", 200),
    base44.entities.CCP.list("-created_date", 50),
    base44.entities.Product.list("-created_date", 100),
    base44.entities.AuditPlan.list("-suggested_date", 20),
    base44.entities.ActionItem.filter({ status: "pending" }, "-due_date", 50),
  ]);

  const reqs = requirements.value || [];
  const compliant = reqs.filter(r => r.status === "compliant").length;
  const total = reqs.length;
  const score = total > 0 ? Math.round((compliant / total) * 100) : 0;

  const crit = reqs.filter(r => r.status === "non_compliant" && r.priority === "critical");
  const partials = reqs.filter(r => r.status === "partial");

  const ccp_list = (ccps.value || []).filter(c => c.status === "active");
  const prod_list = (products.value || []).filter(p => p.status === "active");
  const audit_list = (audits.value || []).filter(a => ["completed", "in_progress"].includes(a.status));
  const open_actions = (actions.value || []);

  return `
## SITE COMPLIANCE SUMMARY (as of ${new Date().toLocaleDateString("en-ZA")})

### Overall Compliance Score: ${score}% (${compliant}/${total} requirements compliant)

### ISO 22000 / FSSC 22000 Compliance Status:
${reqs.slice(0, 30).map(r => `- Clause ${r.clause_number} — ${r.clause_title}: **${r.status?.toUpperCase()}** (${r.priority} priority)${r.evidence_notes ? " | Evidence: " + r.evidence_notes : ""}`).join("\n")}
${reqs.length > 30 ? `\n... and ${reqs.length - 30} additional requirements.` : ""}

### Critical Non-Conformances: ${crit.length}
${crit.map(r => `- Clause ${r.clause_number}: ${r.clause_title} — ${r.corrective_actions || "Corrective action in progress"}`).join("\n") || "None"}

### Partial Compliance Items: ${partials.length}
${partials.slice(0, 10).map(r => `- Clause ${r.clause_number}: ${r.clause_title} — ${r.completion_percentage || 0}% complete`).join("\n") || "None"}

### Active CCPs / OPRPs: ${ccp_list.length}
${ccp_list.map(c => `- ${c.name} | Type: ${c.ccp_type?.toUpperCase()} | Hazard: ${c.hazard_type} | Critical Limit: ${c.critical_limit}`).join("\n") || "None configured"}

### Active Products: ${prod_list.length}
${prod_list.slice(0, 20).map(p => `- ${p.name} (${p.product_code || "N/A"}) | Category: ${p.category} | Allergens: ${(p.allergens || []).join(", ") || "None declared"}`).join("\n") || "None"}

### Recent / In-Progress Audits: ${audit_list.length}
${audit_list.slice(0, 5).map(a => `- ${a.title} | Type: ${a.audit_type} | Status: ${a.status} | Date: ${a.suggested_date}`).join("\n") || "None"}

### Open Action Items: ${open_actions.length}
${open_actions.slice(0, 10).map(a => `- ${a.title} | Priority: ${a.priority} | Due: ${a.due_date || "TBD"}`).join("\n") || "None"}
`;
}

export default function SLADocumentCompletion() {
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleFileSelected = async (selectedFile) => {
    setFile(selectedFile);
    setResult(null);
    setError(null);
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file: selectedFile });
    setFileUrl(file_url);
    setUploading(false);
  };

  const handleGenerate = async () => {
    setGenerating(true);
    setError(null);
    setResult(null);
    const complianceContext = await gatherComplianceContext();

    const prompt = `You are a food safety and compliance expert assistant for a FSSC 22000 / ISO 22000 certified (or certification-seeking) site of manufacture.

A customer has submitted the attached SLA / supplier questionnaire / quality agreement document. Your task is to:
1. Read and understand every question, field, and requirement in the customer document.
2. Complete every section of the document using the real compliance data provided below.
3. Where data is fully available, provide a confident, specific answer.
4. Where data is partially available, note what is in place and what is still being completed.
5. Where data is not available, clearly state what is needed and suggest the appropriate response.
6. Output the FULLY COMPLETED document in clean, well-structured Markdown format, preserving the original structure of the customer document.
7. At the end, add a "Compliance Gap Summary" section listing any areas where the customer's requirements exceed the current compliance level and recommend corrective actions.

--- COMPLIANCE DATA FROM THE SYSTEM ---
${complianceContext}
--- END COMPLIANCE DATA ---

Important: Be specific, professional, and accurate. Do not fabricate data. Where information is genuinely not available, say so clearly. Output the complete document with all fields answered.`;

    const completed = await base44.integrations.Core.InvokeLLM({
      prompt,
      file_urls: [fileUrl],
      model: "claude_sonnet_4_6",
    });

    setResult(completed);
    setGenerating(false);
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const margin = 15;
    const pageWidth = 210 - margin * 2;
    const pageHeight = 297;
    let y = 20;

    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(16, 110, 80);
    doc.text("Completed Customer SLA / Supplier Questionnaire", margin, y);
    y += 6;

    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(120, 120, 120);
    doc.text(`Generated: ${new Date().toLocaleString("en-ZA")} | Based on: ${file?.name || "Uploaded Document"}`, margin, y);
    y += 10;

    doc.setDrawColor(200, 200, 200);
    doc.line(margin, y, 210 - margin, y);
    y += 6;

    const lines = result.split("\n");
    lines.forEach(line => {
      if (y > pageHeight - 20) { doc.addPage(); y = 20; }

      const trimmed = line.trim();
      if (trimmed.startsWith("# ")) {
        doc.setFontSize(13); doc.setFont("helvetica", "bold"); doc.setTextColor(16, 110, 80);
        doc.text(trimmed.replace(/^# /, ""), margin, y); y += 7;
      } else if (trimmed.startsWith("## ")) {
        doc.setFontSize(11); doc.setFont("helvetica", "bold"); doc.setTextColor(30, 80, 130);
        doc.text(trimmed.replace(/^## /, ""), margin, y); y += 6;
      } else if (trimmed.startsWith("### ")) {
        doc.setFontSize(10); doc.setFont("helvetica", "bold"); doc.setTextColor(50, 50, 50);
        doc.text(trimmed.replace(/^### /, ""), margin, y); y += 5;
      } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
        doc.setFontSize(9); doc.setFont("helvetica", "normal"); doc.setTextColor(60, 60, 60);
        const content = trimmed.replace(/^[-*] /, "• ");
        const wrapped = doc.splitTextToSize(content, pageWidth - 4);
        wrapped.forEach(wl => {
          if (y > pageHeight - 20) { doc.addPage(); y = 20; }
          doc.text(wl, margin + 3, y); y += 4.5;
        });
      } else if (trimmed.length > 0) {
        doc.setFontSize(9); doc.setFont("helvetica", "normal"); doc.setTextColor(60, 60, 60);
        const wrapped = doc.splitTextToSize(trimmed.replace(/\*\*/g, ""), pageWidth);
        wrapped.forEach(wl => {
          if (y > pageHeight - 20) { doc.addPage(); y = 20; }
          doc.text(wl, margin, y); y += 4.5;
        });
      } else {
        y += 3;
      }
    });

    doc.save(`Completed_SLA_${file?.name?.replace(/\.[^.]+$/, "") || "Document"}_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  const reset = () => { setFile(null); setFileUrl(null); setResult(null); setError(null); };

  return (
    <div className="p-6 min-h-screen bg-slate-50 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center">
          <FileText className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-900">Customer SLA Auto-Completion</h1>
          <p className="text-sm text-slate-500">Upload a customer SLA, supplier questionnaire, or quality agreement — AI will complete it using your live compliance data</p>
        </div>
      </div>

      {!result && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">1</span>
            <h2 className="text-sm font-semibold text-slate-800">Upload Customer Document</h2>
            <Badge className="bg-slate-100 text-slate-500 text-xs">Word / Excel / PDF</Badge>
          </div>
          <SLADropZone onFileSelected={handleFileSelected} uploading={uploading} file={file} />

          {file && !uploading && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center font-bold">2</span>
                <h2 className="text-sm font-semibold text-slate-800">Generate Completed Document</h2>
              </div>
              <p className="text-xs text-slate-500 mb-4">
                The AI will read your customer's document, then complete every field using your real-time compliance data — ISO 22000 status, CCPs, allergens, audit results, and open actions.
                <span className="text-amber-600 font-medium"> Uses advanced AI model (claude_sonnet_4_6).</span>
              </p>
              <Button onClick={handleGenerate} disabled={generating} className="bg-blue-600 hover:bg-blue-700 text-white">
                {generating ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating — this may take 30–60 seconds...</> : <><CheckCircle2 className="w-4 h-4" /> Complete SLA with Compliance Data</>}
              </Button>
            </div>
          )}

          {error && <p className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg p-3">{error}</p>}
        </div>
      )}

      {result && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-emerald-50">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <span className="text-sm font-semibold text-emerald-800">SLA Completed Successfully</span>
              <Badge className="bg-emerald-100 text-emerald-700 text-xs">{file?.name}</Badge>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={reset} className="text-xs gap-1">
                <RefreshCw className="w-3.5 h-3.5" /> New Document
              </Button>
              <Button size="sm" onClick={handleDownloadPDF} className="bg-blue-600 hover:bg-blue-700 text-white text-xs gap-1">
                <Download className="w-3.5 h-3.5" /> Download PDF
              </Button>
            </div>
          </div>
          <div className="p-6 prose prose-sm prose-slate max-w-none max-h-[70vh] overflow-y-auto">
            <ReactMarkdown>{result}</ReactMarkdown>
          </div>
          <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={reset} className="text-xs gap-1">
              <RefreshCw className="w-3.5 h-3.5" /> Upload Another Document
            </Button>
            <Button size="sm" onClick={handleDownloadPDF} className="bg-blue-600 hover:bg-blue-700 text-white text-xs gap-1">
              <Download className="w-3.5 h-3.5" /> Download PDF
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}