import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle2, Plus, Filter } from "lucide-react";
import SwipeableActionItem from "@/components/mobile/SwipeableActionItem";
import MobileActionSheet from "@/components/mobile/MobileActionSheet";
import PullToRefresh from "@/components/mobile/PullToRefresh";
import { toast } from "sonner";

export default function MobileActionItems() {
  const [selectedTab, setSelectedTab] = useState("pending");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedAction, setSelectedAction] = useState(null);
  const queryClient = useQueryClient();

  const { data: actions = [], isLoading, refetch } = useQuery({
    queryKey: ['action-items-mobile'],
    queryFn: () => base44.entities.ActionItem.list('-created_date', 100)
  });

  const { data: currentUser } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me()
  });

  const updateActionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ActionItem.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['action-items-mobile'] });
    }
  });

  const deleteActionMutation = useMutation({
    mutationFn: (id) => base44.entities.ActionItem.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['action-items-mobile'] });
      toast.success("Action deleted");
    }
  });

  const handleComplete = (id) => {
    updateActionMutation.mutate({
      id,
      data: { status: "completed", completed_date: new Date().toISOString() }
    });
    toast.success("Action completed");
  };

  const handleDelete = (id) => {
    deleteActionMutation.mutate(id);
  };

  const filteredActions = actions.filter(action => {
    if (selectedTab === "my") return action.assigned_to === currentUser?.email;
    if (selectedTab === "pending") return action.status === "pending";
    if (selectedTab === "in_progress") return action.status === "in_progress";
    if (selectedTab === "completed") return action.status === "completed";
    return true;
  });

  const stats = {
    pending: actions.filter(a => a.status === "pending").length,
    in_progress: actions.filter(a => a.status === "in_progress").length,
    completed: actions.filter(a => a.status === "completed").length,
    my: actions.filter(a => a.assigned_to === currentUser?.email).length,
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="sticky top-14 lg:top-0 bg-white dark:bg-slate-900 border-b dark:border-slate-800 z-10">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Action Items</h1>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => setShowFilters(true)}>
                <Filter className="w-4 h-4" />
              </Button>
              <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-1" />
                Add
              </Button>
            </div>
          </div>

          <Tabs value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="w-full grid grid-cols-4 h-auto">
              <TabsTrigger value="my" className="text-xs py-2">
                My Items
                <Badge variant="secondary" className="ml-1">{stats.my}</Badge>
              </TabsTrigger>
              <TabsTrigger value="pending" className="text-xs py-2">
                Pending
                <Badge variant="secondary" className="ml-1">{stats.pending}</Badge>
              </TabsTrigger>
              <TabsTrigger value="in_progress" className="text-xs py-2">
                Active
                <Badge variant="secondary" className="ml-1">{stats.in_progress}</Badge>
              </TabsTrigger>
              <TabsTrigger value="completed" className="text-xs py-2">
                Done
                <Badge variant="secondary" className="ml-1">{stats.completed}</Badge>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      <PullToRefresh onRefresh={refetch}>
        <div className="p-4 space-y-3 pb-24">
          {filteredActions.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle2 className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-sm text-slate-500">No actions in this category</p>
            </div>
          ) : (
            filteredActions.map(action => (
              <SwipeableActionItem
                key={action.id}
                action={action}
                onComplete={handleComplete}
                onDelete={handleDelete}
                onClick={setSelectedAction}
              />
            ))
          )}
        </div>
      </PullToRefresh>

      <MobileActionSheet
        open={!!selectedAction}
        onClose={() => setSelectedAction(null)}
        title={selectedAction?.title}
      >
        {selectedAction && (
          <div className="p-4 space-y-4">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Description</p>
              <p className="text-sm text-slate-700 dark:text-slate-300">{selectedAction.description}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Priority</p>
                <p className="text-sm font-medium text-slate-900 dark:text-white capitalize">{selectedAction.priority}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Status</p>
                <p className="text-sm font-medium text-slate-900 dark:text-white capitalize">{selectedAction.status.replace('_', ' ')}</p>
              </div>
            </div>
            <div className="flex gap-2 pt-4 border-t dark:border-slate-800">
              <Button
                variant="outline"
                onClick={() => {
                  handleComplete(selectedAction.id);
                  setSelectedAction(null);
                }}
                className="flex-1"
              >
                <CheckCircle2 className="w-4 h-4 mr-1" />
                Complete
              </Button>
              <Button
                onClick={() => {
                  updateActionMutation.mutate({
                    id: selectedAction.id,
                    data: { status: "in_progress" }
                  });
                  setSelectedAction(null);
                }}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                Start Working
              </Button>
            </div>
          </div>
        )}
      </MobileActionSheet>
    </div>
  );
}