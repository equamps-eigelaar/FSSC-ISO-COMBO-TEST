import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Camera, CheckCircle2, AlertTriangle, Clock, ChevronRight, Plus, Calendar } from "lucide-react";
import { format } from "date-fns";
import MobileAuditChecklist from "@/components/audit/MobileAuditChecklist";
import StartDepartmentAuditDialog from "@/components/audit/StartDepartmentAuditDialog";
import { toast } from "sonner";
import { useOfflineQuery } from "@/components/offline/useOfflineQuery";

export default function MobileAudit() {
  const [selectedAudit, setSelectedAudit] = useState(null);
  const [showDeptDialog, setShowDeptDialog] = useState(false);
  const queryClient = useQueryClient();

  const { data: activeAudits = [], isLoading } = useOfflineQuery({
    queryKey: ['active-audits'],
    queryFn: () => base44.entities.AuditPlan.filter({ 
      status: { $in: ['scheduled', 'in_progress'] } 
    }, '-suggested_date', 50),
  });

  const { data: requirements = [] } = useOfflineQuery({
    queryKey: ['requirements-for-audit'],
    queryFn: () => base44.entities.ComplianceRequirement.list('-clause_number', 500),
  });

  const updateAuditMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AuditPlan.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-audits'] });
      toast.success("Audit updated");
    }
  });

  const startAudit = (audit) => {
    updateAuditMutation.mutate({
      id: audit.id,
      data: { status: 'in_progress' }
    });
    setSelectedAudit(audit);
  };

  if (selectedAudit) {
    return (
      <MobileAuditChecklist
        audit={selectedAudit}
        requirements={requirements}
        onClose={() => setSelectedAudit(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-2xl mx-auto px-4 py-6 pb-24">
        {/* Header */}
        <div className="mb-6 flex items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-1">
              Field Audits
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Conduct audits offline with photo evidence
            </p>
          </div>
          <Button
            className="bg-emerald-600 hover:bg-emerald-700 gap-2 flex-shrink-0"
            onClick={() => setShowDeptDialog(true)}
          >
            <Plus className="w-4 h-4" />
            New Audit
          </Button>
        </div>

        {/* Quick-start department grid */}
        <div className="mb-6">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-3">Quick-start by Department</p>
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: "Receiving", emoji: "📥" },
              { label: "Production", emoji: "🏭" },
              { label: "Packaging", emoji: "📦" },
              { label: "Cold Store", emoji: "❄️" },
              { label: "QC Lab", emoji: "🔬" },
              { label: "Dispatch", emoji: "🚛" },
            ].map(dept => (
              <button
                key={dept.label}
                onClick={() => setShowDeptDialog(true)}
                className="flex items-center gap-3 p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-emerald-400 hover:shadow-sm transition-all text-left"
              >
                <span className="text-xl">{dept.emoji}</span>
                <span className="text-sm font-medium text-slate-700 dark:text-slate-200">{dept.label}</span>
              </button>
            ))}
          </div>
        </div>

        <StartDepartmentAuditDialog
          open={showDeptDialog}
          onOpenChange={setShowDeptDialog}
          onAuditStarted={(audit) => {
            queryClient.invalidateQueries({ queryKey: ['active-audits'] });
            setSelectedAudit(audit);
          }}
        />

        {/* Active Audits */}
        <div className="space-y-4">
          {activeAudits.map(audit => {
            const progress = audit.checklist 
              ? (audit.checklist.filter(item => item.completed).length / audit.checklist.length) * 100
              : 0;
            
            const isInProgress = audit.status === 'in_progress';
            const isScheduled = audit.status === 'scheduled';

            return (
              <Card 
                key={audit.id} 
                className="border-0 shadow-md hover:shadow-lg transition-shadow"
                onClick={() => startAudit(audit)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-base font-semibold mb-2">
                        {audit.title}
                      </CardTitle>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge 
                          variant={isInProgress ? "default" : "secondary"}
                          className="capitalize"
                        >
                          {isInProgress ? (
                            <><Clock className="w-3 h-3 mr-1" /> In Progress</>
                          ) : (
                            audit.status.replace(/_/g, ' ')
                          )}
                        </Badge>
                        <Badge variant="outline" className="capitalize">
                          {audit.audit_type.replace(/_/g, ' ')}
                        </Badge>
                        {audit.priority === 'high' || audit.priority === 'critical' ? (
                          <Badge variant="destructive" className="capitalize">
                            {audit.priority}
                          </Badge>
                        ) : null}
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400 flex-shrink-0 ml-2" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {audit.scope && (
                    <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2">
                      {audit.scope}
                    </p>
                  )}
                  
                  <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {format(new Date(audit.suggested_date), 'MMM d, yyyy')}
                    </div>
                    {audit.estimated_duration_hours && (
                      <div>⏱️ {audit.estimated_duration_hours}h</div>
                    )}
                  </div>

                  {audit.checklist && audit.checklist.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-600 dark:text-slate-400 font-medium">
                          Progress
                        </span>
                        <span className="text-slate-900 dark:text-white font-semibold">
                          {audit.checklist.filter(i => i.completed).length}/{audit.checklist.length} items
                        </span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  )}

                  {audit.focus_areas?.length > 0 && (
                    <div className="flex gap-1 flex-wrap">
                      {audit.focus_areas.slice(0, 3).map((area, idx) => (
                        <span 
                          key={idx}
                          className="text-xs bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 px-2 py-1 rounded"
                        >
                          {area}
                        </span>
                      ))}
                    </div>
                  )}

                  <Button 
                    className="w-full min-h-[48px]" 
                    size="lg"
                    onClick={(e) => {
                      e.stopPropagation();
                      startAudit(audit);
                    }}
                  >
                    {isInProgress ? (
                      <>Continue Audit</>
                    ) : (
                      <>Start Audit</>
                    )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}

          {activeAudits.length === 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <div className="text-4xl mb-4">📋</div>
                <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">
                  No Active Audits
                </h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Scheduled audits will appear here
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Offline Indicator */}
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <div className="flex items-center gap-2 text-sm text-blue-800 dark:text-blue-200">
            <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
            Works offline - findings sync when online
          </div>
        </div>
      </div>
    </div>
  );
}