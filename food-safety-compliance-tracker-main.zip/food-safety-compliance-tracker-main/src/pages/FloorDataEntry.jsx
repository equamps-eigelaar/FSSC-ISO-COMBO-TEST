import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, RefreshCw, ClipboardList, Thermometer, ChevronDown, ChevronUp, CheckCircle2, Clock } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useFloorOfflineQueue } from '@/components/floor/useFloorOfflineQueue';
import CleaningEntryForm from '@/components/floor/CleaningEntryForm';
import TempLogForm from '@/components/floor/TempLogForm';

export default function FloorDataEntry() {
  const [activeTab, setActiveTab] = useState('cleaning');
  const [user, setUser] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState([]);
  const { isOnline, pendingCount, isSyncing, syncAll, submitEntry, getHistory } = useFloorOfflineQueue();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    setHistory(getHistory().slice(0, 15));
  }, []);

  const handleSubmit = async (type, data) => {
    const ok = await submitEntry(type, data);
    if (ok) setHistory(getHistory().slice(0, 15));
    return ok;
  };

  const todayStr = new Date().toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col">

      {/* ── Online/Offline Status Bar ── */}
      <div className={`sticky top-0 z-50 flex items-center justify-between px-4 py-3 border-b backdrop-blur ${
        isOnline ? 'bg-emerald-950/90 border-emerald-800' : 'bg-red-950/90 border-red-800'
      }`}>
        <div className="flex items-center gap-2">
          {isOnline
            ? <Wifi className="w-4 h-4 text-emerald-400" />
            : <WifiOff className="w-4 h-4 text-red-400" />
          }
          <span className={`text-sm font-semibold ${isOnline ? 'text-emerald-300' : 'text-red-300'}`}>
            {isOnline ? 'Online' : 'Offline Mode – entries queued'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {pendingCount > 0 && (
            <div className="flex items-center gap-1.5 text-amber-300 text-sm font-medium">
              <Clock className="w-3.5 h-3.5" />
              {pendingCount} pending
            </div>
          )}
          {isOnline && pendingCount > 0 && (
            <button onClick={syncAll} disabled={isSyncing}
              className="flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all disabled:opacity-60 min-h-[32px]">
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              {isSyncing ? 'Syncing…' : 'Sync Now'}
            </button>
          )}
          {user?.full_name && (
            <span className="text-slate-500 text-xs hidden sm:block">{user.full_name}</span>
          )}
        </div>
      </div>

      {/* ── Header ── */}
      <div className="px-4 pt-5 pb-2">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Floor Data Entry</h1>
            <p className="text-slate-500 text-sm mt-0.5">{todayStr}</p>
          </div>
          {pendingCount > 0 && (
            <div className="shrink-0 bg-amber-500/20 border border-amber-600 rounded-xl px-3 py-2 text-center">
              <div className="text-amber-400 font-bold text-lg leading-none">{pendingCount}</div>
              <div className="text-amber-500 text-xs mt-0.5">queued</div>
            </div>
          )}
        </div>
      </div>

      {/* ── Tab Switcher ── */}
      <div className="px-4 pb-4">
        <div className="grid grid-cols-2 gap-2 bg-slate-800/80 rounded-2xl p-1.5 border border-slate-700">
          <button onClick={() => setActiveTab('cleaning')}
            className={`flex items-center justify-center gap-2.5 py-4 rounded-xl font-bold text-sm transition-all min-h-[60px] ${
              activeTab === 'cleaning'
                ? 'bg-emerald-600 text-white shadow-lg'
                : 'text-slate-400 hover:text-slate-200'
            }`}>
            <ClipboardList className="w-5 h-5" />
            Cleaning Register
          </button>
          <button onClick={() => setActiveTab('temp')}
            className={`flex items-center justify-center gap-2.5 py-4 rounded-xl font-bold text-sm transition-all min-h-[60px] ${
              activeTab === 'temp'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'text-slate-400 hover:text-slate-200'
            }`}>
            <Thermometer className="w-5 h-5" />
            Temperature Log
          </button>
        </div>
      </div>

      {/* ── Form Area ── */}
      <div className="flex-1 px-4 pb-6">
        {activeTab === 'cleaning' ? (
          <CleaningEntryForm onSubmit={handleSubmit} userName={user?.full_name} />
        ) : (
          <TempLogForm onSubmit={handleSubmit} userName={user?.full_name} />
        )}
      </div>

      {/* ── Today's Entry History (collapsible) ── */}
      {history.length > 0 && (
        <div className="mx-4 mb-6 rounded-2xl overflow-hidden border border-slate-700 bg-slate-800">
          <button onClick={() => setShowHistory(v => !v)}
            className="w-full flex items-center justify-between px-4 py-4 text-left min-h-[56px]">
            <span className="text-slate-300 font-semibold text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              Recent Entries ({history.length})
            </span>
            {showHistory
              ? <ChevronUp className="w-4 h-4 text-slate-500" />
              : <ChevronDown className="w-4 h-4 text-slate-500" />
            }
          </button>

          {showHistory && (
            <div className="border-t border-slate-700 divide-y divide-slate-700/60">
              {history.map(entry => {
                const isCleaning = entry.type === 'cleaning';
                const label = entry.data.area || entry.data.location || '—';
                const shift = entry.data.shift;
                const time = new Date(entry.timestamp).toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' });
                const synced = entry.status === 'synced';

                return (
                  <div key={entry.id} className="flex items-center gap-3 px-4 py-3">
                    <div className={`w-2 h-2 rounded-full shrink-0 ${synced ? 'bg-emerald-500' : 'bg-amber-400'}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-slate-200 text-sm font-medium truncate">
                        {isCleaning ? '🧹' : '🌡️'} {label}
                        {isCleaning && entry.data.result && (
                          <span className={`ml-2 text-xs font-semibold ${entry.data.result === 'pass' ? 'text-emerald-400' : entry.data.result === 'fail' ? 'text-red-400' : 'text-amber-400'}`}>
                            {entry.data.result.replace('_', ' ').toUpperCase()}
                          </span>
                        )}
                      </p>
                      <p className="text-slate-500 text-xs capitalize">{shift} shift · {time}</p>
                    </div>
                    <span className={`text-xs font-semibold px-2 py-1 rounded-lg shrink-0 ${
                      synced ? 'bg-emerald-900/60 text-emerald-400' : 'bg-amber-900/60 text-amber-400'
                    }`}>
                      {synced ? 'Synced' : 'Pending'}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}