import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  FileText, Search, Download, Calendar, User, AlertCircle, FolderOpen,
  GitBranch, ShieldCheck, Tag, History, Eye, X, Lock, Share2, Upload,
  Plus, Filter, LayoutGrid, List, Trash2, Link, Sparkles,
} from "lucide-react";
import { format } from "date-fns";
import DocumentControlPanel from "@/components/documents/DocumentControlPanel";
import DocumentViewer from "@/components/documents/DocumentViewer";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { usePermissions } from "@/components/permissions/usePermissions";
import ProprietaryShareDialog from "@/components/proprietary/ProprietaryShareDialog";
import ProprietarySharePanel from "@/components/proprietary/ProprietarySharePanel";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DocumentUploadDialog from "@/components/documents/DocumentUploadDialog";
import DocumentAnalysisDialog from "@/components/documents/DocumentAnalysisDialog";
import MasterDataTab from "@/components/masterdata/MasterDataTab";
import { toast } from "sonner";

const CATEGORIES = [
  { value: "procedure", label: "SOPs / Procedures" },
  { value: "policy", label: "Policies" },
  { value: "training_material", label: "Training Records" },
  { value: "audit_report", label: "Audit Reports" },
  { value: "compliance_evidence", label: "Compliance Evidence" },
  { value: "supplier_certificate", label: "Supplier Certificates" },
  { value: "safety_data_sheet", label: "Safety Data Sheets" },
  { value: "inspection_report", label: "Inspection Reports" },
  { value: "test_report", label: "Test Reports" },
  { value: "risk_analysis", label: "Risk Analysis" },
  { value: "specification", label: "Specifications" },
  { value: "plan", label: "Plans" },
  { value: "record", label: "Records" },
  { value: "other", label: "Other" },
];

const CATEGORY_MAP = Object.fromEntries(CATEGORIES.map(c => [c.value, c.label]));

const CONTROL_COLORS = {
  controlled: "bg-indigo-50 text-indigo-700 border-indigo-200",
  under_review: "bg-amber-50 text-amber-700 border-amber-200",
  uncontrolled: "bg-slate-50 text-slate-600 border-slate-200",
};

export default function DocumentRepository() {
  const { permissions } = usePermissions();
  const queryClient = useQueryClient();

  // Filters
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [controlFilter, setControlFilter] = useState("all");
  const [expiryFilter, setExpiryFilter] = useState("all");
  const [linkedFilter, setLinkedFilter] = useState("all");
  const [viewMode, setViewMode] = useState("grouped"); // grouped | list

  // Dialogs
  const [uploadOpen, setUploadOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState(null); // version control
  const [historyDoc, setHistoryDoc] = useState(null);
  const [viewerDoc, setViewerDoc] = useState(null);
  const [shareDoc, setShareDoc] = useState(null);
  const [analyzingDoc, setAnalyzingDoc] = useState(null);
  const [activeTab, setActiveTab] = useState("documents");

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ["documents-all"],
    queryFn: () => base44.entities.Document.list("-created_date", 500),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Document.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents-all"] });
      toast.success("Document deleted");
    },
  });

  const filtered = useMemo(() => {
    return documents.filter(doc => {
      const q = search.toLowerCase();
      const matchSearch = !search ||
        doc.file_name?.toLowerCase().includes(q) ||
        doc.title?.toLowerCase().includes(q) ||
        doc.description?.toLowerCase().includes(q) ||
        doc.tags?.some(t => t.toLowerCase().includes(q)) ||
        doc.category?.toLowerCase().includes(q);
      const matchCategory = categoryFilter === "all" || doc.category === categoryFilter;
      const matchControl = controlFilter === "all" || doc.control_status === controlFilter;

      const today = new Date();
      const expiry = doc.expiry_date ? new Date(doc.expiry_date) : null;
      const daysLeft = expiry ? Math.ceil((expiry - today) / (1000 * 60 * 60 * 24)) : null;
      const matchExpiry = expiryFilter === "all" ||
        (expiryFilter === "expired" && daysLeft !== null && daysLeft < 0) ||
        (expiryFilter === "expiring_soon" && daysLeft !== null && daysLeft >= 0 && daysLeft <= 30) ||
        (expiryFilter === "valid" && (daysLeft === null || daysLeft > 30));

      const hasLinks = (doc.linked_requirement_ids?.length > 0);
      const matchLinked = linkedFilter === "all" ||
        (linkedFilter === "linked" && hasLinks) ||
        (linkedFilter === "unlinked" && !hasLinks);

      return matchSearch && matchCategory && matchControl && matchExpiry && matchLinked;
    });
  }, [documents, search, categoryFilter, controlFilter, expiryFilter, linkedFilter]);

  const stats = useMemo(() => ({
    total: documents.length,
    controlled: documents.filter(d => d.control_status === "controlled").length,
    expiringSoon: documents.filter(d => {
      if (!d.expiry_date) return false;
      const days = Math.ceil((new Date(d.expiry_date) - new Date()) / (1000 * 60 * 60 * 24));
      return days >= 0 && days <= 30;
    }).length,
    expired: documents.filter(d => d.expiry_date && new Date(d.expiry_date) < new Date()).length,
  }), [documents]);

  const grouped = useMemo(() => {
    return CATEGORIES.reduce((acc, cat) => {
      const docs = filtered.filter(d => d.category === cat.value);
      if (docs.length > 0) acc[cat.value] = { label: cat.label, docs };
      return acc;
    }, {});
  }, [filtered]);

  const hasActiveFilters = categoryFilter !== "all" || controlFilter !== "all" || expiryFilter !== "all" || linkedFilter !== "all" || search !== "";

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        {/* Header */}
        <div className="flex items-center justify-between mb-6 gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Document Repository</h1>
            <p className="text-sm text-slate-500 mt-1">
              {filtered.length} of {documents.length} document{documents.length !== 1 ? "s" : ""}
            </p>
          </div>
          <Button onClick={() => setUploadOpen(true)} className="bg-emerald-600 hover:bg-emerald-700 gap-2">
            <Plus className="w-4 h-4" />
            Upload Document
          </Button>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="border-b border-slate-200 bg-transparent p-0 h-auto w-full justify-start rounded-none flex-wrap">
            <TabsTrigger value="documents" className="px-3 py-2 border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent">
              Documents
            </TabsTrigger>
            <TabsTrigger value="masterdata" className="px-3 py-2 border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent">
              Master Data
            </TabsTrigger>
            {permissions.canManageSettings && (
              <TabsTrigger value="proprietary" className="px-3 py-2 border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent flex items-center gap-2">
                <Lock className="w-4 h-4" />
                Proprietary Shares
              </TabsTrigger>
            )}
          </TabsList>
        </Tabs>

        {activeTab === "proprietary" ? (
          <ProprietarySharePanel />
        ) : activeTab === "masterdata" ? (
          <MasterDataTab />
        ) : (
          <>
            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
              {[
                { label: "Total Documents", value: stats.total, color: "text-slate-900" },
                { label: "Controlled", value: stats.controlled, color: "text-indigo-600" },
                { label: "Expiring Soon", value: stats.expiringSoon, color: "text-amber-600" },
                { label: "Expired", value: stats.expired, color: "text-rose-600" },
              ].map(stat => (
                <Card key={stat.label} className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className={`text-2xl font-bold mb-1 ${stat.color}`}>{stat.value}</div>
                    <div className="text-xs text-slate-500 font-medium">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Search & Filters */}
            <Card className="border-0 shadow-sm mb-6">
              <CardContent className="p-4 space-y-3">
                {/* Search row */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    placeholder="Search by title, filename, description, tags..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9 border-slate-200"
                  />
                  {search && (
                    <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700">
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Filter row */}
                <div className="flex flex-wrap gap-2">
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-48 h-8 text-xs">
                      <Filter className="w-3 h-3 mr-1" />
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {CATEGORIES.map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={controlFilter} onValueChange={setControlFilter}>
                    <SelectTrigger className="w-44 h-8 text-xs">
                      <SelectValue placeholder="Control Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Control Status</SelectItem>
                      <SelectItem value="controlled">Controlled</SelectItem>
                      <SelectItem value="uncontrolled">Uncontrolled</SelectItem>
                      <SelectItem value="under_review">Under Review</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={expiryFilter} onValueChange={setExpiryFilter}>
                    <SelectTrigger className="w-44 h-8 text-xs">
                      <SelectValue placeholder="Expiry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Expiry</SelectItem>
                      <SelectItem value="expired">Expired</SelectItem>
                      <SelectItem value="expiring_soon">Expiring Soon (30d)</SelectItem>
                      <SelectItem value="valid">Valid</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={linkedFilter} onValueChange={setLinkedFilter}>
                    <SelectTrigger className="w-44 h-8 text-xs">
                      <SelectValue placeholder="Links" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Documents</SelectItem>
                      <SelectItem value="linked">Linked to Requirements</SelectItem>
                      <SelectItem value="unlinked">No Links</SelectItem>
                    </SelectContent>
                  </Select>

                  {hasActiveFilters && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 text-xs text-rose-600 hover:bg-rose-50"
                      onClick={() => {
                        setSearch(""); setCategoryFilter("all");
                        setControlFilter("all"); setExpiryFilter("all");
                        setLinkedFilter("all");
                      }}
                    >
                      <X className="w-3 h-3 mr-1" />
                      Clear filters
                    </Button>
                  )}

                  <div className="ml-auto flex items-center gap-1">
                    <button
                      onClick={() => setViewMode("grouped")}
                      className={`p-1.5 rounded ${viewMode === "grouped" ? "bg-slate-200" : "hover:bg-slate-100"}`}
                    >
                      <LayoutGrid className="w-4 h-4 text-slate-600" />
                    </button>
                    <button
                      onClick={() => setViewMode("list")}
                      className={`p-1.5 rounded ${viewMode === "list" ? "bg-slate-200" : "hover:bg-slate-100"}`}
                    >
                      <List className="w-4 h-4 text-slate-600" />
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Documents */}
            {filtered.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-16 text-center">
                  <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500 font-medium">No documents found</p>
                  <p className="text-sm text-slate-400 mt-1">Try adjusting your filters or upload a new document</p>
                  <Button onClick={() => setUploadOpen(true)} className="mt-4 bg-emerald-600 hover:bg-emerald-700 gap-2">
                    <Plus className="w-4 h-4" />Upload Document
                  </Button>
                </CardContent>
              </Card>
            ) : viewMode === "grouped" ? (
              <div className="space-y-6">
                {Object.entries(grouped).map(([catValue, { label, docs }]) => (
                  <Card key={catValue} className="border-0 shadow-sm">
                    <CardHeader className="border-b border-slate-100 py-3 px-4">
                      <div className="flex items-center gap-2">
                        <FolderOpen className="w-4 h-4 text-emerald-600" />
                        <CardTitle className="text-sm font-semibold">{label}</CardTitle>
                        <Badge variant="secondary" className="ml-auto text-xs">{docs.length}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-3">
                      <div className="space-y-2">
                        {docs.map(doc => (
                          <DocumentRow
                            key={doc.id}
                            doc={doc}
                            permissions={permissions}
                            onView={() => setViewerDoc(doc)}
                            onVersionControl={() => setSelectedDoc(doc)}
                            onHistory={() => setHistoryDoc(doc)}
                            onShare={() => setShareDoc(doc)}
                            onAnalyze={() => setAnalyzingDoc(doc)}
                            onDelete={() => deleteMutation.mutate(doc.id)}
                          />
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-3 space-y-2">
                  {filtered.map(doc => (
                    <DocumentRow
                      key={doc.id}
                      doc={doc}
                      permissions={permissions}
                      onView={() => setViewerDoc(doc)}
                      onVersionControl={() => setSelectedDoc(doc)}
                      onHistory={() => setHistoryDoc(doc)}
                      onShare={() => setShareDoc(doc)}
                      onAnalyze={() => setAnalyzingDoc(doc)}
                      onDelete={() => deleteMutation.mutate(doc.id)}
                      showCategory
                    />
                  ))}
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* Upload Dialog */}
        <DocumentUploadDialog
          open={uploadOpen}
          onOpenChange={setUploadOpen}
          onDocumentUploaded={() => queryClient.invalidateQueries({ queryKey: ["documents-all"] })}
        />

        {/* Document Viewer */}
        <DocumentViewer doc={viewerDoc} open={!!viewerDoc} onClose={() => setViewerDoc(null)} />

        {/* Version Control Dialog */}
        <Dialog open={!!selectedDoc} onOpenChange={(open) => !open && setSelectedDoc(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-indigo-600" />
                {selectedDoc?.title || selectedDoc?.file_name}
              </DialogTitle>
            </DialogHeader>
            <DocumentControlPanel document={selectedDoc} />
          </DialogContent>
        </Dialog>

        {/* Change History Dialog */}
        <HistoryDialog doc={historyDoc} onClose={() => setHistoryDoc(null)} />

        {/* Proprietary Share Dialog */}
        <ProprietaryShareDialog document={shareDoc} open={!!shareDoc} onClose={() => setShareDoc(null)} />

        {/* AI Analysis Dialog */}
        {analyzingDoc && (
          <DocumentAnalysisDialog
            open={!!analyzingDoc}
            onClose={() => setAnalyzingDoc(null)}
            document={analyzingDoc}
          />
        )}
      </div>
    </div>
  );
}

function DocumentRow({ doc, permissions, onView, onVersionControl, onHistory, onShare, onAnalyze, onDelete, showCategory }) {
  const today = new Date();
  const expiry = doc.expiry_date ? new Date(doc.expiry_date) : null;
  const daysLeft = expiry ? Math.ceil((expiry - today) / (1000 * 60 * 60 * 24)) : null;
  const expired = daysLeft !== null && daysLeft < 0;
  const expiringSoon = !expired && daysLeft !== null && daysLeft <= 30;
  const hasLinks = doc.linked_requirement_ids?.length > 0;

  return (
    <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors group">
      <FileText className="w-4 h-4 text-slate-500 mt-0.5 shrink-0" />

      <div className="flex-1 min-w-0">
        <div className="flex flex-wrap items-center gap-1.5 mb-0.5">
          <h4 className="text-sm font-medium text-slate-900 truncate max-w-xs">
            {doc.title || doc.file_name}
          </h4>
          {doc.title && doc.title !== doc.file_name && (
            <span className="text-xs text-slate-400 truncate">{doc.file_name}</span>
          )}
          {doc.control_status === "controlled" && (
            <Badge variant="outline" className={`text-xs ${CONTROL_COLORS.controlled}`}>
              <ShieldCheck className="w-3 h-3 mr-1" />v{doc.current_version || "1.0"}
            </Badge>
          )}
          {doc.control_status === "under_review" && (
            <Badge variant="outline" className={`text-xs ${CONTROL_COLORS.under_review}`}>Under Review</Badge>
          )}
          {showCategory && doc.category && (
            <Badge variant="outline" className="text-xs text-slate-500">
              {CATEGORY_MAP[doc.category] || doc.category}
            </Badge>
          )}
          {expired && (
            <Badge variant="outline" className="text-xs bg-rose-50 text-rose-700 border-rose-200">
              <AlertCircle className="w-3 h-3 mr-0.5" />Expired
            </Badge>
          )}
          {expiringSoon && (
            <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
              <AlertCircle className="w-3 h-3 mr-0.5" />{daysLeft}d left
            </Badge>
          )}
          {hasLinks && (
            <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200">
              <Link className="w-3 h-3 mr-1" />{doc.linked_requirement_ids.length} req{doc.linked_requirement_ids.length !== 1 ? "s" : ""}
            </Badge>
          )}
        </div>

        {doc.description && (
          <p className="text-xs text-slate-500 line-clamp-1 mb-0.5">{doc.description}</p>
        )}

        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
          {doc.file_size && <span>{(doc.file_size / 1024).toFixed(0)} KB</span>}
          <span className="flex items-center gap-1"><User className="w-3 h-3" />{doc.uploaded_by?.split("@")[0]}</span>
          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{format(new Date(doc.created_date), "MMM d, yyyy")}</span>
          {expiry && (
            <span className={expired ? "text-rose-500" : expiringSoon ? "text-amber-500" : ""}>
              Exp. {format(expiry, "MMM d, yyyy")}
            </span>
          )}
        </div>

        {doc.tags?.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1.5">
            {doc.tags.slice(0, 5).map(tag => (
              <span key={tag} className="text-xs px-1.5 py-0.5 bg-white border border-emerald-100 text-emerald-700 rounded-full">{tag}</span>
            ))}
            {doc.tags.length > 5 && <span className="text-xs text-slate-400">+{doc.tags.length - 5} more</span>}
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-0.5 shrink-0 opacity-70 group-hover:opacity-100 transition-opacity">
        {['supplier_certificate', 'safety_data_sheet', 'test_report', 'compliance_evidence', 'audit_report'].includes(doc.category) && (
          <Button variant="ghost" size="sm" onClick={onAnalyze} className="h-8 w-8 p-0 text-slate-400 hover:text-purple-600 hover:bg-purple-50" title="AI Analysis">
            <Sparkles className="w-3.5 h-3.5" />
          </Button>
        )}
        <Button variant="ghost" size="sm" onClick={onView} className="h-8 w-8 p-0 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50" title="Preview">
          <Eye className="w-3.5 h-3.5" />
        </Button>
        <Button variant="ghost" size="sm" onClick={onVersionControl} className="h-8 w-8 p-0 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50" title="Version Control">
          <GitBranch className="w-3.5 h-3.5" />
        </Button>
        <Button variant="ghost" size="sm" onClick={onHistory} className="h-8 w-8 p-0 text-slate-400 hover:text-slate-600" title="Change History">
          <History className="w-3.5 h-3.5" />
        </Button>
        {permissions.canManageSettings && (doc.category === "specification" || doc.category === "other") && (
          <Button variant="ghost" size="sm" onClick={onShare} className="h-8 w-8 p-0 text-amber-500 hover:bg-amber-50" title="Share Proprietary">
            <Share2 className="w-3.5 h-3.5" />
          </Button>
        )}
        <Button variant="ghost" size="sm" onClick={() => window.open(doc.file_url, "_blank")} className="h-8 w-8 p-0 text-slate-400 hover:text-slate-700" title="Download">
          <Download className="w-3.5 h-3.5" />
        </Button>
        {permissions.canManageDocuments && (
          <Button variant="ghost" size="sm" onClick={onDelete} className="h-8 w-8 p-0 text-slate-400 hover:text-rose-600 hover:bg-rose-50" title="Delete">
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        )}
      </div>
    </div>
  );
}

function HistoryDialog({ doc, onClose }) {
  const { data: revisions = [] } = useQuery({
    queryKey: ["document-revisions", doc?.id],
    queryFn: () => base44.entities.DocumentRevision.filter({ document_id: doc.id }, "-created_date", 50),
    enabled: !!doc,
  });

  if (!doc) return null;

  return (
    <Dialog open={!!doc} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="w-4 h-4" />
            Change History — {doc.title || doc.file_name}
          </DialogTitle>
        </DialogHeader>
        <div className="py-4 space-y-3">
          <div className="border border-slate-100 rounded-lg p-3 bg-slate-50">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-slate-600">Original Upload</span>
              <span className="text-xs text-slate-500">{format(new Date(doc.created_date), "MMM d, yyyy h:mm a")}</span>
            </div>
            <p className="text-xs text-slate-600">Uploaded by <strong>{doc.uploaded_by}</strong></p>
          </div>
          {revisions.length > 0 ? revisions.map(rev => (
            <div key={rev.id} className="border border-slate-100 rounded-lg p-3">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-semibold">v{rev.version}</span>
                  <span className={`text-xs px-1.5 py-0.5 rounded ${rev.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : rev.status === 'pending_review' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'}`}>
                    {rev.status?.replace(/_/g, " ")}
                  </span>
                  {rev.is_current && <span className="text-xs px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800">Current</span>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">{format(new Date(rev.created_date), "MMM d, yyyy h:mm a")}</span>
                  <Button size="sm" variant="ghost" asChild className="h-6 w-6 p-0">
                    <a href={rev.file_url} target="_blank" rel="noopener noreferrer"><Download className="w-3 h-3" /></a>
                  </Button>
                </div>
              </div>
              {rev.change_summary && <p className="text-xs text-slate-600">{rev.change_summary}</p>}
              <div className="flex flex-wrap gap-3 text-xs text-slate-400 mt-1">
                <span>{rev.revision_type} revision</span>
                {rev.approved_by && <span>• Approved by {rev.approved_by}</span>}
              </div>
            </div>
          )) : (
            <p className="text-sm text-slate-400 text-center py-4">No version revisions recorded yet.</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}