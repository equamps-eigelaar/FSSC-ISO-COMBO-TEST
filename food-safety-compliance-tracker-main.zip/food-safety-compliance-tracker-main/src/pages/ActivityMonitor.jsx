import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Activity, Search, Download, CheckCircle2, AlertTriangle, XCircle,
  FileText, Calendar, User, Shield, Package, GitBranch, ChevronDown,
  ChevronRight, Eye, History,
} from "lucide-react";
import { format } from "date-fns";

const TYPE_CONFIG = {
  requirement_created:    { icon: FileText,      color: "text-blue-600",    bg: "bg-blue-50",    label: "Req. Created" },
  requirement_updated:    { icon: FileText,      color: "text-amber-600",   bg: "bg-amber-50",   label: "Req. Updated" },
  requirement_deleted:    { icon: XCircle,       color: "text-rose-600",    bg: "bg-rose-50",    label: "Req. Deleted" },
  status_changed:         { icon: CheckCircle2,  color: "text-emerald-600", bg: "bg-emerald-50", label: "Status Change" },
  risk_added:             { icon: AlertTriangle, color: "text-orange-600",  bg: "bg-orange-50",  label: "Risk Added" },
  risk_updated:           { icon: AlertTriangle, color: "text-amber-600",   bg: "bg-amber-50",   label: "Risk Updated" },
  risk_deleted:           { icon: AlertTriangle, color: "text-rose-600",    bg: "bg-rose-50",    label: "Risk Deleted" },
  risk_workflow_changed:  { icon: Shield,        color: "text-purple-600",  bg: "bg-purple-50",  label: "Risk Workflow" },
  evidence_uploaded:      { icon: FileText,      color: "text-blue-600",    bg: "bg-blue-50",    label: "Evidence" },
  document_uploaded:      { icon: GitBranch,     color: "text-indigo-600",  bg: "bg-indigo-50",  label: "Doc Uploaded" },
  document_updated:       { icon: GitBranch,     color: "text-amber-600",   bg: "bg-amber-50",   label: "Doc Updated" },
  document_deleted:       { icon: XCircle,       color: "text-rose-600",    bg: "bg-rose-50",    label: "Doc Deleted" },
  document_version_added: { icon: GitBranch,     color: "text-indigo-600",  bg: "bg-indigo-50",  label: "New Version" },
  document_analysis_run:  { icon: Activity,      color: "text-violet-600",  bg: "bg-violet-50",  label: "AI Analysis" },
  comment_added:          { icon: Activity,      color: "text-purple-600",  bg: "bg-purple-50",  label: "Comment" },
  action_item_created:    { icon: CheckCircle2,  color: "text-sky-600",     bg: "bg-sky-50",     label: "Action Created" },
  action_item_updated:    { icon: CheckCircle2,  color: "text-amber-600",   bg: "bg-amber-50",   label: "Action Updated" },
  action_item_completed:  { icon: CheckCircle2,  color: "text-emerald-600", bg: "bg-emerald-50", label: "Action Done" },
  batch_created:          { icon: Package,       color: "text-cyan-600",    bg: "bg-cyan-50",    label: "Batch Created" },
  batch_updated:          { icon: Package,       color: "text-cyan-600",    bg: "bg-cyan-50",    label: "Batch Updated" },
  batch_operation:        { icon: Package,       color: "text-cyan-600",    bg: "bg-cyan-50",    label: "Batch Operation" },
  user_invited:           { icon: User,          color: "text-emerald-600", bg: "bg-emerald-50", label: "User Invited" },
  user_login:             { icon: User,          color: "text-green-600",   bg: "bg-green-50",   label: "User Login" },
  report_generated:       { icon: FileText,      color: "text-indigo-600",  bg: "bg-indigo-50",  label: "Report Generated" },
  settings_changed:       { icon: Shield,        color: "text-slate-600",   bg: "bg-slate-100",  label: "Settings Changed" },
  bug_reported:           { icon: AlertTriangle, color: "text-orange-600",  bg: "bg-orange-50",  label: "Bug Reported" },
  access_control_event:   { icon: Shield,        color: "text-purple-600",  bg: "bg-purple-50",  label: "Access Control" },
  audit_completed:        { icon: CheckCircle2,  color: "text-green-600",   bg: "bg-green-50",   label: "Audit Completed" },
  system_event:           { icon: Activity,      color: "text-slate-500",   bg: "bg-slate-50",   label: "System" },
  review_completed:       { icon: CheckCircle2,  color: "text-emerald-600", bg: "bg-emerald-50", label: "Review Done" },
};

const MODULE_OPTIONS = [
  { value: "all",          label: "All Modules" },
  { value: "requirements", label: "Requirements" },
  { value: "risks",        label: "Risk Assessments" },
  { value: "documents",    label: "Documents" },
  { value: "actions",      label: "Action Items" },
  { value: "comments",     label: "Comments" },
  { value: "traceability", label: "Traceability" },
  { value: "user",         label: "User Activity" },
  { value: "reports",      label: "Reports" },
  { value: "settings",     label: "Settings" },
  { value: "support",      label: "Support Tickets" },
];

function ActivityRow({ activity }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = TYPE_CONFIG[activity.activity_type] || TYPE_CONFIG.system_event;
  const Icon = cfg.icon;
  const hasChanges = activity.field_changes?.length > 0;

  return (
    <Card className="border-0 shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-0">
        <button
          className="w-full text-left p-4 flex items-start gap-4"
          onClick={() => hasChanges && setExpanded(!expanded)}
        >
          <div className={`w-9 h-9 rounded-lg ${cfg.bg} flex items-center justify-center shrink-0 mt-0.5`}>
            <Icon className={`w-4 h-4 ${cfg.color}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <p className="text-sm text-slate-900 font-medium leading-snug">{activity.description}</p>
              <span className="text-xs text-slate-400 shrink-0 whitespace-nowrap">
                {format(new Date(activity.created_date), "MMM d, HH:mm")}
              </span>
            </div>
            <div className="flex items-center gap-2 flex-wrap mt-1.5">
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cfg.bg} ${cfg.color}`}>
                {cfg.label}
              </span>
              {activity.entity_type && (
                <Badge variant="outline" className="text-xs">{activity.entity_type}</Badge>
              )}
              {activity.user_email && (
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <User className="w-3 h-3" />
                  {activity.user_name || activity.user_email}
                </span>
              )}
              {hasChanges && (
                <span className="text-xs text-slate-400 flex items-center gap-1 ml-auto">
                  {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                  {activity.field_changes.length} field change{activity.field_changes.length > 1 ? "s" : ""}
                </span>
              )}
            </div>
          </div>
        </button>

        {expanded && hasChanges && (
          <div className="px-4 pb-4 pt-0 border-t border-slate-50">
            <div className="ml-13 pl-4 border-l-2 border-slate-100 space-y-1.5 pt-3">
              {activity.field_changes.map((change, i) => (
                <div key={i} className="text-xs grid grid-cols-[120px_1fr_1fr] gap-2 items-center">
                  <span className="font-medium text-slate-500">{change.field?.replace(/_/g, " ")}</span>
                  <span className="text-rose-600 bg-rose-50 px-2 py-0.5 rounded truncate">
                    {formatChangeVal(change.old_value)}
                  </span>
                  <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded truncate">
                    {formatChangeVal(change.new_value)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function formatChangeVal(val) {
  if (val === null || val === undefined) return "—";
  if (typeof val === "boolean") return val ? "Yes" : "No";
  if (Array.isArray(val)) return `[${val.length} item(s)]`;
  if (typeof val === "object") return "[Object]";
  const s = String(val);
  return s.length > 80 ? s.substring(0, 80) + "…" : s;
}

export default function ActivityMonitor() {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [moduleFilter, setModuleFilter] = useState("all");
  const [dateRange, setDateRange] = useState("30");
  const [userFilter, setUserFilter] = useState("all");
  const queryClient = useQueryClient();

  const { data: activities = [], isLoading } = useQuery({
    queryKey: ["activity-logs"],
    queryFn: () => base44.entities.ActivityLog.list("-created_date", 500),
  });

  const { data: comments = [] } = useQuery({
    queryKey: ["all-comments"],
    queryFn: () => base44.entities.Comment.list("-created_date", 200),
  });

  useEffect(() => {
    const unsubscribe = base44.entities.ActivityLog.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["activity-logs"] });
    });
    return unsubscribe;
  }, [queryClient]);

  // Merge comments into feed
  const allActivities = [
    ...activities,
    ...comments.map(c => ({
      id: `comment-${c.id}`,
      activity_type: "comment_added",
      entity_type: c.entity_type,
      entity_id: c.entity_id,
      entity_label: c.entity_id,
      description: `${c.user_name || c.user_email} commented on ${c.entity_type}`,
      user_email: c.user_email,
      user_name: c.user_name,
      created_date: c.created_date,
    })),
  ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  // Unique users for filter
  const users = [...new Set(allActivities.map(a => a.user_email).filter(Boolean))];

  const filtered = allActivities.filter(a => {
    const matchSearch =
      !search ||
      a.description?.toLowerCase().includes(search.toLowerCase()) ||
      a.user_email?.toLowerCase().includes(search.toLowerCase()) ||
      a.entity_label?.toLowerCase().includes(search.toLowerCase());

    const matchType = typeFilter === "all" || a.activity_type === typeFilter;
    const matchUser = userFilter === "all" || a.user_email === userFilter;

    const matchModule =
      moduleFilter === "all" ||
      (moduleFilter === "requirements" && a.entity_type === "ComplianceRequirement") ||
      (moduleFilter === "risks" && a.entity_type === "RiskAssessment") ||
      (moduleFilter === "documents" && (a.entity_type === "Document" || a.entity_type === "DocumentRevision")) ||
      (moduleFilter === "actions" && a.entity_type === "ActionItem") ||
      (moduleFilter === "comments" && a.activity_type === "comment_added") ||
      (moduleFilter === "traceability" && (a.entity_type === "RawMaterialBatch" || a.entity_type === "FoodBatchRecord")) ||
      (moduleFilter === "user" && ["user_login", "user_invited", "access_control_event"].includes(a.activity_type)) ||
      (moduleFilter === "reports" && a.activity_type === "report_generated") ||
      (moduleFilter === "settings" && a.activity_type === "settings_changed") ||
      (moduleFilter === "support" && a.activity_type === "bug_reported");

    if (dateRange !== "all") {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - parseInt(dateRange));
      if (new Date(a.created_date) < cutoff) return false;
    }

    return matchSearch && matchType && matchModule && matchUser;
  });

  // Stats
  const today = allActivities.filter(a => new Date(a.created_date).toDateString() === new Date().toDateString()).length;
  const byUser = {};
  allActivities.forEach(a => { if (a.user_email) byUser[a.user_email] = (byUser[a.user_email] || 0) + 1; });

  const exportCSV = () => {
    const rows = [
      ["Date", "Type", "Module", "Description", "Entity", "User", "Field Changes"],
      ...filtered.map(a => [
        format(new Date(a.created_date), "yyyy-MM-dd HH:mm:ss"),
        a.activity_type,
        a.entity_type || "",
        `"${(a.description || "").replace(/"/g, "'")}"`,
        a.entity_label || a.entity_id || "",
        a.user_email || "system",
        a.field_changes?.length || 0,
      ])
    ].map(r => r.join(",")).join("\n");

    const blob = new Blob([rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const el = document.createElement("a");
    el.href = url;
    el.download = `audit-trail-${format(new Date(), "yyyy-MM-dd")}.csv`;
    el.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        {/* Header */}
        <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <History className="w-7 h-7 text-emerald-600" />
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Audit Trail</h1>
            </div>
            <p className="text-slate-500 text-sm ml-10">
              Complete, searchable history of all user actions across the system
            </p>
          </div>
          <Button onClick={exportCSV} variant="outline" size="sm" className="gap-2">
            <Download className="w-4 h-4" />
            Export CSV
          </Button>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <StatCard label="Total Events" value={allActivities.length} color="text-slate-700" />
          <StatCard label="Today" value={today} color="text-emerald-600" />
          <StatCard label="Filtered Results" value={filtered.length} color="text-indigo-600" />
          <StatCard label="Active Users" value={Object.keys(byUser).length} color="text-amber-600" />
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-3 flex-wrap">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search by description, user, entity…"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={moduleFilter} onValueChange={setModuleFilter}>
                <SelectTrigger className="w-full md:w-44">
                  <SelectValue placeholder="Module" />
                </SelectTrigger>
                <SelectContent>
                  {MODULE_OPTIONS.map(o => (
                    <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Event type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Event Types</SelectItem>
                  {Object.entries(TYPE_CONFIG).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={userFilter} onValueChange={setUserFilter}>
                <SelectTrigger className="w-full md:w-52">
                  <SelectValue placeholder="User" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Users</SelectItem>
                  {users.map(u => (
                    <SelectItem key={u} value={u}>{u}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-full md:w-36">
                  <SelectValue placeholder="Period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Last 24h</SelectItem>
                  <SelectItem value="7">Last 7 days</SelectItem>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                  <SelectItem value="all">All Time</SelectItem>
                </SelectContent>
              </Select>
              {(search || typeFilter !== "all" || moduleFilter !== "all" || userFilter !== "all") && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => { setSearch(""); setTypeFilter("all"); setModuleFilter("all"); setUserFilter("all"); }}
                  className="text-slate-400 hover:text-slate-700"
                >
                  Clear
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Feed */}
        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-16 text-center">
              <History className="w-12 h-12 text-slate-200 mx-auto mb-3" />
              <p className="text-slate-500 font-medium">No audit events found</p>
              <p className="text-slate-400 text-sm mt-1">Try adjusting your filters</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            <p className="text-xs text-slate-400 mb-3">
              Showing {filtered.length} of {allActivities.length} events · click a row to expand field changes
            </p>
            {filtered.map(a => <ActivityRow key={a.id} activity={a} />)}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, color }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-5">
        <div className={`text-2xl font-bold ${color} mb-0.5`}>{value}</div>
        <div className="text-xs text-slate-400 font-medium">{label}</div>
      </CardContent>
    </Card>
  );
}