import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Package, Plus, Search, Calendar } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import FoodBatchDialog from "@/components/food/FoodBatchDialog";
import BatchDocumentButtons from "@/components/food/BatchDocumentButtons";

export default function FoodBatchRecords() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingBatch, setEditingBatch] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: batches = [], isLoading } = useQuery({
    queryKey: ["food-batches"],
    queryFn: () => base44.entities.FoodBatchRecord.list("-production_date", 100),
  });

  const filteredBatches = batches.filter(batch => {
    const matchesSearch = batch.batch_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      batch.product_name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || batch.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusColors = {
    in_production: "bg-blue-50 text-blue-700 border-blue-200",
    completed: "bg-slate-50 text-slate-700 border-slate-200",
    quality_hold: "bg-amber-50 text-amber-700 border-amber-200",
    released: "bg-emerald-50 text-emerald-700 border-emerald-200",
    rejected: "bg-red-50 text-red-700 border-red-200",
  };

  const handleEdit = (batch) => {
    setEditingBatch(batch);
    setShowDialog(true);
  };

  const handleClose = () => {
    setShowDialog(false);
    setEditingBatch(null);
  };

  if (isLoading) {
    return <div className="p-6 text-slate-500">Loading batch records...</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Food Batch Records</h1>
            <p className="text-slate-600 mt-1">Track production batches from ingredients to finished product</p>
          </div>
          <Button onClick={() => setShowDialog(true)} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-2" />
            New Batch Record
          </Button>
        </div>

        <div className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search batch number or product..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="in_production">In Production</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="quality_hold">Quality Hold</SelectItem>
              <SelectItem value="released">Released</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4">
           {filteredBatches.map((batch) => (
             <Card key={batch.id} className="hover:shadow-md transition-shadow">
               <CardHeader>
                 <div className="flex items-start justify-between">
                   <div className="flex-1 cursor-pointer" onClick={() => handleEdit(batch)}>
                     <div className="flex items-center gap-2 mb-2">
                       <Package className="w-5 h-5 text-emerald-600" />
                       <CardTitle className="text-xl">{batch.product_name}</CardTitle>
                     </div>
                     <p className="text-sm text-slate-600">Batch: {batch.batch_number}</p>
                   </div>
                   <div className="flex items-center gap-3">
                     <Badge variant="outline" className={statusColors[batch.status]}>
                       {batch.status.replace(/_/g, " ")}
                     </Badge>
                   </div>
                 </div>
               </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-xs font-medium text-slate-500">Production Date</p>
                    <p className="text-sm text-slate-900 flex items-center gap-1 mt-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(batch.production_date).toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-slate-500">Quantity</p>
                    <p className="text-sm text-slate-900 mt-1">{batch.quantity_produced} {batch.unit}</p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-slate-500">Line</p>
                    <p className="text-sm text-slate-900 mt-1">{batch.production_line || "—"}</p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-slate-500">Shift</p>
                    <p className="text-sm text-slate-900 mt-1 capitalize">{batch.shift || "—"}</p>
                  </div>
                </div>
                {batch.allergens_present?.length > 0 && (
                  <div className="mb-4 pt-3 border-t">
                    <p className="text-xs font-medium text-slate-500 mb-1">Allergens Present</p>
                    <div className="flex flex-wrap gap-1">
                      {batch.allergens_present.map((allergen, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                          {allergen}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                <div className="border-t pt-4">
                  <BatchDocumentButtons batch={batch} />
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredBatches.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">No batch records found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {showDialog && (
        <FoodBatchDialog
          open={showDialog}
          onClose={handleClose}
          batch={editingBatch}
        />
      )}
    </div>
  );
}