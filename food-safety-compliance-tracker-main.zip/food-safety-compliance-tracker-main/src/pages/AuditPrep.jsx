import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  AlertTriangle, Clock, XCircle, CheckCircle2, FileText,
  Calendar, ChevronRight, Download, ShieldCheck, TrendingUp,
  ClipboardList, Activity, Package
} from "lucide-react";

const SECTIONS = [
  "4 - Context of the Organization",
  "5 - Leadership",
  "6 - Planning",
  "7 - Support",
  "8 - Operation",
  "9 - Performance Evaluation",
  "10 - Improvement",
  "TS 22002-4 - Establishment",
  "TS 22002-4 - Utilities",
  "TS 22002-4 - Equipment",
  "TS 22002-4 - Hygiene",
  "TS 22002-4 - Personnel",
  "TS 22002-4 - Transportation",
  "TS 22002-4 - Product Information",
  "TS 22002-4 - Other Requirements",
];

const STATUS_CONFIG = {
  compliant: { label: "Compliant", color: "bg-emerald-100 text-emerald-800", dot: "bg-emerald-500" },
  in_progress: { label: "In Progress", color: "bg-blue-100 text-blue-800", dot: "bg-blue-500" },
  partial: { label: "Partial", color: "bg-amber-100 text-amber-800", dot: "bg-amber-500" },
  not_started: { label: "Not Started", color: "bg-slate-100 text-slate-600", dot: "bg-slate-400" },
  non_compliant: { label: "Non-Compliant", color: "bg-red-100 text-red-800", dot: "bg-red-500" },
};

const PRIORITY_CONFIG = {
  critical: "bg-red-100 text-red-800",
  high: "bg-orange-100 text-orange-800",
  medium: "bg-yellow-100 text-yellow-800",
  low: "bg-slate-100 text-slate-600",
};

export default function AuditPrep() {
  const [exporting, setExporting] = useState(false);

  const { data: requirements = [], isLoading } = useQuery({
    queryKey: ['requirements-audit-prep'],
    queryFn: () => base44.entities.ComplianceRequirement.list('-clause_number', 500)
  });
  const { data: documents = [] } = useQuery({
    queryKey: ['documents-audit-prep'],
    queryFn: () => base44.entities.Document.list('-created_date', 500)
  });
  const { data: risks = [] } = useQuery({
    queryKey: ['risks-audit-prep'],
    queryFn: () => base44.entities.RiskAssessment.list('-created_date', 500)
  });
  const { data: actions = [] } = useQuery({
    queryKey: ['actions-audit-prep'],
    queryFn: () => base44.entities.ActionItem.list('-created_date', 500)
  });

  const stats = useMemo(() => {
    const total = requirements.length;
    const compliant = requirements.filter(r => r.status === 'compliant').length;
    const nonCompliant = requirements.filter(r => r.status === 'non_compliant').length;
    const partial = requirements.filter(r => r.status === 'partial').length;
    const inProgress = requirements.filter(r => r.status === 'in_progress').length;
    const notStarted = requirements.filter(r => r.status === 'not_started').length;
    const readiness = total > 0 ? Math.round((compliant / total) * 100) : 0;
    const overdue = requirements.filter(r =>
      r.due_date && new Date(r.due_date) < new Date() && r.status !== 'compliant'
    ).length;
    const missingEvidence = requirements.filter(r =>
      !r.evidence_notes && (!r.evidence_files || r.evidence_files.length === 0) && r.status !== 'compliant'
    ).length;
    const openActions = actions.filter(a => a.status === 'pending' || a.status === 'in_progress').length;
    return { total, compliant, nonCompliant, partial, inProgress, notStarted, readiness, overdue, missingEvidence, openActions };
  }, [requirements, actions]);

  const nonConformances = useMemo(() =>
    requirements.filter(r => r.status === 'non_compliant' || r.status === 'partial'),
    [requirements]
  );

  const openActions = useMemo(() =>
    actions.filter(a => a.status === 'pending' || a.status === 'in_progress' || a.status === 'blocked'),
    [actions]
  );

  const expiringDocs = useMemo(() =>
    documents.filter(d => {
      if (!d.expiry_date) return false;
      const days = Math.ceil((new Date(d.expiry_date) - new Date()) / 86400000);
      return days <= 60 && days >= 0;
    }),
    [documents]
  );

  const bySection = useMemo(() => {
    return SECTIONS.map(section => {
      const reqs = requirements.filter(r => r.section === section);
      const compliant = reqs.filter(r => r.status === 'compliant').length;
      const nc = reqs.filter(r => r.status === 'non_compliant').length;
      const partial = reqs.filter(r => r.status === 'partial').length;
      const pct = reqs.length > 0 ? Math.round((compliant / reqs.length) * 100) : null;
      return { section, reqs, compliant, nc, partial, total: reqs.length, pct };
    }).filter(s => s.total > 0);
  }, [requirements]);

  const handleExport = () => {
    setExporting(true);
    const esc = v => {
      if (v == null) return "";
      const s = String(v).replace(/"/g, '""');
      return /[",\n\r]/.test(s) ? `"${s}"` : s;
    };
    const row = cols => cols.map(esc).join(",");

    const lines = [
      "ISO 22000:2018 EXTERNAL AUDIT PREPARATION PACK",
      `Generated: ${new Date().toLocaleString()}`,
      "",
      "=== AUDIT READINESS SUMMARY ===",
      row(["Metric", "Value"]),
      row(["Overall Readiness", `${stats.readiness}%`]),
      row(["Total Requirements", stats.total]),
      row(["Compliant", stats.compliant]),
      row(["Non-Compliant", stats.nonCompliant]),
      row(["Partial", stats.partial]),
      row(["In Progress", stats.inProgress]),
      row(["Not Started", stats.notStarted]),
      row(["Overdue", stats.overdue]),
      row(["Missing Evidence", stats.missingEvidence]),
      row(["Open Actions", stats.openActions]),
      "",
      "=== NON-CONFORMANCES & GAPS ===",
      row(["Clause", "Title", "Section", "Status", "Priority", "Findings", "Corrective Actions", "Assigned To", "Due Date", "Completion %"]),
      ...nonConformances.map(r => row([
        r.clause_number, r.clause_title, r.section, r.status, r.priority,
        r.findings, r.corrective_actions, r.assigned_to, r.due_date, r.completion_percentage
      ])),
      "",
      "=== OPEN ACTION ITEMS ===",
      row(["Title", "Source", "Priority", "Status", "Assigned To", "Due Date", "Progress Notes"]),
      ...openActions.map(a => row([
        a.title, a.source_type, a.priority, a.status, a.assigned_to, a.due_date, a.progress_notes
      ])),
      "",
      "=== FULL GAP ANALYSIS CHECKLIST (ISO 22000:2018) ===",
      row(["Clause", "Title", "Section", "Status", "Priority", "Responsible", "Due Date", "Completion %", "Evidence Notes", "Findings", "Corrective Actions"]),
      ...requirements.sort((a, b) => (a.clause_number || "").localeCompare(b.clause_number || "")).map(r => row([
        r.clause_number, r.clause_title, r.section, r.status, r.priority,
        r.responsible_person, r.due_date, r.completion_percentage,
        r.evidence_notes, r.findings, r.corrective_actions
      ])),
      "",
      "=== EXPIRING DOCUMENTS (next 60 days) ===",
      row(["Document", "Category", "Expiry Date", "Control Status"]),
      ...expiringDocs.map(d => row([d.title || d.file_name, d.category, d.expiry_date, d.control_status])),
    ].join("\r\n");

    const blob = new Blob(["\uFEFF" + lines], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Audit-Prep-Pack-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    a.remove();
    setExporting(false);
  };

  const readinessColor = stats.readiness >= 80 ? "text-emerald-600" : stats.readiness >= 60 ? "text-amber-600" : "text-red-600";
  const readinessStroke = stats.readiness >= 80 ? "text-emerald-500" : stats.readiness >= 60 ? "text-amber-500" : "text-red-500";

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 text-sm">Loading audit pack...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">

        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
              <h1 className="text-2xl font-bold text-slate-900">Audit Prep Pack</h1>
            </div>
            <p className="text-sm text-slate-500 mt-0.5">ISO 22000:2018 — External Audit Preparation</p>
          </div>
          <Button
            onClick={handleExport}
            disabled={exporting}
            className="bg-emerald-600 hover:bg-emerald-700 gap-2"
          >
            <Download className="w-4 h-4" />
            {exporting ? "Exporting..." : "Export Full Pack (CSV)"}
          </Button>
        </div>

        {/* Readiness Banner */}
        <Card className="border-0 shadow-sm mb-6 bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <div className="relative flex-shrink-0">
                <svg className="w-28 h-28 -rotate-90">
                  <circle cx="56" cy="56" r="46" stroke="#e2e8f0" strokeWidth="10" fill="none" />
                  <circle
                    cx="56" cy="56" r="46"
                    stroke="currentColor" strokeWidth="10" fill="none"
                    strokeDasharray={`${2 * Math.PI * 46}`}
                    strokeDashoffset={`${2 * Math.PI * 46 * (1 - stats.readiness / 100)}`}
                    className={readinessStroke}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className={`text-2xl font-bold ${readinessColor}`}>{stats.readiness}%</span>
                </div>
              </div>
              <div className="flex-1 w-full">
                <h3 className="text-base font-semibold text-slate-900 mb-3">Audit Readiness</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { label: "Compliant", val: stats.compliant, color: "text-emerald-700 bg-emerald-50" },
                    { label: "Non-Compliant", val: stats.nonCompliant, color: "text-red-700 bg-red-50" },
                    { label: "Partial", val: stats.partial, color: "text-amber-700 bg-amber-50" },
                    { label: "Overdue", val: stats.overdue, color: "text-orange-700 bg-orange-50" },
                    { label: "In Progress", val: stats.inProgress, color: "text-blue-700 bg-blue-50" },
                    { label: "Not Started", val: stats.notStarted, color: "text-slate-700 bg-slate-100" },
                    { label: "Missing Evidence", val: stats.missingEvidence, color: "text-purple-700 bg-purple-50" },
                    { label: "Open Actions", val: stats.openActions, color: "text-indigo-700 bg-indigo-50" },
                  ].map(s => (
                    <div key={s.label} className={`rounded-lg px-3 py-2 ${s.color}`}>
                      <div className="text-xl font-bold">{s.val}</div>
                      <div className="text-xs font-medium">{s.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="nonconformances">
          <TabsList className="mb-6 bg-white border border-slate-200 h-auto flex-wrap">
            <TabsTrigger value="nonconformances" className="gap-1.5">
              <XCircle className="w-3.5 h-3.5" />
              Non-Conformances
              {stats.nonCompliant + stats.partial > 0 && (
                <Badge className="bg-red-100 text-red-700 ml-1 text-[10px] px-1 py-0">{stats.nonCompliant + stats.partial}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="actions" className="gap-1.5">
              <Activity className="w-3.5 h-3.5" />
              Open Actions
              {openActions.length > 0 && (
                <Badge className="bg-blue-100 text-blue-700 ml-1 text-[10px] px-1 py-0">{openActions.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="checklist" className="gap-1.5">
              <ClipboardList className="w-3.5 h-3.5" />
              Gap Analysis
            </TabsTrigger>
            <TabsTrigger value="documents" className="gap-1.5">
              <FileText className="w-3.5 h-3.5" />
              Documents
              {expiringDocs.length > 0 && (
                <Badge className="bg-amber-100 text-amber-700 ml-1 text-[10px] px-1 py-0">{expiringDocs.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          {/* NON-CONFORMANCES */}
          <TabsContent value="nonconformances">
            <div className="space-y-3">
              {nonConformances.length === 0 ? (
                <Card className="border-0 shadow-sm">
                  <CardContent className="py-12 text-center">
                    <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                    <p className="text-slate-600 font-medium">No non-conformances found!</p>
                    <p className="text-slate-400 text-sm">All requirements are compliant or in progress.</p>
                  </CardContent>
                </Card>
              ) : (
                <>
                  <p className="text-xs text-slate-500 mb-2">{nonConformances.length} items requiring attention before external audit</p>
                  {nonConformances.sort((a, b) => {
                    const order = { critical: 0, high: 1, medium: 2, low: 3 };
                    return (order[a.priority] ?? 2) - (order[b.priority] ?? 2);
                  }).map(r => (
                    <Link key={r.id} to={createPageUrl("RequirementDetail") + `?id=${r.id}`}>
                      <Card className="border-0 shadow-sm hover:shadow-md transition-all cursor-pointer">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <span className="text-xs font-mono font-bold text-slate-400 mt-0.5 shrink-0 w-10">{r.clause_number}</span>
                            <div className="flex-1 min-w-0">
                              <div className="flex flex-wrap items-center gap-2 mb-1">
                                <span className="text-sm font-semibold text-slate-800 truncate">{r.clause_title}</span>
                                <Badge className={STATUS_CONFIG[r.status]?.color || ""}>{STATUS_CONFIG[r.status]?.label}</Badge>
                                {r.priority && <Badge className={PRIORITY_CONFIG[r.priority] || ""}>{r.priority}</Badge>}
                              </div>
                              <p className="text-xs text-slate-500 truncate">{r.section}</p>
                              {r.findings && (
                                <p className="text-xs text-slate-600 mt-1 line-clamp-2">
                                  <span className="font-medium">Finding:</span> {r.findings}
                                </p>
                              )}
                              {r.corrective_actions && (
                                <p className="text-xs text-slate-600 mt-0.5 line-clamp-2">
                                  <span className="font-medium">Action:</span> {r.corrective_actions}
                                </p>
                              )}
                              <div className="flex items-center gap-3 mt-2">
                                {r.completion_percentage > 0 && (
                                  <div className="flex items-center gap-1.5">
                                    <div className="w-20 bg-slate-200 rounded-full h-1.5">
                                      <div className="bg-amber-500 h-1.5 rounded-full" style={{ width: `${r.completion_percentage}%` }} />
                                    </div>
                                    <span className="text-[10px] text-slate-500">{r.completion_percentage}%</span>
                                  </div>
                                )}
                                {r.due_date && (
                                  <span className={`text-[10px] ${new Date(r.due_date) < new Date() ? 'text-red-500 font-medium' : 'text-slate-400'}`}>
                                    Due: {r.due_date}
                                  </span>
                                )}
                                {r.assigned_to && (
                                  <span className="text-[10px] text-slate-400">→ {r.assigned_to}</span>
                                )}
                              </div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-slate-300 shrink-0 mt-1" />
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </>
              )}
            </div>
          </TabsContent>

          {/* OPEN ACTIONS */}
          <TabsContent value="actions">
            <div className="space-y-3">
              {openActions.length === 0 ? (
                <Card className="border-0 shadow-sm">
                  <CardContent className="py-12 text-center">
                    <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                    <p className="text-slate-600 font-medium">No open actions!</p>
                  </CardContent>
                </Card>
              ) : (
                <>
                  <p className="text-xs text-slate-500 mb-2">{openActions.length} actions pending before external audit</p>
                  {openActions.sort((a, b) => {
                    const order = { critical: 0, high: 1, medium: 2, low: 3 };
                    return (order[a.priority] ?? 2) - (order[b.priority] ?? 2);
                  }).map(a => (
                    <Card key={a.id} className="border-0 shadow-sm">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex flex-wrap items-center gap-2 mb-1">
                              <span className="text-sm font-semibold text-slate-800">{a.title}</span>
                              {a.priority && <Badge className={PRIORITY_CONFIG[a.priority] || ""}>{a.priority}</Badge>}
                              <Badge className={a.status === 'blocked' ? 'bg-red-100 text-red-700' : a.status === 'in_progress' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'}>
                                {a.status}
                              </Badge>
                            </div>
                            {a.description && <p className="text-xs text-slate-500 line-clamp-2">{a.description}</p>}
                            <div className="flex items-center gap-3 mt-2">
                              {a.source_type && <span className="text-[10px] text-slate-400">Source: {a.source_type.replace(/_/g, ' ')}</span>}
                              {a.due_date && <span className={`text-[10px] ${new Date(a.due_date) < new Date() ? 'text-red-500 font-medium' : 'text-slate-400'}`}>Due: {a.due_date}</span>}
                              {a.assigned_to && <span className="text-[10px] text-slate-400">→ {a.assigned_to}</span>}
                            </div>
                            {a.progress_notes && (
                              <p className="text-xs text-slate-600 mt-1 italic">{a.progress_notes}</p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </>
              )}
            </div>
          </TabsContent>

          {/* GAP ANALYSIS CHECKLIST */}
          <TabsContent value="checklist">
            <div className="space-y-4">
              {bySection.map(s => {
                const barColor = s.pct >= 80 ? "bg-emerald-500" : s.pct >= 50 ? "bg-amber-500" : "bg-red-500";
                const hasGaps = s.nc > 0 || s.partial > 0;
                return (
                  <Card key={s.section} className={`border-0 shadow-sm ${hasGaps ? 'border-l-4 border-l-red-400' : ''}`}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm font-semibold text-slate-800">{s.section}</CardTitle>
                        <div className="flex items-center gap-2">
                          {s.nc > 0 && <Badge className="bg-red-100 text-red-700 text-xs">{s.nc} NC</Badge>}
                          {s.partial > 0 && <Badge className="bg-amber-100 text-amber-700 text-xs">{s.partial} Partial</Badge>}
                          <span className={`text-sm font-bold ${s.pct >= 80 ? 'text-emerald-600' : s.pct >= 50 ? 'text-amber-600' : 'text-red-600'}`}>
                            {s.pct}%
                          </span>
                        </div>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2">
                        <div className={`h-1.5 rounded-full ${barColor}`} style={{ width: `${s.pct}%` }} />
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-1.5">
                        {s.reqs.sort((a, b) => (a.clause_number || "").localeCompare(b.clause_number || "")).map(r => {
                          const sc = STATUS_CONFIG[r.status] || STATUS_CONFIG.not_started;
                          return (
                            <Link key={r.id} to={createPageUrl("RequirementDetail") + `?id=${r.id}`}
                              className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 transition-colors group">
                              <span className="text-[10px] font-mono text-slate-400 w-8 shrink-0">{r.clause_number}</span>
                              <span className="text-xs text-slate-700 flex-1 truncate">{r.clause_title}</span>
                              <div className={`w-2 h-2 rounded-full shrink-0 ${sc.dot}`} />
                              <span className={`text-[10px] px-1.5 py-0.5 rounded-full shrink-0 ${sc.color}`}>{sc.label}</span>
                              {r.evidence_files?.length > 0 && (
                                <FileText className="w-3 h-3 text-emerald-500 shrink-0" title="Evidence attached" />
                              )}
                            </Link>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
              {bySection.length === 0 && (
                <Card className="border-0 shadow-sm">
                  <CardContent className="py-12 text-center text-slate-400">
                    No requirements loaded yet.
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* DOCUMENTS */}
          <TabsContent value="documents">
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-slate-800">{documents.length}</div>
                    <div className="text-xs text-slate-500">Total Documents</div>
                  </CardContent>
                </Card>
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-amber-600">{expiringDocs.length}</div>
                    <div className="text-xs text-slate-500">Expiring (60 days)</div>
                  </CardContent>
                </Card>
                <Card className="border-0 shadow-sm">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-emerald-600">
                      {documents.filter(d => d.control_status === 'controlled').length}
                    </div>
                    <div className="text-xs text-slate-500">Controlled Docs</div>
                  </CardContent>
                </Card>
              </div>

              {expiringDocs.length > 0 && (
                <>
                  <h3 className="text-sm font-semibold text-amber-700 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" /> Documents Expiring Within 60 Days
                  </h3>
                  {expiringDocs.map(d => {
                    const days = Math.ceil((new Date(d.expiry_date) - new Date()) / 86400000);
                    return (
                      <Card key={d.id} className="border-0 shadow-sm border-l-4 border-l-amber-400">
                        <CardContent className="p-3">
                          <div className="flex items-center justify-between gap-2">
                            <div className="min-w-0">
                              <p className="text-sm font-medium text-slate-800 truncate">{d.title || d.file_name}</p>
                              <p className="text-xs text-slate-400">{d.category?.replace(/_/g, ' ')}</p>
                            </div>
                            <Badge className={days <= 7 ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}>
                              {days}d left
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </>
              )}

              <div className="mt-4 text-center">
                <Link to={createPageUrl("DocumentRepository")}>
                  <Button variant="outline" className="gap-2">
                    <Package className="w-4 h-4" />
                    View All Documents
                  </Button>
                </Link>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}