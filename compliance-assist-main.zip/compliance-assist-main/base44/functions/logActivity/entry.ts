import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const EXCLUDED_FIELDS = ['id', 'created_date', 'updated_date', 'created_by'];

function getFieldChanges(oldData, newData) {
  const changes = [];
  const allKeys = new Set([...Object.keys(oldData || {}), ...Object.keys(newData || {})]);
  for (const key of allKeys) {
    if (EXCLUDED_FIELDS.includes(key)) continue;
    const oldVal = oldData?.[key];
    const newVal = newData?.[key];
    if (JSON.stringify(oldVal) !== JSON.stringify(newVal)) {
      changes.push({ field: key, old_value: oldVal, new_value: newVal });
    }
  }
  return changes;
}

function trunc(val, len = 60) {
  if (val === null || val === undefined) return 'empty';
  if (typeof val === 'boolean') return val ? 'Yes' : 'No';
  if (Array.isArray(val)) return `[${val.length} item(s)]`;
  if (typeof val === 'object') return '[Object]';
  const s = String(val);
  return s.length > len ? s.substring(0, len) + '…' : s;
}

function buildEntry(event, data, old_data, userEmail, userName) {
  const { entity_name, entity_id, type: evtType } = event;
  let activity_type = 'system_event';
  let description = '';
  let entity_label = entity_id || '';
  let field_changes = [];
  let severity = 'low';

  // ── ComplianceRequirement ──────────────────────────────
  if (entity_name === 'ComplianceRequirement') {
    const label = data?.clause_number
      ? `${data.clause_number} – ${data.clause_title || ''}`
      : (old_data?.clause_number ? `${old_data.clause_number} – ${old_data.clause_title || ''}` : entity_id);
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'requirement_created';
      description = `Created requirement: ${label}`;
      severity = 'medium';
    } else if (evtType === 'delete') {
      activity_type = 'requirement_deleted';
      description = `Deleted requirement: ${label}`;
      severity = 'high';
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      if (old_data?.status !== data?.status) {
        activity_type = 'status_changed';
        description = `Status changed on ${label}: "${old_data?.status}" → "${data?.status}"`;
        severity = 'medium';
      } else {
        activity_type = 'requirement_updated';
        const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
        description = `Updated requirement ${label} (${fields || 'no changes'})`;
      }
    }

  // ── RiskAssessment ─────────────────────────────────────
  } else if (entity_name === 'RiskAssessment') {
    const label = (data?.hazard_description || old_data?.hazard_description || '').substring(0, 50) || entity_id;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'risk_added';
      description = `Added ${data?.hazard_type || ''} risk (${data?.risk_level || ''} level): ${label}`;
      severity = data?.risk_level === 'critical' ? 'critical' : data?.risk_level === 'high' ? 'high' : 'medium';
    } else if (evtType === 'delete') {
      activity_type = 'risk_deleted';
      description = `Deleted risk assessment: ${label}`;
      severity = 'high';
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      if (old_data?.workflow_status !== data?.workflow_status) {
        activity_type = 'risk_workflow_changed';
        description = `Risk workflow changed on "${label}": "${old_data?.workflow_status}" → "${data?.workflow_status}"`;
        severity = 'medium';
      } else if (old_data?.risk_level !== data?.risk_level) {
        activity_type = 'risk_updated';
        description = `Risk level changed on "${label}": ${old_data?.risk_level} → ${data?.risk_level}`;
        severity = data?.risk_level === 'critical' ? 'critical' : 'medium';
      } else {
        activity_type = 'risk_updated';
        const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
        description = `Updated risk assessment "${label}" (${fields || 'no changes'})`;
      }
    }

  // ── Document ───────────────────────────────────────────
  } else if (entity_name === 'Document') {
    const label = data?.file_name || old_data?.file_name || entity_id;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'document_uploaded';
      description = `Uploaded document: "${label}"`;
      severity = 'low';
    } else if (evtType === 'delete') {
      activity_type = 'document_deleted';
      description = `Deleted document: "${label}"`;
      severity = 'high';
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      activity_type = 'document_updated';
      const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
      description = `Updated document "${label}" (${fields || 'no changes'})`;
    }

  // ── DocumentRevision ──────────────────────────────────
  } else if (entity_name === 'DocumentRevision') {
    const label = `v${data?.version || '?'}`;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'document_version_added';
      description = `Added document revision ${label}`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      activity_type = 'document_updated';
      description = `Updated document revision ${label}`;
    }

  // ── ActionItem ─────────────────────────────────────────
  } else if (entity_name === 'ActionItem') {
    const label = data?.title || old_data?.title || entity_id;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'action_item_created';
      description = `Created action item: "${label}"`;
      severity = data?.priority === 'critical' ? 'high' : 'low';
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      if (data?.status === 'completed' && old_data?.status !== 'completed') {
        activity_type = 'action_item_completed';
        description = `Completed action item: "${label}"`;
      } else {
        activity_type = 'action_item_updated';
        const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
        description = `Updated action item "${label}" (${fields || 'no changes'})`;
      }
    } else if (evtType === 'delete') {
      activity_type = 'system_event';
      description = `Deleted action item: "${label}"`;
      severity = 'medium';
    }

  // ── RawMaterialBatch / FoodBatchRecord ─────────────────
  } else if (entity_name === 'RawMaterialBatch' || entity_name === 'FoodBatchRecord') {
    const label = data?.batch_number || old_data?.batch_number || entity_id;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'batch_created';
      description = `Created batch record: ${label}`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      activity_type = 'batch_updated';
      const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
      description = `Updated batch ${label} (${fields || 'no changes'})`;
    }

  // ── MonitoringLog ──────────────────────────────────────
  } else if (entity_name === 'MonitoringLog') {
    const label = `${data?.log_type?.replace(/_/g, ' ') || ''} – ${data?.log_date || ''}`;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'monitoring_log_added';
      description = `Monitoring log added: ${label}`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      activity_type = 'system_event';
      description = `Updated monitoring log: ${label}`;
    }

  // ── CleaningRegister ───────────────────────────────────
  } else if (entity_name === 'CleaningRegister') {
    const label = data?.area_name || entity_id;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'cleaning_task_completed';
      description = `Cleaning task completed: ${label}`;
    }

  // ── SupportTicket ──────────────────────────────────────
  } else if (entity_name === 'SupportTicket') {
    const label = data?.title || data?.subject || entity_id;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'support_ticket_created';
      description = `Support ticket created: "${label}"`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      activity_type = 'support_ticket_updated';
      const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
      description = `Support ticket updated: "${label}" (${fields || 'no changes'})`;
    }

  // ── Subscription ───────────────────────────────────────
  } else if (entity_name === 'Subscription') {
    const label = data?.plan_name || entity_id;
    entity_label = label;
    if (evtType === 'create') {
      activity_type = 'subscription_changed';
      description = `New subscription created: ${label}`;
      severity = 'medium';
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      activity_type = 'subscription_changed';
      if (old_data?.status !== data?.status) {
        description = `Subscription status changed for ${label}: "${old_data?.status}" → "${data?.status}"`;
        severity = data?.status === 'cancelled' ? 'high' : 'medium';
      } else {
        description = `Subscription updated: ${label}`;
      }
    }

  // ── Generic fallback ───────────────────────────────────
  } else {
    entity_label = entity_id || entity_name;
    if (evtType === 'create') {
      description = `Created ${entity_name}`;
    } else if (evtType === 'update') {
      field_changes = getFieldChanges(old_data, data);
      const fields = field_changes.map(c => c.field.replace(/_/g, ' ')).join(', ');
      description = `Updated ${entity_name} (${fields || 'no changes'})`;
    } else if (evtType === 'delete') {
      description = `Deleted ${entity_name}`;
      severity = 'medium';
    }
  }

  return {
    activity_type,
    entity_type: entity_name,
    entity_id,
    entity_label,
    description,
    field_changes: field_changes.length ? field_changes : undefined,
    metadata: {
      event_type: evtType,
      change_count: field_changes.length || undefined,
    },
    user_email: userEmail || data?.created_by || 'system',
    user_name: userName || undefined,
    severity,
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    const { event, data, old_data } = payload;

    if (!event?.entity_name) {
      return Response.json({ error: 'Missing event data' }, { status: 400 });
    }

    let userEmail = data?.created_by || data?.uploaded_by || 'system';
    let userName = undefined;
    try {
      const user = await base44.auth.me();
      if (user?.email) { userEmail = user.email; userName = user.full_name; }
    } catch (_) {}

    const entry = buildEntry(event, data, old_data, userEmail, userName);

    if (entry.activity_type) {
      await base44.asServiceRole.entities.ActivityLog.create(entry);
    }

    return Response.json({ success: true, logged: entry.activity_type });
  } catch (error) {
    console.error('logActivity error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});