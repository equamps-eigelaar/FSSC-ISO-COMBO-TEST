import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// ─── HTML Email Templates ─────────────────────────────────────────────────────

function baseTemplate(content) {
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<style>
  body{margin:0;padding:0;background:#f1f5f9;font-family:Arial,sans-serif;color:#1e293b}
  .wrap{max-width:600px;margin:32px auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08)}
  .header{background:#059669;padding:28px 32px;text-align:center}
  .header h1{color:#fff;margin:0;font-size:20px;font-weight:700}
  .header p{color:#d1fae5;margin:4px 0 0;font-size:13px}
  .body{padding:32px}
  .body h2{font-size:18px;font-weight:700;margin:0 0 8px}
  .body p{font-size:14px;line-height:1.6;color:#475569;margin:0 0 16px}
  .info-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px 20px;margin:20px 0}
  .info-row{display:flex;justify-content:space-between;padding:5px 0;font-size:13px;border-bottom:1px solid #f1f5f9}
  .info-row:last-child{border-bottom:none;font-weight:700;font-size:14px;padding-top:8px}
  .badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;margin-bottom:16px}
  .badge-success{background:#d1fae5;color:#065f46}
  .badge-warning{background:#fef3c7;color:#92400e}
  .badge-danger{background:#fee2e2;color:#991b1b}
  .btn{display:inline-block;background:#059669;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-size:14px;font-weight:600;margin:8px 0}
  .footer{background:#f8fafc;padding:20px 32px;text-align:center;font-size:12px;color:#94a3b8;border-top:1px solid #e2e8f0}
</style></head>
<body><div class="wrap">${content}</div></body></html>`;
}

function paymentConfirmationEmail({ planName, billingCycle, amount, currency, nextBillingDate, userEmail }) {
  return baseTemplate(`
    <div class="header">
      <h1>✓ Payment Confirmed</h1>
      <p>FSSC 22000 Compliance Tracker</p>
    </div>
    <div class="body">
      <div class="badge badge-success">Payment Successful</div>
      <h2>Thank you for your subscription!</h2>
      <p>Your payment has been processed and your subscription is now active. You have full access to the FSSC 22000 Compliance Tracker.</p>
      <div class="info-box">
        <div class="info-row"><span>Plan</span><span>${planName}</span></div>
        <div class="info-row"><span>Billing Cycle</span><span style="text-transform:capitalize">${billingCycle}</span></div>
        <div class="info-row"><span>Amount Charged</span><span>${currency} ${Number(amount).toLocaleString()}</span></div>
        ${nextBillingDate ? `<div class="info-row"><span>Next Billing Date</span><span>${nextBillingDate}</span></div>` : ''}
        <div class="info-row"><span>Account</span><span>${userEmail}</span></div>
      </div>
      <p>If you have any questions about your invoice, please contact your administrator.</p>
    </div>
    <div class="footer">© ${new Date().getFullYear()} FSSC 22000 Compliance Tracker · <a href="#" style="color:#059669">View Subscription</a></div>
  `);
}

function renewalReminderEmail({ planName, billingCycle, amount, currency, nextBillingDate, daysUntil, userEmail }) {
  return baseTemplate(`
    <div class="header">
      <h1>🔔 Renewal Reminder</h1>
      <p>FSSC 22000 Compliance Tracker</p>
    </div>
    <div class="body">
      <div class="badge badge-warning">Renewal in ${daysUntil} day${daysUntil !== 1 ? 's' : ''}</div>
      <h2>Your subscription renews soon</h2>
      <p>This is a friendly reminder that your ${planName} plan is due for renewal in <strong>${daysUntil} day${daysUntil !== 1 ? 's' : ''}</strong>. Please ensure your payment details are up to date.</p>
      <div class="info-box">
        <div class="info-row"><span>Plan</span><span>${planName}</span></div>
        <div class="info-row"><span>Billing Cycle</span><span style="text-transform:capitalize">${billingCycle}</span></div>
        <div class="info-row"><span>Renewal Date</span><span>${nextBillingDate}</span></div>
        <div class="info-row"><span>Amount Due</span><span>${currency} ${Number(amount).toLocaleString()}</span></div>
      </div>
      <p>No action is required if your billing is set up. You'll receive a payment confirmation once processed.</p>
    </div>
    <div class="footer">© ${new Date().getFullYear()} FSSC 22000 Compliance Tracker</div>
  `);
}

function trialExpiryEmail({ planName, trialEndDate, daysLeft, userEmail }) {
  const isExpired = daysLeft <= 0;
  return baseTemplate(`
    <div class="header" style="background:${isExpired ? '#dc2626' : '#d97706'}">
      <h1>${isExpired ? '⚠️ Trial Expired' : '⏰ Trial Ending Soon'}</h1>
      <p>FSSC 22000 Compliance Tracker</p>
    </div>
    <div class="body">
      <div class="badge ${isExpired ? 'badge-danger' : 'badge-warning'}">
        ${isExpired ? 'Trial Expired' : `${daysLeft} Day${daysLeft !== 1 ? 's' : ''} Remaining`}
      </div>
      <h2>${isExpired ? 'Your free trial has ended' : 'Your free trial is ending soon'}</h2>
      <p>
        ${isExpired
          ? `Your free trial for the <strong>${planName}</strong> plan expired on <strong>${trialEndDate}</strong>. To continue using the FSSC 22000 Compliance Tracker, please subscribe to a paid plan.`
          : `Your free trial for the <strong>${planName}</strong> plan ends on <strong>${trialEndDate}</strong>. Subscribe now to keep uninterrupted access to all compliance features.`
        }
      </p>
      <div class="info-box">
        <div class="info-row"><span>Plan</span><span>${planName}</span></div>
        <div class="info-row"><span>Trial End Date</span><span>${trialEndDate}</span></div>
        <div class="info-row"><span>Account</span><span>${userEmail}</span></div>
      </div>
      <p>Contact your administrator to upgrade your subscription and retain access to all your compliance data.</p>
    </div>
    <div class="footer">© ${new Date().getFullYear()} FSSC 22000 Compliance Tracker</div>
  `);
}

function cancellationEmail({ planName, cancelledDate, userEmail }) {
  return baseTemplate(`
    <div class="header" style="background:#64748b">
      <h1>Subscription Cancelled</h1>
      <p>FSSC 22000 Compliance Tracker</p>
    </div>
    <div class="body">
      <div class="badge" style="background:#f1f5f9;color:#475569">Subscription Cancelled</div>
      <h2>Your subscription has been cancelled</h2>
      <p>We've confirmed the cancellation of your <strong>${planName}</strong> subscription. You'll retain access until the end of your current billing period.</p>
      <div class="info-box">
        <div class="info-row"><span>Plan Cancelled</span><span>${planName}</span></div>
        <div class="info-row"><span>Cancellation Date</span><span>${cancelledDate}</span></div>
        <div class="info-row"><span>Account</span><span>${userEmail}</span></div>
      </div>
      <p>If this was a mistake or you'd like to reactivate, please contact your administrator.</p>
    </div>
    <div class="footer">© ${new Date().getFullYear()} FSSC 22000 Compliance Tracker</div>
  `);
}

// ─── Main Handler ─────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const { type } = body;

    // Called directly (e.g. from manageSubscription after payment)
    if (type === 'payment_confirmation') {
      const { to, planName, billingCycle, amount, currency, nextBillingDate } = body;
      await base44.asServiceRole.integrations.Core.SendEmail({
        to,
        subject: `✓ Payment Confirmed — ${planName} Plan`,
        body: paymentConfirmationEmail({ planName, billingCycle, amount, currency, nextBillingDate, userEmail: to }),
      });
      return Response.json({ success: true });
    }

    if (type === 'cancellation') {
      const { to, planName, cancelledDate } = body;
      await base44.asServiceRole.integrations.Core.SendEmail({
        to,
        subject: `Subscription Cancelled — ${planName}`,
        body: cancellationEmail({ planName, cancelledDate, userEmail: to }),
      });
      return Response.json({ success: true });
    }

    // Called by scheduler — checks all subscriptions and sends relevant emails
    if (type === 'daily_check') {
      const user = await base44.auth.me();
      if (user?.role !== 'admin') {
        return Response.json({ error: 'Forbidden' }, { status: 403 });
      }

      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];
      const allSubs = await base44.asServiceRole.entities.Subscription.list('-created_date', 500);

      let sent = 0;

      for (const sub of allSubs) {
        if (!sub.user_email) continue;

        // ── Trial expiry warnings: 3 days before, 1 day before, on expiry ──
        if ((sub.status === 'trialing' || sub.status === 'trial_expired') && sub.trial_end_date) {
          const trialEnd = new Date(sub.trial_end_date);
          const daysLeft = Math.ceil((trialEnd - today) / 86400000);

          if ([3, 1, 0, -1].includes(daysLeft)) {
            const subject = daysLeft <= 0
              ? `⚠️ Your free trial has expired`
              : `⏰ Your free trial ends in ${daysLeft} day${daysLeft !== 1 ? 's' : ''}`;

            await base44.asServiceRole.integrations.Core.SendEmail({
              to: sub.user_email,
              subject,
              body: trialExpiryEmail({
                planName: sub.plan_name || 'Compliance',
                trialEndDate: sub.trial_end_date,
                daysLeft: Math.max(daysLeft, 0),
                userEmail: sub.user_email,
              }),
            });

            // Also create in-app notification
            await base44.asServiceRole.entities.Notification.create({
              recipient_email: sub.user_email,
              title: subject,
              message: daysLeft <= 0
                ? 'Your free trial has expired. Subscribe to continue.'
                : `Your free trial ends in ${daysLeft} day${daysLeft !== 1 ? 's' : ''}.`,
              type: 'compliance_alert',
              is_read: false,
              priority: daysLeft <= 1 ? 'high' : 'normal',
            });

            sent++;
          }
        }

        // ── Renewal reminders: 7 days and 1 day before next billing ──
        if (sub.status === 'active' && sub.next_billing_date) {
          const billingDate = new Date(sub.next_billing_date);
          const daysUntil = Math.ceil((billingDate - today) / 86400000);

          if ([7, 1].includes(daysUntil)) {
            await base44.asServiceRole.integrations.Core.SendEmail({
              to: sub.user_email,
              subject: `🔔 Subscription renewal in ${daysUntil} day${daysUntil !== 1 ? 's' : ''} — ${sub.plan_name}`,
              body: renewalReminderEmail({
                planName: sub.plan_name || 'Compliance',
                billingCycle: sub.billing_cycle || 'monthly',
                amount: sub.amount || 0,
                currency: sub.currency || 'ZAR',
                nextBillingDate: sub.next_billing_date,
                daysUntil,
                userEmail: sub.user_email,
              }),
            });

            await base44.asServiceRole.entities.Notification.create({
              recipient_email: sub.user_email,
              title: `Renewal reminder: ${sub.plan_name}`,
              message: `Your subscription renews in ${daysUntil} day${daysUntil !== 1 ? 's' : ''} on ${sub.next_billing_date}.`,
              type: 'due_soon',
              is_read: false,
              priority: daysUntil === 1 ? 'high' : 'normal',
            });

            sent++;
          }
        }
      }

      return Response.json({ success: true, emailsSent: sent, checked: allSubs.length });
    }

    return Response.json({ error: 'Unknown notification type' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});