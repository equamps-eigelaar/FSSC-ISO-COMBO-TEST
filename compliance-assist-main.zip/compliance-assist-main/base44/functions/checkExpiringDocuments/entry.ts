import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const now = new Date();
    const warningThreshold = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    const allDocuments = await base44.asServiceRole.entities.Document.list();
    const expiringDocs = allDocuments.filter(doc => {
      if (!doc.expiry_date) return false;
      const expiryDate = new Date(doc.expiry_date);
      return expiryDate <= warningThreshold && expiryDate >= now;
    });

    const allUsers = await base44.asServiceRole.entities.User.list();
    const preferences = await base44.asServiceRole.entities.NotificationPreference.list();

    let notificationsSent = 0;

    for (const doc of expiringDocs) {
      const daysUntilExpiry = Math.ceil((new Date(doc.expiry_date) - now) / (1000 * 60 * 60 * 24));
      
      for (const user of allUsers) {
        const userPref = preferences.find(p => p.user_email === user.email);
        if (userPref && userPref.expiring_documents === false) continue;

        const existingNotifications = await base44.asServiceRole.entities.Notification.filter({
          recipient_email: user.email,
          entity_type: 'Document',
          entity_id: doc.id,
          type: 'expiring_document'
        });

        const recentNotification = existingNotifications.find(n => {
          const notifDate = new Date(n.created_date);
          const daysSinceNotif = (now - notifDate) / (1000 * 60 * 60 * 24);
          return daysSinceNotif < 7;
        });

        if (recentNotification) continue;

        await base44.asServiceRole.entities.Notification.create({
          recipient_email: user.email,
          title: `Document Expiring in ${daysUntilExpiry} days`,
          message: `Document "${doc.file_name}" (${doc.document_type}) expires on ${new Date(doc.expiry_date).toLocaleDateString()}`,
          type: 'expiring_document',
          entity_type: 'Document',
          entity_id: doc.id,
          is_read: false
        });

        notificationsSent++;
      }
    }

    return Response.json({
      success: true,
      expiring_documents: expiringDocs.length,
      notifications_sent: notificationsSent
    });
  } catch (error) {
    console.error('Error checking expiring documents:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});