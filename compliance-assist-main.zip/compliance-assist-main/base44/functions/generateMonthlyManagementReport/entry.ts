import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import { jsPDF } from 'npm:jspdf@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Allow both authenticated users and scheduled automation (service role)
    let callerName = 'Automated System';
    try {
      const user = await base44.auth.me();
      if (user) callerName = user.full_name || user.email;
    } catch (_) { /* scheduled run – no user */ }

    // Determine report month (default: previous calendar month)
    let body = {};
    try { body = await req.clone().json(); } catch (_) {}
    const now = new Date();
    const reportMonth = body.month ?? (now.getMonth() === 0 ? 12 : now.getMonth());
    const reportYear = body.year ?? (now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear());
    const monthName = new Date(reportYear, reportMonth - 1, 1).toLocaleString('default', { month: 'long' });
    const periodLabel = `${monthName} ${reportYear}`;

    const monthStart = new Date(reportYear, reportMonth - 1, 1);
    const monthEnd = new Date(reportYear, reportMonth, 0, 23, 59, 59);

    // --- Fetch all data in parallel ---
    const [requirements, risks, monitoringLogs, actionItems, users] = await Promise.all([
      base44.asServiceRole.entities.ComplianceRequirement.list('-created_date', 500),
      base44.asServiceRole.entities.RiskAssessment.list('-created_date', 500),
      base44.asServiceRole.entities.MonitoringLog.list('-created_date', 500),
      base44.asServiceRole.entities.ActionItem.list('-created_date', 200),
      base44.asServiceRole.entities.User.list(),
    ]);

    // Filter monitoring logs to the report month
    const monthlyLogs = monitoringLogs.filter(l => {
      const d = new Date(l.created_date);
      return d >= monthStart && d <= monthEnd;
    });

    // Compliance stats
    const nonCompliant = requirements.filter(r => r.status === 'non_compliant');
    const inProgress = requirements.filter(r => r.status === 'in_progress');
    const compliant = requirements.filter(r => r.status === 'compliant');
    const notStarted = requirements.filter(r => r.status === 'not_started');
    const overdue = requirements.filter(r => r.due_date && new Date(r.due_date) < now && r.status !== 'compliant');
    const complianceRate = requirements.length ? Math.round((compliant.length / requirements.length) * 100) : 0;

    // Risk stats
    const criticalRisks = risks.filter(r => r.risk_level === 'critical');
    const highRisks = risks.filter(r => r.risk_level === 'high');
    const unresolvedHighRisks = [...criticalRisks, ...highRisks].filter(r => r.status !== 'under_control');

    // Action items
    const openActions = actionItems.filter(a => a.status !== 'completed');
    const overdueActions = openActions.filter(a => a.due_date && new Date(a.due_date) < now);

    // Monitoring log summary by type
    const logsByType = {};
    for (const log of monthlyLogs) {
      const key = log.log_type || 'general';
      logsByType[key] = (logsByType[key] || 0) + 1;
    }

    // --- Build PDF ---
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const pageW = 210;
    const margin = 18;
    const contentW = pageW - margin * 2;
    let y = 0;

    const addPage = () => { doc.addPage(); y = 20; };
    const checkPage = (needed = 20) => { if (y + needed > 275) addPage(); };

    // ── Cover Page ──
    doc.setFillColor(16, 185, 129); // emerald-500
    doc.rect(0, 0, pageW, 60, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.setFont(undefined, 'bold');
    doc.text('Monthly Compliance Report', margin, 28);
    doc.setFontSize(14);
    doc.setFont(undefined, 'normal');
    doc.text(`Period: ${periodLabel}`, margin, 38);
    doc.setFontSize(10);
    doc.text(`Package Manufacturing Compliance Tracker`, margin, 50);

    y = 72;
    doc.setTextColor(71, 85, 105); // slate-600
    doc.setFontSize(9);
    doc.text(`Generated: ${now.toLocaleString()}  |  Prepared by: ${callerName}`, margin, y);

    // ── Executive Summary Box ──
    y += 10;
    doc.setFillColor(240, 253, 244); // green-50
    doc.setDrawColor(16, 185, 129);
    doc.roundedRect(margin, y, contentW, 40, 3, 3, 'FD');
    y += 7;
    doc.setTextColor(15, 118, 110);
    doc.setFontSize(12);
    doc.setFont(undefined, 'bold');
    doc.text('Executive Summary', margin + 4, y);
    y += 6;
    doc.setFont(undefined, 'normal');
    doc.setFontSize(9);
    doc.setTextColor(30, 41, 59);

    const summaryLines = [
      `Overall Compliance Rate: ${complianceRate}%  (${compliant.length} of ${requirements.length} requirements compliant)`,
      `Non-Compliant Requirements: ${nonCompliant.length}  |  Overdue: ${overdue.length}`,
      `High/Critical Risks Unresolved: ${unresolvedHighRisks.length}  |  Open Action Items: ${openActions.length}`,
      `Monitoring Logs Recorded (${periodLabel}): ${monthlyLogs.length}`,
    ];
    for (const line of summaryLines) {
      doc.text(line, margin + 4, y);
      y += 6;
    }

    // ── Section helper ──
    const sectionHeader = (title, color = [16, 185, 129]) => {
      checkPage(14);
      y += 4;
      doc.setFillColor(...color);
      doc.rect(margin, y, contentW, 8, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(11);
      doc.setFont(undefined, 'bold');
      doc.text(title, margin + 3, y + 5.5);
      doc.setTextColor(30, 41, 59);
      doc.setFont(undefined, 'normal');
      y += 12;
    };

    const dataRow = (label, value, shade = false) => {
      checkPage(8);
      if (shade) {
        doc.setFillColor(248, 250, 252);
        doc.rect(margin, y - 2, contentW, 7, 'F');
      }
      doc.setFontSize(9);
      doc.setFont(undefined, 'bold');
      doc.text(label, margin + 2, y + 3);
      doc.setFont(undefined, 'normal');
      const valLines = doc.splitTextToSize(String(value), contentW - 55);
      doc.text(valLines, margin + 52, y + 3);
      y += Math.max(7, valLines.length * 4.5);
    };

    // ── 1. Compliance Requirements Summary ──
    sectionHeader('1. Compliance Requirements Summary');
    dataRow('Total Requirements', requirements.length, false);
    dataRow('Compliant', `${compliant.length} (${complianceRate}%)`, true);
    dataRow('In Progress', inProgress.length, false);
    dataRow('Non-Compliant', nonCompliant.length, true);
    dataRow('Not Started', notStarted.length, false);
    dataRow('Overdue', overdue.length, true);

    // ── 2. Non-Compliant Requirements Detail ──
    if (nonCompliant.length > 0) {
      sectionHeader('2. Open Non-Compliant Requirements', [239, 68, 68]);
      for (const req of nonCompliant.slice(0, 20)) {
        checkPage(18);
        doc.setFontSize(9);
        doc.setFont(undefined, 'bold');
        doc.text(`${req.clause_number} – ${req.clause_title}`, margin + 2, y);
        y += 5;
        doc.setFont(undefined, 'normal');
        doc.setTextColor(100, 116, 139);
        doc.text(`Section: ${req.section || '—'}  |  Priority: ${req.priority || '—'}  |  Due: ${req.due_date || 'Not set'}  |  Assigned: ${req.assigned_to || req.responsible_person || 'Unassigned'}`, margin + 2, y);
        y += 4;
        if (req.findings) {
          const lines = doc.splitTextToSize(`Findings: ${req.findings}`, contentW - 4);
          doc.text(lines.slice(0, 3), margin + 2, y);
          y += lines.slice(0, 3).length * 4;
        }
        if (req.corrective_actions) {
          const lines = doc.splitTextToSize(`Corrective Actions: ${req.corrective_actions}`, contentW - 4);
          doc.text(lines.slice(0, 2), margin + 2, y);
          y += lines.slice(0, 2).length * 4;
        }
        doc.setTextColor(30, 41, 59);
        doc.setDrawColor(226, 232, 240);
        doc.line(margin, y + 1, margin + contentW, y + 1);
        y += 5;
      }
      if (nonCompliant.length > 20) {
        doc.setFontSize(8);
        doc.setTextColor(100, 116, 139);
        doc.text(`… and ${nonCompliant.length - 20} more non-compliant requirements (see full tracker).`, margin + 2, y);
        y += 6;
        doc.setTextColor(30, 41, 59);
      }
    }

    // ── 3. Monthly Monitoring Logs ──
    checkPage(30);
    sectionHeader('3. Monitoring Logs Summary', [59, 130, 246]);
    dataRow('Total Logs This Month', monthlyLogs.length, false);
    let shade = true;
    for (const [type, count] of Object.entries(logsByType)) {
      dataRow(type.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()), count, shade);
      shade = !shade;
    }
    if (monthlyLogs.length === 0) {
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text('No monitoring logs recorded in this period.', margin + 2, y);
      y += 6;
      doc.setTextColor(30, 41, 59);
    }

    // ── 4. High & Critical Risk Findings ──
    sectionHeader('4. High & Critical Risk Assessment Findings', [245, 158, 11]);
    if (unresolvedHighRisks.length === 0) {
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text('No unresolved high or critical risks at this time.', margin + 2, y);
      y += 6;
      doc.setTextColor(30, 41, 59);
    } else {
      for (const risk of unresolvedHighRisks.slice(0, 15)) {
        checkPage(20);
        const levelColor = risk.risk_level === 'critical' ? [244, 63, 94] : [249, 115, 22];
        doc.setFillColor(...levelColor);
        doc.rect(margin, y - 1, 2, 10, 'F');
        doc.setFont(undefined, 'bold');
        doc.setFontSize(9);
        doc.text(`[${(risk.risk_level || '').toUpperCase()}] ${(risk.hazard_type || '').toUpperCase()} Hazard`, margin + 5, y + 3);
        y += 6;
        doc.setFont(undefined, 'normal');
        doc.setTextColor(100, 116, 139);
        const descLines = doc.splitTextToSize(risk.hazard_description || '—', contentW - 6);
        doc.text(descLines.slice(0, 2), margin + 5, y);
        y += descLines.slice(0, 2).length * 4 + 2;
        doc.text(`Likelihood: ${risk.likelihood || '—'}  |  Severity: ${risk.severity || '—'}  |  Status: ${(risk.status || '—').replace(/_/g, ' ')}  |  CCP: ${risk.is_ccp ? 'Yes' : 'No'}`, margin + 5, y);
        y += 4;
        if (risk.mitigation_strategy) {
          const mLines = doc.splitTextToSize(`Mitigation: ${risk.mitigation_strategy}`, contentW - 6);
          doc.text(mLines.slice(0, 2), margin + 5, y);
          y += mLines.slice(0, 2).length * 4;
        }
        doc.setTextColor(30, 41, 59);
        doc.setDrawColor(226, 232, 240);
        doc.line(margin, y + 1, margin + contentW, y + 1);
        y += 5;
      }
    }

    // ── 5. Open Action Items ──
    checkPage(20);
    sectionHeader('5. Open Action Items', [99, 102, 241]);
    dataRow('Total Open', openActions.length, false);
    dataRow('Overdue', overdueActions.length, true);
    const critActions = openActions.filter(a => a.priority === 'critical' || a.priority === 'high');
    dataRow('High/Critical Priority', critActions.length, false);

    if (critActions.length > 0) {
      y += 3;
      doc.setFontSize(9);
      doc.setFont(undefined, 'bold');
      doc.text('Critical & High Priority Actions:', margin + 2, y);
      y += 5;
      doc.setFont(undefined, 'normal');
      for (const action of critActions.slice(0, 10)) {
        checkPage(10);
        doc.setFontSize(8);
        doc.setTextColor(100, 116, 139);
        const aLines = doc.splitTextToSize(`• ${action.title}  [${(action.priority || '').toUpperCase()}] Due: ${action.due_date || 'N/A'} | Assigned: ${action.assigned_to || 'Unassigned'}`, contentW - 4);
        doc.text(aLines, margin + 4, y);
        y += aLines.length * 4 + 2;
      }
      doc.setTextColor(30, 41, 59);
    }

    // ── 6. Recommendations ──
    checkPage(30);
    sectionHeader('6. Management Recommendations', [16, 185, 129]);
    const recommendations = [];
    if (nonCompliant.length > 0) recommendations.push(`Address ${nonCompliant.length} non-compliant requirement(s) — prioritise any with an assigned due date.`);
    if (overdue.length > 0) recommendations.push(`Immediately review ${overdue.length} overdue requirement(s) and update corrective action plans.`);
    if (criticalRisks.length > 0) recommendations.push(`${criticalRisks.length} CRITICAL risk(s) require urgent management review and mitigation verification.`);
    if (overdueActions.length > 0) recommendations.push(`Escalate ${overdueActions.length} overdue action item(s) to responsible owners.`);
    if (monthlyLogs.length === 0) recommendations.push('No monitoring logs were recorded this period — ensure monitoring activities are being captured.');
    if (complianceRate < 70) recommendations.push(`Compliance rate of ${complianceRate}% is below the 70% threshold. A compliance improvement plan is recommended.`);
    if (recommendations.length === 0) recommendations.push('Overall compliance posture is satisfactory. Continue maintaining current standards and monitoring cadence.');

    doc.setFontSize(9);
    for (const rec of recommendations) {
      checkPage(10);
      const lines = doc.splitTextToSize(`• ${rec}`, contentW - 4);
      doc.text(lines, margin + 2, y);
      y += lines.length * 5 + 2;
    }

    // ── Footer on all pages ──
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text(`Package Manufacturing Compliance Tracker  |  Monthly Report – ${periodLabel}  |  Page ${i} of ${totalPages}`, margin, 290);
    }

    // ── Upload PDF to storage & notify admins ──
    const pdfBytes = doc.output('arraybuffer');
    const uint8 = new Uint8Array(pdfBytes);
    const blob = new Blob([uint8], { type: 'application/pdf' });
    const formData = new FormData();
    formData.append('file', blob, `compliance-report-${reportYear}-${String(reportMonth).padStart(2,'0')}.pdf`);

    const { file_url } = await base44.asServiceRole.integrations.Core.UploadFile({ file: blob });

    // Save report record
    await base44.asServiceRole.entities.ComplianceReport.create({
      report_name: `Monthly Compliance Report – ${periodLabel}`,
      report_type: 'monthly_management',
      file_url,
      period: periodLabel,
      generated_by: callerName,
      summary: {
        compliance_rate: complianceRate,
        non_compliant: nonCompliant.length,
        overdue: overdue.length,
        high_critical_risks: unresolvedHighRisks.length,
        monitoring_logs: monthlyLogs.length,
        open_actions: openActions.length,
      },
    });

    // Email all admins
    const adminEmails = users.filter(u => u.role === 'admin').map(u => u.email);
    for (const email of adminEmails) {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject: `📊 Monthly Compliance Report Ready – ${periodLabel}`,
        body: `
<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#f8fafc;padding:24px;border-radius:12px;">
  <div style="background:#10b981;padding:20px;border-radius:8px;margin-bottom:20px;">
    <h2 style="color:white;margin:0;">Monthly Compliance Report</h2>
    <p style="color:#d1fae5;margin:4px 0 0;">${periodLabel}</p>
  </div>
  <table style="width:100%;border-collapse:collapse;background:white;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.1);margin-bottom:20px;">
    <tr style="background:#f1f5f9;"><td style="padding:10px 16px;font-size:12px;font-weight:bold;color:#64748b;width:55%;">COMPLIANCE RATE</td><td style="padding:10px 16px;font-size:13px;color:#10b981;font-weight:bold;">${complianceRate}%</td></tr>
    <tr><td style="padding:10px 16px;font-size:12px;font-weight:bold;color:#64748b;">NON-COMPLIANT REQUIREMENTS</td><td style="padding:10px 16px;font-size:13px;color:#ef4444;font-weight:bold;">${nonCompliant.length}</td></tr>
    <tr style="background:#f1f5f9;"><td style="padding:10px 16px;font-size:12px;font-weight:bold;color:#64748b;">OVERDUE REQUIREMENTS</td><td style="padding:10px 16px;font-size:13px;color:#f97316;">${overdue.length}</td></tr>
    <tr><td style="padding:10px 16px;font-size:12px;font-weight:bold;color:#64748b;">HIGH/CRITICAL UNRESOLVED RISKS</td><td style="padding:10px 16px;font-size:13px;color:#f43f5e;font-weight:bold;">${unresolvedHighRisks.length}</td></tr>
    <tr style="background:#f1f5f9;"><td style="padding:10px 16px;font-size:12px;font-weight:bold;color:#64748b;">MONITORING LOGS (MONTH)</td><td style="padding:10px 16px;font-size:13px;color:#1e293b;">${monthlyLogs.length}</td></tr>
    <tr><td style="padding:10px 16px;font-size:12px;font-weight:bold;color:#64748b;">OPEN ACTION ITEMS</td><td style="padding:10px 16px;font-size:13px;color:#1e293b;">${openActions.length}</td></tr>
  </table>
  <p style="font-size:13px;color:#475569;">The full PDF report has been saved to the Compliance Reports section. Log in to view or download it.</p>
  <p style="font-size:11px;color:#94a3b8;margin-top:16px;">Package Manufacturing Compliance Tracker · Monthly Report Notification</p>
</div>`,
        from_name: 'Compliance Tracker',
      });
    }

    return Response.json({
      success: true,
      period: periodLabel,
      file_url,
      stats: { complianceRate, nonCompliant: nonCompliant.length, overdue: overdue.length, unresolvedHighRisks: unresolvedHighRisks.length, monthlyLogs: monthlyLogs.length },
    });

  } catch (error) {
    console.error('generateMonthlyManagementReport error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});