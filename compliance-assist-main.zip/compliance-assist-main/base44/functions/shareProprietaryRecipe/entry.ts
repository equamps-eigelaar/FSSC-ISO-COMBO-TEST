import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if user is admin or auditor
    if (user.role !== 'admin' && user.role !== 'auditor' && user.role !== 'quality_auditor') {
      return Response.json(
        { error: 'Forbidden: Only admins and auditors can share proprietary recipes' },
        { status: 403 }
      );
    }

    const { recipeId, recipientEmail, accessLevel, shareType, tokenExpiry } = await req.json();

    if (!recipeId || !recipientEmail) {
      return Response.json(
        { error: 'Missing required fields: recipeId, recipientEmail' },
        { status: 400 }
      );
    }

    // Fetch the recipe
    const recipe = await base44.asServiceRole.entities.ProprietaryRecipeShare.get(recipeId);
    if (!recipe) {
      return Response.json({ error: 'Recipe not found' }, { status: 404 });
    }

    // Generate external token if needed
    let accessToken = null;
    let tokenExpiryDate = null;
    if (shareType === 'external') {
      accessToken = Math.random().toString(36).substring(2, 15) + 
                    Math.random().toString(36).substring(2, 15);
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + (tokenExpiry || 30));
      tokenExpiryDate = expiryDate.toISOString().split('T')[0];
    }

    // Add recipient to the recipients list
    const recipients = recipe.recipients || [];
    recipients.push({
      email: recipientEmail,
      name: recipientEmail.split('@')[0],
      type: shareType,
      access_level: accessLevel,
      shared_date: new Date().toISOString(),
    });

    // Update recipe with new recipient and token
    const updateData = { recipients };
    if (accessToken) {
      updateData.access_token = accessToken;
      updateData.token_expiry = tokenExpiryDate;
    }

    const updatedRecipe = await base44.asServiceRole.entities.ProprietaryRecipeShare.update(
      recipeId,
      updateData
    );

    // Send email notification if sharing externally
    if (shareType === 'external') {
      const shareLink = `${Deno.env.get('APP_URL') || 'https://app.example.com'}/recipe/${accessToken}`;
      await base44.integrations.Core.SendEmail({
        to: recipientEmail,
        subject: `Access to Proprietary Recipe: ${recipe.recipe_name}`,
        body: `You have been granted access to a proprietary recipe.\n\nRecipe: ${recipe.recipe_name}\nAccess Level: ${accessLevel}\n\nAccess Link: ${shareLink}\n\nThis link expires on ${tokenExpiryDate}`,
        from_name: 'Compliance System',
      });
    }

    return Response.json({
      success: true,
      recipe: updatedRecipe,
      accessToken,
      message: `Recipe shared with ${recipientEmail}`,
    });
  } catch (error) {
    console.error('Error sharing recipe:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});