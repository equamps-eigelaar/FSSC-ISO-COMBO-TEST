import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function getFieldChanges(oldData, newData) {
  const changes = [];
  const allKeys = new Set([...Object.keys(oldData || {}), ...Object.keys(newData || {})]);
  
  const excludeFields = ['id', 'created_date', 'updated_date', 'created_by'];
  
  for (const key of allKeys) {
    if (excludeFields.includes(key)) continue;
    
    const oldValue = oldData?.[key];
    const newValue = newData?.[key];
    
    if (JSON.stringify(oldValue) !== JSON.stringify(newValue)) {
      changes.push({
        field: key,
        old_value: oldValue,
        new_value: newValue,
      });
    }
  }
  
  return changes;
}

function formatFieldName(field) {
  return field
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

function formatValue(value) {
  if (value === null || value === undefined) return 'empty';
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  if (Array.isArray(value)) return `[${value.length} items]`;
  if (typeof value === 'object') return '[Object]';
  if (typeof value === 'string' && value.length > 50) return value.substring(0, 50) + '...';
  return String(value);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { event } = await req.json();
    
    if (!event || !event.entity_name || !event.entity_id) {
      return Response.json({ error: 'Invalid event data' }, { status: 400 });
    }

    let activityType = '';
    let description = '';
    const metadata = {
      entity_id: event.entity_id,
      entity_name: event.entity_name,
      event_type: event.type,
    };

    if (event.type === 'create') {
      activityType = `${event.entity_name.toLowerCase()}_created`;
      description = `Created ${event.entity_name}: ${event.data?.clause_number || event.data?.batch_number || event.data?.hazard_description?.substring(0, 50) || event.entity_id}`;
      metadata.new_data = event.data;
    } else if (event.type === 'update') {
      activityType = `${event.entity_name.toLowerCase()}_updated`;
      
      const changes = getFieldChanges(event.old_data, event.data);
      
      if (changes.length > 0) {
        const changeSummary = changes.map(c => 
          `${formatFieldName(c.field)}: ${formatValue(c.old_value)} → ${formatValue(c.new_value)}`
        ).join('; ');
        
        description = `Updated ${event.entity_name}: ${changeSummary}`;
        metadata.changes = changes;
        metadata.change_count = changes.length;
      } else {
        description = `Updated ${event.entity_name} (no field changes detected)`;
      }
    } else if (event.type === 'delete') {
      activityType = `${event.entity_name.toLowerCase()}_deleted`;
      description = `Deleted ${event.entity_name}: ${event.old_data?.clause_number || event.old_data?.batch_number || event.entity_id}`;
      metadata.deleted_data = event.old_data;
    }

    await base44.entities.ActivityLog.create({
      activity_type: activityType,
      entity_type: event.entity_name,
      entity_id: event.entity_id,
      description,
      metadata,
      user_email: user.email,
    });

    return Response.json({ success: true, logged: activityType });
  } catch (error) {
    console.error('Error logging change:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});