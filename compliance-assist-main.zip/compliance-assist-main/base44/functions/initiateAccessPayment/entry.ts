import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { accessRequestId, email, companyName } = await req.json();

    if (!accessRequestId || !email) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Check if STRIPE_API_KEY is set
    const stripeApiKey = Deno.env.get("STRIPE_API_KEY");
    if (!stripeApiKey) {
      return Response.json(
        { error: 'Stripe API key not configured. Contact admin.' },
        { status: 500 }
      );
    }

    // Create Stripe checkout session
    const stripeResponse = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${stripeApiKey}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        "payment_method_types[]": "card",
        "line_items[0][price]": "price_1HZ5W92eZvKYlo2CZa9qVS0E", // Default price ID - update as needed
        "line_items[0][quantity]": "1",
        "mode": "payment",
        "success_url": `${new URL(req.url).origin}/access-request-success?session_id={CHECKOUT_SESSION_ID}`,
        "cancel_url": `${new URL(req.url).origin}/access-request-cancelled`,
        "customer_email": email,
        "metadata[accessRequestId]": accessRequestId,
        "metadata[companyName]": companyName,
      }).toString(),
    });

    if (!stripeResponse.ok) {
      const error = await stripeResponse.text();
      return Response.json(
        { error: 'Failed to create Stripe session', details: error },
        { status: 500 }
      );
    }

    const session = await stripeResponse.json();

    // Update access request with session ID
    await base44.asServiceRole.entities.AccessRequest.update(accessRequestId, {
      stripe_session_id: session.id,
      payment_amount_cents: 9999, // $99.99 - update as needed
    });

    return Response.json({
      sessionId: session.id,
      checkoutUrl: session.url,
    });
  } catch (error) {
    console.error("Payment initiation error:", error);
    return Response.json(
      { error: error.message || 'Failed to initiate payment' },
      { status: 500 }
    );
  }
});