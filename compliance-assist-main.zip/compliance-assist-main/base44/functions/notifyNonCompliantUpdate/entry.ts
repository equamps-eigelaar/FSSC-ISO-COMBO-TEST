import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const { event, data, old_data } = body;

    if (!event || event.entity_name !== 'ComplianceRequirement') {
      return Response.json({ skipped: 'Not a ComplianceRequirement event' });
    }

    const requirement = data;
    if (!requirement) {
      return Response.json({ skipped: 'No requirement data' });
    }

    // Only trigger if the requirement is non_compliant and was just updated
    const isNonCompliant = requirement.status === 'non_compliant';
    const wasAlreadyNonCompliant = old_data?.status === 'non_compliant';

    // Notify if:
    // - Newly set to non_compliant (status changed)
    // - OR was already non_compliant and had a meaningful field update
    const statusChangedToNonCompliant = isNonCompliant && old_data?.status !== 'non_compliant';
    const nonCompliantItemUpdated = isNonCompliant && wasAlreadyNonCompliant && event.type === 'update';

    if (!statusChangedToNonCompliant && !nonCompliantItemUpdated) {
      return Response.json({ skipped: 'No trigger condition met' });
    }

    const clauseLabel = `${requirement.clause_number} – ${requirement.clause_title}`;
    const actionUrl = `/RequirementDetail?id=${requirement.id}`;

    const subject = statusChangedToNonCompliant
      ? `🚨 Non-Compliant Requirement: ${requirement.clause_number}`
      : `🔔 Non-Compliant Requirement Updated: ${requirement.clause_number}`;

    const triggerReason = statusChangedToNonCompliant
      ? `Requirement "${clauseLabel}" has been marked as Non-Compliant`
      : `Non-compliant requirement "${clauseLabel}" has been updated`;

    const emailBody = `
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8fafc; padding: 24px; border-radius: 12px;">
  <div style="background: #fff1f2; border-left: 4px solid #f43f5e; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
    <h2 style="margin: 0 0 8px 0; color: #1e293b; font-size: 18px;">${subject}</h2>
    <p style="margin: 0; color: #475569; font-size: 14px;">${triggerReason}.</p>
  </div>

  <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
    <tr style="background: #f1f5f9;">
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b; width: 40%;">CLAUSE</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${clauseLabel}</td>
    </tr>
    <tr>
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">SECTION</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${requirement.section || '—'}</td>
    </tr>
    <tr style="background: #f1f5f9;">
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">STATUS</td>
      <td style="padding: 10px 16px; font-size: 13px; font-weight: bold; color: #f43f5e;">Non-Compliant</td>
    </tr>
    <tr>
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">PRIORITY</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b; text-transform: capitalize;">${requirement.priority || '—'}</td>
    </tr>
    <tr style="background: #f1f5f9;">
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">DUE DATE</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${requirement.due_date || 'Not set'}</td>
    </tr>
    <tr>
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">ASSIGNED TO</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${requirement.assigned_to || requirement.responsible_person || 'Unassigned'}</td>
    </tr>
    ${requirement.findings ? `
    <tr style="background: #f1f5f9;">
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">FINDINGS</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${requirement.findings}</td>
    </tr>` : ''}
    ${requirement.corrective_actions ? `
    <tr>
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">CORRECTIVE ACTIONS</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${requirement.corrective_actions}</td>
    </tr>` : ''}
  </table>

  <div style="margin-top: 20px; text-align: center;">
    <a href="https://app.base44.com${actionUrl}" style="display: inline-block; background: #10b981; color: white; padding: 10px 24px; border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: bold;">View Requirement</a>
  </div>

  <p style="margin-top: 20px; font-size: 12px; color: #94a3b8; text-align: center;">
    Package Manufacturing Compliance Tracker · Requirement Alert
  </p>
</div>
`;

    // Determine recipients
    const recipients = new Set();
    if (requirement.assigned_to) recipients.add(requirement.assigned_to);

    // Also notify admins
    const allUsers = await base44.asServiceRole.entities.User.list();
    for (const u of allUsers) {
      if (u.role === 'admin') recipients.add(u.email);
    }

    const preferences = await base44.asServiceRole.entities.NotificationPreference.list();

    let emailsSent = 0;
    for (const email of recipients) {
      const pref = preferences.find(p => p.user_email === email);
      if (pref && pref.requirement_status_changes === false) continue;

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject,
        body: emailBody,
        from_name: 'Compliance Tracker',
      });
      emailsSent++;

      await base44.asServiceRole.entities.Notification.create({
        recipient_email: email,
        title: subject,
        message: triggerReason,
        type: 'compliance_alert',
        entity_type: 'ComplianceRequirement',
        entity_id: requirement.id,
        action_url: actionUrl,
        is_read: false,
        priority: requirement.priority === 'critical' ? 'critical' : 'high',
      });
    }

    return Response.json({ success: true, emails_sent: emailsSent });
  } catch (error) {
    console.error('notifyNonCompliantUpdate error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});