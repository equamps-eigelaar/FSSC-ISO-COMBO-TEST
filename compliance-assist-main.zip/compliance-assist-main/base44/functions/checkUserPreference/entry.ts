import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { user_email, notification_type } = await req.json();

    if (!user_email || !notification_type) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const preferences = await base44.asServiceRole.entities.NotificationPreference.filter({
      user_email
    });

    if (preferences.length === 0) {
      return Response.json({ should_notify: true, preference_exists: false });
    }

    const pref = preferences[0];
    const shouldNotify = pref[notification_type] !== false;

    return Response.json({
      should_notify: shouldNotify,
      preference_exists: true,
      preferences: pref
    });
  } catch (error) {
    console.error('Error checking preferences:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});