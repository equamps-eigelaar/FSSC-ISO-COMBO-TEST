import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const today = new Date().toISOString().split('T')[0];

    // Fetch all active recurring billing schedules due today or earlier
    const allRecurring = await base44.asServiceRole.entities.RecurringBilling.list();
    const due = allRecurring.filter(r =>
      r.status === 'active' && r.next_billing_date && r.next_billing_date <= today
    );

    if (due.length === 0) {
      return Response.json({ message: 'No recurring billing records due today.', generated: 0 });
    }

    const generated = [];

    for (const schedule of due) {
      // Create billing record
      await base44.asServiceRole.entities.BillingRecord.create({
        transaction_date: today,
        billable_type: schedule.billable_type,
        entity_name: schedule.entity_name || schedule.description,
        customer_type: schedule.customer_type,
        customer_name: schedule.customer_name,
        customer_email: schedule.customer_email,
        quantity: schedule.quantity || 1,
        unit_cost: schedule.unit_cost,
        total_cost: schedule.total_cost,
        currency: schedule.currency || 'USD',
        description: `[Recurring - ${schedule.cycle}] ${schedule.description || schedule.entity_name || ''}`,
        billing_status: 'pending',
        notes: `Auto-generated from recurring schedule ID: ${schedule.id}`,
      });

      // Calculate next billing date
      const nextDate = new Date(today);
      switch (schedule.cycle) {
        case 'monthly':
          nextDate.setMonth(nextDate.getMonth() + 1);
          break;
        case 'quarterly':
          nextDate.setMonth(nextDate.getMonth() + 3);
          break;
        case 'semi_annual':
          nextDate.setMonth(nextDate.getMonth() + 6);
          break;
        case 'annual':
          nextDate.setFullYear(nextDate.getFullYear() + 1);
          break;
      }
      const nextBillingDate = nextDate.toISOString().split('T')[0];

      // Update the recurring schedule
      await base44.asServiceRole.entities.RecurringBilling.update(schedule.id, {
        last_generated_date: today,
        next_billing_date: nextBillingDate,
      });

      // Send invoice email
      const cycleLabel = { monthly: 'Monthly', quarterly: 'Quarterly', semi_annual: 'Semi-Annual', annual: 'Annual' }[schedule.cycle] || schedule.cycle;
      const itemName = schedule.entity_name || schedule.description || 'Compliance Services';
      const amount = `${schedule.currency || 'USD'} ${(schedule.total_cost || 0).toFixed(2)}`;
      const emailBody = `
Dear ${schedule.customer_name},

Please find below your auto-generated invoice for recurring services.

─────────────────────────────
INVOICE DETAILS
─────────────────────────────
Date:         ${today}
Customer:     ${schedule.customer_name}
Service:      ${itemName}
Cycle:        ${cycleLabel}
Quantity:     ${schedule.quantity || 1}
Unit Cost:    ${schedule.currency || 'USD'} ${(schedule.unit_cost || 0).toFixed(2)}
Total Due:    ${amount}
─────────────────────────────

Status: PENDING PAYMENT

Please process payment at your earliest convenience.

If you have any questions regarding this invoice, please don't hesitate to contact us.

Kind regards,
Package Manufacturing Compliance Team
      `.trim();

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: 'eigelaarenterprises@gmail.com',
        subject: `Invoice – ${itemName} (${cycleLabel}) – ${today}`,
        body: emailBody,
      });

      generated.push({ schedule_id: schedule.id, customer: schedule.customer_name, next_billing_date: nextBillingDate });
    }

    return Response.json({ message: `Generated ${generated.length} billing record(s).`, generated });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});