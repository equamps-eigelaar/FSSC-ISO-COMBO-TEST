import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const today = new Date();
    const in7Days = new Date(today);
    in7Days.setDate(in7Days.getDate() + 7);
    const todayStr = today.toISOString().split('T')[0];
    const in7Str = in7Days.toISOString().split('T')[0];

    const allSchedules = await base44.asServiceRole.entities.RecurringBilling.list();
    const upcoming = allSchedules.filter(
      (s) => s.status === 'active' && s.next_billing_date >= todayStr && s.next_billing_date <= in7Str
    );

    if (upcoming.length === 0) {
      return Response.json({ message: 'No upcoming billing events in the next 7 days.', notified: 0 });
    }

    const rows = upcoming.map((s) => {
      const cycleLabel = { monthly: 'Monthly', quarterly: 'Quarterly', semi_annual: 'Semi-Annual', annual: 'Annual' }[s.cycle] || s.cycle;
      return `• ${s.customer_name} — ${s.entity_name || s.description || 'Service'} (${cycleLabel}) — Due: ${s.next_billing_date} — ${s.currency || 'USD'} ${(s.total_cost || 0).toFixed(2)}`;
    }).join('\n');

    const emailBody = `
Upcoming Recurring Billing Events (Next 7 Days)
================================================

${rows}

Please review and process these billing records as needed.

Package Manufacturing Compliance System
    `.trim();

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: 'eigelaarenterprises@gmail.com',
      subject: `Billing Reminder: ${upcoming.length} recurring invoice(s) due within 7 days`,
      body: emailBody,
    });

    return Response.json({ message: `Notified about ${upcoming.length} upcoming billing events.`, notified: upcoming.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});