import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    const { event, data } = payload;

    // Check if document requires review
    if (event.entity_name === 'Document' && event.type === 'create') {
      const documentTypes = ['compliance_evidence', 'risk_analysis', 'inspection_report'];
      
      if (documentTypes.includes(data.document_type)) {
        // Get all users with notification preferences
        const allUsers = await base44.asServiceRole.entities.User.list();
        
        for (const user of allUsers) {
          const prefs = await base44.asServiceRole.entities.NotificationPreference.filter({
            user_email: user.email,
          });

          const userPref = prefs.length > 0 ? prefs[0] : null;
          
          if (!userPref || userPref.documents_pending_review !== false) {
            await base44.asServiceRole.entities.Notification.create({
              recipient_email: user.email,
              title: 'Document Uploaded for Review',
              message: `A new ${data.document_type.replace(/_/g, ' ')} document "${data.file_name}" has been uploaded and may require review.`,
              type: 'document_review',
              entity_type: 'Document',
              entity_id: event.entity_id,
              action_url: `/DocumentRepository?id=${event.entity_id}`,
              is_read: false,
              priority: 'normal'
            });
          }
        }
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error notifying document review:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});