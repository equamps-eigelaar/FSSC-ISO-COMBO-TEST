import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

async function getValidToken(base44) {
  const tokens = await base44.asServiceRole.entities.XeroToken.filter({});
  if (tokens.length === 0) throw new Error('Xero not connected');
  let token = tokens[0];

  if (new Date(token.expires_at) < new Date(Date.now() + 60000)) {
    const CLIENT_ID = Deno.env.get('XERO_CLIENT_ID');
    const CLIENT_SECRET = Deno.env.get('XERO_CLIENT_SECRET');
    const credentials = btoa(`${CLIENT_ID}:${CLIENT_SECRET}`);
    const res = await fetch('https://identity.xero.com/connect/token', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: token.refresh_token,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error('Token refresh failed: ' + JSON.stringify(data));
    token = {
      ...token,
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: new Date(Date.now() + data.expires_in * 1000).toISOString(),
    };
    await base44.asServiceRole.entities.XeroToken.update(token.id, {
      access_token: token.access_token,
      refresh_token: token.refresh_token,
      expires_at: token.expires_at,
    });
  }
  return token;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { customerName, customerEmail, planId, billingCycle = 'monthly', startDate } = body;

    if (!customerName || !planId) {
      return Response.json({ error: 'customerName and planId are required' }, { status: 400 });
    }

    // Load the plan
    const plans = await base44.asServiceRole.entities.PricePlan.filter({ id: planId });
    if (plans.length === 0) return Response.json({ error: 'Plan not found' }, { status: 404 });
    const plan = plans[0];

    const unitAmount = billingCycle === 'annual' ? (plan.price_annual || plan.price_monthly) : plan.price_monthly;
    const today = startDate || new Date().toISOString().split('T')[0];
    const dueDate = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];

    const token = await getValidToken(base44);
    const headers = {
      'Authorization': `Bearer ${token.access_token}`,
      'Xero-tenant-id': token.tenant_id,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    const invoiceData = {
      Type: 'ACCREC',
      Contact: { Name: customerName, EmailAddress: customerEmail || '' },
      Date: today,
      DueDate: dueDate,
      LineItems: [{
        Description: `${plan.name} Plan — ${billingCycle === 'annual' ? 'Annual' : 'Monthly'} Subscription`,
        Quantity: 1,
        UnitAmount: unitAmount,
        AccountCode: plan.xero_account_code || '200',
        ItemCode: plan.xero_item_code || undefined,
      }],
      Status: 'AUTHORISED',
      Reference: `SUB-${plan.tier.toUpperCase()}-${Date.now()}`,
      CurrencyCode: plan.currency || 'ZAR',
    };

    const res = await fetch('https://api.xero.com/api.xro/2.0/Invoices', {
      method: 'POST',
      headers,
      body: JSON.stringify({ Invoices: [invoiceData] }),
    });
    const data = await res.json();
    if (!res.ok) return Response.json({ error: data }, { status: 400 });

    const xeroInvoice = data.Invoices?.[0];

    // Also create a local BillingRecord
    await base44.asServiceRole.entities.BillingRecord.create({
      transaction_date: today,
      billable_type: 'template_usage',
      entity_name: `${plan.name} Plan Subscription`,
      customer_type: 'external',
      customer_name: customerName,
      customer_email: customerEmail || '',
      quantity: 1,
      unit_cost: unitAmount,
      total_cost: unitAmount,
      currency: plan.currency || 'ZAR',
      description: `${billingCycle === 'annual' ? 'Annual' : 'Monthly'} subscription to ${plan.name} Plan`,
      billing_status: 'invoiced',
      invoice_number: xeroInvoice?.InvoiceNumber || '',
      notes: `Xero ID: ${xeroInvoice?.InvoiceID} | Plan: ${plan.tier}`,
    });

    return Response.json({ success: true, invoice: xeroInvoice });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});