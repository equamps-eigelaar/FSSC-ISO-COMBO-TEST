import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const { recipientEmail, reportType, reportName, filters } = await req.json();

    if (!recipientEmail || !reportType) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Generate the report PDF
    const reportResult = await base44.asServiceRole.functions.invoke('generateReport', {
      reportType,
      filters: filters || {},
      includeCharts: true
    });

    if (!reportResult.data) {
      return Response.json({ error: 'Failed to generate report' }, { status: 500 });
    }

    // Upload the PDF to get a URL
    const pdfBlob = new Blob([reportResult.data], { type: 'application/pdf' });
    const formData = new FormData();
    formData.append('file', pdfBlob, `${reportType}-report.pdf`);
    
    const uploadResponse = await fetch('https://api.base44.com/integrations/core/UploadFile', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('BASE44_SERVICE_ROLE_KEY')}`
      },
      body: formData
    });

    const { file_url } = await uploadResponse.json();

    // Send email with report link
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: recipientEmail,
      subject: `${reportName || 'Compliance Report'} - ${new Date().toLocaleDateString()}`,
      body: `
        <h2>Your scheduled compliance report is ready</h2>
        <p>Report Type: ${reportType.charAt(0).toUpperCase() + reportType.slice(1)}</p>
        <p>Generated: ${new Date().toLocaleString()}</p>
        <p><a href="${file_url}" style="background: #10b981; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; display: inline-block;">Download Report</a></p>
        <p style="color: #666; font-size: 12px; margin-top: 20px;">This is an automated report from Package Manufacturing Compliance Tracker</p>
      `
    });

    return Response.json({ 
      success: true, 
      message: 'Report sent successfully',
      file_url 
    });

  } catch (error) {
    console.error('Error sending report:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});