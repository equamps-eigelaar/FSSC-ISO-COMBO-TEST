import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { ticketId, ticketNumber, title, description, reporterEmail, category, priority } = body;

    // Send email to support address
    await base44.integrations.Core.SendEmail({
      to: 'eigelaarenterprises@gmail.com',
      subject: `New Support Ticket: ${ticketNumber} - ${title}`,
      body: `
New Support Ticket Received

Ticket Number: ${ticketNumber}
Title: ${title}
Category: ${category}
Priority: ${priority}
Reporter: ${reporterEmail}

Description:
${description}

Status: Open

You can manage this ticket in the system.
      `,
      from_name: 'Support Ticket System'
    });

    // Send confirmation email to reporter
    await base44.integrations.Core.SendEmail({
      to: reporterEmail,
      subject: `Ticket Confirmation: ${ticketNumber}`,
      body: `
Thank you for reporting this issue.

Your ticket number is: ${ticketNumber}
Title: ${title}
Category: ${category}

We have received your report and will address it as soon as possible.

You can track your ticket using the ticket number above.
      `,
      from_name: 'Support System'
    });

    return Response.json({ 
      success: true, 
      message: 'Ticket notification sent',
      ticketNumber 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});