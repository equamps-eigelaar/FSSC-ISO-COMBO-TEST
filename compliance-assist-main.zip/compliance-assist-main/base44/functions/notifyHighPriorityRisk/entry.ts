import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const { event, data, old_data } = body;

    if (!event || event.entity_name !== 'RiskAssessment') {
      return Response.json({ skipped: 'Not a RiskAssessment event' });
    }

    const risk = data;
    if (!risk) {
      return Response.json({ skipped: 'No risk data' });
    }

    const isHighPriority = risk.risk_level === 'high' || risk.risk_level === 'critical';
    const isNewHighPriority = event.type === 'create' && isHighPriority;
    const isPendingReviewChange = event.type === 'update' &&
      risk.workflow_status === 'pending_review' &&
      old_data?.workflow_status !== 'pending_review';

    if (!isNewHighPriority && !isPendingReviewChange) {
      return Response.json({ skipped: 'No trigger condition met' });
    }

    // Determine recipients: assigned user + all admins
    const allUsers = await base44.asServiceRole.entities.User.list();
    const preferences = await base44.asServiceRole.entities.NotificationPreference.list();

    const recipients = new Set();

    // Always include assigned user if present
    if (risk.assigned_to) recipients.add(risk.assigned_to);
    if (risk.approver_email) recipients.add(risk.approver_email);

    // Include admins who haven't opted out
    for (const u of allUsers) {
      if (u.role === 'admin') recipients.add(u.email);
    }

    // Build email content
    const triggerReason = isNewHighPriority
      ? `A new **${risk.risk_level?.toUpperCase()}** risk has been created`
      : `A risk assessment has been submitted for **Pending Review**`;

    const subject = isNewHighPriority
      ? `⚠️ ${risk.risk_level?.toUpperCase()} Risk Alert: ${risk.hazard_type || 'New Risk'}`
      : `🔍 Risk Pending Review: ${risk.hazard_type || 'Risk Assessment'}`;

    const emailBody = `
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8fafc; padding: 24px; border-radius: 12px;">
  <div style="background: ${risk.risk_level === 'critical' ? '#fff1f2' : risk.risk_level === 'high' ? '#fff7ed' : '#fefce8'}; border-left: 4px solid ${risk.risk_level === 'critical' ? '#f43f5e' : risk.risk_level === 'high' ? '#f97316' : '#f59e0b'}; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
    <h2 style="margin: 0 0 8px 0; color: #1e293b; font-size: 18px;">${subject}</h2>
    <p style="margin: 0; color: #475569; font-size: 14px;">${triggerReason}.</p>
  </div>

  <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
    <tr style="background: #f1f5f9;">
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b; width: 40%;">HAZARD TYPE</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b; text-transform: capitalize;">${risk.hazard_type || '—'}</td>
    </tr>
    <tr>
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">DESCRIPTION</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${risk.hazard_description || '—'}</td>
    </tr>
    <tr style="background: #f1f5f9;">
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">RISK LEVEL</td>
      <td style="padding: 10px 16px; font-size: 13px; font-weight: bold; color: ${risk.risk_level === 'critical' ? '#f43f5e' : risk.risk_level === 'high' ? '#f97316' : '#f59e0b'}; text-transform: uppercase;">${risk.risk_level || '—'}</td>
    </tr>
    <tr>
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">LIKELIHOOD</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b; text-transform: capitalize;">${risk.likelihood || '—'}</td>
    </tr>
    <tr style="background: #f1f5f9;">
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">SEVERITY</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b; text-transform: capitalize;">${risk.severity || '—'}</td>
    </tr>
    <tr>
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">WORKFLOW STATUS</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b; text-transform: replace;">${(risk.workflow_status || '—').replace(/_/g, ' ')}</td>
    </tr>
    <tr style="background: #f1f5f9;">
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">ASSIGNED TO</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${risk.assigned_to || 'Unassigned'}</td>
    </tr>
    ${risk.mitigation_strategy ? `
    <tr>
      <td style="padding: 10px 16px; font-size: 12px; font-weight: bold; color: #64748b;">MITIGATION</td>
      <td style="padding: 10px 16px; font-size: 13px; color: #1e293b;">${risk.mitigation_strategy}</td>
    </tr>` : ''}
  </table>

  <p style="margin-top: 20px; font-size: 12px; color: #94a3b8; text-align: center;">
    Package Manufacturing Compliance Tracker · Risk Assessment Notification
  </p>
</div>
`;

    let emailsSent = 0;
    let notificationsSent = 0;

    for (const email of recipients) {
      // Check notification preferences
      const pref = preferences.find(p => p.user_email === email);
      if (pref && pref.high_priority_risks === false) continue;

      // Send email
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject,
        body: emailBody,
        from_name: 'Compliance Tracker',
      });
      emailsSent++;

      // Also create in-app notification
      await base44.asServiceRole.entities.Notification.create({
        recipient_email: email,
        title: subject,
        message: `${triggerReason}: ${risk.hazard_description?.substring(0, 100) || ''}`,
        type: 'high_priority_risk',
        entity_type: 'RiskAssessment',
        entity_id: risk.id,
        is_read: false,
        priority: risk.risk_level === 'critical' ? 'critical' : 'high',
      });
      notificationsSent++;
    }

    return Response.json({
      success: true,
      trigger: isNewHighPriority ? 'new_high_priority' : 'pending_review_status_change',
      emails_sent: emailsSent,
      notifications_sent: notificationsSent,
    });
  } catch (error) {
    console.error('Error in notifyHighPriorityRisk:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});