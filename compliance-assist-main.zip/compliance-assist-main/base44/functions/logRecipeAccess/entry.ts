import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const { recipeId, accessToken } = await req.json();

    if (!recipeId || !accessToken) {
      return Response.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const base44 = createClientFromRequest(req);

    // Find recipe by access token
    const recipes = await base44.asServiceRole.entities.ProprietaryRecipeShare.filter(
      { access_token: accessToken },
      '-created_date',
      1
    );

    if (recipes.length === 0) {
      return Response.json({ error: 'Invalid or expired access token' }, { status: 404 });
    }

    const recipe = recipes[0];

    // Check token expiry
    if (recipe.token_expiry) {
      const expiryDate = new Date(recipe.token_expiry);
      if (expiryDate < new Date()) {
        return Response.json({ error: 'Access token has expired' }, { status: 403 });
      }
    }

    // Increment access count and update last_accessed
    const updatedRecipe = await base44.asServiceRole.entities.ProprietaryRecipeShare.update(
      recipe.id,
      {
        access_count: (recipe.access_count || 0) + 1,
        last_accessed: new Date().toISOString(),
      }
    );

    return Response.json({
      success: true,
      recipe: updatedRecipe,
      message: 'Access logged successfully',
    });
  } catch (error) {
    console.error('Error logging recipe access:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});