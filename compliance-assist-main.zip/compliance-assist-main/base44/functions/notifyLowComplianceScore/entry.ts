import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    const { event, data } = payload;

    // Check if compliance score drops below threshold
    if (event.entity_name === 'ComplianceRequirement' && event.type === 'update' && data.completion_percentage !== undefined) {
      const threshold = 50; // Alert when below 50%
      
      if (data.completion_percentage < threshold && data.assigned_to) {
        const prefs = await base44.asServiceRole.entities.NotificationPreference.filter({
          user_email: data.assigned_to,
        });

        const userPref = prefs.length > 0 ? prefs[0] : null;
        
        if (!userPref || userPref.low_compliance_scores !== false) {
          await base44.asServiceRole.entities.Notification.create({
            recipient_email: data.assigned_to,
            title: 'Low Compliance Score Alert',
            message: `"${data.clause_number}" compliance is at ${data.completion_percentage}%. Please take action to improve compliance.`,
            type: 'compliance_alert',
            entity_type: event.entity_name,
            entity_id: event.entity_id,
            action_url: `/RequirementDetail?id=${event.entity_id}`,
            is_read: false,
            priority: data.completion_percentage < 25 ? 'critical' : 'high'
          });

          // Send email
          await base44.asServiceRole.integrations.Core.SendEmail({
            to: data.assigned_to,
            subject: `Low Compliance Score: ${data.clause_number}`,
            body: `The compliance score for "${data.clause_number} – ${data.clause_title}" has dropped to ${data.completion_percentage}%.\n\nPlease log in to the compliance tracker to review and take necessary actions.`
          });
        }
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error notifying low compliance score:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});