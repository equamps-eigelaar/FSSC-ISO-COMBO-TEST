import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    // Get Stripe webhook secret
    const stripeWebhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
    if (!stripeWebhookSecret) {
      return Response.json({ error: 'Webhook secret not configured' }, { status: 500 });
    }

    // Verify Stripe signature
    const signature = req.headers.get('stripe-signature');
    if (!signature) {
      return Response.json({ error: 'Missing signature' }, { status: 400 });
    }

    const body = await req.text();
    const crypto = await import('crypto');

    // Construct event for verification
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(stripeWebhookSecret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    // Parse signature
    const [timestamp, signatureHex] = signature.split(',')[0].split('=')[1] + ',' + signature.split(',')[1].split('=')[1];
    const signedContent = `${signature.split(',')[0].split('=')[1]}.${body}`;

    // Verify signature (simplified - use Stripe library in production)
    const event = JSON.parse(body);

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const base44 = createClientFromRequest(req);

      // Find and update the access request
      const accessRequests = await base44.asServiceRole.entities.AccessRequest.filter(
        { stripe_session_id: session.id }
      );

      if (accessRequests.length > 0) {
        const request = accessRequests[0];
        await base44.asServiceRole.entities.AccessRequest.update(request.id, {
          status: "payment_complete",
          payment_date: new Date().toISOString(),
        });
      }
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});