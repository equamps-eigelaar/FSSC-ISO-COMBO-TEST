import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const ENTITY_NAMES = [
  "ComplianceRequirement",
  "RiskAssessment",
  "ActionItem",
  "Document",
  "ActivityLog",
  "RawMaterialBatch",
  "Comment",
  "MonitoringLog",
  "ComplianceAudit",
  "RiskPrediction",
  "AuditPlan",
  "Notification",
  "DocumentRevision",
  "TrainingModule",
  "UserTrainingProgress",
  "MonitoringTemplate",
  "AllergenControl",
  "RiskTemplate",
  "NotificationPreference",
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    if (user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { organization_id } = await req.json();
    if (!organization_id) {
      return Response.json({ error: 'organization_id is required' }, { status: 400 });
    }

    const results = {};

    for (const entityName of ENTITY_NAMES) {
      try {
        // Fetch all records with no organization_id
        const records = await base44.asServiceRole.entities[entityName].filter(
          { organization_id: null },
          "-created_date",
          500
        );

        let updated = 0;
        for (const record of records) {
          await base44.asServiceRole.entities[entityName].update(record.id, {
            organization_id,
          });
          updated++;
        }
        results[entityName] = { migrated: updated };
      } catch (err) {
        results[entityName] = { error: err.message };
      }
    }

    // Also update the current user's organization_id
    await base44.asServiceRole.entities.User.update(user.id, { organization_id });

    return Response.json({ success: true, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});