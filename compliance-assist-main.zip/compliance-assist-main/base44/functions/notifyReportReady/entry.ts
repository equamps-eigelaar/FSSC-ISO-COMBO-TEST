import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();
    
    const { recipientEmail, reportName, reportType, reportUrl } = payload;

    if (!recipientEmail) {
      return Response.json({ error: 'Missing recipient email' }, { status: 400 });
    }

    // Check user preferences
    const prefs = await base44.asServiceRole.entities.NotificationPreference.filter({
      user_email: recipientEmail,
    });

    const userPref = prefs.length > 0 ? prefs[0] : null;
    
    if (!userPref || userPref.reports_ready !== false) {
      await base44.asServiceRole.entities.Notification.create({
        recipient_email: recipientEmail,
        title: 'Report Ready',
        message: `Your ${reportType} report "${reportName}" is ready for download.`,
        type: 'report_ready',
        entity_type: 'Report',
        entity_id: reportName,
        action_url: reportUrl || '/Reports',
        is_read: false,
        priority: 'normal'
      });

      // Send email
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: recipientEmail,
        subject: `Your Report is Ready: ${reportName}`,
        body: `Your ${reportType} report "${reportName}" has been generated and is ready for download.\n\nLog in to the compliance tracker to view and download your report.`
      });
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error notifying report ready:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});