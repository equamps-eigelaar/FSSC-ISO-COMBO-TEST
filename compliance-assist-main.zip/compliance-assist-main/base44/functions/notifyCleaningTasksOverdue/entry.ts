import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // This function runs on a schedule to check for overdue cleaning tasks
    const today = new Date();
    const threeDaysAgo = new Date(today.getTime() - 3 * 24 * 60 * 60 * 1000);

    // Get all monitoring templates for cleaning
    const templates = await base44.asServiceRole.entities.MonitoringTemplate.filter({
      log_type: 'cleaning',
    });

    const allUsers = await base44.asServiceRole.entities.User.list();

    for (const template of templates) {
      // Get recent logs for this template
      const logs = await base44.asServiceRole.entities.MonitoringLog.filter({
        template_id: template.id,
      }, '-log_date', 1);

      const lastLog = logs[0];
      const lastLogDate = lastLog ? new Date(lastLog.log_date) : threeDaysAgo;

      // Check if log is overdue based on frequency
      let daysSinceLog = Math.floor((today.getTime() - lastLogDate.getTime()) / (24 * 60 * 60 * 1000));
      let isOverdue = false;

      if (template.frequency === 'daily' && daysSinceLog > 1) isOverdue = true;
      if (template.frequency === 'weekly' && daysSinceLog > 7) isOverdue = true;

      if (isOverdue) {
        // Notify assigned roles
        for (const user of allUsers) {
          const prefs = await base44.asServiceRole.entities.NotificationPreference.filter({
            user_email: user.email,
          });

          const userPref = prefs.length > 0 ? prefs[0] : null;
          
          if (!userPref || userPref.overdue_cleaning_tasks !== false) {
            await base44.asServiceRole.entities.Notification.create({
              recipient_email: user.email,
              title: 'Overdue Cleaning Task',
              message: `"${template.name}" cleaning task is overdue. Last completed ${daysSinceLog} days ago.`,
              type: 'overdue_task',
              entity_type: 'MonitoringTemplate',
              entity_id: template.id,
              action_url: `/DailyMonitoring`,
              is_read: false,
              priority: daysSinceLog > 7 ? 'high' : 'normal'
            });
          }
        }
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error checking cleaning tasks:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});