/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import AccessRequests from './pages/AccessRequests';
import ActionItems from './pages/ActionItems';
import ActivityMonitor from './pages/ActivityMonitor';
import AllergenControl from './pages/AllergenControl';
import Analytics from './pages/Analytics';
import AuditLog from './pages/AuditLog';
import AuditPrep from './pages/AuditPrep';
import Billing from './pages/Billing';
import CleaningRegisters from './pages/CleaningRegisters';
import ComplianceAudits from './pages/ComplianceAudits';
import ComplianceImport from './pages/ComplianceImport';
import DailyMonitoring from './pages/DailyMonitoring';
import Dashboard from './pages/Dashboard';
import DocumentRepository from './pages/DocumentRepository';
import DocumentTemplates from './pages/DocumentTemplates';
import FSSC22000Tracker from './pages/FSSC22000Tracker';
import FoodBatchRecords from './pages/FoodBatchRecords';
import FoodBatchTraceability from './pages/FoodBatchTraceability';
import HygieneZones from './pages/HygieneZones';
import KPITrendDashboard from './pages/KPITrendDashboard';
import LocationSharing from './pages/LocationSharing';
import MobileActionItems from './pages/MobileActionItems';
import MobileAudit from './pages/MobileAudit';
import ModerationDashboard from './pages/ModerationDashboard';
import NotificationCenter from './pages/NotificationCenter';
import OrganizationSetup from './pages/OrganizationSetup';
import PlanManagement from './pages/PlanManagement';
import Pricing from './pages/Pricing';
import PricingPlans from './pages/PricingPlans';
import PrivacyPolicy from './pages/PrivacyPolicy';
import ProprietarySharing from './pages/ProprietarySharing';
import RawMaterialTraceability from './pages/RawMaterialTraceability';
import RegulatoryChangeRegister from './pages/RegulatoryChangeRegister';
import Reports from './pages/Reports';
import RequirementDetail from './pages/RequirementDetail';
import Requirements from './pages/Requirements';
import RetentionSamples from './pages/RetentionSamples';
import RiskPredictions from './pages/RiskPredictions';
import RiskWorkflow from './pages/RiskWorkflow';
import SelfAssessment from './pages/SelfAssessment';
import ServiceLevelAgreement from './pages/ServiceLevelAgreement';
import Settings from './pages/Settings';
import SupplierManagement from './pages/SupplierManagement';
import SupplierPortal from './pages/SupplierPortal';
import SupportTickets from './pages/SupportTickets';
import TenantSetupGuide from './pages/TenantSetupGuide';
import TermsAndConditions from './pages/TermsAndConditions';
import Training from './pages/Training';
import UserManagement from './pages/UserManagement';
import __Layout from './Layout.jsx';


export const PAGES = {
    "AccessRequests": AccessRequests,
    "ActionItems": ActionItems,
    "ActivityMonitor": ActivityMonitor,
    "AllergenControl": AllergenControl,
    "Analytics": Analytics,
    "AuditLog": AuditLog,
    "AuditPrep": AuditPrep,
    "Billing": Billing,
    "CleaningRegisters": CleaningRegisters,
    "ComplianceAudits": ComplianceAudits,
    "ComplianceImport": ComplianceImport,
    "DailyMonitoring": DailyMonitoring,
    "Dashboard": Dashboard,
    "DocumentRepository": DocumentRepository,
    "DocumentTemplates": DocumentTemplates,
    "FSSC22000Tracker": FSSC22000Tracker,
    "FoodBatchRecords": FoodBatchRecords,
    "FoodBatchTraceability": FoodBatchTraceability,
    "HygieneZones": HygieneZones,
    "KPITrendDashboard": KPITrendDashboard,
    "LocationSharing": LocationSharing,
    "MobileActionItems": MobileActionItems,
    "MobileAudit": MobileAudit,
    "ModerationDashboard": ModerationDashboard,
    "NotificationCenter": NotificationCenter,
    "OrganizationSetup": OrganizationSetup,
    "PlanManagement": PlanManagement,
    "Pricing": Pricing,
    "PricingPlans": PricingPlans,
    "PrivacyPolicy": PrivacyPolicy,
    "ProprietarySharing": ProprietarySharing,
    "RawMaterialTraceability": RawMaterialTraceability,
    "RegulatoryChangeRegister": RegulatoryChangeRegister,
    "Reports": Reports,
    "RequirementDetail": RequirementDetail,
    "Requirements": Requirements,
    "RetentionSamples": RetentionSamples,
    "RiskPredictions": RiskPredictions,
    "RiskWorkflow": RiskWorkflow,
    "SelfAssessment": SelfAssessment,
    "ServiceLevelAgreement": ServiceLevelAgreement,
    "Settings": Settings,
    "SupplierManagement": SupplierManagement,
    "SupplierPortal": SupplierPortal,
    "SupportTickets": SupportTickets,
    "TenantSetupGuide": TenantSetupGuide,
    "TermsAndConditions": TermsAndConditions,
    "Training": Training,
    "UserManagement": UserManagement,
}

export const pagesConfig = {
    mainPage: "ActionItems",
    Pages: PAGES,
    Layout: __Layout,
};