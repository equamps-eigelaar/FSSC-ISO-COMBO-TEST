import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  ClipboardList,
  ShieldCheck,
  Activity,
  ChevronDown,
  Users,
  Package,
  FileText,
  BarChart3,
  Settings as SettingsIcon,
  CheckCircle2,
  History,
  FlaskConical,
  Lock,
  Upload,
  ArrowLeft,
  Navigation,
  Shield,
  BookOpen,
  LogOut,
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import NotificationBell from "@/components/collaboration/NotificationBell";
import { usePermissions } from "@/components/permissions/usePermissions";
import OfflineIndicator from "@/components/offline/OfflineIndicator";
import MobileHeader from "@/components/mobile/MobileHeader";
import BottomTabBar from "@/components/mobile/BottomTabBar";
import DisclaimerDialog from "@/components/legal/DisclaimerDialog";
import PWAInstallPrompt from "@/components/pwa/PWAInstallPrompt";
import OnboardingFlow from "@/components/onboarding/OnboardingFlow";
import { useTour } from "@/components/onboarding/useTour";
import TrialBanner from "@/components/trial/TrialBanner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const NAV_ITEMS = [
  { name: "Dashboard", icon: LayoutDashboard, page: "Dashboard" },
  { name: "Audit Prep", icon: CheckCircle2, page: "AuditPrep" },
  { name: "FSSC 22000 Tracker", icon: ShieldCheck, page: "FSSC22000Tracker" },
  { name: "Field Audits", icon: ClipboardList, page: "MobileAudit" },
  { name: "Daily Monitoring", icon: ClipboardList, page: "DailyMonitoring" },
  { name: "Requirements", icon: ClipboardList, page: "Requirements" },
  { name: "Risk Workflow", icon: ShieldCheck, page: "RiskWorkflow" },
  { name: "Action Items", icon: Activity, page: "ActionItems" },
  { name: "Self Assessment", icon: ClipboardList, page: "SelfAssessment" },
  { name: "Supplier Portal", icon: Users, page: "SupplierPortal" },
  { name: "Supplier Management", icon: Users, page: "SupplierManagement", adminOnly: true },
  { name: "Templates", icon: FileText, page: "DocumentTemplates" },
  { name: "Documents", icon: FileText, page: "DocumentRepository" },
  { name: "Proprietary Sharing", icon: Lock, page: "ProprietarySharing", adminOnly: true },
  { name: "Compliance Import", icon: Upload, page: "ComplianceImport", adminOnly: true },
  { name: "Audit Trail", icon: History, page: "ActivityMonitor" },
  { name: "Training", icon: Users, page: "Training" },
  { name: "Batch Traceability", icon: Package, page: "FoodBatchTraceability" },
  { name: "Retention Samples", icon: FlaskConical, page: "RetentionSamples" },
  { name: "Location Sharing", icon: Navigation, page: "LocationSharing" },
  { name: "Cleaning Registers", icon: ClipboardList, page: "CleaningRegisters" },
  { name: "Raw Materials", icon: Package, page: "RawMaterialTraceability" },
  { name: "AI Audits", icon: Activity, page: "ComplianceAudits" },
  { name: "Support Tickets", icon: Activity, page: "SupportTickets" },
  { name: "Moderation", icon: Shield, page: "ModerationDashboard", adminOnly: true },
  { name: "Pricing Plans", icon: FileText, page: "PricingPlans" },
  { name: "KPI Trends", icon: BarChart3, page: "KPITrendDashboard" },
  { name: "Regulatory Changes", icon: BookOpen, page: "RegulatoryChangeRegister" },
  { name: "Reports", icon: FileText, page: "Reports" },
  { name: "Analytics", icon: BarChart3, page: "Analytics" },
  { name: "Billing & Costs", icon: FileText, page: "Billing" },
  { name: "Settings", icon: SettingsIcon, page: "Settings" },
  { name: "User Management", icon: Users, page: "UserManagement", adminOnly: true },
  { name: "Organization Setup", icon: Users, page: "OrganizationSetup", adminOnly: true },
];

export default function Layout({ children, currentPageName }) {
  const { permissions } = usePermissions();
  const { showTour, currentStep, completeTour, skipTour, nextStep } = useTour();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex">
      <DisclaimerDialog />
      <PWAInstallPrompt />
      {showTour && (
        <OnboardingFlow
          onComplete={completeTour}
          onSkip={skipTour}
        />
      )}
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-60 bg-white dark:bg-slate-900 border-r border-slate-100 dark:border-slate-800 fixed h-full z-30">
        <div className="p-5 border-b border-slate-100 dark:border-slate-800">
          <Link
            to={createPageUrl("Dashboard")}
            className="flex items-center gap-2.5 hover:opacity-80 transition-opacity"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center">
              <ShieldCheck className="w-4.5 h-4.5 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">Package Manufacturing</h1>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">Compliance Tracker</p>
            </div>
          </Link>
        </div>
        <nav className="flex-1 p-3 overflow-y-auto">
          {NAV_ITEMS.filter(item => !item.adminOnly || permissions.canManageUsers).map(item => {
            const active = currentPageName === item.page;
            return (
              <Link
                key={item.page}
                to={createPageUrl(item.page)}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors mb-1 select-none min-h-[44px]
                  ${active
                    ? "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400"
                    : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-slate-300"
                  }`}
              >
                <item.icon className={`w-4 h-4 ${active ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400 dark:text-slate-500"}`} />
                {item.name}
              </Link>
            );
          })}
        </nav>

        {/* Back to Dashboard Button */}
        {currentPageName !== "Dashboard" && (
          <div className="p-3 border-t border-slate-100 dark:border-slate-800">
            <Link
              to={createPageUrl("Dashboard")}
              className="w-full flex items-center justify-center gap-2 px-4 py-3.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 text-sm font-medium hover:bg-emerald-100 dark:hover:bg-emerald-900/30 transition-colors select-none min-h-[44px]"
              title="Return to Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </Link>
          </div>
        )}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <NotificationBell />
            <button
              onClick={() => base44.auth.logout()}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-500 dark:text-slate-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-600 dark:hover:text-red-400 transition-colors min-h-[44px]"
              title="Log out"
            >
              <LogOut className="w-4 h-4" />
              Log out
            </button>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger className="w-full select-none">
              <div className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors min-h-[44px]">
                <span className="text-xs font-medium text-slate-600 dark:text-slate-400">Monitoring Tools</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
              </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-52">
              <DropdownMenuItem asChild>
                <Link to={createPageUrl("ActivityMonitor")} className="cursor-pointer">
                  <Activity className="w-4 h-4 mr-2" />
                  Activity Monitor
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to={createPageUrl("Dashboard")} className="cursor-pointer">
                  <LayoutDashboard className="w-4 h-4 mr-2" />
                  Compliance Dashboard
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* Trial Banner */}
      <div className="fixed top-0 left-0 right-0 z-50">
        <TrialBanner />
      </div>

      {/* Mobile Header */}
      <MobileHeader currentPageName={currentPageName} />

      {/* Content */}
      <main
        className="flex-1 lg:ml-60 lg:pt-0 lg:pb-0 overscroll-none"
        style={{
          paddingTop: 'calc(3.5rem + env(safe-area-inset-top, 0px))',
          paddingBottom: 'calc(5rem + env(safe-area-inset-bottom, 0px))',
        }}
      >
        <style>{`@media (min-width: 1024px) { main { padding-top: 0 !important; padding-bottom: 0 !important; } }`}</style>
        <div className="max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPageName}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>


      {/* Mobile Bottom Tab Bar */}
      <BottomTabBar currentPageName={currentPageName} />

      {/* Offline Indicator */}
      <OfflineIndicator />

      {/* Footer */}
      <footer className="hidden lg:block lg:ml-60 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 py-4 px-6 w-full">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            © {new Date().getFullYear()} Package Manufacturing Compliance Tracker
          </p>
          <Link to={createPageUrl("PrivacyPolicy")} className="text-xs text-slate-600 dark:text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors select-none whitespace-nowrap">
            Privacy Policy
          </Link>
        </div>
      </footer>
    </div>
  );
}