import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Shield,
  FileText,
  CheckCircle2,
  Printer,
  ChevronDown,
  ChevronUp,
  ClipboardList,
  Truck,
  Users,
  AlertTriangle,
  Lock,
  Building2,
  Pen,
} from "lucide-react";
import SLASigningWorkflow from "@/components/signatures/SLASigningWorkflow";

const SLA_DATE = "19 February 2026";
const SLA_REV = "Rev 5";

const sections = [
  {
    id: "preamble",
    icon: Building2,
    title: "1. Preamble & Scope",
    content: (
      <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
        <p>
          <strong>Package Manufacturing Compliance Tracker</strong> ("the Platform", "Service Provider") is committed to
          supporting the manufacture, storage and dispatch of primary and secondary packaging to the food, beverage,
          pharmaceutical and retail market sectors. The Platform's primary objective is to ensure that products are
          manufactured safely, are legally compliant, and have been produced in accordance with relevant quality
          assurance standards aligned with <strong>FSSC 22000 / ISO 22000 / BRCGS</strong>.
        </p>
        <p>
          This Service Level Agreement ("SLA") sets out the obligations, expectations and standards applicable between
          the Platform and the Customer (Approved Supplier / Transporter / Service Provider) in relation to the use of
          the Package Manufacturing Compliance Tracker system.
        </p>
        <p>
          The Platform enacts a Food Safety Program inclusive of Food Security, Food Defence and Food Fraud programs,
          which are compulsory in terms of BRCGS Certification. The requirements of this document communicate delivery
          and service expectations, and are fundamental to the development of these programs.
        </p>
      </div>
    ),
  },
  {
    id: "platform_services",
    icon: Shield,
    title: "2. Platform Services & Uptime",
    content: (
      <div className="space-y-4 text-sm text-slate-700">
        <p>The Service Provider agrees to deliver the following services to the Customer:</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { label: "System Availability", value: "99.5% uptime (excluding scheduled maintenance)" },
            { label: "Scheduled Maintenance", value: "Communicated ≥ 24 hours in advance" },
            { label: "Critical Bug Response", value: "Within 4 business hours" },
            { label: "General Support Response", value: "Within 1 business day" },
            { label: "Data Backup Frequency", value: "Daily automated backups" },
            { label: "Data Retention", value: "Minimum 7 years (food safety compliance)" },
          ].map((item) => (
            <div key={item.label} className="flex justify-between items-start bg-slate-50 rounded-lg p-3">
              <span className="font-medium text-slate-600 text-xs">{item.label}</span>
              <span className="text-xs text-slate-800 text-right ml-2 max-w-[55%]">{item.value}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-500 italic">
          The Platform provides compliance management, risk assessment, document control, audit trails, supplier
          self-assessments, and real-time notifications as part of the standard service offering.
        </p>
      </div>
    ),
  },
  {
    id: "quality_requirements",
    icon: ClipboardList,
    title: "3. Quality & Food Safety Requirements",
    content: (
      <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
        <p>
          Customers using the Platform to manage supplier and service provider relationships must ensure that all
          Approved Suppliers consistently meet the following standards:
        </p>
        <ul className="space-y-2">
          {[
            "Maintain all applicable licences, site registrations, certifications and permits required to supply goods and services.",
            "Immediately notify the end user of any incident, contamination event, product safety concern or withdrawal/recall that may impact products supplied.",
            "Demonstrate a positive food safety and quality culture, including employee awareness, risk reporting and management commitment.",
            "Notify the end user of any significant Health Authority Inspections and regulatory issues related to products supplied.",
            "Provide written notification in advance of any proposed changes to specifications, test methods, suppliers, materials, chemicals, manufacturing processes or equipment.",
            "Establish and maintain documented Quality Controls covering GMP, Good Documentation Practices, Data Integrity, Training & Evaluation, and Effective Traceability programmes.",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "audit",
    icon: FileText,
    title: "4. Audit & Verification",
    content: (
      <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
        <p>
          The end user may request on-site audits, remote audits, or supporting documentation from Approved Suppliers,
          Transporters and Service Providers at any time to verify compliance with this Agreement and applicable food
          safety requirements.
        </p>
        <p>
          The Platform provides built-in audit trail functionality, AI-assisted compliance audits, and document
          management to facilitate these verification activities. All audit records generated through the Platform are
          treated as controlled documents.
        </p>
        <ul className="space-y-2">
          {[
            "Customers must retain audit records for a minimum period of 3 years.",
            "All audit findings must be actioned within the timeframes specified in the corrective action plan.",
            "Non-conformances identified during audits shall be formally logged and tracked to closure through the Platform's Action Items module.",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "delivery",
    icon: Truck,
    title: "5. Delivery Vehicles & Logistics",
    content: (
      <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
        <p>
          Where applicable, Customers managing logistics-related suppliers must enforce the following vehicle and
          delivery requirements:
        </p>
        <ul className="space-y-2">
          {[
            "All delivery vehicles must be weather-tight and roadworthy at all times.",
            "Materials shall be transported in a manner that protects the integrity of the material against damage, adverse weather and contamination.",
            "All vehicles shall be acceptable for transporting food-contact packaging and shall be clean, dry and free of any contamination or off odours.",
            "No food, allergens, chemicals or detergents shall be transported in the same vehicle as end-user packaging.",
            "Raw materials and packaging must be delivered in locked vehicles using padlocks or tamper-evident seals; seal numbers must be recorded on shipping documents.",
            "Pallets must be properly wrapped. Vehicles will be inspected prior to loading/offloading; non-compliant vehicles will be refused and a non-conformance issued.",
            "Drivers shall maintain vehicles in a clean and hygienic condition; cleaning records must be available upon request.",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "contractors",
    icon: Users,
    title: "6. Service Providers & Contractors",
    content: (
      <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
        <p>All contractors and service providers accessing end-user facilities must comply with the following:</p>
        <ul className="space-y-2">
          {[
            "Report to End User Reception or Security upon arrival and identify the responsible manager for the visit.",
            "Wear correct PPE (hair net, earplugs, disposable dust coat) when entering production areas.",
            "Complete the Visitors Indemnity Form (6.4.2) prior to accessing the production facility.",
            "Present the company Safety File to the SHE Manager and complete the 37.2 Agreement.",
            "Subcontracting is prohibited without the express written approval of the end user.",
            "Inform the end user of any changes that may impact the quality of products or services provided.",
            "Induction Training must be completed before any visit to the production area.",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "data_security",
    icon: Lock,
    title: "7. Data Security & Confidentiality",
    content: (
      <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
        <p>
          The Platform handles sensitive compliance data, proprietary formulations, audit results and supplier
          information. Both parties agree to the following:
        </p>
        <ul className="space-y-2">
          {[
            "All data submitted to the Platform remains the property of the Customer and will not be shared with third parties without written consent.",
            "The Platform implements role-based access controls, audit trails for all data access, and encrypted storage.",
            "Customers are responsible for maintaining secure credentials and managing user access through the Platform's User Management module.",
            "Proprietary supplier documents shared through the Platform are subject to confidentiality obligations and tracked via the Proprietary Sharing module.",
            "In the event of a data breach, the Service Provider will notify affected Customers within 72 hours.",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    ),
  },
  {
    id: "non_conformance",
    icon: AlertTriangle,
    title: "8. Non-Conformance & Escalation",
    content: (
      <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
        <p>
          Any non-conformance with this Agreement shall be formally documented, tracked and resolved as follows:
        </p>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100">
                <th className="text-left p-2 border border-slate-200 font-semibold">Severity</th>
                <th className="text-left p-2 border border-slate-200 font-semibold">Initial Response</th>
                <th className="text-left p-2 border border-slate-200 font-semibold">Resolution Target</th>
                <th className="text-left p-2 border border-slate-200 font-semibold">Consequence</th>
              </tr>
            </thead>
            <tbody>
              {[
                { severity: "Critical", badge: "critical", response: "Immediate (same day)", resolution: "48 hours", consequence: "Suspension of approval" },
                { severity: "High", badge: "high", response: "Within 4 hours", resolution: "5 business days", consequence: "Formal warning issued" },
                { severity: "Medium", badge: "medium", response: "Within 1 business day", resolution: "14 business days", consequence: "Corrective action required" },
                { severity: "Low", badge: "low", response: "Within 3 business days", resolution: "30 business days", consequence: "Observation logged" },
              ].map((row) => (
                <tr key={row.severity} className="even:bg-slate-50">
                  <td className="p-2 border border-slate-200">
                    <Badge className={`text-[10px] ${
                      row.badge === "critical" ? "bg-red-100 text-red-700" :
                      row.badge === "high" ? "bg-orange-100 text-orange-700" :
                      row.badge === "medium" ? "bg-yellow-100 text-yellow-700" :
                      "bg-slate-100 text-slate-600"
                    }`}>{row.severity}</Badge>
                  </td>
                  <td className="p-2 border border-slate-200">{row.response}</td>
                  <td className="p-2 border border-slate-200">{row.resolution}</td>
                  <td className="p-2 border border-slate-200">{row.consequence}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    ),
  },
  {
    id: "termination",
    icon: FileText,
    title: "9. Termination & Review",
    content: (
      <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
        <ul className="space-y-2">
          {[
            "This Agreement is reviewed annually or upon any significant change to food safety regulations or Platform capabilities.",
            "Either party may terminate this Agreement with 30 days' written notice.",
            "Immediate termination may be enacted in the event of a critical food safety incident, wilful non-compliance, or fraudulent activity.",
            "Upon termination, the Customer's data will be made available for export for a period of 30 days, after which it will be securely deleted.",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    ),
  },
];

function SectionCard({ section }) {
  const [open, setOpen] = useState(true);
  const Icon = section.icon;
  return (
    <Card className="border border-slate-200">
      <button
        className="w-full text-left"
        onClick={() => setOpen((v) => !v)}
      >
        <CardHeader className="py-4 px-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center">
                <Icon className="w-4 h-4 text-emerald-600" />
              </div>
              <CardTitle className="text-sm font-semibold text-slate-800">{section.title}</CardTitle>
            </div>
            {open ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
          </div>
        </CardHeader>
      </button>
      {open && (
        <CardContent className="px-6 pb-6 pt-0">
          {section.content}
        </CardContent>
      )}
    </Card>
  );
}

export default function ServiceLevelAgreement() {
  const [showSigningDialog, setShowSigningDialog] = useState(false);
  const handlePrint = () => window.print();

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <SLASigningWorkflow open={showSigningDialog} onClose={() => setShowSigningDialog(false)} />

        {/* Header */}
        <Card className="border-0 shadow-sm bg-gradient-to-br from-emerald-700 to-emerald-900 text-white">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-6 h-6 text-emerald-300" />
                  <span className="text-emerald-200 text-sm font-medium uppercase tracking-wider">
                    Approved Suppliers / Transporters / Service Providers
                  </span>
                </div>
                <h1 className="text-2xl md:text-3xl font-bold leading-tight">
                  Service Level Agreement
                </h1>
                <p className="text-emerald-200 mt-2 text-sm">
                  Package Manufacturing Compliance Tracker Platform
                </p>
              </div>
              <div className="flex flex-col items-start md:items-end gap-2 shrink-0">
                <Badge className="bg-emerald-600 text-white border-0">{SLA_REV}</Badge>
                <span className="text-emerald-200 text-xs">{SLA_DATE}</span>
                <div className="flex gap-2 flex-col sm:flex-row">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handlePrint}
                    className="bg-white/10 border-white/30 text-white hover:bg-white/20 gap-1.5"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Print
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => setShowSigningDialog(true)}
                    className="bg-white text-emerald-700 hover:bg-slate-100 gap-1.5 font-semibold"
                  >
                    <Pen className="w-3.5 h-3.5" />
                    Sign Now
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Alert Banner */}
        <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-lg p-4">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <p className="text-sm text-amber-800">
            As an Approved Supplier to the end user, it is the Supplier's responsibility to meet or exceed all
            expectations set out in this Agreement. Non-compliance may result in suspension or removal from the
            Approved Supplier list.
          </p>
        </div>

        {/* Sections */}
        <div className="space-y-4">
          {sections.map((section) => (
            <SectionCard key={section.id} section={section} />
          ))}
        </div>

        {/* Declaration */}
        <Card className="border-2 border-emerald-200 bg-emerald-50">
          <CardHeader>
            <CardTitle className="text-base text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              Approved Suppliers / Transporters / Service Providers Declaration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-slate-700">
              The undersigned Company hereby acknowledges and agrees that:
            </p>
            <ul className="space-y-2 text-sm text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                All goods and services supplied will conform with the aforementioned food safety and security
                procedures unless otherwise agreed to in writing and in advance by the Customer.
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                They will immediately inform the end user (and confirm in writing) if they become aware of any error
                or omission in terms of the food safety and security procedures.
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                They will inform the end user in writing and in advance of any change to the food safety and security
                procedures provided herein.
              </li>
            </ul>

            <Separator className="my-4" />

            <div className="bg-slate-100 border border-slate-300 rounded-lg p-4 text-center">
              <p className="text-sm text-slate-700 mb-4">
                <strong>Sign this agreement digitally</strong> to create a tamper-evident, timestamped record stored in the system.
              </p>
              <Button
                onClick={() => setShowSigningDialog(true)}
                className="bg-emerald-600 hover:bg-emerald-700 gap-2 px-6"
              >
                <Pen className="w-4 h-4" />
                Open Digital Signing Workflow
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              {[
                "Company Name",
                "Name & Surname",
                "Position / Title",
                "Date",
                "Signature",
                "On behalf of (Company Name)",
              ].map((field) => (
                <div key={field} className="space-y-1">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide">{field}</label>
                  <div className="border-b-2 border-slate-300 pb-1 min-h-[28px]" />
                </div>
              ))}
            </div>

            <div className="mt-4 pt-4 border-t border-emerald-200">
              <p className="text-xs text-slate-500 text-center">
                Approved by: Package Manufacturing Compliance Tracker · {SLA_REV} · {SLA_DATE}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <style>{`
        @media print {
          body * { visibility: hidden; }
          .max-w-4xl, .max-w-4xl * { visibility: visible; }
          .max-w-4xl { position: absolute; left: 0; top: 0; width: 100%; }
          button { display: none !important; }
        }
      `}</style>
    </div>
  );
}