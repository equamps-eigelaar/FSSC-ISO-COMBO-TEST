import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Plus, Bell } from "lucide-react";
import PlanCard from "@/components/pricing/PlanCard";
import PlanFormDialog from "@/components/pricing/PlanFormDialog";
import CreateInvoiceDialog from "@/components/pricing/CreateInvoiceDialog";
import MySubscriptionCard from "@/components/pricing/MySubscriptionCard";
import { usePermissions } from "@/components/permissions/usePermissions";
import { toast } from "sonner";

export default function PricingPlans() {
  const { isAdmin, loading: permLoading, user } = usePermissions();
  const [billingCycle, setBillingCycle] = useState("monthly");
  const [showForm, setShowForm] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [invoicePlan, setInvoicePlan] = useState(null);
  const queryClient = useQueryClient();

  const { data: mySubscription } = useQuery({
    queryKey: ["my-subscription", user?.email],
    queryFn: () => base44.entities.Subscription.filter({ user_email: user?.email }),
    enabled: !!user?.email && !isAdmin,
    select: (data) => data[0] || null,
  });

  const { data: plans = [] } = useQuery({
    queryKey: ["price-plans"],
    queryFn: () => base44.entities.PricePlan.list("sort_order", 50),
  });

  const visiblePlans = plans.filter((p) => p.is_active);

  const handleEdit = (plan) => {
    setEditingPlan(plan);
    setShowForm(true);
  };

  const handleNew = () => {
    setEditingPlan(null);
    setShowForm(true);
  };

  const handleSelect = (plan) => {
    if (isAdmin) {
      setEditingPlan(plan);
      setShowForm(true);
    } else {
      // Non-admin: show subscription/contact action
      toast.info(`To subscribe to the ${plan.name} plan, please contact your administrator.`);
    }
  };

  const handleSendRenewalReminders = async () => {
    try {
      const subs = await base44.entities.Subscription.filter({});
      const now = new Date();
      const soon = new Date(now);
      soon.setDate(soon.getDate() + 7);

      const expiring = subs.filter(s => {
        if (s.status === "trialing" && s.trial_end_date) {
          const end = new Date(s.trial_end_date);
          return end >= now && end <= soon;
        }
        if (s.status === "active" && s.next_billing_date) {
          const next = new Date(s.next_billing_date);
          return next >= now && next <= soon;
        }
        return false;
      });

      if (expiring.length === 0) {
        toast.info("No expiring subscriptions in the next 7 days.");
        return;
      }

      for (const sub of expiring) {
        const isTrialing = sub.status === "trialing";
        const endDate = isTrialing ? sub.trial_end_date : sub.next_billing_date;
        await base44.integrations.Core.SendEmail({
          to: sub.user_email,
          subject: isTrialing
            ? "Your FSSC 22000 Compliance free trial is ending soon"
            : "Your FSSC 22000 Compliance subscription is due for renewal",
          body: isTrialing
            ? `Hi,\n\nYour 7-day free trial expires on ${endDate}. Subscribe now to keep full access to FSSC 22000 Compliance Monitoring.\n\nThank you.`
            : `Hi,\n\nYour subscription (${sub.plan_name || "compliance plan"}) is due for renewal on ${endDate}. Please ensure your payment is up to date.\n\nThank you.`,
        });
      }
      toast.success(`Renewal reminders sent to ${expiring.length} user(s).`);
    } catch (e) {
      toast.error("Failed to send reminders: " + e.message);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">

        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="bg-emerald-100 text-emerald-700 mb-4 text-xs font-semibold px-3 py-1">
            Pricing
          </Badge>
          <h1 className="text-4xl font-extrabold text-slate-900 mb-4">
            Simple, transparent pricing
          </h1>
          <p className="text-lg text-slate-500 max-w-xl mx-auto">
            Choose the plan that fits your operational compliance needs. No hidden fees.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-3 mt-8">
            <span className={`text-sm font-medium ${billingCycle === "monthly" ? "text-slate-900" : "text-slate-400"}`}>
              Monthly
            </span>
            <Switch
              checked={billingCycle === "annual"}
              onCheckedChange={(v) => setBillingCycle(v ? "annual" : "monthly")}
            />
            <span className={`text-sm font-medium ${billingCycle === "annual" ? "text-slate-900" : "text-slate-400"}`}>
              Annual
            </span>
            {billingCycle === "annual" && (
              <Badge className="bg-emerald-100 text-emerald-700 text-xs">Save 15%</Badge>
            )}
          </div>
        </div>

        {/* Admin toolbar */}
        {isAdmin && (
          <div className="flex justify-end mb-6 gap-2 flex-wrap">
            <Button onClick={handleSendRenewalReminders} size="sm" variant="outline">
              <Bell className="w-4 h-4 mr-1" /> Send Renewal Reminders
            </Button>
            <Button onClick={handleNew} size="sm" className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="w-4 h-4 mr-1" /> Add Plan
            </Button>
          </div>
        )}

        {/* My Subscription (non-admin users) */}
        {!isAdmin && !permLoading && (
          <div className="max-w-md mx-auto mb-10">
            <MySubscriptionCard user={user} plans={visiblePlans} />
          </div>
        )}

        {/* Plans Grid */}
        {visiblePlans.length === 0 ? (
          <div className="text-center py-16 text-slate-500">
            <p className="mb-4">No pricing plans configured yet.</p>
            {isAdmin && (
              <Button onClick={handleNew} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-1" /> Create First Plan
              </Button>
            )}
          </div>
        ) : (
          <div className={`grid gap-6 ${visiblePlans.length === 1 ? "max-w-sm mx-auto" : visiblePlans.length === 2 ? "grid-cols-1 md:grid-cols-2 max-w-3xl mx-auto" : "grid-cols-1 md:grid-cols-3"}`}>
            {visiblePlans.map((plan) => (
              <PlanCard
                key={plan.id}
                plan={plan}
                billingCycle={billingCycle}
                isAdmin={isAdmin}
                onSelect={() => handleSelect(plan)}
                onCreateInvoice={isAdmin ? (p) => setInvoicePlan(p) : null}
                currentSubscription={!isAdmin ? mySubscription : null}
              />
            ))}
          </div>
        )}

        {/* Footer note */}
        <p className="text-center text-xs text-slate-400 mt-10">
          Prices in ZAR for local clients · International clients (UK, AU, US) billed in USD/GBP via Wise.com · VAT may apply · Invoiced via Xero
        </p>
      </div>

      {/* Dialogs */}
      <PlanFormDialog
        open={showForm}
        onClose={() => setShowForm(false)}
        plan={editingPlan}
        onSaved={() => queryClient.invalidateQueries({ queryKey: ["price-plans"] })}
      />

      <CreateInvoiceDialog
        open={!!invoicePlan}
        onClose={() => setInvoicePlan(null)}
        plan={invoicePlan}
      />
    </div>
  );
}