import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Plus, Search, Filter, Download, Pen } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AllergenControlDialog from "@/components/food/AllergenControlDialog";
import SignFormDialog from "@/components/signatures/SignFormDialog";

export default function AllergenControl() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingAllergen, setEditingAllergen] = useState(null);
  const [showSignDialog, setShowSignDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const queryClient = useQueryClient();

  const { data: allergens = [], isLoading } = useQuery({
    queryKey: ["allergen-controls"],
    queryFn: () => base44.entities.AllergenControl.list("-created_date", 100),
  });

  const { data: rawMaterials = [] } = useQuery({
    queryKey: ["raw-material-batches"],
    queryFn: () => base44.entities.RawMaterialBatch.list("-created_date", 200),
  });

  const downloadDeclaration = () => {
    const date = new Date().toLocaleDateString("en-ZA");
    const orgName = "Package Manufacturing Facility";

    // Build allergen summary from allergen controls
    const allergenRows = allergens.map(a => [
      a.allergen_type.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
      a.product_line || "—",
      a.segregation_method.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
      (a.control_measures || []).join("; ") || "—",
      a.status.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
      a.risk_level.replace(/\b\w/g, c => c.toUpperCase()),
    ]);

    // Raw material allergen summary
    const matRows = rawMaterials.slice(0, 50).map(m => [
      m.material_name || "—",
      m.supplier || "—",
      m.batch_number || "—",
      m.status.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
      m.expiry_date ? new Date(m.expiry_date).toLocaleDateString("en-ZA") : "—",
    ]);

    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>Allergen Control Declaration</title>
  <style>
    body { font-family: Arial, sans-serif; color: #1e293b; margin: 40px; font-size: 12px; }
    h1 { font-size: 20px; color: #065f46; margin-bottom: 4px; }
    h2 { font-size: 14px; color: #065f46; margin-top: 28px; margin-bottom: 8px; border-bottom: 1px solid #d1fae5; padding-bottom: 4px; }
    .meta { color: #64748b; font-size: 11px; margin-bottom: 24px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    th { background: #ecfdf5; color: #065f46; padding: 8px; text-align: left; font-size: 11px; }
    td { padding: 7px 8px; border-bottom: 1px solid #f1f5f9; font-size: 11px; }
    tr:nth-child(even) td { background: #f8fafc; }
    .footer { margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 16px; color: #94a3b8; font-size: 10px; }
    .sig { margin-top: 40px; display: flex; gap: 80px; }
    .sig-box { border-top: 1px solid #334155; padding-top: 8px; min-width: 180px; font-size: 11px; color: #475569; }
  </style>
</head>
<body>
  <h1>Allergen Control Declaration</h1>
  <div class="meta">
    <strong>${orgName}</strong> &nbsp;|&nbsp; Generated: ${date} &nbsp;|&nbsp; FSSC 22000 / TS 22002-4 Compliance
  </div>

  <h2>1. Allergen Control Matrix</h2>
  <table>
    <thead><tr>
      <th>Allergen</th><th>Product Line</th><th>Segregation Method</th><th>Control Measures</th><th>Status</th><th>Risk Level</th>
    </tr></thead>
    <tbody>
      ${allergenRows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="6" style="text-align:center;color:#94a3b8">No allergen control records found</td></tr>`}
    </tbody>
  </table>

  <h2>2. Raw Material Allergen Traceability</h2>
  <table>
    <thead><tr>
      <th>Material Name</th><th>Supplier</th><th>Batch No.</th><th>Status</th><th>Expiry Date</th>
    </tr></thead>
    <tbody>
      ${matRows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="5" style="text-align:center;color:#94a3b8">No raw material records found</td></tr>`}
    </tbody>
  </table>

  <div class="sig">
    <div class="sig-box">Quality Manager Signature<br/><br/><br/>Name: ________________<br/>Date: ________________</div>
    <div class="sig-box">Approved By<br/><br/><br/>Name: ________________<br/>Date: ________________</div>
  </div>

  <div class="footer">This document is generated from live compliance data. It is valid only at the time of generation. Retain as part of your FSSC 22000 documentation records.</div>
</body>
</html>`;

    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Allergen_Control_Declaration_${date.replace(/\//g, "-")}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredAllergens = allergens.filter(allergen => {
    const matchesSearch = allergen.allergen_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      allergen.product_line?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || allergen.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusColors = {
    controlled: "bg-emerald-50 text-emerald-700 border-emerald-200",
    under_review: "bg-amber-50 text-amber-700 border-amber-200",
    action_required: "bg-red-50 text-red-700 border-red-200",
  };

  const riskColors = {
    low: "bg-blue-50 text-blue-700 border-blue-200",
    medium: "bg-yellow-50 text-yellow-700 border-yellow-200",
    high: "bg-orange-50 text-orange-700 border-orange-200",
    critical: "bg-red-50 text-red-700 border-red-200",
  };

  const handleEdit = (allergen) => {
    setEditingAllergen(allergen);
    setShowDialog(true);
  };

  const handleClose = () => {
    setShowDialog(false);
    setEditingAllergen(null);
  };

  if (isLoading) {
    return <div className="p-6 text-slate-500">Loading allergen controls...</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Allergen Control</h1>
            <p className="text-slate-600 mt-1">Manage allergen segregation and control measures</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={downloadDeclaration}>
              <Download className="w-4 h-4 mr-2" />
              Download Declaration
            </Button>
            <Button variant="outline" onClick={() => setShowSignDialog(true)} className="border-emerald-300 text-emerald-700 hover:bg-emerald-50">
              <Pen className="w-4 h-4 mr-2" />
              Sign Declaration
            </Button>
            <Button onClick={() => setShowDialog(true)} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Allergen Control
            </Button>
          </div>
        </div>

        <div className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search allergens or product lines..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="controlled">Controlled</SelectItem>
              <SelectItem value="under_review">Under Review</SelectItem>
              <SelectItem value="action_required">Action Required</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4">
          {filteredAllergens.map((allergen) => (
            <Card key={allergen.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleEdit(allergen)}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="w-5 h-5 text-amber-600" />
                      <CardTitle className="text-xl capitalize">
                        {allergen.allergen_type.replace(/_/g, " ")}
                      </CardTitle>
                    </div>
                    <p className="text-sm text-slate-600">{allergen.product_line}</p>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="outline" className={statusColors[allergen.status]}>
                      {allergen.status.replace(/_/g, " ")}
                    </Badge>
                    <Badge variant="outline" className={riskColors[allergen.risk_level]}>
                      {allergen.risk_level} risk
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs font-medium text-slate-500 mb-1">Segregation Method</p>
                    <p className="text-sm text-slate-900 capitalize">{allergen.segregation_method.replace(/_/g, " ")}</p>
                  </div>
                  {allergen.control_measures?.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-slate-500 mb-1">Control Measures</p>
                      <div className="flex flex-wrap gap-1">
                        {allergen.control_measures.slice(0, 3).map((measure, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">{measure}</Badge>
                        ))}
                        {allergen.control_measures.length > 3 && (
                          <Badge variant="outline" className="text-xs">+{allergen.control_measures.length - 3} more</Badge>
                        )}
                      </div>
                    </div>
                  )}
                  {allergen.last_verification_date && (
                    <p className="text-xs text-slate-500">
                      Last verified: {new Date(allergen.last_verification_date).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredAllergens.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <AlertTriangle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">No allergen controls found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {showDialog && (
        <AllergenControlDialog
          open={showDialog}
          onClose={handleClose}
          allergen={editingAllergen}
        />
      )}

      <SignFormDialog
        open={showSignDialog}
        onClose={() => setShowSignDialog(false)}
        formKey="allergen_declaration"
        formTitle="Allergen Control Declaration"
      />
    </div>
  );
}