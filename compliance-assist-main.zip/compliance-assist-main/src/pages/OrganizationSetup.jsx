import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Building2, CheckCircle2, AlertTriangle, Loader2, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

export default function OrganizationSetup() {
  const [user, setUser] = useState(null);
  const [orgs, setOrgs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [migrating, setMigrating] = useState(false);
  const [migrationResults, setMigrationResults] = useState(null);
  const [orgName, setOrgName] = useState("");
  const [selectedOrgId, setSelectedOrgId] = useState("");
  const [step, setStep] = useState("select"); // select | migrate | done

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.Organization.list("-created_date", 100),
    ]).then(([u, o]) => {
      setUser(u);
      setOrgs(o);
      if (u?.organization_id) setSelectedOrgId(u.organization_id);
      setLoading(false);
    });
  }, []);

  const handleCreateOrg = async () => {
    if (!orgName.trim()) return;
    setCreating(true);
    try {
      const org = await base44.entities.Organization.create({ name: orgName.trim(), is_active: true });
      setOrgs(prev => [org, ...prev]);
      setSelectedOrgId(org.id);
      setOrgName("");
      toast.success("Organization created");
    } catch (e) {
      toast.error("Failed to create organization");
    }
    setCreating(false);
  };

  const handleMigrate = async () => {
    if (!selectedOrgId) return;
    setMigrating(true);
    try {
      const res = await base44.functions.invoke("migrateOrganizationData", { organization_id: selectedOrgId });
      setMigrationResults(res.data.results);
      setStep("done");
      toast.success("Migration complete!");
    } catch (e) {
      toast.error("Migration failed: " + e.message);
    }
    setMigrating(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-2xl mx-auto px-4 py-10 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Organization Setup</h1>
            <p className="text-sm text-slate-500 dark:text-slate-400">Configure multi-tenant isolation for your data</p>
          </div>
        </div>

        {step === "done" ? (
          <Card className="border-0 shadow-sm dark:bg-slate-900">
            <CardContent className="py-10 text-center space-y-4">
              <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
              <h2 className="text-xl font-semibold text-slate-800 dark:text-white">Migration Complete</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">All existing records have been assigned to your organization.</p>
              {migrationResults && (
                <div className="text-left max-w-sm mx-auto space-y-1 mt-4">
                  {Object.entries(migrationResults).map(([entity, result]) => (
                    <div key={entity} className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
                      <span>{entity}</span>
                      {result.error ? (
                        <Badge variant="destructive" className="text-[10px]">Error</Badge>
                      ) : (
                        <Badge className="text-[10px] bg-emerald-100 text-emerald-700">{result.migrated} migrated</Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
              <Button
                className="bg-emerald-600 hover:bg-emerald-700 mt-4"
                onClick={() => window.location.href = createPageUrl("Dashboard")}
              >
                Go to Dashboard <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Create new org */}
            <Card className="border-0 shadow-sm dark:bg-slate-900">
              <CardHeader>
                <CardTitle className="text-base dark:text-white">Create a New Organization</CardTitle>
              </CardHeader>
              <CardContent className="flex gap-3">
                <Input
                  placeholder="e.g. Acme Packaging Ltd"
                  value={orgName}
                  onChange={e => setOrgName(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleCreateOrg()}
                  className="dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
                <Button onClick={handleCreateOrg} disabled={creating || !orgName.trim()} className="shrink-0 bg-emerald-600 hover:bg-emerald-700">
                  {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : "Create"}
                </Button>
              </CardContent>
            </Card>

            {/* Select org */}
            {orgs.length > 0 && (
              <Card className="border-0 shadow-sm dark:bg-slate-900">
                <CardHeader>
                  <CardTitle className="text-base dark:text-white">Select Organization</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {orgs.map(org => (
                    <button
                      key={org.id}
                      onClick={() => setSelectedOrgId(org.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg border text-left transition-all
                        ${selectedOrgId === org.id
                          ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20"
                          : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
                        }`}
                    >
                      <Building2 className={`w-5 h-5 ${selectedOrgId === org.id ? "text-emerald-600" : "text-slate-400"}`} />
                      <div className="flex-1">
                        <p className={`text-sm font-medium ${selectedOrgId === org.id ? "text-emerald-700 dark:text-emerald-400" : "text-slate-800 dark:text-white"}`}>{org.name}</p>
                        <p className="text-xs text-slate-400">{org.id}</p>
                      </div>
                      {selectedOrgId === org.id && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                    </button>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Migrate */}
            {selectedOrgId && (
              <Card className="border-0 shadow-sm dark:bg-slate-900 border-amber-200 dark:border-amber-800">
                <CardContent className="pt-5 space-y-4">
                  <div className="flex gap-3 p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-800">
                    <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-amber-800 dark:text-amber-300">Migrate Existing Records</p>
                      <p className="text-xs text-amber-700 dark:text-amber-400 mt-0.5">
                        All existing records without an organization will be assigned to the selected organization. This cannot be undone.
                      </p>
                    </div>
                  </div>
                  <Button
                    className="w-full bg-emerald-600 hover:bg-emerald-700 min-h-[44px]"
                    onClick={handleMigrate}
                    disabled={migrating}
                  >
                    {migrating ? (
                      <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Migrating...</>
                    ) : (
                      <>Migrate All Records to Selected Organization</>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}