import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  AlertTriangle,
  Clock,
  XCircle,
  CheckCircle2,
  FileText,
  Calendar,
  ChevronRight
} from "lucide-react";
import { format } from "date-fns";

export default function AuditPrep() {
  const { data: requirements = [] } = useQuery({
    queryKey: ['requirements-audit-prep'],
    queryFn: () => base44.entities.ComplianceRequirement.list('-created_date', 500)
  });

  const { data: documents = [] } = useQuery({
    queryKey: ['documents-audit-prep'],
    queryFn: () => base44.entities.Document.list('-created_date', 500)
  });

  const { data: risks = [] } = useQuery({
    queryKey: ['risks-audit-prep'],
    queryFn: () => base44.entities.RiskAssessment.list('-created_date', 500)
  });

  const { data: actions = [] } = useQuery({
    queryKey: ['actions-audit-prep'],
    queryFn: () => base44.entities.ActionItem.list('-created_date', 500)
  });

  // Calculate audit readiness
  const missing = requirements.filter(r => 
    !r.evidence_notes && !r.evidence_files?.length && r.status === 'not_started'
  );

  const overdue = requirements.filter(r => 
    r.due_date && new Date(r.due_date) < new Date() && r.status !== 'compliant'
  );

  const nonCompliant = requirements.filter(r => 
    r.status === 'non_compliant' || r.status === 'partial'
  );

  const expiringDocs = documents.filter(d => {
    if (!d.expiry_date) return false;
    const expiry = new Date(d.expiry_date);
    const today = new Date();
    const daysUntil = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    return daysUntil <= 30 && daysUntil >= 0;
  });

  const highRisks = risks.filter(r => 
    r.risk_level === 'high' || r.risk_level === 'critical'
  );

  const pendingActions = actions.filter(a => 
    a.status === 'pending' || a.status === 'blocked'
  );

  const stats = {
    readiness: Math.round((requirements.filter(r => r.status === 'compliant').length / requirements.length) * 100) || 0,
    missing: missing.length,
    overdue: overdue.length,
    nonCompliant: nonCompliant.length,
    expiringDocs: expiringDocs.length,
    highRisks: highRisks.length,
    pendingActions: pendingActions.length
  };

  const issues = [
    {
      title: "Missing Evidence",
      count: stats.missing,
      icon: FileText,
      color: "text-red-600",
      bgColor: "bg-red-50",
      items: missing.slice(0, 5),
      link: "Requirements"
    },
    {
      title: "Overdue Requirements",
      count: stats.overdue,
      icon: Clock,
      color: "text-amber-600",
      bgColor: "bg-amber-50",
      items: overdue.slice(0, 5),
      link: "Requirements"
    },
    {
      title: "Non-Compliant",
      count: stats.nonCompliant,
      icon: XCircle,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      items: nonCompliant.slice(0, 5),
      link: "Requirements"
    },
    {
      title: "High Priority Risks",
      count: stats.highRisks,
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-red-50",
      items: highRisks.slice(0, 5),
      link: "RiskWorkflow"
    },
    {
      title: "Expiring Documents",
      count: stats.expiringDocs,
      icon: Calendar,
      color: "text-amber-600",
      bgColor: "bg-amber-50",
      items: expiringDocs.slice(0, 5),
      link: "DocumentRepository"
    },
    {
      title: "Pending Actions",
      count: stats.pendingActions,
      icon: Clock,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      items: pendingActions.slice(0, 5),
      link: "ActionItems",
      renderItem: (item) => (
        <div className="flex items-start justify-between gap-2">
          <span className="truncate">{item.title}</span>
          {item.due_date && new Date(item.due_date) < new Date() && (
            <span className="shrink-0 text-[10px] text-rose-600 font-medium">overdue</span>
          )}
        </div>
      )
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Audit Preparation</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Everything an auditor needs to see
          </p>
        </div>

        {/* Readiness Score */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-6">
            <div className="flex flex-wrap items-center gap-6">
              <div className="relative">
                <svg className="w-24 h-24 transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="none"
                    className="text-slate-200 dark:text-slate-800"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={`${2 * Math.PI * 40}`}
                    strokeDashoffset={`${2 * Math.PI * 40 * (1 - stats.readiness / 100)}`}
                    className={stats.readiness >= 80 ? "text-emerald-600" : stats.readiness >= 60 ? "text-amber-600" : "text-red-600"}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-slate-900 dark:text-white">
                    {stats.readiness}%
                  </span>
                </div>
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-1">
                  Audit Readiness Score
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {stats.readiness >= 80 
                    ? "✓ Ready for audit" 
                    : stats.readiness >= 60 
                    ? "⚠ Some work needed" 
                    : "⚠ Critical gaps to address"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Issues Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {issues.map((issue, idx) => (
            <Card key={idx} className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`p-2 rounded-lg shrink-0 ${issue.bgColor}`}>
                      <issue.icon className={`w-5 h-5 ${issue.color}`} />
                    </div>
                    <CardTitle className="text-sm font-semibold truncate">{issue.title}</CardTitle>
                  </div>
                  <Badge variant={issue.count > 0 ? "destructive" : "secondary"} className="font-bold">
                    {issue.count}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {issue.count > 0 ? (
                  <div className="space-y-2">
                    {issue.items.map((item, itemIdx) => (
                      <div key={itemIdx} className="text-xs text-slate-600 dark:text-slate-400">
                        • {issue.renderItem ? issue.renderItem(item) : (item.clause_number || item.title || item.file_name || item.hazard_description)}
                      </div>
                    ))}
                    {issue.count > 5 && (
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        +{issue.count - 5} more
                      </div>
                    )}
                    <Link to={createPageUrl(issue.link)}>
                      <Button size="sm" variant="outline" className="w-full mt-2">
                        View All <ChevronRight className="w-3 h-3 ml-1" />
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-emerald-600 text-xs">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>All clear</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Pending Action Items Widget */}
        {pendingActions.length > 0 && (
          <Card className="border-0 shadow-sm mt-6">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-blue-50">
                    <Clock className="w-5 h-5 text-blue-600" />
                  </div>
                  <CardTitle className="text-sm font-semibold">Pending Action Items</CardTitle>
                </div>
                <Badge className="bg-blue-100 text-blue-700 font-bold">{pendingActions.length}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {pendingActions.slice(0, 8).map((action, idx) => {
                  const isOverdue = action.due_date && new Date(action.due_date) < new Date();
                  return (
                    <div key={idx} className={`flex items-center justify-between gap-3 p-2 rounded-lg ${isOverdue ? "bg-rose-50" : "bg-slate-50 dark:bg-slate-800"}`}>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate">{action.title}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          {action.clause_reference && (
                            <span className="text-[10px] text-slate-500">Clause {action.clause_reference}</span>
                          )}
                          {action.assigned_to && (
                            <span className="text-[10px] text-slate-400">{action.assigned_to}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {action.priority && (
                          <Badge variant="outline" className={`text-[10px] ${action.priority === "critical" ? "bg-rose-50 text-rose-700 border-rose-200" : action.priority === "high" ? "bg-orange-50 text-orange-700 border-orange-200" : "bg-slate-100 text-slate-600"}`}>
                            {action.priority}
                          </Badge>
                        )}
                        {action.due_date && (
                          <span className={`text-[10px] font-medium ${isOverdue ? "text-rose-600" : "text-slate-500"}`}>
                            {isOverdue ? "⚠ " : ""}{format(new Date(action.due_date), "MMM d")}
                          </span>
                        )}
                        <Badge className={`text-[10px] ${action.status === "blocked" ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-700"}`}>
                          {action.status?.replace(/_/g, " ")}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
                {pendingActions.length > 8 && (
                  <p className="text-xs text-slate-500 pl-2">+{pendingActions.length - 8} more items</p>
                )}
              </div>
              <Link to={createPageUrl("ActionItems")}>
                <Button size="sm" variant="outline" className="w-full mt-3">
                  Manage All Action Items <ChevronRight className="w-3 h-3 ml-1" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Quick Actions */}
        <Card className="border-0 shadow-sm mt-6">
          <CardHeader>
            <CardTitle className="text-sm font-semibold">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Link to={createPageUrl("ComplianceAudits")}>
                <Button variant="outline" className="w-full">
                  Run AI Audit
                </Button>
              </Link>
              <Link to={createPageUrl("DocumentRepository")}>
                <Button variant="outline" className="w-full">
                  Evidence Files
                </Button>
              </Link>
              <Link to={createPageUrl("DailyMonitoring")}>
                <Button variant="outline" className="w-full">
                  Monitoring Logs
                </Button>
              </Link>
              <Link to={createPageUrl("Analytics")}>
                <Button variant="outline" className="w-full">
                  View Reports
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}