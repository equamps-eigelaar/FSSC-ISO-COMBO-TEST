import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle2, AlertTriangle, Settings, Users, Lock, CreditCard } from "lucide-react";

export default function TenantSetupGuide() {
  const steps = [
    {
      icon: Settings,
      title: "1. Configure App Settings",
      description: "Set the app to private mode",
      details: [
        "Go to app Settings (admin only)",
        "Enable 'Private App' toggle",
        "This requires login for all pages",
      ],
    },
    {
      icon: CreditCard,
      title: "2. Set Up Stripe Payment",
      description: "Configure payment processing",
      details: [
        "Add STRIPE_API_KEY to environment variables",
        "Add STRIPE_WEBHOOK_SECRET for payment verification",
        "Create a price in Stripe dashboard (default: $99.99)",
        "Update the price ID in initiateAccessPayment function",
      ],
    },
    {
      icon: Users,
      title: "3. Review Access Requests",
      description: "Manage user signups and approvals",
      details: [
        "Users submit access requests with payment",
        "Check Access Requests page after payment",
        "Review, approve (sends invite), or reject each request",
        "Approved users get login credentials via email",
      ],
    },
    {
      icon: Lock,
      title: "4. Enforce Row-Level Security",
      description: "Ensure data isolation",
      details: [
        "All entities have RLS enabled by default",
        "Users can only see records they created",
        "Admins can view all records",
        "Each user gets their own isolated workspace",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-3">
          <h1 className="text-3xl font-bold text-slate-900">Multi-Tenant SaaS Setup</h1>
          <p className="text-slate-600">Your app is configured for secure multi-tenant operation</p>
        </div>

        {/* Architecture Overview */}
        <Card className="border-2 border-emerald-200 bg-emerald-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-emerald-800">
              <CheckCircle2 className="w-5 h-5" />
              Architecture Configured
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-slate-700">
            <p>✓ App is private — requires login for all access</p>
            <p>✓ New users submit access requests with payment via Stripe</p>
            <p>✓ You manually approve/reject requests after payment</p>
            <p>✓ Row-level security ensures each user only sees their own data</p>
            <p>✓ Admins have full visibility across all user data</p>
          </CardContent>
        </Card>

        {/* Setup Steps */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-slate-900">Setup Steps</h2>
          <div className="grid gap-4">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              return (
                <Card key={idx} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center shrink-0">
                        <Icon className="w-5 h-5 text-emerald-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-slate-900 mb-1">{step.title}</h3>
                        <p className="text-sm text-slate-600 mb-3">{step.description}</p>
                        <ul className="space-y-2 text-sm text-slate-700">
                          {step.details.map((detail, i) => (
                            <li key={i} className="flex items-start gap-2">
                              <span className="text-emerald-600 font-bold mt-0.5">•</span>
                              {detail}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Data Flow */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">User Onboarding Flow</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <Badge className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center p-0">1</Badge>
                <span>User accesses app → forced to login page</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center p-0">2</Badge>
                <span>User clicks "Request Access" → fills form with email, company, role</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center p-0">3</Badge>
                <span>User completes Stripe payment → access request marked "payment_complete"</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center p-0">4</Badge>
                <span>Admin reviews in Access Requests page → approves or rejects</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center p-0">5</Badge>
                <span>Admin approves → user gets invitation email + login credentials</span>
              </div>
              <div className="flex items-center gap-3">
                <Badge className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center p-0">6</Badge>
                <span>User logs in → only sees their own records (RLS enforced)</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Row-Level Security Details */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Row-Level Security (RLS)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <p className="text-slate-600">
              All your data entities automatically enforce RLS. Users can only access records they created:
            </p>
            <pre className="bg-slate-50 rounded-lg p-4 text-xs font-mono text-slate-700 overflow-auto">
{`// User can READ/UPDATE/DELETE only if:
"created_by": "{{user.email}}"

// Admins can READ/UPDATE/DELETE everything
"user_condition": {{"role": "admin"}}`}
            </pre>
            <p className="text-slate-600 pt-2">
              Update each entity's RLS rules to match this pattern for multi-tenant isolation.
            </p>
          </CardContent>
        </Card>

        {/* Environment Variables Required */}
        <Card className="border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2 text-amber-800">
              <AlertTriangle className="w-5 h-5" />
              Required Environment Variables
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="space-y-1">
              <p className="font-mono text-amber-900 bg-white rounded px-2 py-1">STRIPE_API_KEY</p>
              <p className="text-amber-800 text-xs">Your Stripe API secret key</p>
            </div>
            <div className="space-y-1">
              <p className="font-mono text-amber-900 bg-white rounded px-2 py-1">STRIPE_WEBHOOK_SECRET</p>
              <p className="text-amber-800 text-xs">Webhook signing secret for payment verification</p>
            </div>
            <p className="text-amber-800 text-xs pt-2">
              Add these in Settings → Environment Variables (admin only)
            </p>
          </CardContent>
        </Card>

        {/* Next Steps */}
        <Card className="border-0 shadow-sm bg-gradient-to-br from-emerald-50 to-blue-50">
          <CardContent className="p-6">
            <h3 className="font-semibold text-slate-900 mb-3">Next Steps</h3>
            <ul className="space-y-2 text-sm text-slate-700">
              <li>✓ Set app to Private mode</li>
              <li>✓ Add Stripe API keys to environment</li>
              <li>✓ Share signup link with users</li>
              <li>✓ Review access requests as they arrive</li>
              <li>✓ Monitor Access Requests page for pending approvals</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}