import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CheckCircle2, Circle, Clock, AlertTriangle, Search,
  ChevronDown, ChevronRight, Users, FileText, ShieldCheck, Zap,
  BookOpen, Download, BarChart3, RefreshCw, Paperclip
} from "lucide-react";
import { toast } from "sonner";
import { usePermissions } from "@/components/permissions/usePermissions";
import ClauseDocumentLinker from "@/components/fssc/ClauseDocumentLinker";

// ─── FSSC 22000 v6.0 Clause Structure ───────────────────────────────────────
const FSSC_CLAUSES = [
  // ISO 22000:2018 Clauses
  { clause: "4.1", title: "Understanding the organization and its context", section: "4 - Context of the Organization", description: "Determine external and internal issues relevant to FSMS purpose and strategic direction.", steps: ["Conduct SWOT/PESTLE analysis", "Document internal & external issues register", "Review issues annually or on change"], roles: { food_safety_manager: "lead", compliance_manager: "lead", site_manager: "review", admin: "approve" }, priority: "high", category: "iso22000" },
  { clause: "4.2", title: "Understanding needs and expectations of interested parties", section: "4 - Context of the Organization", description: "Identify interested parties and their relevant food safety requirements.", steps: ["List all interested parties (customers, regulators, suppliers)", "Document their requirements and expectations", "Update register annually"], roles: { food_safety_manager: "lead", compliance_manager: "lead", site_manager: "review" }, priority: "high", category: "iso22000" },
  { clause: "4.3", title: "Determining the scope of the FSMS", section: "4 - Context of the Organization", description: "Define FSMS scope boundaries including products, processes, and sites.", steps: ["Define products and product categories in scope", "Define physical boundaries (sites, areas)", "Identify and justify any exclusions", "Document and approve scope statement"], roles: { admin: "lead", food_safety_manager: "lead", compliance_manager: "support" }, priority: "critical", category: "iso22000" },
  { clause: "4.4", title: "Food Safety Management System", section: "4 - Context of the Organization", description: "Establish, implement, maintain and update the FSMS.", steps: ["Map all processes within scope", "Define process interactions and sequences", "Establish documented information requirements"], roles: { food_safety_manager: "lead", compliance_manager: "support" }, priority: "critical", category: "iso22000" },
  { clause: "5.1", title: "Leadership and commitment", section: "5 - Leadership", description: "Top management demonstrates leadership and commitment to the FSMS.", steps: ["Senior management policy statement", "Assign FSMS resources", "Conduct management reviews", "Establish food safety culture program"], roles: { admin: "lead", site_manager: "support" }, priority: "critical", category: "iso22000" },
  { clause: "5.2", title: "Food safety policy", section: "5 - Leadership", description: "Establish, implement and maintain a food safety policy.", steps: ["Draft policy covering ISO 22000 requirements and quality objectives (2.5.9)", "Get top management approval and sign-off", "Communicate to all personnel", "Display at all relevant locations", "Review annually"], roles: { admin: "lead", food_safety_manager: "draft", site_manager: "implement" }, priority: "critical", category: "iso22000" },
  { clause: "5.3", title: "Organizational roles, responsibilities and authorities", section: "5 - Leadership", description: "Assign and communicate roles, responsibilities and authorities.", steps: ["Create org chart with food safety responsibilities", "Define FSSC 22000 contact person / Food Safety Team Leader", "Document backup roles for key positions", "Communicate roles to all staff"], roles: { admin: "lead", food_safety_manager: "define" }, priority: "high", category: "iso22000" },
  { clause: "6.1", title: "Actions to address risks and opportunities", section: "6 - Planning", description: "Plan actions to address risks and opportunities that can affect the FSMS.", steps: ["Conduct risk register for FSMS (not food safety hazards)", "Define mitigation actions for each risk", "Integrate into management review"], roles: { food_safety_manager: "lead", compliance_manager: "support", site_manager: "input" }, priority: "high", category: "iso22000" },
  { clause: "6.2", title: "Objectives of the FSMS and planning to achieve them", section: "6 - Planning", description: "Establish FSMS objectives at relevant functions and levels.", steps: ["Set SMART food safety and quality objectives (2.5.9)", "Define measurement metrics for each objective", "Assign ownership per objective", "Track progress quarterly", "Include in management review"], roles: { admin: "approve", food_safety_manager: "lead", site_manager: "monitor" }, priority: "high", category: "iso22000" },
  { clause: "7.1", title: "Resources", section: "7 - Support", description: "Determine and provide necessary resources including infrastructure and work environment.", steps: ["Budget allocation for FSMS resources", "Infrastructure maintenance schedule", "Work environment assessment"], roles: { admin: "approve", site_manager: "lead", food_safety_manager: "support" }, priority: "medium", category: "iso22000" },
  { clause: "7.2", title: "Competence", section: "7 - Support", description: "Determine necessary competence for persons affecting FSMS performance.", steps: ["Create competence matrix per role", "Identify training gaps", "Develop training plan", "Conduct and record training", "Evaluate training effectiveness"], roles: { admin: "lead", food_safety_manager: "define", production_operator: "attend" }, priority: "high", category: "iso22000" },
  { clause: "7.3", title: "Awareness", section: "7 - Support", description: "Ensure persons are aware of the food safety policy and their FSMS contribution.", steps: ["Develop FSMS awareness program", "Train all staff on food safety policy", "Conduct allergen awareness training (2.5.6)", "Test and verify awareness"], roles: { food_safety_manager: "lead", site_manager: "implement", production_operator: "attend" }, priority: "high", category: "iso22000" },
  { clause: "7.4", title: "Communication", section: "7 - Support", description: "Establish internal and external communication processes.", steps: ["Define external communication procedure (2.5.17)", "Define internal communication channels", "Establish emergency communication protocol", "Record all food safety communications"], roles: { food_safety_manager: "lead", compliance_manager: "support" }, priority: "medium", category: "iso22000" },
  { clause: "7.5", title: "Documented information", section: "7 - Support", description: "Maintain and control documented information required by FSMS.", steps: ["Create document register/master list", "Establish document control procedure", "Define retention periods per document type", "Implement version control system"], roles: { compliance_manager: "lead", food_safety_manager: "support", production_operator: "follow" }, priority: "high", category: "iso22000" },
  { clause: "8.1", title: "Operational planning and control", section: "8 - Operation", description: "Plan, implement, control, and maintain processes needed to achieve FSMS objectives.", steps: ["Define operational controls for all processes", "Establish process verification procedures", "Document process parameters and limits"], roles: { food_safety_manager: "lead", production_operator: "implement", site_manager: "verify" }, priority: "critical", category: "iso22000" },
  { clause: "8.2", title: "Prerequisite Programs (PRPs)", section: "8 - Operation", description: "Establish, implement and maintain PRPs covering facility, equipment, personnel, and supply chain.", steps: ["Identify applicable PRPs per ISO/TS 22002-4 (Category I)", "Document each PRP procedure", "Train staff on PRPs", "Establish PRP monitoring records", "Conduct monthly PRP inspections (2.5.12)"], roles: { food_safety_manager: "lead", production_operator: "implement", site_manager: "verify", quality_auditor: "audit" }, priority: "critical", category: "iso22000" },
  { clause: "8.3", title: "Traceability system", section: "8 - Operation", description: "Establish a traceability system to identify material lots and processing records.", steps: ["Define traceability procedure scope", "Implement batch/lot numbering system", "Test traceability (full trace within 4 hours)", "Document traceability test results"], roles: { food_safety_manager: "design", production_operator: "implement", site_manager: "test" }, priority: "critical", category: "iso22000" },
  { clause: "8.4", title: "Emergency preparedness and response", section: "8 - Operation", description: "Establish procedures for emergency situations that affect food safety.", steps: ["Identify potential emergency scenarios", "Develop emergency response procedures", "Train key personnel on emergency procedures", "Test emergency procedures (drill)", "Review after any real emergency event"], roles: { admin: "approve", food_safety_manager: "develop", site_manager: "lead_response" }, priority: "high", category: "iso22000" },
  { clause: "8.5", title: "Hazard Analysis and HACCP", section: "8 - Operation", description: "Conduct hazard analysis, establish HACCP plan with CCPs, OPRPs and PRPs.", steps: ["Form multi-disciplinary food safety team", "Describe products and intended use", "Construct and verify process flow diagrams", "Identify and assess all food safety hazards", "Apply HACCP decision tree to determine CCPs", "Establish critical limits for each CCP", "Establish monitoring system for CCPs", "Define corrective actions for CCP deviations", "Validate control measures", "Document HACCP plan"], roles: { food_safety_manager: "lead", quality_auditor: "review", site_manager: "input", production_operator: "provide_info" }, priority: "critical", category: "iso22000" },
  { clause: "8.6", title: "Updating preliminary information and raw material documentation", section: "8 - Operation", description: "Update and review all preliminary information used for hazard analysis.", steps: ["Annual review of product descriptions", "Update process flow diagrams on change", "Update raw material specifications"], roles: { food_safety_manager: "lead", compliance_manager: "track" }, priority: "medium", category: "iso22000" },
  { clause: "8.7", title: "Control of monitoring and measuring", section: "8 - Operation", description: "Ensure measurement resources are suitable, maintained and calibrated.", steps: ["Create calibration register for all monitoring equipment", "Establish calibration schedule", "Record calibration results", "Define actions when equipment found out of calibration"], roles: { site_manager: "lead", production_operator: "execute", food_safety_manager: "review" }, priority: "high", category: "iso22000" },
  { clause: "8.8", title: "PRP and HACCP verification", section: "8 - Operation", description: "Establish verification activities to confirm PRPs and HACCP are effective.", steps: ["Establish internal audit program covering all FSMS elements", "Conduct monthly site PRP inspections (2.5.12)", "Perform annual HACCP review and validation", "Analyse monitoring trends and customer complaints", "Report verification outcomes to management"], roles: { quality_auditor: "lead", food_safety_manager: "review", admin: "receive_report" }, priority: "critical", category: "iso22000" },
  { clause: "8.9", title: "Control of nonconformities", section: "8 - Operation", description: "Define corrections and corrective actions for nonconformities.", steps: ["Establish NC reporting system", "Define process for product holds and withdrawals/recalls", "Train staff on NC reporting", "Track and trend all NCs", "Verify effectiveness of corrective actions"], roles: { food_safety_manager: "lead", production_operator: "report", site_manager: "investigate", quality_auditor: "verify" }, priority: "critical", category: "iso22000" },
  { clause: "9.1", title: "Monitoring, measurement, analysis and evaluation", section: "9 - Performance Evaluation", description: "Determine what to monitor and measure and analyse results.", steps: ["Define KPIs for FSMS performance", "Establish data collection methods", "Conduct trend analysis monthly", "Report to management review"], roles: { food_safety_manager: "lead", site_manager: "collect", admin: "review" }, priority: "high", category: "iso22000" },
  { clause: "9.2", title: "Internal audit", section: "9 - Performance Evaluation", description: "Conduct internal audits at planned intervals.", steps: ["Develop annual internal audit schedule covering all FSSC requirements", "Train internal auditors (16hr course minimum)", "Conduct audits and document findings", "Follow up on corrective actions", "Report results to management review"], roles: { quality_auditor: "lead_auditor", admin: "review", food_safety_manager: "support" }, priority: "critical", category: "iso22000" },
  { clause: "9.3", title: "Management review", section: "9 - Performance Evaluation", description: "Top management reviews the FSMS at planned intervals.", steps: ["Schedule annual management review meeting", "Compile management review inputs (KPIs, NCs, audits, customer feedback)", "Conduct review meeting with senior management", "Document outcomes and action items", "Monitor action items to closure"], roles: { admin: "chair", food_safety_manager: "compile_inputs", site_manager: "attend" }, priority: "critical", category: "iso22000" },
  { clause: "10.1", title: "Nonconformity and corrective action", section: "10 - Improvement", description: "React to nonconformities and take corrective actions to prevent recurrence.", steps: ["Implement root cause analysis methodology", "Link CAs to trend data", "Verify CA effectiveness"], roles: { food_safety_manager: "lead", quality_auditor: "verify", production_operator: "implement" }, priority: "high", category: "iso22000" },
  { clause: "10.2", title: "Continual improvement", section: "10 - Improvement", description: "Continually improve FSMS suitability, adequacy and effectiveness.", steps: ["Review improvement opportunities from audits and trends", "Implement improvement projects", "Track improvements in management review"], roles: { admin: "champion", food_safety_manager: "lead", site_manager: "implement" }, priority: "medium", category: "iso22000" },

  // FSSC 22000 Additional Requirements (Part 2, Section 2.5)
  { clause: "2.5.1", title: "Management of Services and Purchased Materials", section: "FSSC Additional Requirements", description: "Laboratory competence, emergency procurement, spec reviews, recycled packaging criteria.", steps: ["Establish approved laboratory list with ISO 17025 criteria", "Document emergency procurement procedure", "Establish material/product specification review process", "Define recycled packaging criteria (Category I)"], roles: { food_safety_manager: "lead", compliance_manager: "support", quality_auditor: "verify" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.2", title: "Product Labeling and Printed Materials", section: "FSSC Additional Requirements", description: "Ensure labeling meets statutory requirements; artwork management for Category I.", steps: ["Establish label review procedure against legal requirements", "Include allergen and customer-specific requirements", "For Cat I: implement artwork approval and print control process", "Verify claim validation and traceability (allergen, nutritional, etc.)"], roles: { food_safety_manager: "lead", compliance_manager: "review", production_operator: "verify_at_line" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.3", title: "Food Defense", section: "FSSC Additional Requirements", description: "Documented threat assessment and food defense plan covering all processes.", steps: ["Conduct food defense threat assessment using recognised methodology", "Identify significant threats and define mitigation measures", "Document food defense plan aligned with FSMS", "Train key staff on food defense procedures", "Review plan annually or after significant change"], roles: { food_safety_manager: "lead", admin: "approve", site_manager: "implement" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.4", title: "Food Fraud Mitigation", section: "FSSC Additional Requirements", description: "Vulnerability assessment and food fraud mitigation plan for all food chain categories.", steps: ["Conduct food fraud vulnerability assessment (VACCP)", "Identify significant vulnerabilities and mitigation measures", "Document food fraud mitigation plan", "Train key staff on food fraud awareness", "Review plan annually or after supply chain change"], roles: { food_safety_manager: "lead", compliance_manager: "support", admin: "approve" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.5", title: "Logo Use", section: "FSSC Additional Requirements", description: "FSSC 22000 logo used only as specified — not on products, labels or packaging.", steps: ["Establish logo use policy", "Train marketing/sales on logo restrictions", "Audit logo usage annually"], roles: { admin: "lead", compliance_manager: "monitor" }, priority: "medium", category: "fssc_additional" },
  { clause: "2.5.6", title: "Management of Allergens", section: "FSSC Additional Requirements", description: "Documented allergen management plan including risk assessment, controls and verification.", steps: ["List all allergens handled on site and in raw materials", "Conduct allergen risk assessment for cross-contamination", "Define and implement allergen control measures", "Establish allergen verification testing schedule", "Train ALL personnel on allergen awareness", "Review allergen plan annually or after any recall/change"], roles: { food_safety_manager: "lead", production_operator: "implement", quality_auditor: "verify", site_manager: "oversee" }, priority: "critical", category: "fssc_additional" },
  { clause: "2.5.7", title: "Environmental Monitoring (Cat BIII, C, I & K)", section: "FSSC Additional Requirements", description: "Risk-based environmental monitoring program for pathogens and indicator organisms.", steps: ["Develop risk-based environmental monitoring plan", "Define sampling sites, frequency and organisms to test", "Implement testing and record results", "Conduct trend analysis on results", "Review EMP annually and on trigger events"], roles: { food_safety_manager: "design", quality_auditor: "execute", site_manager: "review" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.8", title: "Food Safety and Quality Culture", section: "FSSC Additional Requirements", description: "Senior management to establish food safety & quality culture objectives with a documented plan.", steps: ["Define food safety & quality culture objectives", "Develop culture plan covering communication, training, feedback and performance measurement", "Implement culture activities covering all sections", "Include culture metrics in management review", "Review and update plan annually"], roles: { admin: "champion", food_safety_manager: "lead", site_manager: "implement", production_operator: "participate" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.9", title: "Quality Control", section: "FSSC Additional Requirements", description: "Quality policy, quality objectives, quality parameters in product specs, calibration, and line start-up controls.", steps: ["Establish quality policy and SMART quality objectives (aligned to 5.2 & 6.2)", "Define quality parameters per product/product group spec", "Establish quality control testing program with product release criteria", "Implement calibration program for QC equipment", "Establish line start-up and changeover procedures"], roles: { food_safety_manager: "lead", quality_auditor: "audit", production_operator: "execute", site_manager: "verify" }, priority: "critical", category: "fssc_additional" },
  { clause: "2.5.10", title: "Transport, Storage and Warehousing", section: "FSSC Additional Requirements", description: "FEFO/FIFO stock rotation, temperature requirements, and tanker cleaning plans.", steps: ["Document FEFO + FIFO stock rotation procedure", "Define temperature monitoring requirements in storage/transport", "Implement tanker cleaning and validation plan if tankers used", "Train warehouse staff on stock rotation"], roles: { site_manager: "lead", production_operator: "implement", food_safety_manager: "define" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.11", title: "Hazard Control & Cross-Contamination Prevention", section: "FSSC Additional Requirements", description: "Foreign matter risk assessment and detection equipment management.", steps: ["Conduct foreign body risk assessment", "Select appropriate detection equipment (metal detector, X-ray, sieve, magnet)", "Document detection equipment management procedure", "Establish management controls for breakages (metal, ceramic, hard plastic)", "Verify detection equipment at defined frequency"], roles: { food_safety_manager: "design", production_operator: "operate", site_manager: "verify", quality_auditor: "audit" }, priority: "critical", category: "fssc_additional" },
  { clause: "2.5.12", title: "PRP Verification (Cat BIII, C, D, G, I & K)", section: "FSSC Additional Requirements", description: "Routine monthly site inspections/PRP checks to verify site and equipment condition.", steps: ["Develop site inspection checklist linked to ISO/TS 22002-4", "Schedule monthly PRP inspections", "Record inspection findings and corrective actions", "Trend inspection results and report to management"], roles: { quality_auditor: "lead", site_manager: "support", food_safety_manager: "review" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.13", title: "Product Design and Development (Cat BIII, C, D, E, F, I & K)", section: "FSSC Additional Requirements", description: "Documented D&D procedure for new products and process changes including shelf-life validation.", steps: ["Establish product design and development procedure", "Define FSMS impact assessment for new products/changes", "Conduct shelf-life trials and validation for new products", "Include allergen assessment in D&D process", "Validate cooking instructions for RTC products"], roles: { food_safety_manager: "lead", quality_auditor: "review", site_manager: "trial_support" }, priority: "high", category: "fssc_additional" },
  { clause: "2.5.15", title: "Equipment Management", section: "FSSC Additional Requirements", description: "Documented purchase specs covering hygienic design and risk-based change management for new/changed equipment.", steps: ["Create equipment purchase specification template (hygienic design, legal requirements)", "Implement change management process for new/changed equipment", "Document commissioning records with food safety sign-off"], roles: { site_manager: "lead", food_safety_manager: "approve", production_operator: "commission" }, priority: "medium", category: "fssc_additional" },
  { clause: "2.5.16", title: "Food Loss and Waste", section: "FSSC Additional Requirements", description: "Documented policy and controls to reduce food loss and waste (all categories except I).", steps: ["Develop food loss and waste reduction policy with objectives", "Identify and quantify current food waste streams", "Implement waste reduction controls", "Manage donated products safely", "Monitor and report on food waste KPIs"], roles: { admin: "policy_owner", food_safety_manager: "implement", site_manager: "monitor" }, priority: "medium", category: "fssc_additional" },
  { clause: "2.5.17", title: "Communication Requirements", section: "FSSC Additional Requirements", description: "Notify certification body within 3 working days of serious events, recalls, regulatory actions or legal proceedings.", steps: ["Document escalation procedure for serious events", "Define notification trigger list (recalls, regulatory action, legal, fraud)", "Assign responsible person to manage CB notifications", "Test escalation procedure annually"], roles: { admin: "lead", food_safety_manager: "support", compliance_manager: "execute" }, priority: "high", category: "fssc_additional" },

  // ISO/TS 22002-4 (Packaging) PRPs
  { clause: "TS22002-4: 4", title: "Construction and plant layout (PRP)", section: "TS 22002-4 - Establishment", description: "Building construction and layout to prevent contamination and facilitate cleaning.", steps: ["Assess building fabric condition (walls, floors, ceilings, drains)", "Define hygienic zoning map", "Ensure pest-proof building envelope", "Document and schedule building maintenance program"], roles: { site_manager: "lead", production_operator: "report_issues", food_safety_manager: "approve" }, priority: "high", category: "prp" },
  { clause: "TS22002-4: 5", title: "Layout of premises and workspace (PRP)", section: "TS 22002-4 - Establishment", description: "Work areas designed to prevent cross-contamination and facilitate flow.", steps: ["Review and verify process flow vs layout (people, materials, waste)", "Define traffic flow for personnel and materials", "Ensure adequate space for all operations"], roles: { site_manager: "lead", food_safety_manager: "review" }, priority: "medium", category: "prp" },
  { clause: "TS22002-4: 6", title: "Utilities: air, water, energy (PRP)", section: "TS 22002-4 - Utilities", description: "Water quality, compressed air, steam and other utilities meet food safety requirements.", steps: ["Test and document water quality (potable water standard)", "Define compressed air quality specification and test frequency", "Document utility maintenance and monitoring records"], roles: { site_manager: "lead", production_operator: "monitor", food_safety_manager: "verify" }, priority: "high", category: "prp" },
  { clause: "TS22002-4: 7", title: "Waste and sewage disposal (PRP)", section: "TS 22002-4 - Utilities", description: "Waste handling and sewage systems prevent contamination.", steps: ["Document waste segregation and disposal procedures", "Define waste contractor requirements", "Ensure sewage flows away from production areas"], roles: { site_manager: "lead", production_operator: "execute" }, priority: "medium", category: "prp" },
  { clause: "TS22002-4: 8", title: "Equipment suitability, cleaning and maintenance (PRP)", section: "TS 22002-4 - Equipment", description: "Equipment designed and maintained to facilitate cleaning and prevent contamination.", steps: ["Establish equipment register with hygienic design rating", "Develop preventive maintenance schedule for all production equipment", "Document cleaning instructions per equipment (CIP/COP)", "Calibration schedule (linked to 8.7)"], roles: { site_manager: "lead", production_operator: "execute", quality_auditor: "audit" }, priority: "high", category: "prp" },
  { clause: "TS22002-4: 9", title: "Management of purchased materials (PRP)", section: "TS 22002-4 - Equipment", description: "Supplier approval and incoming material verification.", steps: ["Establish supplier approval procedure and approved supplier list", "Define incoming inspection/testing requirements per material category", "Implement certificate of conformance system for key raw materials", "Conduct supplier audits as per risk profile"], roles: { food_safety_manager: "lead", compliance_manager: "manage_list", quality_auditor: "audit" }, priority: "critical", category: "prp" },
  { clause: "TS22002-4: 10", title: "Cross-contamination prevention (PRP)", section: "TS 22002-4 - Equipment", description: "Measures to prevent physical, chemical and microbiological cross-contamination.", steps: ["Define cross-contamination risk map for site", "Implement colour-coding / zoning controls", "Establish procedures for rework handling", "Verify controls through environmental monitoring (2.5.7)"], roles: { food_safety_manager: "design", production_operator: "implement", site_manager: "verify" }, priority: "critical", category: "prp" },
  { clause: "TS22002-4: 11", title: "Cleaning and disinfecting (PRP)", section: "TS 22002-4 - Hygiene", description: "Cleaning and disinfecting procedures for all areas and equipment.", steps: ["Develop master cleaning schedule (MCS)", "Write validated cleaning procedures for each area/equipment", "Define chemical concentrations, contact times and methods", "Train cleaning personnel", "Verify cleaning effectiveness (ATP/micro testing)"], roles: { site_manager: "lead", production_operator: "execute", quality_auditor: "verify" }, priority: "critical", category: "prp" },
  { clause: "TS22002-4: 12", title: "Pest control (PRP)", section: "TS 22002-4 - Hygiene", description: "Pest control program to prevent pest entry and infestation.", steps: ["Appoint licensed pest control contractor", "Develop site pest control plan with trap/bait map", "Conduct monthly pest inspections", "Document all pest sightings and corrective actions"], roles: { site_manager: "lead", production_operator: "report_sightings", quality_auditor: "review_records" }, priority: "high", category: "prp" },
  { clause: "TS22002-4: 13", title: "Personnel hygiene (PRP)", section: "TS 22002-4 - Personnel", description: "Personnel hygiene rules and practices to prevent food safety hazards.", steps: ["Document personnel hygiene policy", "Define handwashing procedure and verify compliance", "Establish illness/injury reporting procedure", "Define rules for jewellery, cosmetics, personal items", "Train all staff and contractors on hygiene rules", "Conduct periodic hygiene audits"], roles: { site_manager: "lead", production_operator: "comply", food_safety_manager: "define", quality_auditor: "audit" }, priority: "critical", category: "prp" },
  { clause: "TS22002-4: 14", title: "Rework (PRP)", section: "TS 22002-4 - Personnel", description: "Rework handling to prevent contamination or allergen cross-contact.", steps: ["Define rework classification and identification system", "Document rework procedures with allergen controls", "Train production staff on rework rules", "Verify rework through product testing where required"], roles: { food_safety_manager: "lead", production_operator: "execute", quality_auditor: "verify" }, priority: "medium", category: "prp" },
  { clause: "TS22002-4: 15", title: "Product recall procedures (PRP)", section: "TS 22002-4 - Product Information", description: "Documented recall and withdrawal procedures linked to HACCP and traceability.", steps: ["Document product recall/withdrawal procedure with roles", "Establish communication tree for recall events", "Define recall team and responsibilities", "Conduct mock recall annually", "Document and review mock recall results"], roles: { admin: "recall_decision", food_safety_manager: "lead_procedure", compliance_manager: "communicate" }, priority: "critical", category: "prp" },
  { clause: "TS22002-4: 16", title: "Warehousing (PRP)", section: "TS 22002-4 - Other Requirements", description: "Storage conditions for raw materials, packaging and finished product.", steps: ["Define storage conditions per material category", "Implement FEFO/FIFO controls in warehouse (2.5.10)", "Monitor and record temperature/humidity in storage areas", "Inspect storage areas for pest activity and product integrity weekly"], roles: { site_manager: "lead", production_operator: "execute", food_safety_manager: "define_conditions" }, priority: "medium", category: "prp" },
  { clause: "TS22002-4: 17", title: "Product information / consumer awareness (PRP)", section: "TS 22002-4 - Product Information", description: "Ensure product information is sufficient for safe handling, display and consumption.", steps: ["Verify all product specifications are current and accurate", "Ensure labels meet labelling requirements (2.5.2)", "Review customer specifications annually"], roles: { food_safety_manager: "lead", compliance_manager: "review" }, priority: "medium", category: "prp" },
];

const ROLE_LABELS = {
  admin: "Admin",
  food_safety_manager: "Food Safety Manager",
  compliance_manager: "Compliance Manager",
  quality_auditor: "Quality Auditor",
  site_manager: "Site Manager",
  production_operator: "Production Operator",
  auditor: "Auditor",
  viewer: "Viewer",
  user: "User"
};

const STATUS_COLORS = {
  not_started: "bg-slate-100 text-slate-600 border-slate-200",
  in_progress: "bg-blue-50 text-blue-700 border-blue-200",
  partial: "bg-amber-50 text-amber-700 border-amber-200",
  compliant: "bg-emerald-50 text-emerald-700 border-emerald-200",
  non_compliant: "bg-red-50 text-red-700 border-red-200",
};

const PRIORITY_COLORS = {
  critical: "bg-red-100 text-red-700 border-red-200",
  high: "bg-orange-100 text-orange-700 border-orange-200",
  medium: "bg-amber-100 text-amber-700 border-amber-200",
  low: "bg-slate-100 text-slate-500 border-slate-200",
};

const CATEGORY_LABELS = {
  iso22000: "ISO 22000:2018",
  fssc_additional: "FSSC Additional Reqs",
  prp: "ISO/TS 22002-4 PRPs",
};

export default function FSSC22000Tracker() {
  const { user, permissions, isAdmin } = usePermissions();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterSection, setFilterSection] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterRole, setFilterRole] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [expandedClause, setExpandedClause] = useState(null);
  const [activeTab, setActiveTab] = useState("tracker");
  const [seeding, setSeeding] = useState(false);

  const { data: requirements = [], isLoading } = useQuery({
    queryKey: ["requirements-fssc-tracker"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-clause_number", 500),
  });

  // Load all documents once to compute per-clause linked doc counts
  const { data: allDocuments = [] } = useQuery({
    queryKey: ["documents-all-tracker"],
    queryFn: () => base44.entities.Document.list("-created_date", 300),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ComplianceRequirement.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["requirements-fssc-tracker"] }),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ComplianceRequirement.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["requirements-fssc-tracker"] }),
  });

  // Map existing requirements by clause number
  const reqByClause = useMemo(() => {
    const map = {};
    requirements.forEach(r => { map[r.clause_number] = r; });
    return map;
  }, [requirements]);

  // Seeding function — creates requirements for all FSSC clauses not yet in DB
  const handleSeedRequirements = async () => {
    setSeeding(true);
    try {
      const missing = FSSC_CLAUSES.filter(c => !reqByClause[c.clause]);
      let count = 0;
      for (const clause of missing) {
        await base44.entities.ComplianceRequirement.create({
          clause_number: clause.clause,
          clause_title: clause.title,
          section: clause.section,
          description: clause.description,
          status: "not_started",
          priority: clause.priority,
          evidence_notes: "",
        });
        count++;
      }
      queryClient.invalidateQueries({ queryKey: ["requirements-fssc-tracker"] });
      toast.success(`Created ${count} FSSC 22000 v6.0 requirement records.`);
    } catch (e) {
      toast.error("Seeding failed: " + e.message);
    } finally {
      setSeeding(false);
    }
  };

  const handleStatusChange = (clause, newStatus) => {
    const existing = reqByClause[clause.clause];
    if (existing) {
      updateMutation.mutate({ id: existing.id, data: { status: newStatus } });
    } else {
      createMutation.mutate({
        clause_number: clause.clause,
        clause_title: clause.title,
        section: clause.section,
        description: clause.description,
        status: newStatus,
        priority: clause.priority,
      });
    }
  };

  // Unique sections for filter
  const sections = useMemo(() => ["all", ...Array.from(new Set(FSSC_CLAUSES.map(c => c.section)))], []);
  const userRole = user?.role || "user";

  const filteredClauses = useMemo(() => {
    return FSSC_CLAUSES.filter(clause => {
      const req = reqByClause[clause.clause];
      const status = req?.status || "not_started";
      if (filterSection !== "all" && clause.section !== filterSection) return false;
      if (filterStatus !== "all" && status !== filterStatus) return false;
      if (filterCategory !== "all" && clause.category !== filterCategory) return false;
      if (filterPriority !== "all" && clause.priority !== filterPriority) return false;
      if (filterRole !== "all" && !clause.roles[filterRole]) return false;
      if (search) {
        const q = search.toLowerCase();
        return clause.clause.toLowerCase().includes(q) ||
          clause.title.toLowerCase().includes(q) ||
          clause.description.toLowerCase().includes(q);
      }
      return true;
    });
  }, [search, filterSection, filterStatus, filterRole, filterCategory, filterPriority, reqByClause]);

  // Stats
  const stats = useMemo(() => {
    const total = FSSC_CLAUSES.length;
    const compliant = FSSC_CLAUSES.filter(c => reqByClause[c.clause]?.status === "compliant").length;
    const inProgress = FSSC_CLAUSES.filter(c => ["in_progress", "partial"].includes(reqByClause[c.clause]?.status)).length;
    const nonCompliant = FSSC_CLAUSES.filter(c => reqByClause[c.clause]?.status === "non_compliant").length;
    const notStarted = FSSC_CLAUSES.filter(c => !reqByClause[c.clause] || reqByClause[c.clause].status === "not_started").length;
    const pct = Math.round((compliant / total) * 100);

    const byCategory = {};
    Object.keys(CATEGORY_LABELS).forEach(cat => {
      const catClauses = FSSC_CLAUSES.filter(c => c.category === cat);
      const catCompliant = catClauses.filter(c => reqByClause[c.clause]?.status === "compliant").length;
      byCategory[cat] = { total: catClauses.length, compliant: catCompliant, pct: Math.round((catCompliant / catClauses.length) * 100) };
    });

    return { total, compliant, inProgress, nonCompliant, notStarted, pct, byCategory };
  }, [reqByClause]);

  // My clauses (where my role has a task)
  const myClauses = useMemo(() =>
    FSSC_CLAUSES.filter(c => c.roles[userRole]),
    [userRole]
  );

  // Build map: requirementId -> linked doc count
  const linkedDocCountByReqId = useMemo(() => {
    const map = {};
    allDocuments.forEach(doc => {
      (doc.linked_requirement_ids || []).forEach(rid => {
        map[rid] = (map[rid] || 0) + 1;
      });
    });
    return map;
  }, [allDocuments]);

  const getStatusIcon = (status) => {
    if (status === "compliant") return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
    if (status === "in_progress" || status === "partial") return <Clock className="w-4 h-4 text-blue-500" />;
    if (status === "non_compliant") return <AlertTriangle className="w-4 h-4 text-red-500" />;
    return <Circle className="w-4 h-4 text-slate-400" />;
  };

  const exportCSV = () => {
    const rows = [["Clause", "Title", "Section", "Category", "Priority", "Status", "Assigned Roles", "Steps"]];
    FSSC_CLAUSES.forEach(c => {
      const req = reqByClause[c.clause];
      rows.push([
        c.clause, c.title, c.section, CATEGORY_LABELS[c.category], c.priority,
        req?.status || "not_started",
        Object.entries(c.roles).map(([r, role]) => `${ROLE_LABELS[r] || r}: ${role}`).join("; "),
        c.steps.join(" | ")
      ]);
    });
    const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "FSSC22000_v6_Tracker.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
              FSSC 22000 v6.0 Compliance Tracker
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Step-by-step requirement tracker with role allocations — Category I (Food Packaging)
            </p>
          </div>
          <div className="flex items-center gap-2">
            {(isAdmin || permissions.canManageSettings) && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleSeedRequirements}
                disabled={seeding}
                className="text-xs"
              >
                <RefreshCw className={`w-3 h-3 mr-1 ${seeding ? "animate-spin" : ""}`} />
                {seeding ? "Loading..." : "Load FSSC Clauses"}
              </Button>
            )}
            <Button variant="outline" size="sm" onClick={exportCSV} className="text-xs">
              <Download className="w-3 h-3 mr-1" /> Export CSV
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="tracker">
              <FileText className="w-4 h-4 mr-1.5" /> Full Tracker
            </TabsTrigger>
            <TabsTrigger value="my_tasks">
              <Users className="w-4 h-4 mr-1.5" /> My Role Tasks
            </TabsTrigger>
            <TabsTrigger value="overview">
              <BarChart3 className="w-4 h-4 mr-1.5" /> Overview
            </TabsTrigger>
            <TabsTrigger value="role_matrix">
              <BookOpen className="w-4 h-4 mr-1.5" /> Role Matrix
            </TabsTrigger>
          </TabsList>

          {/* ── OVERVIEW TAB ───────────────────────────────────── */}
          <TabsContent value="overview">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {[
                { label: "Overall Compliance", value: `${stats.pct}%`, color: "text-emerald-600", sub: `${stats.compliant}/${stats.total} clauses` },
                { label: "Compliant", value: stats.compliant, color: "text-emerald-600", sub: "clauses complete" },
                { label: "In Progress", value: stats.inProgress, color: "text-blue-600", sub: "clauses active" },
                { label: "Not Started", value: stats.notStarted, color: "text-slate-500", sub: "clauses pending" },
              ].map((s, i) => (
                <Card key={i} className="border-0 shadow-sm">
                  <CardContent className="p-4 text-center">
                    <div className={`text-3xl font-bold ${s.color}`}>{s.value}</div>
                    <div className="text-sm font-medium text-slate-700 dark:text-slate-300 mt-1">{s.label}</div>
                    <div className="text-xs text-slate-400 mt-0.5">{s.sub}</div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {Object.entries(CATEGORY_LABELS).map(([cat, label]) => {
                const d = stats.byCategory[cat];
                return (
                  <Card key={cat} className="border-0 shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{label}</p>
                          <p className="text-xs text-slate-500">{d.compliant}/{d.total} compliant</p>
                        </div>
                        <span className="text-lg font-bold text-emerald-600">{d.pct}%</span>
                      </div>
                      <Progress value={d.pct} className="h-2" />
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Critical gaps */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                  Critical Clauses Not Yet Started
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {FSSC_CLAUSES
                    .filter(c => c.priority === "critical" && (!reqByClause[c.clause] || reqByClause[c.clause].status === "not_started"))
                    .map(c => (
                      <div key={c.clause} className="flex items-start gap-2 p-2 bg-red-50 rounded-lg">
                        <Badge variant="outline" className="text-[10px] bg-red-100 text-red-700 border-red-200 shrink-0">
                          {c.clause}
                        </Badge>
                        <div>
                          <p className="text-xs font-medium text-red-800">{c.title}</p>
                          <p className="text-[10px] text-red-600">{c.section}</p>
                        </div>
                      </div>
                    ))
                  }
                </div>
                {FSSC_CLAUSES.filter(c => c.priority === "critical" && (!reqByClause[c.clause] || reqByClause[c.clause].status === "not_started")).length === 0 && (
                  <p className="text-sm text-emerald-600 flex items-center gap-2"><CheckCircle2 className="w-4 h-4" /> All critical clauses are in progress or compliant!</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ── MY TASKS TAB ─────────────────────────────────────── */}
          <TabsContent value="my_tasks">
            <div className="mb-4 flex items-center gap-2">
              <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
                {ROLE_LABELS[userRole] || userRole}
              </Badge>
              <span className="text-sm text-slate-500">— {myClauses.length} clauses assigned to your role</span>
            </div>
            <div className="space-y-3">
              {myClauses.map(clause => {
                const req = reqByClause[clause.clause];
                const status = req?.status || "not_started";
                const myTask = clause.roles[userRole];
                return (
                  <ClauseRow
                    key={clause.clause}
                    clause={clause}
                    status={status}
                    myTask={myTask}
                    expanded={expandedClause === clause.clause}
                    onToggle={() => setExpandedClause(expandedClause === clause.clause ? null : clause.clause)}
                    onStatusChange={handleStatusChange}
                    canEdit={permissions.canEditRequirements || isAdmin}
                    getStatusIcon={getStatusIcon}
                    reqByClause={reqByClause}
                    linkedDocCount={linkedDocCountByReqId[reqByClause[clause.clause]?.id] || 0}
                  />
                );
              })}
            </div>
          </TabsContent>

          {/* ── FULL TRACKER TAB ─────────────────────────────────── */}
          <TabsContent value="tracker">
            {/* Filters */}
            <div className="flex flex-wrap gap-2 mb-4">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <Input
                  className="pl-8 h-8 text-xs w-48"
                  placeholder="Search clauses..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </div>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="h-8 text-xs w-40">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {Object.entries(CATEGORY_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="h-8 text-xs w-36">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  {["all","not_started","in_progress","partial","compliant","non_compliant"].map(s => (
                    <SelectItem key={s} value={s}>{s === "all" ? "All Statuses" : s.replace(/_/g, " ")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger className="h-8 text-xs w-32">
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  {["all","critical","high","medium","low"].map(p => (
                    <SelectItem key={p} value={p}>{p === "all" ? "All Priorities" : p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterRole} onValueChange={setFilterRole}>
                <SelectTrigger className="h-8 text-xs w-44">
                  <SelectValue placeholder="Role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  {Object.entries(ROLE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
              <span className="text-xs text-slate-500 self-center ml-auto">{filteredClauses.length} clauses</span>
            </div>

            {/* Progress Bar */}
            <div className="mb-4 bg-white dark:bg-slate-900 rounded-lg p-3 border border-slate-100 dark:border-slate-800 shadow-sm">
              <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400 mb-1">
                <span>Overall Progress</span>
                <span className="font-semibold text-emerald-600">{stats.pct}% — {stats.compliant}/{stats.total}</span>
              </div>
              <Progress value={stats.pct} className="h-2" />
            </div>

            {/* Clause List */}
            <div className="space-y-2">
              {filteredClauses.length === 0 && (
                <div className="text-center text-sm text-slate-400 py-10">No clauses match your filters.</div>
              )}
              {filteredClauses.map(clause => {
                const req = reqByClause[clause.clause];
                const status = req?.status || "not_started";
                return (
                  <ClauseRow
                    key={clause.clause}
                    clause={clause}
                    status={status}
                    myTask={clause.roles[userRole]}
                    expanded={expandedClause === clause.clause}
                    onToggle={() => setExpandedClause(expandedClause === clause.clause ? null : clause.clause)}
                    onStatusChange={handleStatusChange}
                    canEdit={permissions.canEditRequirements || isAdmin}
                    getStatusIcon={getStatusIcon}
                    reqByClause={reqByClause}
                    linkedDocCount={linkedDocCountByReqId[reqByClause[clause.clause]?.id] || 0}
                  />
                );
              })}
            </div>
          </TabsContent>

          {/* ── ROLE MATRIX TAB ───────────────────────────────────── */}
          <TabsContent value="role_matrix">
            <div className="overflow-x-auto">
              <p className="text-sm text-slate-500 mb-3">Shows the primary task/responsibility for each role per clause. Lead = primary owner, support = contributor, review/verify = checker, attend = participant.</p>
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 dark:bg-slate-800">
                    <th className="text-left p-2 border border-slate-200 dark:border-slate-700 sticky left-0 bg-slate-100 dark:bg-slate-800 min-w-[120px]">Clause</th>
                    {["food_safety_manager","compliance_manager","quality_auditor","site_manager","production_operator","admin"].map(r => (
                      <th key={r} className="p-2 border border-slate-200 dark:border-slate-700 text-center min-w-[100px] font-medium">
                        {ROLE_LABELS[r]}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {FSSC_CLAUSES.map((clause, idx) => (
                    <tr key={clause.clause} className={idx % 2 === 0 ? "bg-white dark:bg-slate-900" : "bg-slate-50 dark:bg-slate-800/50"}>
                      <td className="p-2 border border-slate-200 dark:border-slate-700 sticky left-0 bg-inherit font-mono">
                        <span className="font-medium text-slate-800 dark:text-slate-200">{clause.clause}</span>
                        <span className="text-slate-500 ml-1 hidden sm:inline truncate max-w-[80px] block">{clause.title}</span>
                      </td>
                      {["food_safety_manager","compliance_manager","quality_auditor","site_manager","production_operator","admin"].map(r => {
                        const task = clause.roles[r];
                        return (
                          <td key={r} className="p-2 border border-slate-200 dark:border-slate-700 text-center">
                            {task ? (
                              <Badge variant="outline" className={`text-[10px] ${task === "lead" || task === "lead_auditor" || task === "lead_procedure" ? "bg-emerald-50 text-emerald-700 border-emerald-200" : task === "review" || task === "verify" || task === "audit" ? "bg-blue-50 text-blue-700 border-blue-200" : "bg-slate-100 text-slate-600 border-slate-200"}`}>
                                {task.replace(/_/g, " ")}
                              </Badge>
                            ) : (
                              <span className="text-slate-300">—</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// ─── Clause Row Component ──────────────────────────────────────────────────────
function ClauseRow({ clause, status, myTask, expanded, onToggle, onStatusChange, canEdit, getStatusIcon, reqByClause, linkedDocCount }) {
  const req = reqByClause[clause.clause];
  const steps = clause.steps || [];
  // Simple step completion — use evidence_notes to track step progress as JSON
  let completedSteps = [];
  try { completedSteps = JSON.parse(req?.evidence_notes || "[]"); } catch { completedSteps = []; }
  const stepPct = steps.length ? Math.round((completedSteps.length / steps.length) * 100) : 0;

  return (
    <div className={`bg-white dark:bg-slate-900 rounded-lg border shadow-sm transition-all ${expanded ? "border-emerald-200 dark:border-emerald-700" : "border-slate-100 dark:border-slate-800"}`}>
      <div
        className="flex items-start gap-3 p-3 cursor-pointer select-none"
        onClick={onToggle}
      >
        <div className="mt-0.5">{getStatusIcon(status)}</div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-1.5 mb-0.5">
            <span className="font-mono text-xs font-bold text-slate-500 dark:text-slate-400">{clause.clause}</span>
            <span className="text-sm font-semibold text-slate-800 dark:text-slate-200 truncate">{clause.title}</span>
            {myTask && (
              <Badge variant="outline" className="text-[10px] bg-purple-50 text-purple-700 border-purple-200">
                Your task: {myTask.replace(/_/g, " ")}
              </Badge>
            )}
          </div>
          <div className="flex flex-wrap gap-1.5 items-center">
            <Badge variant="outline" className={`text-[10px] ${PRIORITY_COLORS[clause.priority]}`}>
              {clause.priority}
            </Badge>
            <Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[status]}`}>
              {status.replace(/_/g, " ")}
            </Badge>
            <span className="text-[10px] text-slate-400">{CATEGORY_LABELS[clause.category]}</span>
            {steps.length > 0 && (
              <span className="text-[10px] text-slate-400">{completedSteps.length}/{steps.length} steps</span>
            )}
            {linkedDocCount > 0 && (
              <span className="text-[10px] text-emerald-600 flex items-center gap-0.5">
                <Paperclip className="w-2.5 h-2.5" />{linkedDocCount} doc{linkedDocCount !== 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {canEdit && (
            <Select
              value={status}
              onValueChange={(v) => { onStatusChange(clause, v); }}
            >
              <SelectTrigger className="h-7 text-xs w-28 border-slate-200" onClick={e => e.stopPropagation()}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="not_started">Not Started</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="partial">Partial</SelectItem>
                <SelectItem value="compliant">Compliant</SelectItem>
                <SelectItem value="non_compliant">Non-Compliant</SelectItem>
              </SelectContent>
            </Select>
          )}
          {expanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
        </div>
      </div>

      {expanded && (
        <div className="border-t border-slate-100 dark:border-slate-800 px-4 pb-4 pt-3">
          <p className="text-xs text-slate-600 dark:text-slate-400 mb-3">{clause.description}</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Steps */}
            <div>
              <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-500" /> Implementation Steps
                {steps.length > 0 && <span className="text-slate-400 font-normal">— {stepPct}% complete</span>}
              </h4>
              {steps.length > 0 && <Progress value={stepPct} className="h-1.5 mb-2" />}
              <ol className="space-y-1.5">
                {steps.map((step, i) => {
                  const done = completedSteps.includes(i);
                  return (
                    <li key={i} className="flex items-start gap-2 text-xs">
                      {canEdit ? (
                        <button
                          onClick={() => {
                            const updated = done
                              ? completedSteps.filter(x => x !== i)
                              : [...completedSteps, i];
                            const r = reqByClause[clause.clause];
                            if (r) {
                              base44.entities.ComplianceRequirement.update(r.id, { evidence_notes: JSON.stringify(updated) });
                            } else {
                              base44.entities.ComplianceRequirement.create({
                                clause_number: clause.clause,
                                clause_title: clause.title,
                                section: clause.section,
                                description: clause.description,
                                status: "in_progress",
                                priority: clause.priority,
                                evidence_notes: JSON.stringify([i]),
                              });
                            }
                          }}
                          className={`mt-0.5 shrink-0 w-4 h-4 rounded border flex items-center justify-center transition-colors ${done ? "bg-emerald-500 border-emerald-500 text-white" : "border-slate-300 hover:border-emerald-400"}`}
                        >
                          {done && <CheckCircle2 className="w-3 h-3" />}
                        </button>
                      ) : (
                        <span className={`mt-0.5 shrink-0 w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold ${done ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{i + 1}</span>
                      )}
                      <span className={done ? "line-through text-slate-400" : "text-slate-700 dark:text-slate-300"}>{step}</span>
                    </li>
                  );
                })}
              </ol>
            </div>

            {/* Role Assignments */}
            <div>
              <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1">
                <Users className="w-3 h-3 text-blue-500" /> Role Allocations
              </h4>
              <div className="space-y-1.5">
                {Object.entries(clause.roles).map(([role, task]) => (
                  <div key={role} className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 dark:text-slate-400">{ROLE_LABELS[role] || role}</span>
                    <Badge variant="outline" className={`text-[10px] ${
                      task === "lead" || task.startsWith("lead") ? "bg-emerald-50 text-emerald-700 border-emerald-200" :
                      task === "review" || task === "verify" || task === "audit" ? "bg-blue-50 text-blue-700 border-blue-200" :
                      task === "approve" ? "bg-purple-50 text-purple-700 border-purple-200" :
                      "bg-slate-100 text-slate-600 border-slate-200"
                    }`}>
                      {task.replace(/_/g, " ")}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Evidence Documents — full width below the 2-col grid */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <ClauseDocumentLinker
              clauseNumber={clause.clause}
              requirementId={req?.id}
              canEdit={canEdit}
            />
          </div>
        </div>
      )}
    </div>
  );
}