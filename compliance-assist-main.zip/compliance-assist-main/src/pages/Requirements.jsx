import React, { useState, useMemo } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useOfflineQuery } from "@/components/offline/useOfflineQuery";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Plus, AlertTriangle, Zap, LayoutTemplate, SlidersHorizontal, X } from "lucide-react";
import RequirementRow from "@/components/requirements/RequirementRow";
import ClauseAccordionRow from "@/components/requirements/ClauseAccordionRow";
import AddRequirementDialog from "@/components/requirements/AddRequirementDialog";
import RequirementTemplateManager from "@/components/requirements/RequirementTemplateManager";
import FSSC22000RequirementsList from "@/components/requirements/FSSC22000RequirementsList";
import { usePermissions } from "@/components/permissions/usePermissions";
import { useSectionAccess } from "@/components/permissions/useSectionAccess";
import PullToRefresh from "@/components/mobile/PullToRefresh";
import MobileSelect from "@/components/mobile/MobileSelect";
import { useAuditLog } from "@/components/audit/useAuditLog";

const STATUS_OPTIONS = [
  { value: "all", label: "All Statuses" },
  { value: "not_started", label: "Not Started" },
  { value: "in_progress", label: "In Progress" },
  { value: "partial", label: "Partial" },
  { value: "compliant", label: "Compliant" },
  { value: "non_compliant", label: "Non-Compliant" },
];

const PRIORITY_OPTIONS = [
  { value: "all", label: "All Priorities" },
  { value: "critical", label: "Critical" },
  { value: "high", label: "High" },
  { value: "medium", label: "Medium" },
  { value: "low", label: "Low" },
];

const STATUS_COLORS = {
  compliant: "bg-emerald-100 text-emerald-700",
  in_progress: "bg-blue-100 text-blue-700",
  partial: "bg-yellow-100 text-yellow-700",
  not_started: "bg-slate-100 text-slate-500",
  non_compliant: "bg-red-100 text-red-700",
};

function sectionShortLabel(section) {
  if (section.startsWith("Prerequisite")) return section.replace("Prerequisite - ", "PRE ");
  return section.split(" - ")[0]; // e.g. "4"
}

export default function Requirements() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [showAdd, setShowAdd] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [activeTab, setActiveTab] = useState(null);
  const [sortBy, setSortBy] = useState("default"); // "attention" | "default"
  const [viewMode, setViewMode] = useState("tracker"); // "tracker" | "fssc_list"

  const { permissions, isAdmin } = usePermissions();
  const { canEditSection, canApproveSection, getAccessibleSections, loading: sectionLoading } = useSectionAccess();
  const { logAction } = useAuditLog();
  const queryClient = useQueryClient();

  const { data: requirements = [], isLoading, refetch } = useOfflineQuery(
    ["compliance-requirements"],
    "ComplianceRequirement",
    () => base44.entities.ComplianceRequirement.list("clause_number", 200)
  );

  const updateMutation = useMutation({
    mutationFn: ({ id, status, oldStatus, label }) =>
      base44.entities.ComplianceRequirement.update(id, { status }),
    onMutate: async ({ id, status }) => {
      await queryClient.cancelQueries({ queryKey: ["compliance-requirements"] });
      const prev = queryClient.getQueryData(["compliance-requirements"]);
      queryClient.setQueryData(["compliance-requirements"], (old) =>
        old?.map((req) => (req.id === id ? { ...req, status } : req))
      );
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      queryClient.setQueryData(["compliance-requirements"], ctx.prev);
    },
    onSuccess: (_data, variables) => {
      logAction("status_changed", `Status changed for ${variables.label}: ${variables.oldStatus} → ${variables.status}`, {
        entity_type: "ComplianceRequirement",
        entity_id: variables.id,
        entity_label: variables.label,
        field_changes: [{ field: "status", old_value: variables.oldStatus, new_value: variables.status }],
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-requirements"] });
    },
  });

  const filtered = useMemo(() => {
    return requirements.filter((r) => {
      const matchSearch =
        search === "" ||
        r.clause_number?.toLowerCase().includes(search.toLowerCase()) ||
        r.clause_title?.toLowerCase().includes(search.toLowerCase()) ||
        r.description?.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "all" || r.status === statusFilter;
      const matchPriority = priorityFilter === "all" || r.priority === priorityFilter;
      return matchSearch && matchStatus && matchPriority;
    });
  }, [requirements, search, statusFilter, priorityFilter]);

  const grouped = useMemo(() => {
    const groups = {};
    filtered.forEach((r) => {
      if (!groups[r.section]) groups[r.section] = [];
      groups[r.section].push(r);
    });
    return groups;
  }, [filtered]);

  const sortedSections = useMemo(
    () =>
      Object.keys(grouped).sort((a, b) => {
        const numA = parseInt(a.split(" ")[0]);
        const numB = parseInt(b.split(" ")[0]);
        return numA - numB;
      }),
    [grouped]
  );

  // Attention score: non_compliant > critical/high not_started > overdue > others
  const attentionScore = (r) => {
    let score = 0;
    if (r.status === "non_compliant") score += 100;
    if (r.status === "not_started" && r.priority === "critical") score += 80;
    if (r.status === "not_started" && r.priority === "high") score += 60;
    if (r.due_date && new Date(r.due_date) < new Date() && r.status !== "compliant") score += 50;
    if (r.priority === "critical") score += 20;
    if (r.priority === "high") score += 10;
    if (r.status === "in_progress") score -= 5;
    return score;
  };

  const needsAttention = useMemo(() => {
    if (sortBy !== "attention") return [];
    return [...filtered]
      .filter(r => r.status !== "compliant")
      .sort((a, b) => attentionScore(b) - attentionScore(a))
      .slice(0, 15);
  }, [filtered, sortBy]);

  const attentionStats = useMemo(() => ({
    nonCompliant: requirements.filter(r => r.status === "non_compliant").length,
    notStartedCritical: requirements.filter(r => r.status === "not_started" && r.priority === "critical").length,
    overdue: requirements.filter(r => r.due_date && new Date(r.due_date) < new Date() && r.status !== "compliant").length,
  }), [requirements]);

  // Default to first section tab
  const currentTab = activeTab && sortedSections.includes(activeTab) ? activeTab : sortedSections[0] ?? "";

  if (isLoading || sectionLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={refetch}>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
        {/* Sticky Header */}
        <div className="sticky top-0 z-20 bg-slate-50 dark:bg-slate-950 border-b border-slate-100 dark:border-slate-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 pb-3">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">Requirements</h1>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  {filtered.length} of {requirements.length} requirements
                </p>
              </div>
              <div className="flex items-center gap-2">
                {/* View toggle */}
                <div className="hidden sm:flex items-center bg-slate-100 dark:bg-slate-800 rounded-lg p-1 gap-1">
                  <button
                    onClick={() => setViewMode("tracker")}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${viewMode === "tracker" ? "bg-white dark:bg-slate-700 text-slate-800 dark:text-white shadow-sm" : "text-slate-500 dark:text-slate-400 hover:text-slate-700"}`}
                  >
                    Tracker
                  </button>
                  <button
                    onClick={() => setViewMode("fssc_list")}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${viewMode === "fssc_list" ? "bg-white dark:bg-slate-700 text-slate-800 dark:text-white shadow-sm" : "text-slate-500 dark:text-slate-400 hover:text-slate-700"}`}
                  >
                    FSSC List
                  </button>
                </div>
                {isAdmin && viewMode === "tracker" && (
                  <Button
                    variant="outline"
                    onClick={() => setShowTemplates(true)}
                    className="min-h-[44px] border-slate-200 dark:border-slate-700 hidden sm:flex"
                  >
                    <LayoutTemplate className="w-4 h-4 mr-1.5 text-emerald-600" />
                    Templates
                  </Button>
                )}
                {(permissions.canEditRequirements || isAdmin) && viewMode === "tracker" && (
                  <Button
                    onClick={() => setShowAdd(true)}
                    className="bg-emerald-600 hover:bg-emerald-700 min-h-[44px]"
                  >
                    <Plus className="w-4 h-4 mr-1.5" />
                    Add
                  </Button>
                )}
              </div>
            </div>

            {/* Attention Banner */}
            {(attentionStats.nonCompliant > 0 || attentionStats.notStartedCritical > 0 || attentionStats.overdue > 0) && (
              <div
                className="flex flex-wrap items-center gap-2 mb-3 p-2.5 rounded-lg bg-rose-50 border border-rose-100 cursor-pointer hover:bg-rose-100 transition-colors"
                onClick={() => setSortBy(sortBy === "attention" ? "default" : "attention")}
              >
                <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="text-xs font-semibold text-rose-700">Needs attention:</span>
                {attentionStats.nonCompliant > 0 && <Badge className="bg-rose-100 text-rose-700 text-xs">{attentionStats.nonCompliant} non-compliant</Badge>}
                {attentionStats.notStartedCritical > 0 && <Badge className="bg-orange-100 text-orange-700 text-xs">{attentionStats.notStartedCritical} critical not started</Badge>}
                {attentionStats.overdue > 0 && <Badge className="bg-amber-100 text-amber-700 text-xs">{attentionStats.overdue} overdue</Badge>}
                <span className="ml-auto text-xs text-rose-500 font-medium flex items-center gap-1">
                  <Zap className="w-3 h-3" />
                  {sortBy === "attention" ? "Showing priority view" : "Show priority view"}
                </span>
              </div>
            )}

            {/* Filters */}
            <div className="flex gap-2">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search clauses..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 border-slate-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white min-h-[44px]"
                />
              </div>

              {/* Mobile filter button */}
              <button
                onClick={() => setShowMobileFilters(true)}
                className="sm:hidden flex items-center gap-1.5 px-3 min-h-[44px] rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-sm font-medium shrink-0"
              >
                <SlidersHorizontal className="w-4 h-4" />
                {(statusFilter !== "all" || priorityFilter !== "all") && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                )}
              </button>

              {/* Desktop filters */}
              <div className="hidden sm:flex gap-2">
                <MobileSelect
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                  placeholder="Status"
                  label="Select Status"
                  triggerClassName="w-40 border-slate-200 dark:border-slate-700 min-h-[44px]"
                >
                  {STATUS_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                  ))}
                </MobileSelect>
                <MobileSelect
                  value={priorityFilter}
                  onValueChange={setPriorityFilter}
                  placeholder="Priority"
                  label="Select Priority"
                  triggerClassName="w-36 border-slate-200 dark:border-slate-700 min-h-[44px]"
                >
                  {PRIORITY_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                  ))}
                </MobileSelect>
              </div>
            </div>

            {/* Active filter chips (mobile) */}
            {(statusFilter !== "all" || priorityFilter !== "all") && (
              <div className="sm:hidden flex flex-wrap gap-1.5 mt-2">
                {statusFilter !== "all" && (
                  <span className="flex items-center gap-1 text-xs bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full px-2.5 py-1">
                    {STATUS_OPTIONS.find(o => o.value === statusFilter)?.label}
                    <button onClick={() => setStatusFilter("all")}><X className="w-3 h-3" /></button>
                  </span>
                )}
                {priorityFilter !== "all" && (
                  <span className="flex items-center gap-1 text-xs bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full px-2.5 py-1">
                    {PRIORITY_OPTIONS.find(o => o.value === priorityFilter)?.label}
                    <button onClick={() => setPriorityFilter("all")}><X className="w-3 h-3" /></button>
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Sidebar + Content */}
        <div className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-4">
          {viewMode === "fssc_list" && <FSSC22000RequirementsList />}
          {viewMode === "tracker" && (
            <>
              {/* Priority / Attention View */}
              {sortBy === "attention" && needsAttention.length > 0 && (
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-rose-500" />
                <h2 className="text-sm font-semibold text-slate-700 dark:text-slate-300">Priority Items — Needs Attention</h2>
                <Badge className="bg-rose-100 text-rose-700 text-xs">{needsAttention.length}</Badge>
                <button onClick={() => setSortBy("default")} className="ml-auto text-xs text-slate-400 hover:text-slate-600 underline">
                  Back to full list
                </button>
              </div>
              <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-rose-100 overflow-hidden divide-y divide-slate-50 dark:divide-slate-800">
                {needsAttention.map((req) => {
                  const canEditThis = isAdmin || (permissions.canEditRequirements && canEditSection(req.section));
                  const canApproveThis = canApproveSection(req.section);
                  const isOverdue = req.due_date && new Date(req.due_date) < new Date() && req.status !== "compliant";
                  return (
                    <div key={req.id} className={isOverdue ? "border-l-2 border-l-amber-400" : req.status === "non_compliant" ? "border-l-2 border-l-rose-500" : ""}>
                      <RequirementRow
                        requirement={req}
                        onStatusChange={(newStatus) =>
                          updateMutation.mutate({ id: req.id, status: newStatus, oldStatus: req.status, label: `${req.clause_number} ${req.clause_title}` })
                        }
                        canEdit={canEditThis}
                        canApprove={canApproveThis}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {sortedSections.length === 0 ? (
            <div className="text-center py-20">
              <Search className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 dark:text-slate-400">No requirements match your filters</p>
            </div>
          ) : sortBy === "attention" ? null : (
            <div className="space-y-6">
              {sortedSections.map((section) => {
                const items = grouped[section];
                const compliantCount = items.filter((r) => r.status === "compliant").length;
                return (
                  <div key={section}>
                    <div className="flex items-center gap-2 mb-2">
                      <h2 className="text-sm font-semibold text-slate-700 dark:text-slate-300">{section}</h2>
                      <Badge variant="secondary" className={`text-xs ${compliantCount === items.length ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 dark:bg-slate-800 text-slate-500"}`}>
                        {compliantCount}/{items.length}
                      </Badge>
                    </div>
                    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden divide-y divide-slate-50 dark:divide-slate-800">
                      {items
                        .sort((a, b) =>
                          (a.clause_number || "").localeCompare(b.clause_number || "", undefined, { numeric: true })
                        )
                        .map((req) => {
                          const canEditThis = isAdmin || (permissions.canEditRequirements && canEditSection(req.section));
                          const canApproveThis = canApproveSection(req.section);
                          const canViewThis = isAdmin || canEditSection(req.section) || canApproveSection(req.section) || permissions.canViewReports;
                          return (
                            <ClauseAccordionRow
                              key={req.id}
                              requirement={req}
                              onStatusChange={(newStatus) =>
                                updateMutation.mutate({
                                  id: req.id,
                                  status: newStatus,
                                  oldStatus: req.status,
                                  label: `${req.clause_number} ${req.clause_title}`,
                                })
                              }
                              canEdit={canEditThis}
                              canApprove={canApproveThis}
                              isHidden={!canViewThis}
                            />
                          );
                        })}
                    </div>
                  </div>
                );
              })}
            </div>
              )}
            </>
          )}
        </div>
      </div>

      <AddRequirementDialog open={showAdd} onClose={() => setShowAdd(false)} />
      <RequirementTemplateManager open={showTemplates} onClose={() => setShowTemplates(false)} />

      {/* Mobile Filter Bottom Sheet */}
      {showMobileFilters && (
        <div className="fixed inset-0 z-50 sm:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowMobileFilters(false)} />
          <div className="absolute bottom-0 left-0 right-0 bg-white dark:bg-slate-900 rounded-t-2xl p-5 pb-8 shadow-xl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-base font-semibold text-slate-800 dark:text-white">Filter Requirements</h3>
              <button onClick={() => setShowMobileFilters(false)} className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-2">Status</label>
                <div className="flex flex-wrap gap-2">
                  {STATUS_OPTIONS.map((o) => (
                    <button
                      key={o.value}
                      onClick={() => setStatusFilter(o.value)}
                      className={`px-3 py-2 rounded-full text-sm font-medium border transition-colors min-h-[40px] ${
                        statusFilter === o.value
                          ? "bg-emerald-600 text-white border-emerald-600"
                          : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700"
                      }`}
                    >
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-2">Priority</label>
                <div className="flex flex-wrap gap-2">
                  {PRIORITY_OPTIONS.map((o) => (
                    <button
                      key={o.value}
                      onClick={() => setPriorityFilter(o.value)}
                      className={`px-3 py-2 rounded-full text-sm font-medium border transition-colors min-h-[40px] ${
                        priorityFilter === o.value
                          ? "bg-emerald-600 text-white border-emerald-600"
                          : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700"
                      }`}
                    >
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => { setStatusFilter("all"); setPriorityFilter("all"); }}
              >
                Clear All
              </Button>
              <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700" onClick={() => setShowMobileFilters(false)}>
                Apply
              </Button>
            </div>
          </div>
        </div>
      )}
    </PullToRefresh>
  );
}