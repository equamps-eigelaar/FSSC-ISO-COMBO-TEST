import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTheme } from '@/components/theme/ThemeProvider';
import { Sun, Moon, Trash2, Bell, Settings as SettingsIcon, Database, Download, Shield, Clock } from 'lucide-react';
import { toast } from 'sonner';
import NotificationPreferencesPanel from '@/components/notifications/NotificationPreferencesPanel';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    try {
      const user = await base44.auth.me();
      if (user) {
        // Use service role to delete the user account
        await base44.asServiceRole.entities.User.delete(user.id);
        // Logout and redirect
        await base44.auth.logout('/');
        toast.success('Account deleted successfully');
      }
    } catch (error) {
      console.error('Delete account error:', error);
      toast.error('Failed to delete account. Please contact support.');
      setIsDeleting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <SettingsIcon className="w-6 h-6" />
            Settings
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage your preferences and account
          </p>
        </div>

        <Tabs defaultValue="appearance" className="w-full">
          <TabsList className="grid w-full grid-cols-4 dark:bg-slate-800">
            <TabsTrigger value="appearance" className="dark:text-slate-300 text-xs sm:text-sm">Appearance</TabsTrigger>
            <TabsTrigger value="notifications" className="dark:text-slate-300 text-xs sm:text-sm">Notifications</TabsTrigger>
            <TabsTrigger value="data" className="dark:text-slate-300 text-xs sm:text-sm">Data & Privacy</TabsTrigger>
            <TabsTrigger value="account" className="dark:text-slate-300 text-xs sm:text-sm">Account</TabsTrigger>
          </TabsList>

          <TabsContent value="appearance" className="space-y-4 mt-4">
            <Card className="border-0 shadow-sm dark:bg-slate-900 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-base dark:text-white">Appearance</CardTitle>
              </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {theme === 'dark' ? (
                    <Moon className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                  ) : (
                    <Sun className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                  )}
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-white">Dark Mode</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {theme === 'dark' ? 'Enabled' : 'Disabled'}
                    </p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                  className="min-h-[44px] select-none dark:bg-slate-800 dark:text-white dark:border-slate-700"
                >
                  Toggle Theme
                </Button>
              </div>
            </CardContent>
            </Card>
            </TabsContent>

            <TabsContent value="notifications" className="mt-4">
            <Card className="border-0 shadow-sm dark:bg-slate-900 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-base dark:text-white flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Notification Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <NotificationPreferencesPanel />
              </CardContent>
            </Card>
            </TabsContent>

          <TabsContent value="data" className="space-y-4 mt-4">
            {/* Data Retention Policy Info */}
            <Card className="border-0 shadow-sm dark:bg-slate-900 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-base dark:text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-emerald-600" />
                  Data Retention & Deletion Policy
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900 p-4 space-y-3">
                  <div className="flex gap-3">
                    <Shield className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-blue-800 dark:text-blue-300">POPIA Compliance</p>
                      <p className="text-xs text-blue-700 dark:text-blue-400 mt-0.5">
                        Your data is handled in accordance with the Protection of Personal Information Act (POPIA) and applicable data protection legislation.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <Download className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-blue-800 dark:text-blue-300">Data Export Window</p>
                      <p className="text-xs text-blue-700 dark:text-blue-400 mt-0.5">
                        Upon termination of your subscription, you may request a full export of your data within <strong>30 days</strong>. Exports include compliance requirements, risk assessments, monitoring logs, documents, and audit records.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <Clock className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-blue-800 dark:text-blue-300">Post-Termination Retention</p>
                      <p className="text-xs text-blue-700 dark:text-blue-400 mt-0.5">
                        After the 30-day export window, your data may be securely archived or permanently deleted in line with POPIA requirements. You will be notified before any deletion occurs.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
                  To request a data export or exercise your right to erasure, please contact our support team or submit a support ticket. We will process your request within <strong>5 business days</strong>.
                </div>
              </CardContent>
            </Card>

            {/* Request Data Export */}
            <Card className="border-0 shadow-sm dark:bg-slate-900 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-base dark:text-white flex items-center gap-2">
                  <Download className="w-5 h-5 text-slate-500" />
                  Request Data Export
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm text-slate-700 dark:text-slate-300">
                      Download a copy of your organisation's compliance data including requirements, risks, documents, and monitoring logs.
                    </p>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                      A download link will be sent to your account email within 24 hours of your request.
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="shrink-0 min-h-[44px] gap-2 dark:bg-slate-800 dark:text-white dark:border-slate-700"
                    onClick={async () => {
                      try {
                        const user = await base44.auth.me();
                        await base44.integrations.Core.SendEmail({
                          to: user.email,
                          subject: 'Data Export Request Received',
                          body: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;background:#f8fafc;border-radius:10px;"><h2 style="color:#10b981;">Data Export Request</h2><p style="color:#475569;">Hi ${user.full_name || 'there'},</p><p style="color:#475569;">We have received your data export request. Your export will be prepared and a download link will be sent to this email address within <strong>24 hours</strong>.</p><p style="color:#475569;">If you have any questions, please submit a support ticket in the platform.</p><p style="color:#94a3b8;font-size:12px;margin-top:20px;">Package Manufacturing Compliance Tracker · POPIA Data Export</p></div>`,
                        });
                        toast.success('Export request submitted. Check your email within 24 hours.');
                      } catch {
                        toast.error('Failed to submit request. Please try again or contact support.');
                      }
                    }}
                  >
                    <Download className="w-4 h-4" />
                    Request Export
                  </Button>
                </div>
              </CardContent>
            </Card>

            </TabsContent>

          <TabsContent value="account" className="space-y-4 mt-4">
            <Card className="border-0 shadow-sm dark:bg-slate-900 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-base dark:text-white flex items-center gap-2">
                  <Trash2 className="w-5 h-5 text-rose-600" />
                  Account Deletion
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900 p-4 space-y-2">
                  <p className="text-sm font-semibold text-rose-800 dark:text-rose-300">Permanent Action</p>
                  <p className="text-xs text-rose-700 dark:text-rose-400">
                    Deleting your account will permanently remove all your compliance data, documents, risk assessments, monitoring logs, and personal information from our servers. This cannot be undone.
                  </p>
                  <ul className="text-xs text-rose-600 dark:text-rose-400 list-disc ml-4 space-y-1 mt-1">
                    <li>All compliance requirements and evidence</li>
                    <li>All risk assessments and audit records</li>
                    <li>All uploaded documents and files</li>
                    <li>All monitoring logs and reports</li>
                  </ul>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  If you wish to keep a copy of your data, please request a data export first from the <strong>Data & Privacy</strong> tab before deleting your account.
                </p>
                <Button
                  variant="destructive"
                  className="w-full min-h-[44px] gap-2"
                  onClick={() => setShowDeleteDialog(true)}
                >
                  <Trash2 className="w-4 h-4" />
                  Delete My Account
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
            </Tabs>
            </div>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="dark:bg-slate-900 dark:border-slate-800">
          <AlertDialogHeader>
            <AlertDialogTitle className="dark:text-white">Delete Account Permanently?</AlertDialogTitle>
            <AlertDialogDescription className="dark:text-slate-400 space-y-2">
              <span className="block">This action <strong>cannot be undone</strong>. All of the following will be permanently deleted:</span>
              <span className="block pl-2 text-xs space-y-0.5">
                <span className="block">• Compliance requirements & evidence</span>
                <span className="block">• Risk assessments & audit records</span>
                <span className="block">• Documents, monitoring logs & reports</span>
                <span className="block">• Your personal account and login access</span>
              </span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="min-h-[44px] dark:bg-slate-800 dark:text-white dark:border-slate-700">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteAccount}
              disabled={isDeleting}
              className="min-h-[44px] bg-rose-600 hover:bg-rose-700"
            >
              {isDeleting ? 'Deleting...' : 'Delete Account'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}