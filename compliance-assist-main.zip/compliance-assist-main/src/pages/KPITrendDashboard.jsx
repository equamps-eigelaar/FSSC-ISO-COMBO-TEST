import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend
} from "recharts";
import {
  ShieldCheck, TrendingUp, TrendingDown, AlertTriangle,
  CheckCircle2, Clock, FileText, Activity, Users
} from "lucide-react";
import { format, subMonths, startOfMonth } from "date-fns";

const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6"];

export default function KPITrendDashboard() {
  const { data: requirements = [] } = useQuery({
    queryKey: ["kpi-requirements"],
    queryFn: () => base44.entities.ComplianceRequirement.list("-created_date", 500),
  });

  const { data: risks = [] } = useQuery({
    queryKey: ["kpi-risks"],
    queryFn: () => base44.entities.RiskAssessment.list("-created_date", 500),
  });

  const { data: actions = [] } = useQuery({
    queryKey: ["kpi-actions"],
    queryFn: () => base44.entities.ActionItem.list("-created_date", 500),
  });

  const { data: documents = [] } = useQuery({
    queryKey: ["kpi-documents"],
    queryFn: () => base44.entities.Document.list("-created_date", 200),
  });

  const { data: audits = [] } = useQuery({
    queryKey: ["kpi-audits"],
    queryFn: () => base44.entities.ComplianceAudit.list("-audit_date", 12),
  });

  // Compliance score
  const complianceScore = useMemo(() => {
    if (!requirements.length) return 0;
    const compliant = requirements.filter(r => r.status === "compliant").length;
    return Math.round((compliant / requirements.length) * 100);
  }, [requirements]);

  // Risk summary
  const riskSummary = useMemo(() => ({
    critical: risks.filter(r => r.risk_level === "critical").length,
    high: risks.filter(r => r.risk_level === "high").length,
    medium: risks.filter(r => r.risk_level === "medium").length,
    low: risks.filter(r => r.risk_level === "low").length,
  }), [risks]);

  // Action items summary
  const actionSummary = useMemo(() => ({
    pending: actions.filter(a => a.status === "pending").length,
    inProgress: actions.filter(a => a.status === "in_progress").length,
    completed: actions.filter(a => a.status === "completed").length,
    overdue: actions.filter(a => a.due_date && new Date(a.due_date) < new Date() && a.status !== "completed").length,
  }), [actions]);

  // Trend data from audits (last 6 months simulated from requirements updated_date)
  const trendData = useMemo(() => {
    const months = Array.from({ length: 6 }, (_, i) => {
      const month = subMonths(new Date(), 5 - i);
      const label = format(month, "MMM yy");
      const monthStart = startOfMonth(month);
      const monthEnd = startOfMonth(subMonths(month, -1));
      const monthReqs = requirements.filter(r => {
        const d = new Date(r.updated_date || r.created_date);
        return d >= monthStart && d < monthEnd;
      });
      const compliant = monthReqs.filter(r => r.status === "compliant").length;
      const total = monthReqs.length || 1;
      return {
        month: label,
        score: Math.round((compliant / total) * 100),
        compliant,
        nonCompliant: monthReqs.filter(r => r.status === "non_compliant").length,
        inProgress: monthReqs.filter(r => r.status === "in_progress").length,
      };
    });
    return months;
  }, [requirements]);

  // Audit scores trend
  const auditTrend = useMemo(() =>
    audits.slice(0, 6).reverse().map(a => ({
      date: format(new Date(a.audit_date), "MMM yy"),
      score: a.overall_score || 0,
    })), [audits]);

  // Requirements by section
  const sectionData = useMemo(() => {
    const map = {};
    requirements.forEach(r => {
      const sec = (r.section || "Other").split(" - ")[0];
      if (!map[sec]) map[sec] = { section: sec, compliant: 0, total: 0 };
      map[sec].total++;
      if (r.status === "compliant") map[sec].compliant++;
    });
    return Object.values(map).map(s => ({ ...s, score: Math.round((s.compliant / s.total) * 100) }));
  }, [requirements]);

  // Document expiry
  const expiringDocs = useMemo(() =>
    documents.filter(d => {
      if (!d.expiry_date) return false;
      const exp = new Date(d.expiry_date);
      const diff = (exp - new Date()) / (1000 * 60 * 60 * 24);
      return diff >= 0 && diff <= 90;
    }).length, [documents]);

  const kpiCards = [
    {
      label: "Compliance Score",
      value: `${complianceScore}%`,
      icon: ShieldCheck,
      color: complianceScore >= 80 ? "emerald" : complianceScore >= 60 ? "amber" : "rose",
      sub: `${requirements.filter(r => r.status === "compliant").length} / ${requirements.length} compliant`,
    },
    {
      label: "Critical Risks",
      value: riskSummary.critical,
      icon: AlertTriangle,
      color: riskSummary.critical === 0 ? "emerald" : "rose",
      sub: `${riskSummary.high} high, ${riskSummary.medium} medium`,
    },
    {
      label: "Overdue Actions",
      value: actionSummary.overdue,
      icon: Clock,
      color: actionSummary.overdue === 0 ? "emerald" : actionSummary.overdue < 5 ? "amber" : "rose",
      sub: `${actionSummary.inProgress} in progress`,
    },
    {
      label: "Docs Expiring (90d)",
      value: expiringDocs,
      icon: FileText,
      color: expiringDocs === 0 ? "emerald" : expiringDocs < 3 ? "amber" : "rose",
      sub: `${documents.length} total documents`,
    },
  ];

  const colorMap = {
    emerald: { bg: "bg-emerald-50", text: "text-emerald-700", icon: "text-emerald-600", badge: "bg-emerald-100 text-emerald-700" },
    amber: { bg: "bg-amber-50", text: "text-amber-700", icon: "text-amber-600", badge: "bg-amber-100 text-amber-700" },
    rose: { bg: "bg-rose-50", text: "text-rose-700", icon: "text-rose-600", badge: "bg-rose-100 text-rose-700" },
  };

  const riskPieData = [
    { name: "Critical", value: riskSummary.critical, color: "#ef4444" },
    { name: "High", value: riskSummary.high, color: "#f97316" },
    { name: "Medium", value: riskSummary.medium, color: "#f59e0b" },
    { name: "Low", value: riskSummary.low, color: "#10b981" },
  ].filter(d => d.value > 0);

  const statusPieData = [
    { name: "Compliant", value: requirements.filter(r => r.status === "compliant").length, color: "#10b981" },
    { name: "In Progress", value: requirements.filter(r => r.status === "in_progress").length, color: "#3b82f6" },
    { name: "Partial", value: requirements.filter(r => r.status === "partial").length, color: "#f59e0b" },
    { name: "Non-Compliant", value: requirements.filter(r => r.status === "non_compliant").length, color: "#ef4444" },
    { name: "Not Started", value: requirements.filter(r => r.status === "not_started").length, color: "#94a3b8" },
  ].filter(d => d.value > 0);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">KPI Trend Dashboard</h1>
            <p className="text-sm text-slate-500">Real-time compliance performance indicators</p>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {kpiCards.map((kpi) => {
            const c = colorMap[kpi.color];
            return (
              <Card key={kpi.label} className="border-0 shadow-sm">
                <CardContent className="p-5">
                  <div className={`w-10 h-10 rounded-lg ${c.bg} flex items-center justify-center mb-3`}>
                    <kpi.icon className={`w-5 h-5 ${c.icon}`} />
                  </div>
                  <div className={`text-3xl font-bold ${c.text} mb-1`}>{kpi.value}</div>
                  <div className="text-sm font-medium text-slate-700 mb-1">{kpi.label}</div>
                  <div className="text-xs text-slate-400">{kpi.sub}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Trend Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Compliance Score Trend */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                Compliance Activity Trend (6 Months)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="compliant" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} name="Compliant" />
                  <Line type="monotone" dataKey="inProgress" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} name="In Progress" />
                  <Line type="monotone" dataKey="nonCompliant" stroke="#ef4444" strokeWidth={2} dot={{ r: 3 }} name="Non-Compliant" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Audit Score Trend */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-600" />
                AI Audit Scores Trend
              </CardTitle>
            </CardHeader>
            <CardContent>
              {auditTrend.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={auditTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
                    <Tooltip formatter={(v) => [`${v}%`, "Score"]} />
                    <Bar dataKey="score" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Audit Score" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[220px] flex items-center justify-center text-slate-400 text-sm">
                  No audit data yet. Run AI audits to see trends.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Pie Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Status Distribution */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Requirements Status Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={statusPieData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                    {statusPieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Risk Distribution */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-500" />
                Risk Level Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              {riskPieData.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie data={riskPieData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                      {riskPieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[220px] flex items-center justify-center text-slate-400 text-sm">No risk data yet.</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Section Progress */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Compliance Score by Section
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={sectionData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11 }} tickFormatter={v => `${v}%`} />
                <YAxis type="category" dataKey="section" tick={{ fontSize: 10 }} width={40} />
                <Tooltip formatter={(v) => [`${v}%`, "Score"]} />
                <Bar dataKey="score" radius={[0, 4, 4, 0]}>
                  {sectionData.map((entry, i) => (
                    <Cell key={i} fill={entry.score >= 80 ? "#10b981" : entry.score >= 60 ? "#f59e0b" : "#ef4444"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}