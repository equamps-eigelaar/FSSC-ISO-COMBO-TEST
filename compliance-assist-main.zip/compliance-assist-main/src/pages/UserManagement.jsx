import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield, Mail, UserPlus, Search } from "lucide-react";
import { usePermissions, getRoleLabel, getRoleColor, getRoleDescription, getRolePermissions } from "@/components/permissions/usePermissions";
import { toast } from "sonner";
import RolePermissionsMatrix from "@/components/permissions/RolePermissionsMatrix";
import RoleManager from "@/components/permissions/RoleManager";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Info } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export default function UserManagement() {
  const [search, setSearch] = useState("");
  const [showInvite, setShowInvite] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("read_only");

  const { permissions, isLoading: permLoading } = usePermissions();
  const queryClient = useQueryClient();

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list("-created_date", 100),
    enabled: permissions.canManageUsers,
  });

  const updateRoleMutation = useMutation({
    mutationFn: ({ userId, role }) =>
      base44.entities.User.update(userId, { role }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["users"] });
      toast.success("User role updated");
    },
    onError: () => toast.error("Failed to update role"),
  });

  const inviteMutation = useMutation({
    mutationFn: async ({ email, role }) => {
      await base44.users.inviteUser(email, "user");
      // Note: The invited user will need their compliance role set after they accept
      toast.success(`Invitation sent to ${email}`, {
        description: "Set their compliance role after they register",
      });
    },
    onSuccess: () => {
      setShowInvite(false);
      setInviteEmail("");
      setInviteRole("read_only");
    },
    onError: () => toast.error("Failed to send invitation"),
  });

  if (permLoading || isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!permissions.canManageUsers) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <Shield className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-slate-900 mb-2">Access Denied</h2>
            <p className="text-sm text-slate-500">
              You don't have permission to manage users. Contact an administrator.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredUsers = users.filter(u =>
    u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">User Management</h1>
            <p className="text-sm text-slate-500 mt-1">Manage users, roles, and permissions</p>
          </div>
          <Button onClick={() => setShowInvite(true)} className="bg-emerald-600 hover:bg-emerald-700">
            <UserPlus className="w-4 h-4 mr-2" />
            Invite User
          </Button>
        </div>

        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="bg-white border border-slate-200 flex-wrap h-auto gap-1">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="manage-roles">Manage Roles</TabsTrigger>
            <TabsTrigger value="roles">Role Descriptions</TabsTrigger>
            <TabsTrigger value="matrix">Permissions Matrix</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">

        <Card className="border-0 shadow-sm mb-4">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search users..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 border-slate-200"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-600" />
              Users ({filteredUsers.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-slate-50">
              {filteredUsers.map(user => (
                <div key={user.id} className="p-4 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="text-sm font-medium text-slate-900">
                          {user.full_name || "Unnamed User"}
                        </h3>
                        <Badge
                          variant="outline"
                          className={getRoleColor(user.role || "viewer")}
                        >
                          {getRoleLabel(user.role || "viewer")}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <Mail className="w-3 h-3" />
                        {user.email}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select
                       value={user.role || "viewer"}
                       onValueChange={(newRole) =>
                         updateRoleMutation.mutate({ userId: user.id, role: newRole })
                       }
                       disabled={user.role === "admin"}
                      >
                       <SelectTrigger className="w-52 h-8 text-xs">
                         <SelectValue />
                       </SelectTrigger>
                       <SelectContent>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="compliance_manager">Compliance Manager</SelectItem>
                        <SelectItem value="auditor">Auditor</SelectItem>
                        <SelectItem value="site_manager">Site Manager</SelectItem>
                        <SelectItem value="food_safety_manager">Food Safety Manager</SelectItem>
                        <SelectItem value="quality_auditor">Quality Auditor</SelectItem>
                        <SelectItem value="production_operator">Production Operator</SelectItem>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="viewer">Viewer</SelectItem>
                       </SelectContent>
                       </Select>
                    </div>
                  </div>
                </div>
              ))}

              {filteredUsers.length === 0 && (
                <div className="p-8 text-center text-slate-500 text-sm">
                  No users found
                </div>
              )}
            </div>
          </CardContent>
        </Card>
          </TabsContent>

          <TabsContent value="manage-roles">
            <RoleManager />
          </TabsContent>

          <TabsContent value="roles">
            <div className="grid gap-4">
              {["admin", "compliance_manager", "auditor", "site_manager", "food_safety_manager", "quality_auditor", "production_operator", "user", "viewer"].map(role => (
                <Card key={role} className="border-0 shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Badge className={getRoleColor(role)} variant="outline">
                            {getRoleLabel(role)}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600 mb-4">
                          {getRoleDescription(role)}
                        </p>
                        <div>
                          <h4 className="text-xs font-semibold text-slate-700 mb-2">Permissions:</h4>
                          <ul className="space-y-1">
                            {getRolePermissions(role).map((perm, idx) => (
                              <li key={idx} className="text-xs text-slate-600 flex items-center gap-2">
                                <div className="w-1 h-1 rounded-full bg-emerald-600" />
                                {perm}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="matrix">
            <RolePermissionsMatrix />
          </TabsContent>
        </Tabs>

        <Dialog open={showInvite} onOpenChange={setShowInvite}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Invite User</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div>
                <Label className="text-xs">Email Address</Label>
                <Input
                  type="email"
                  placeholder="user@example.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                />
              </div>
              <div>
                <Label className="text-xs">Role</Label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="compliance_manager">Compliance Manager</SelectItem>
                    <SelectItem value="auditor">Auditor</SelectItem>
                    <SelectItem value="site_manager">Site Manager</SelectItem>
                    <SelectItem value="food_safety_manager">Food Safety Manager</SelectItem>
                    <SelectItem value="quality_auditor">Quality Auditor</SelectItem>
                    <SelectItem value="production_operator">Production Operator</SelectItem>
                    <SelectItem value="user">User</SelectItem>
                    <SelectItem value="viewer">Viewer</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500 mt-1.5">
                  You can update their role after they accept the invitation
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowInvite(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => inviteMutation.mutate({ email: inviteEmail, role: inviteRole })}
                disabled={!inviteEmail || inviteMutation.isPending}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {inviteMutation.isPending ? "Sending..." : "Send Invitation"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}