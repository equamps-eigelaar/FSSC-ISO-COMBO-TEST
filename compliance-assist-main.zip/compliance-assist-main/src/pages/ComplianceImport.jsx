import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Upload, Zap } from "lucide-react";
import ComplianceImportCSV from "@/components/compliance/ComplianceImportCSV";
import ComplianceImportAPI from "@/components/compliance/ComplianceImportAPI";
import { usePermissions } from "@/components/permissions/usePermissions";

export default function ComplianceImport() {
  const { permissions } = usePermissions();

  if (!permissions.canManageSettings) {
    return (
      <div className="min-h-screen bg-slate-50 p-6">
        <div className="max-w-4xl mx-auto">
          <Card className="border-rose-200 bg-rose-50">
            <CardContent className="p-6 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-rose-900">Access Restricted</h3>
                <p className="text-sm text-rose-800 mt-1">
                  You don't have permission to manage compliance imports.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-4 sm:p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Compliance Data Import</h1>
          <p className="text-slate-600">
            Ingest compliance data from external sources with field mapping and validation
          </p>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <Card className="border-0 shadow-sm bg-blue-50 border-l-4 border-blue-600">
            <CardContent className="p-4">
              <div className="flex gap-3">
                <Upload className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-blue-900">CSV Import</h3>
                  <p className="text-sm text-blue-800 mt-1">
                    Upload CSV files and map columns to compliance requirements with validation
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-purple-50 border-l-4 border-purple-600">
            <CardContent className="p-4">
              <div className="flex gap-3">
                <Zap className="w-5 h-5 text-purple-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-purple-900">API Integration</h3>
                  <p className="text-sm text-purple-800 mt-1">
                    Connect to third-party compliance databases for automated imports
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Import Methods */}
        <Card className="border-0 shadow-sm">
          <Tabs defaultValue="csv" className="w-full">
            <TabsList className="border-b border-slate-200 bg-transparent p-0 h-auto w-full justify-start rounded-none">
              <TabsTrigger value="csv" className="px-6 py-3 border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent rounded-none">
                CSV Upload
              </TabsTrigger>
              <TabsTrigger value="api" className="px-6 py-3 border-b-2 border-transparent data-[state=active]:border-emerald-600 data-[state=active]:bg-transparent rounded-none">
                API Integration
              </TabsTrigger>
            </TabsList>

            <TabsContent value="csv" className="p-6">
              <ComplianceImportCSV />
            </TabsContent>

            <TabsContent value="api" className="p-6">
              <ComplianceImportAPI />
            </TabsContent>
          </Tabs>
        </Card>

        {/* Framework Info */}
        <Card className="border-0 shadow-sm mt-8 bg-amber-50 border-l-4 border-amber-600">
          <CardHeader>
            <CardTitle className="text-sm">Supported Frameworks</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-amber-900">
            <ul className="space-y-1">
              <li>• <strong>Food Safety Management System</strong> - Core food safety requirements</li>
              <li>• <strong>Prerequisite Programmes</strong> - Packaging and manufacturing PRPs</li>
              <li>Custom frameworks via field mapping</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}