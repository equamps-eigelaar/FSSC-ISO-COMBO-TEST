import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Activity, Search, Download, CheckCircle2, AlertTriangle, XCircle,
  FileText, User, Shield, Package, GitBranch, ChevronDown,
  ChevronRight, History, RefreshCw, Filter, AlertCircle,
} from "lucide-react";
import { format, isToday, isYesterday } from "date-fns";

// ── Config ─────────────────────────────────────────────────────────────────────

const TYPE_CONFIG = {
  requirement_created:      { icon: FileText,      color: "text-blue-600",    bg: "bg-blue-50",    label: "Req. Created",        module: "requirements" },
  requirement_updated:      { icon: FileText,      color: "text-amber-600",   bg: "bg-amber-50",   label: "Req. Updated",        module: "requirements" },
  requirement_deleted:      { icon: XCircle,       color: "text-rose-600",    bg: "bg-rose-50",    label: "Req. Deleted",        module: "requirements" },
  status_changed:           { icon: CheckCircle2,  color: "text-emerald-600", bg: "bg-emerald-50", label: "Status Changed",      module: "requirements" },
  risk_added:               { icon: AlertTriangle, color: "text-orange-600",  bg: "bg-orange-50",  label: "Risk Added",          module: "risks" },
  risk_updated:             { icon: AlertTriangle, color: "text-amber-600",   bg: "bg-amber-50",   label: "Risk Updated",        module: "risks" },
  risk_deleted:             { icon: AlertTriangle, color: "text-rose-600",    bg: "bg-rose-50",    label: "Risk Deleted",        module: "risks" },
  risk_workflow_changed:    { icon: Shield,        color: "text-purple-600",  bg: "bg-purple-50",  label: "Risk Workflow",       module: "risks" },
  evidence_uploaded:        { icon: FileText,      color: "text-blue-600",    bg: "bg-blue-50",    label: "Evidence Uploaded",   module: "documents" },
  document_uploaded:        { icon: GitBranch,     color: "text-indigo-600",  bg: "bg-indigo-50",  label: "Doc Uploaded",        module: "documents" },
  document_updated:         { icon: GitBranch,     color: "text-amber-600",   bg: "bg-amber-50",   label: "Doc Updated",         module: "documents" },
  document_deleted:         { icon: XCircle,       color: "text-rose-600",    bg: "bg-rose-50",    label: "Doc Deleted",         module: "documents" },
  document_version_added:   { icon: GitBranch,     color: "text-indigo-600",  bg: "bg-indigo-50",  label: "New Doc Version",     module: "documents" },
  document_analysis_run:    { icon: Activity,      color: "text-violet-600",  bg: "bg-violet-50",  label: "AI Analysis",         module: "documents" },
  comment_added:            { icon: Activity,      color: "text-purple-600",  bg: "bg-purple-50",  label: "Comment",             module: "comments" },
  action_item_created:      { icon: CheckCircle2,  color: "text-sky-600",     bg: "bg-sky-50",     label: "Action Created",      module: "actions" },
  action_item_updated:      { icon: CheckCircle2,  color: "text-amber-600",   bg: "bg-amber-50",   label: "Action Updated",      module: "actions" },
  action_item_completed:    { icon: CheckCircle2,  color: "text-emerald-600", bg: "bg-emerald-50", label: "Action Completed",    module: "actions" },
  batch_created:            { icon: Package,       color: "text-cyan-600",    bg: "bg-cyan-50",    label: "Batch Created",       module: "traceability" },
  batch_updated:            { icon: Package,       color: "text-cyan-600",    bg: "bg-cyan-50",    label: "Batch Updated",       module: "traceability" },
  monitoring_log_added:     { icon: Activity,      color: "text-teal-600",    bg: "bg-teal-50",    label: "Monitoring Log",      module: "monitoring" },
  cleaning_task_completed:  { icon: CheckCircle2,  color: "text-green-600",   bg: "bg-green-50",   label: "Cleaning Done",       module: "monitoring" },
  user_invited:             { icon: User,          color: "text-emerald-600", bg: "bg-emerald-50", label: "User Invited",        module: "user" },
  user_login:               { icon: User,          color: "text-green-600",   bg: "bg-green-50",   label: "User Login",          module: "user" },
  user_logout:              { icon: User,          color: "text-slate-600",   bg: "bg-slate-100",  label: "User Logout",         module: "user" },
  report_generated:         { icon: FileText,      color: "text-indigo-600",  bg: "bg-indigo-50",  label: "Report Generated",    module: "reports" },
  settings_changed:         { icon: Shield,        color: "text-slate-600",   bg: "bg-slate-100",  label: "Settings Changed",    module: "settings" },
  access_control_event:     { icon: Shield,        color: "text-purple-600",  bg: "bg-purple-50",  label: "Access Control",      module: "user" },
  sensitive_data_accessed:  { icon: AlertCircle,   color: "text-rose-600",    bg: "bg-rose-50",    label: "Sensitive Access",    module: "user" },
  audit_completed:          { icon: CheckCircle2,  color: "text-green-600",   bg: "bg-green-50",   label: "Audit Completed",     module: "reports" },
  bulk_import:              { icon: Package,       color: "text-blue-600",    bg: "bg-blue-50",    label: "Bulk Import",         module: "settings" },
  subscription_changed:     { icon: AlertCircle,   color: "text-amber-600",   bg: "bg-amber-50",   label: "Subscription",        module: "settings" },
  support_ticket_created:   { icon: AlertTriangle, color: "text-orange-600",  bg: "bg-orange-50",  label: "Ticket Created",      module: "support" },
  support_ticket_updated:   { icon: AlertTriangle, color: "text-amber-600",   bg: "bg-amber-50",   label: "Ticket Updated",      module: "support" },
  review_completed:         { icon: CheckCircle2,  color: "text-emerald-600", bg: "bg-emerald-50", label: "Review Completed",    module: "documents" },
  bug_reported:             { icon: AlertTriangle, color: "text-orange-600",  bg: "bg-orange-50",  label: "Bug Reported",        module: "support" },
  system_event:             { icon: Activity,      color: "text-slate-500",   bg: "bg-slate-50",   label: "System",              module: "system" },
};

const SEVERITY_CONFIG = {
  critical: { label: "Critical", color: "text-rose-700",   bg: "bg-rose-100",   border: "border-rose-200" },
  high:     { label: "High",     color: "text-orange-700", bg: "bg-orange-100", border: "border-orange-200" },
  medium:   { label: "Medium",   color: "text-amber-700",  bg: "bg-amber-100",  border: "border-amber-200" },
  low:      { label: "Low",      color: "text-slate-600",  bg: "bg-slate-100",  border: "border-slate-200" },
};

const MODULE_OPTIONS = [
  { value: "all",           label: "All Modules" },
  { value: "requirements",  label: "Requirements" },
  { value: "risks",         label: "Risk Assessments" },
  { value: "documents",     label: "Documents" },
  { value: "actions",       label: "Action Items" },
  { value: "comments",      label: "Comments" },
  { value: "traceability",  label: "Traceability" },
  { value: "monitoring",    label: "Monitoring & Cleaning" },
  { value: "user",          label: "User Activity" },
  { value: "reports",       label: "Reports & Audits" },
  { value: "settings",      label: "Settings & Admin" },
  { value: "support",       label: "Support Tickets" },
];

// ── Helpers ────────────────────────────────────────────────────────────────────

function formatChangeVal(val) {
  if (val === null || val === undefined) return "—";
  if (typeof val === "boolean") return val ? "Yes" : "No";
  if (Array.isArray(val)) return `[${val.length} item(s)]`;
  if (typeof val === "object") return "[Object]";
  const s = String(val);
  return s.length > 80 ? s.substring(0, 80) + "…" : s;
}

function groupByDate(activities) {
  const groups = {};
  activities.forEach(a => {
    const d = new Date(a.created_date);
    let label;
    if (isToday(d)) label = "Today";
    else if (isYesterday(d)) label = "Yesterday";
    else label = format(d, "EEEE, MMMM d, yyyy");
    if (!groups[label]) groups[label] = [];
    groups[label].push(a);
  });
  return groups;
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function SeverityBadge({ severity }) {
  if (!severity || severity === "low") return null;
  const cfg = SEVERITY_CONFIG[severity] || SEVERITY_CONFIG.low;
  return (
    <span className={`text-[10px] px-1.5 py-0.5 rounded border font-semibold ${cfg.bg} ${cfg.color} ${cfg.border}`}>
      {cfg.label}
    </span>
  );
}

function ActivityRow({ activity }) {
  const [expanded, setExpanded] = useState(false);
  const cfg = TYPE_CONFIG[activity.activity_type] || TYPE_CONFIG.system_event;
  const Icon = cfg.icon;
  const hasChanges = activity.field_changes?.length > 0;

  return (
    <div className="bg-white rounded-lg border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
      <button
        className="w-full text-left p-4 flex items-start gap-3"
        onClick={() => hasChanges && setExpanded(!expanded)}
      >
        <div className={`w-8 h-8 rounded-lg ${cfg.bg} flex items-center justify-center shrink-0 mt-0.5`}>
          <Icon className={`w-4 h-4 ${cfg.color}`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm text-slate-900 font-medium leading-snug">{activity.description}</p>
            <span className="text-xs text-slate-400 shrink-0 whitespace-nowrap ml-2">
              {format(new Date(activity.created_date), "HH:mm")}
            </span>
          </div>
          <div className="flex items-center gap-2 flex-wrap mt-1.5">
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cfg.bg} ${cfg.color}`}>
              {cfg.label}
            </span>
            <SeverityBadge severity={activity.severity} />
            {activity.entity_type && (
              <Badge variant="outline" className="text-xs py-0">{activity.entity_type}</Badge>
            )}
            {activity.user_email && (
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <User className="w-3 h-3" />
                {activity.user_name || activity.user_email}
              </span>
            )}
            {hasChanges && (
              <span className="text-xs text-slate-400 flex items-center gap-1 ml-auto">
                {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                {activity.field_changes.length} field change{activity.field_changes.length > 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>
      </button>

      {expanded && hasChanges && (
        <div className="px-4 pb-4 border-t border-slate-50">
          <div className="mt-3 space-y-1.5">
            <div className="grid grid-cols-[130px_1fr_1fr] gap-2 text-xs text-slate-400 font-medium px-1 mb-1">
              <span>Field</span><span>Before</span><span>After</span>
            </div>
            {activity.field_changes.map((change, i) => (
              <div key={i} className="text-xs grid grid-cols-[130px_1fr_1fr] gap-2 items-center">
                <span className="font-medium text-slate-500 truncate">{change.field?.replace(/_/g, " ")}</span>
                <span className="text-rose-600 bg-rose-50 px-2 py-0.5 rounded truncate border border-rose-100">
                  {formatChangeVal(change.old_value)}
                </span>
                <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded truncate border border-emerald-100">
                  {formatChangeVal(change.new_value)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, color, sub }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4">
        <div className={`text-2xl font-bold ${color} mb-0.5`}>{value}</div>
        <div className="text-xs text-slate-500 font-medium">{label}</div>
        {sub && <div className="text-[10px] text-slate-400 mt-0.5">{sub}</div>}
      </CardContent>
    </Card>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export default function ActivityMonitor() {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [moduleFilter, setModuleFilter] = useState("all");
  const [dateRange, setDateRange] = useState("30");
  const [userFilter, setUserFilter] = useState("all");
  const [severityFilter, setSeverityFilter] = useState("all");
  const queryClient = useQueryClient();

  const { data: activities = [], isLoading, isFetching } = useQuery({
    queryKey: ["activity-logs"],
    queryFn: () => base44.entities.ActivityLog.list("-created_date", 1000),
  });

  const { data: comments = [] } = useQuery({
    queryKey: ["all-comments"],
    queryFn: () => base44.entities.Comment.list("-created_date", 200),
  });

  useEffect(() => {
    const unsubscribe = base44.entities.ActivityLog.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ["activity-logs"] });
    });
    return unsubscribe;
  }, [queryClient]);

  // Merge comments into feed
  const allActivities = [
    ...activities,
    ...comments.map(c => ({
      id: `comment-${c.id}`,
      activity_type: "comment_added",
      entity_type: c.entity_type,
      entity_id: c.entity_id,
      entity_label: c.entity_id,
      description: `${c.user_name || c.user_email} commented on ${c.entity_type}`,
      user_email: c.user_email,
      user_name: c.user_name,
      created_date: c.created_date,
      severity: "low",
    })),
  ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  const users = [...new Set(allActivities.map(a => a.user_email).filter(Boolean))];

  const filtered = allActivities.filter(a => {
    const matchSearch =
      !search ||
      a.description?.toLowerCase().includes(search.toLowerCase()) ||
      a.user_email?.toLowerCase().includes(search.toLowerCase()) ||
      a.user_name?.toLowerCase().includes(search.toLowerCase()) ||
      a.entity_label?.toLowerCase().includes(search.toLowerCase()) ||
      a.entity_type?.toLowerCase().includes(search.toLowerCase());

    const matchType = typeFilter === "all" || a.activity_type === typeFilter;
    const matchUser = userFilter === "all" || a.user_email === userFilter;
    const matchSeverity = severityFilter === "all" || (a.severity || "low") === severityFilter;

    const actModule = TYPE_CONFIG[a.activity_type]?.module || "system";
    const matchModule = moduleFilter === "all" || actModule === moduleFilter;

    if (dateRange !== "all") {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - parseInt(dateRange));
      if (new Date(a.created_date) < cutoff) return false;
    }

    return matchSearch && matchType && matchModule && matchUser && matchSeverity;
  });

  // Stats
  const todayCount = allActivities.filter(a => isToday(new Date(a.created_date))).length;
  const criticalCount = allActivities.filter(a => a.severity === "critical" || a.severity === "high").length;
  const uniqueUsers = new Set(allActivities.map(a => a.user_email).filter(Boolean)).size;

  const exportCSV = () => {
    const rows = [
      ["Date", "Time", "Type", "Module", "Severity", "Description", "Entity Type", "Entity", "User Email", "User Name", "Field Changes"],
      ...filtered.map(a => [
        format(new Date(a.created_date), "yyyy-MM-dd"),
        format(new Date(a.created_date), "HH:mm:ss"),
        a.activity_type,
        TYPE_CONFIG[a.activity_type]?.module || "",
        a.severity || "low",
        `"${(a.description || "").replace(/"/g, "'")}"`,
        a.entity_type || "",
        `"${(a.entity_label || a.entity_id || "").replace(/"/g, "'")}"`,
        a.user_email || "system",
        a.user_name || "",
        a.field_changes?.length || 0,
      ])
    ].map(r => r.join(",")).join("\n");

    const blob = new Blob([rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const el = document.createElement("a");
    el.href = url;
    el.download = `audit-trail-${format(new Date(), "yyyy-MM-dd")}.csv`;
    el.click();
    URL.revokeObjectURL(url);
  };

  const clearFilters = () => {
    setSearch(""); setTypeFilter("all"); setModuleFilter("all");
    setUserFilter("all"); setSeverityFilter("all");
  };
  const hasFilters = search || typeFilter !== "all" || moduleFilter !== "all" || userFilter !== "all" || severityFilter !== "all";

  const grouped = groupByDate(filtered);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        {/* Header */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <History className="w-7 h-7 text-emerald-600" />
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Audit Trail</h1>
              {isFetching && <RefreshCw className="w-4 h-4 text-slate-400 animate-spin" />}
            </div>
            <p className="text-slate-500 text-sm ml-10">
              Searchable, filterable history of all user actions across the system
            </p>
          </div>
          <Button onClick={exportCSV} variant="outline" size="sm" className="gap-2">
            <Download className="w-4 h-4" />
            Export CSV
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <StatCard label="Total Events" value={allActivities.length.toLocaleString()} color="text-slate-700" />
          <StatCard label="Today" value={todayCount} color="text-emerald-600" />
          <StatCard label="High / Critical" value={criticalCount} color="text-rose-600" />
          <StatCard label="Active Users" value={uniqueUsers} color="text-indigo-600" />
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm mb-5">
          <CardContent className="p-4">
            <div className="flex flex-col gap-3">
              {/* Row 1: search + export */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search by description, user, entity type…"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              {/* Row 2: dropdowns */}
              <div className="flex flex-wrap gap-2">
                <Select value={moduleFilter} onValueChange={setModuleFilter}>
                  <SelectTrigger className="w-[160px]">
                    <Filter className="w-3.5 h-3.5 text-slate-400 mr-1" />
                    <SelectValue placeholder="Module" />
                  </SelectTrigger>
                  <SelectContent>
                    {MODULE_OPTIONS.map(o => (
                      <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-[170px]">
                    <SelectValue placeholder="Event type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Event Types</SelectItem>
                    {Object.entries(TYPE_CONFIG).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={severityFilter} onValueChange={setSeverityFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Severity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Severities</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={userFilter} onValueChange={setUserFilter}>
                  <SelectTrigger className="w-[200px]">
                    <User className="w-3.5 h-3.5 text-slate-400 mr-1" />
                    <SelectValue placeholder="User" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Users</SelectItem>
                    {users.map(u => (
                      <SelectItem key={u} value={u}>{u}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Last 24h</SelectItem>
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 90 days</SelectItem>
                    <SelectItem value="365">Last year</SelectItem>
                    <SelectItem value="all">All Time</SelectItem>
                  </SelectContent>
                </Select>

                {hasFilters && (
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="text-slate-400 hover:text-slate-700">
                    Clear filters
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results count */}
        <p className="text-xs text-slate-400 mb-4">
          Showing <span className="font-semibold text-slate-600">{filtered.length.toLocaleString()}</span> of {allActivities.length.toLocaleString()} events
          {hasFilters && " · filters active"}
          {" · click a row to expand field-level changes"}
        </p>

        {/* Feed */}
        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-16 text-center">
              <History className="w-12 h-12 text-slate-200 mx-auto mb-3" />
              <p className="text-slate-500 font-medium">No audit events found</p>
              <p className="text-slate-400 text-sm mt-1">Try adjusting your filters or date range</p>
              {hasFilters && (
                <Button variant="outline" size="sm" className="mt-4" onClick={clearFilters}>Clear all filters</Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {Object.entries(grouped).map(([dateLabel, items]) => (
              <div key={dateLabel}>
                <div className="flex items-center gap-3 mb-3">
                  <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{dateLabel}</h2>
                  <div className="flex-1 h-px bg-slate-100" />
                  <span className="text-xs text-slate-400">{items.length} event{items.length !== 1 ? "s" : ""}</span>
                </div>
                <div className="space-y-2">
                  {items.map(a => <ActivityRow key={a.id} activity={a} />)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}