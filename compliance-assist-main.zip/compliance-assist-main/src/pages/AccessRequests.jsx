import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle2, XCircle, Clock, DollarSign, Search, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { usePermissions } from "@/components/permissions/usePermissions";

const statusBadgeConfig = {
  pending: { bg: "bg-yellow-100 text-yellow-800", icon: Clock, label: "Pending" },
  payment_pending: { bg: "bg-orange-100 text-orange-800", icon: DollarSign, label: "Payment Pending" },
  payment_complete: { bg: "bg-blue-100 text-blue-800", icon: CheckCircle2, label: "Payment Complete" },
  approved: { bg: "bg-green-100 text-green-800", icon: CheckCircle2, label: "Approved" },
  rejected: { bg: "bg-red-100 text-red-800", icon: XCircle, label: "Rejected" },
  expired: { bg: "bg-slate-100 text-slate-800", icon: Clock, label: "Expired" },
};

export default function AccessRequests() {
  const { permissions } = usePermissions();
  const [search, setSearch] = useState("");
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [approvalNotes, setApprovalNotes] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");
  const [actionType, setActionType] = useState(null);
  const queryClient = useQueryClient();

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["accessRequests"],
    queryFn: () => base44.entities.AccessRequest.list("-created_date", 100),
    enabled: permissions.canManageUsers,
  });

  const approveMutation = useMutation({
    mutationFn: async ({ requestId, role }) => {
      const user = await base44.auth.me();
      await base44.entities.AccessRequest.update(requestId, {
        status: "approved",
        approved_by: user.email,
        approval_date: new Date().toISOString(),
        notes: approvalNotes,
      });
      // Send invitation to the user
      const request = requests.find(r => r.id === requestId);
      await base44.users.inviteUser(request.email, "user");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["accessRequests"] });
      toast.success("Request approved and invitation sent");
      setSelectedRequest(null);
      setApprovalNotes("");
      setActionType(null);
    },
    onError: () => toast.error("Failed to approve request"),
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ requestId }) => {
      const user = await base44.auth.me();
      await base44.entities.AccessRequest.update(requestId, {
        status: "rejected",
        approved_by: user.email,
        rejection_date: new Date().toISOString(),
        rejection_reason: rejectionReason,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["accessRequests"] });
      toast.success("Request rejected");
      setSelectedRequest(null);
      setRejectionReason("");
      setActionType(null);
    },
    onError: () => toast.error("Failed to reject request"),
  });

  if (!permissions.canManageUsers) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <UserPlus className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-slate-900 mb-2">Access Denied</h2>
            <p className="text-sm text-slate-500">Only admins can manage access requests.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredRequests = requests.filter(r =>
    r.email?.toLowerCase().includes(search.toLowerCase()) ||
    r.company_name?.toLowerCase().includes(search.toLowerCase())
  );

  const pendingCount = requests.filter(r => r.status === "payment_complete").length;

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Access Requests</h1>
            <p className="text-sm text-slate-500 mt-1">Manage user access requests and approvals</p>
          </div>
          {pendingCount > 0 && (
            <Badge className="bg-red-100 text-red-800 px-3 py-1.5 text-sm gap-1.5">
              <Clock className="w-4 h-4" />
              {pendingCount} Awaiting Review
            </Badge>
          )}
        </div>

        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search by email or company..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 border-slate-200"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="text-sm font-semibold">Requests ({filteredRequests.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-8 text-center text-slate-500">Loading...</div>
            ) : filteredRequests.length === 0 ? (
              <div className="p-8 text-center text-slate-500">No requests found</div>
            ) : (
              <div className="divide-y divide-slate-50">
                {filteredRequests.map(request => {
                  const config = statusBadgeConfig[request.status];
                  return (
                    <div key={request.id} className="p-4 hover:bg-slate-50 transition-colors">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-medium text-slate-900">{request.email}</h3>
                            <Badge className={config.bg}>{config.label}</Badge>
                          </div>
                          <div className="text-sm text-slate-600">
                            <p>{request.company_name}</p>
                            <p className="text-xs text-slate-500 mt-1">
                              Role: {request.requested_role} • Requested {new Date(request.created_date).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedRequest(request)}
                          className="shrink-0"
                        >
                          {request.status === "approved" ? "View" : "Review"}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selectedRequest} onOpenChange={(open) => !open && setSelectedRequest(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Access Request Details</DialogTitle>
          </DialogHeader>
          {selectedRequest && (
            <div className="space-y-4 py-4">
              <div className="bg-slate-50 rounded-lg p-4 space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">Email</span>
                  <span className="font-medium">{selectedRequest.email}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Company</span>
                  <span className="font-medium">{selectedRequest.company_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Requested Role</span>
                  <span className="font-medium">{selectedRequest.requested_role}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Status</span>
                  <Badge className={statusBadgeConfig[selectedRequest.status].bg}>
                    {statusBadgeConfig[selectedRequest.status].label}
                  </Badge>
                </div>
                {selectedRequest.approval_date && (
                  <div className="flex justify-between">
                    <span className="text-slate-600">Approved</span>
                    <span className="text-xs">{new Date(selectedRequest.approval_date).toLocaleDateString()}</span>
                  </div>
                )}
              </div>

              {selectedRequest.status === "payment_complete" && !actionType && (
                <div className="flex gap-2 pt-4">
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => setActionType("reject")}
                    className="flex-1"
                  >
                    Reject
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => setActionType("approve")}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                  >
                    Approve
                  </Button>
                </div>
              )}

              {actionType === "approve" && (
                <div className="space-y-3 pt-2 border-t border-slate-200">
                  <div>
                    <label className="text-xs font-semibold text-slate-600">Approval Notes (optional)</label>
                    <Textarea
                      value={approvalNotes}
                      onChange={(e) => setApprovalNotes(e.target.value)}
                      placeholder="Add any notes..."
                      className="mt-1.5 text-sm h-20"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => setActionType(null)} className="flex-1">
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => approveMutation.mutate({ requestId: selectedRequest.id })}
                      disabled={approveMutation.isPending}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                    >
                      {approveMutation.isPending ? "Approving..." : "Confirm Approval"}
                    </Button>
                  </div>
                </div>
              )}

              {actionType === "reject" && (
                <div className="space-y-3 pt-2 border-t border-slate-200">
                  <div>
                    <label className="text-xs font-semibold text-slate-600">Rejection Reason *</label>
                    <Textarea
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      placeholder="Why are you rejecting this request?"
                      className="mt-1.5 text-sm h-20"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => setActionType(null)} className="flex-1">
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => rejectMutation.mutate({ requestId: selectedRequest.id })}
                      disabled={rejectMutation.isPending || !rejectionReason.trim()}
                      variant="destructive"
                      className="flex-1"
                    >
                      {rejectMutation.isPending ? "Rejecting..." : "Confirm Rejection"}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}