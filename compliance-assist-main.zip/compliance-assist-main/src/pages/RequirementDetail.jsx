import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import {
  ArrowLeft,
  Save,
  Trash2,
  Upload,
  AlertTriangle,
  Plus,
  Link2,
  BookOpen,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import StandardReferencePanel from "@/components/requirements/StandardReferencePanel";
import { toast } from "sonner";
import RiskAssessmentCard from "@/components/risk/RiskAssessmentCard";
import RiskAssessmentDialog from "@/components/risk/RiskAssessmentDialog";
import CommentSection from "@/components/collaboration/CommentSection";
import DocumentUploader from "@/components/documents/DocumentUploader";
import DocumentList from "@/components/documents/DocumentList";
import RiskMitigationSuggestions from "@/components/risk/RiskMitigationSuggestions";
import EvidenceFilesSection from "@/components/requirements/EvidenceFilesSection";
import RequirementAuditTrail from "@/components/requirements/RequirementAuditTrail";
import LinkedDocumentsSection from "@/components/documents/LinkedDocumentsSection";
import DocumentVersionHistory from "@/components/documents/DocumentVersionHistory";
import { useAuditLog } from "@/components/audit/useAuditLog";

const STATUS_CONFIG = {
  not_started: { label: "Not Started", className: "bg-slate-100 text-slate-600" },
  in_progress: { label: "In Progress", className: "bg-blue-50 text-blue-700" },
  partial: { label: "Partial", className: "bg-amber-50 text-amber-700" },
  compliant: { label: "Compliant", className: "bg-emerald-50 text-emerald-700" },
  non_compliant: { label: "Non-Compliant", className: "bg-rose-50 text-rose-700" },
};

const SECTIONS = [
  "4 - Context of the Organization",
  "5 - Leadership",
  "6 - Planning",
  "7 - Support",
  "8 - Operation",
  "9 - Performance Evaluation",
  "10 - Improvement",
  "TS 22002-4 - Establishment",
  "TS 22002-4 - Utilities",
  "TS 22002-4 - Equipment",
  "TS 22002-4 - Hygiene",
  "TS 22002-4 - Personnel",
  "TS 22002-4 - Transportation",
  "TS 22002-4 - Product Information",
  "TS 22002-4 - Other Requirements",
];

export default function RequirementDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");

  const queryClient = useQueryClient();
  const { logAction } = useAuditLog();

  const { data: requirement, isLoading } = useQuery({
    queryKey: ["requirement", id],
    queryFn: async () => {
      const all = await base44.entities.ComplianceRequirement.list("-created_date", 200);
      return all.find(r => r.id === id);
    },
    enabled: !!id,
  });

  const { data: riskAssessments = [] } = useQuery({
    queryKey: ["risk-assessments", id],
    queryFn: async () => {
      const all = await base44.entities.RiskAssessment.list("-created_date", 100);
      return all.filter(r => r.requirement_id === id);
    },
    enabled: !!id,
  });

  const { data: users = [] } = useQuery({
    queryKey: ["users"],
    queryFn: () => base44.entities.User.list("-created_date", 100),
  });

  // Fetch linked supplier gap records (same clause_number or linked_clause_number)
  const { data: linkedGaps = [] } = useQuery({
    queryKey: ["linked-gaps", requirement?.clause_number],
    queryFn: async () => {
      const all = await base44.entities.ComplianceRequirement.list("-created_date", 200);
      return all.filter(r =>
        r.id !== id &&
        r.linked_clause_number === requirement.clause_number &&
        (r.evidence_files?.length > 0)
      );
    },
    enabled: !!requirement?.clause_number,
  });

  const [form, setForm] = useState({});
  const [uploading, setUploading] = useState(false);
  const [showRiskDialog, setShowRiskDialog] = useState(false);
  const [editingRisk, setEditingRisk] = useState(null);
  const [showDocUpload, setShowDocUpload] = useState(false);

  useEffect(() => {
    if (requirement) {
      setForm({ ...requirement });
    }
  }, [requirement]);

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.ComplianceRequirement.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-requirements"] });
      queryClient.invalidateQueries({ queryKey: ["requirement", id] });
      toast.success("Requirement updated");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => base44.entities.ComplianceRequirement.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-requirements"] });
      window.location.href = createPageUrl("Requirements");
    },
  });

  const deleteRiskMutation = useMutation({
    mutationFn: (riskId) => base44.entities.RiskAssessment.delete(riskId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["risk-assessments", id] });
      toast.success("Risk assessment deleted");
    },
  });

  const handleUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setUploading(true);
    const uploaded = [];
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      uploaded.push(file_url);
    }
    const currentFiles = form.evidence_files || [];
    const updated = [...currentFiles, ...uploaded];
    setForm({ ...form, evidence_files: updated });
    // Auto-save evidence files immediately so they persist
    await base44.entities.ComplianceRequirement.update(id, { evidence_files: updated });
    queryClient.invalidateQueries({ queryKey: ["requirement", id] });
    setUploading(false);
    toast.success(`${uploaded.length} file(s) uploaded`);
  };

  const handleSave = () => {
    const { id: _, created_date, updated_date, created_by, ...data } = form;
    // Compute field changes for audit log
    const fieldChanges = [];
    const trackedFields = ["status", "priority", "findings", "corrective_actions", "responsible_person", "assigned_to", "due_date", "completion_percentage"];
    trackedFields.forEach((field) => {
      if (form[field] !== requirement[field]) {
        fieldChanges.push({ field, old_value: requirement[field], new_value: form[field] });
      }
    });
    updateMutation.mutate(data, {
      onSuccess: () => {
        if (fieldChanges.length > 0) {
          logAction("requirement_updated", `Updated requirement ${requirement.clause_number}: ${requirement.clause_title}`, {
            entity_type: "ComplianceRequirement",
            entity_id: id,
            entity_label: `${requirement.clause_number} ${requirement.clause_title}`,
            field_changes: fieldChanges,
          });
        }
      },
    });
  };

  if (isLoading || !requirement) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const statusConfig = STATUS_CONFIG[form.status] || STATUS_CONFIG.not_started;

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        {/* Back */}
        <Link
          to={createPageUrl("Requirements")}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-sm text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg mb-6 transition-colors min-h-[44px]"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Requirements
        </Link>

        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-sm font-mono font-bold text-slate-400">{form.clause_number}</span>
              <Badge className={`${statusConfig.className} text-xs`}>{statusConfig.label}</Badge>
            </div>
            <h1 className="text-xl font-bold text-slate-900">{form.clause_title}</h1>
            <p className="text-sm text-slate-500 mt-1">{form.section}</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="text-rose-500 hover:text-rose-600 hover:bg-rose-50"
              onClick={() => {
                if (confirm("Delete this requirement?")) deleteMutation.mutate();
              }}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              className="bg-emerald-600 hover:bg-emerald-700"
              onClick={handleSave}
              disabled={updateMutation.isPending}
            >
              <Save className="w-4 h-4 mr-1.5" />
              {updateMutation.isPending ? "Saving..." : "Save"}
            </Button>
          </div>
        </div>

        <Tabs defaultValue="details" className="mb-6">
          <TabsList className="mb-6">
            <TabsTrigger value="details">Requirement Details</TabsTrigger>
            <TabsTrigger value="standard" className="flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5" />
              Standard Reference
            </TabsTrigger>
          </TabsList>

          <TabsContent value="standard">
            <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
              <StandardReferencePanel highlightClause={requirement?.clause_number} />
            </div>
          </TabsContent>

          <TabsContent value="details">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold">Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-slate-500">Clause Number</Label>
                    <Input
                      value={form.clause_number || ""}
                      onChange={(e) => setForm({ ...form, clause_number: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Section</Label>
                    <Select value={form.section || ""} onValueChange={(v) => setForm({ ...form, section: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {SECTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Title</Label>
                  <Input
                    value={form.clause_title || ""}
                    onChange={(e) => setForm({ ...form, clause_title: e.target.value })}
                  />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Description / Requirement Summary</Label>
                  <Textarea
                    value={form.description || ""}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold">Findings & Corrective Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-xs text-slate-500">Audit Findings / Gaps Identified</Label>
                  <Textarea
                    value={form.findings || ""}
                    onChange={(e) => setForm({ ...form, findings: e.target.value })}
                    rows={3}
                    placeholder="Describe any gaps or findings..."
                  />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Corrective Actions Required</Label>
                  <Textarea
                    value={form.corrective_actions || ""}
                    onChange={(e) => setForm({ ...form, corrective_actions: e.target.value })}
                    rows={3}
                    placeholder="Actions to achieve compliance..."
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold">Evidence & Documentation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-xs text-slate-500">Evidence Notes</Label>
                  <Textarea
                    value={form.evidence_notes || ""}
                    onChange={(e) => setForm({ ...form, evidence_notes: e.target.value })}
                    rows={2}
                    placeholder="Notes on supporting documentation..."
                  />
                </div>
              </CardContent>
            </Card>

            {/* Linked Supplier Gap Evidence */}
            {linkedGaps.length > 0 && (
              <Card className="border-0 shadow-sm border-l-4 border-l-amber-400">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-amber-500" />
                    Linked Supplier Gap Evidence
                    <span className="text-xs font-normal text-slate-400">({linkedGaps.length} linked record{linkedGaps.length > 1 ? "s" : ""})</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {linkedGaps.map(gap => (
                    <div key={gap.id} className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-semibold text-amber-700 bg-amber-50 border border-amber-100 px-2 py-0.5 rounded">{gap.clause_number}</span>
                        <span className="text-xs font-medium text-slate-700">{gap.clause_title}</span>
                      </div>
                      <EvidenceFilesSection
                        files={gap.evidence_files || []}
                        readOnly
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-500" />
                    Risk Assessments
                  </CardTitle>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingRisk(null);
                      setShowRiskDialog(true);
                    }}
                    className="h-7 text-xs"
                  >
                    <Plus className="w-3 h-3 mr-1" />
                    Add
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                {riskAssessments.length === 0 ? (
                  <p className="text-xs text-slate-400 py-4 text-center">No risk assessments yet</p>
                ) : (
                  <div className="space-y-3">
                    {riskAssessments.map(assessment => (
                      <div key={assessment.id} className="space-y-3">
                        <RiskAssessmentCard
                          assessment={assessment}
                          onEdit={() => {
                            setEditingRisk(assessment);
                            setShowRiskDialog(true);
                          }}
                          onDelete={() => {
                            if (confirm("Delete this risk assessment?")) {
                              deleteRiskMutation.mutate(assessment.id);
                            }
                          }}
                        />
                        {(assessment.risk_level === 'critical' || assessment.risk_level === 'high') && (
                          <RiskMitigationSuggestions
                            riskId={assessment.id}
                            onApplied={() => {
                              queryClient.invalidateQueries({ queryKey: ["risk-assessments", id] });
                            }}
                          />
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold">Linked Documents</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <LinkedDocumentsSection requirementId={id} />
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold">Legacy Evidence Files</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-xs text-slate-500 mb-2 block">Attached Evidence Files</Label>
                  <EvidenceFilesSection
                    files={form.evidence_files || []}
                    onFilesChange={(updated) => setForm({ ...form, evidence_files: updated })}
                    uploading={uploading}
                    onUpload={handleUpload}
                  />
                </div>
              </CardContent>
            </Card>

            <CommentSection entityType="ComplianceRequirement" entityId={id} />

            <RequirementAuditTrail requirementId={id} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-5 space-y-5">
                <div>
                  <Label className="text-xs text-slate-500">Status</Label>
                  <Select value={form.status || "not_started"} onValueChange={(v) => setForm({ ...form, status: v })}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="not_started">Not Started</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="partial">Partial</SelectItem>
                      <SelectItem value="compliant">Compliant</SelectItem>
                      <SelectItem value="non_compliant">Non-Compliant</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs text-slate-500">Priority</Label>
                  <Select value={form.priority || "medium"} onValueChange={(v) => setForm({ ...form, priority: v })}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs text-slate-500">Responsible Person</Label>
                  <Input
                    className="mt-1"
                    value={form.responsible_person || ""}
                    onChange={(e) => setForm({ ...form, responsible_person: e.target.value })}
                    placeholder="Assign someone..."
                  />
                </div>

                <div>
                  <Label className="text-xs text-slate-500">Assigned To</Label>
                  <Select value={form.assigned_to || ""} onValueChange={(v) => setForm({ ...form, assigned_to: v })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select user..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Unassigned</SelectItem>
                      {users.map(user => (
                        <SelectItem key={user.id} value={user.email}>
                          {user.full_name} ({user.email})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs text-slate-500">Due Date</Label>
                  <Input
                    type="date"
                    className="mt-1"
                    value={form.due_date || ""}
                    onChange={(e) => setForm({ ...form, due_date: e.target.value })}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-xs text-slate-500">Completion</Label>
                    <span className="text-xs font-semibold text-slate-600">{form.completion_percentage || 0}%</span>
                  </div>
                  <Slider
                    value={[form.completion_percentage || 0]}
                    onValueChange={(v) => setForm({ ...form, completion_percentage: v[0] })}
                    max={100}
                    step={5}
                    className="mt-1"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
          </TabsContent>
        </Tabs>

        <RiskAssessmentDialog
          open={showRiskDialog}
          onClose={() => {
            setShowRiskDialog(false);
            setEditingRisk(null);
          }}
          requirementId={id}
          assessment={editingRisk}
          requirement={requirement}
        />
        <DocumentUploader
          entityType="ComplianceRequirement"
          entityId={id}
          open={showDocUpload}
          onClose={() => setShowDocUpload(false)}
          clauseNumber={requirement?.clause_number}
        />
      </div>
    </div>
  );
}