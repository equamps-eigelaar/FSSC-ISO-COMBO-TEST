import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Mail, MapPin, Phone } from "lucide-react";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <Shield className="w-8 h-8 text-emerald-600" />
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Privacy Policy</h1>
          </div>
          <p className="text-sm text-slate-500">Last updated: 26 February 2026</p>
        </div>

        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-6">
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              This Privacy Policy applies to the <strong>Package Manufacturing Compliance Tracker</strong> ("the App"), 
              operated by the responsible party ("we", "us", "our"), registered in South Africa. 
              We are committed to protecting your personal information in accordance with the 
              <strong> Protection of Personal Information Act, 4 of 2013 ("POPIA")</strong>.
            </p>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
              The App is a web-based compliance management platform used by food and packaging manufacturing organisations to manage 
              ISO 22000 / FSSC 22000 compliance requirements, food safety documentation, risk assessments, audit records, 
              supplier self-assessments, monitoring logs, and training records. By using the App, you agree to the 
              practices described in this policy.
            </p>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <PolicySection
            number="1"
            title="Information We Collect"
            content={
              <>
                <p className="mb-4">We collect only the information necessary to operate the App and support food and packaging manufacturing organisations' compliance obligations. This includes:</p>

                <h4 className="font-semibold text-slate-900 dark:text-white mb-2">1.1 User Account Information</h4>
                <ul className="list-disc pl-6 mb-4 space-y-1">
                  <li>Full name and email address (used for login, assignment of tasks, and notifications)</li>
                  <li>User role (Admin, User, Viewer) — used to control access permissions</li>
                </ul>

                <h4 className="font-semibold text-slate-900 dark:text-white mb-2">1.2 Compliance & Operational Data (Entered by Users)</h4>
                <ul className="list-disc pl-6 mb-4 space-y-1">
                  <li>ISO 22000 / FSSC 22000 compliance requirement records, findings, and corrective actions</li>
                  <li>Risk assessment data including hazard descriptions, likelihood, severity, and mitigation strategies</li>
                  <li>Uploaded documents (certificates, safety data sheets, inspection reports, procedures, PRPs, policies)</li>
                  <li>Supplier self-assessment questionnaires and responses</li>

                  <li>Monitoring logs (temperature, CCP, OPRP, allergen, cleaning, calibration records)</li>
                  <li>Food batch and raw material traceability records</li>
                  <li>Audit plans, findings, and corrective action items</li>
                  <li>Training module completions and quiz results</li>
                  <li>Comments, notes, and evidence attached to records</li>
                </ul>

                <h4 className="font-semibold text-slate-900 dark:text-white mb-2">1.3 Activity & Audit Trail Data</h4>
                <ul className="list-disc pl-6 mb-4 space-y-1">
                  <li>Timestamped activity logs of all create, update, and delete actions performed in the App</li>
                  <li>User email associated with each action (for accountability and traceability)</li>
                </ul>

                <h4 className="font-semibold text-slate-900 dark:text-white mb-2">1.4 Automatically Collected Technical Data</h4>
                <ul className="list-disc pl-6 mb-4 space-y-1">
                  <li>Browser type, device type, and operating system version</li>
                  <li>IP address and session information</li>
                  <li>Error logs and performance data</li>
                </ul>

                <p className="text-sm italic">We do not collect biometric data, payment or financial information, or any data unrelated to the App's compliance management purpose.</p>
              </>
            }
          />

          <PolicySection
            number="2"
            title="How We Use Your Information"
            content={
              <>
                <p className="mb-2">We use the collected information solely to:</p>
                <ul className="list-disc pl-6 space-y-1 mb-4">
                  <li>Operate and deliver the App's compliance tracking and documentation features</li>
                  <li>Assign requirements, action items, and risk assessments to responsible personnel</li>
                  <li>Send in-app and email notifications related to due dates, overdue actions, and compliance alerts</li>
                  <li>Generate compliance reports, audit summaries, and AI-assisted analysis</li>
                  <li>Support AI-powered features including document analysis, risk prediction, and supplier questionnaire evaluation</li>
                  <li>Maintain an auditable activity trail for internal governance and certification purposes</li>
                  <li>Monitor and improve App performance and stability</li>
                  <li>Comply with applicable South African laws and food safety regulatory requirements</li>
                </ul>
                <p className="text-sm italic">We do not use your data for marketing, advertising, or sale to third parties. We do not use it for automated decision-making that affects legal rights.</p>
              </>
            }
          />

          <PolicySection
            number="3"
            title="AI-Powered Features & Data Processing"
            content={
              <>
                <p className="mb-4">
                  The App uses AI-assisted features including document compliance evaluation, supplier questionnaire analysis, 
                  risk prediction, and report generation. When you use these features:
                </p>
                <ul className="list-disc pl-6 space-y-1 mb-4">
                  <li>Uploaded documents and entered compliance data may be processed by an AI model to generate analysis, summaries, and recommendations</li>
                  <li>AI-generated outputs are advisory only and require human review before acting on them</li>
                  <li>No personal information is used to train external AI models</li>
                  <li>AI processing is performed via secure API calls with confidentiality obligations in place</li>
                </ul>
                <p className="text-sm italic">You retain full control over whether to accept, modify, or discard AI-generated suggestions.</p>
              </>
            }
          />

          <PolicySection
            number="4"
            title="Legal Basis for Processing (POPIA Compliance)"
            content={
              <>
                <p className="mb-2">We process personal information on the following grounds:</p>
                <ul className="list-disc pl-6 space-y-1 mb-4">
                  <li><strong>Consent</strong> — you voluntarily provide information when using the App</li>
                  <li><strong>Contractual necessity</strong> — to provide the App's services to authorised personnel within food and packaging manufacturing organisations</li>
                  <li><strong>Legitimate interests</strong> — improving functionality, maintaining security, and supporting FSSC 22000 certification compliance</li>
                  <li><strong>Legal obligation</strong> — where required by South African law or food safety regulations</li>
                </ul>
                <p className="text-sm">You may withdraw consent at any time by contacting your system administrator or using the contact details below.</p>
              </>
            }
          />

          <PolicySection
            number="5"
            title="How We Share Your Information"
            content={
              <>
                <p className="mb-4 font-semibold">We do not sell, rent, or trade your personal information.</p>
                <p className="mb-2">Data may be shared only with:</p>
                <ul className="list-disc pl-6 space-y-1 mb-4">
                  <li><strong>Cloud infrastructure providers</strong> — for secure storage and hosting of App data</li>
                  <li><strong>AI service providers</strong> — for processing document and compliance analysis requests (under confidentiality obligations)</li>
                  <li><strong>Email delivery services</strong> — to send system notifications and compliance alerts</li>
                  <li><strong>Internal authorised personnel</strong> — with role-based access appropriate to their responsibilities</li>
                  <li><strong>Regulators or certification bodies</strong> — only when legally required or as part of a formal audit</li>
                </ul>
                <p className="text-sm">All third-party processors are bound by data-protection obligations consistent with POPIA.</p>
              </>
            }
          />

          <PolicySection
            number="6"
            title="Data Storage, Retention & Security"
            content={
              <>
                <p className="mb-2">We implement appropriate technical and organisational measures to protect your information, including:</p>
                <ul className="list-disc pl-6 space-y-1 mb-4">
                  <li>Encrypted data transmission (HTTPS/TLS)</li>
                  <li>Role-based access controls limiting data visibility to authorised users</li>
                  <li>Secure cloud storage with access logging</li>
                  <li>Regular security assessments</li>
                </ul>
                <p className="mb-2 text-sm">
                  <strong>Retention:</strong> Compliance records, audit trails, and uploaded documents are retained for the duration 
                  required by FSSC 22000 certification obligations and applicable South African food safety regulations (typically 
                  a minimum of 3–5 years). User account data is retained while the account is active and deleted upon request.
                </p>
                <p className="text-sm italic">No security system is impenetrable. In the event of a data breach, we will notify affected parties and the Information Regulator as required by POPIA.</p>
              </>
            }
          />

          <PolicySection
            number="7"
            title="Your Rights Under POPIA"
            content={
              <>
                <p className="mb-2">As a data subject under POPIA, you have the right to:</p>
                <ul className="list-disc pl-6 space-y-1 mb-4">
                  <li>Be informed about the processing of your personal information</li>
                  <li>Access your personal information held by us</li>
                  <li>Request correction of inaccurate or incomplete data</li>
                  <li>Request deletion of your personal information (subject to legal retention requirements)</li>
                  <li>Object to the processing of your personal information</li>
                  <li>Lodge a complaint with the <strong>Information Regulator of South Africa</strong> at <a href="https://www.justice.gov.za/inforeg/" className="text-emerald-600 underline" target="_blank" rel="noopener noreferrer">www.justice.gov.za/inforeg</a></li>
                </ul>
                <p className="text-sm">To exercise any of these rights, contact us using the details in Section 11.</p>
              </>
            }
          />

          <PolicySection
            number="8"
            title="Cookies & Local Storage"
            content={
              <p>
                The App may use browser local storage and session cookies to maintain your login session and 
                user preferences (such as theme settings). These are not used for advertising or tracking. 
                You can clear browser storage at any time through your browser settings, though this will 
                log you out of the App.
              </p>
            }
          />

          <PolicySection
            number="9"
            title="International Data Transfers"
            content={
              <p>
                Some App services (including cloud hosting and AI processing) may involve data being processed 
                outside South Africa. Where this occurs, we ensure the receiving party provides adequate 
                data-protection safeguards consistent with POPIA, either through contractual protections or 
                by operating in jurisdictions with equivalent data protection laws.
              </p>
            }
          />

          <PolicySection
            number="10"
            title="Children's Privacy"
            content={
              <p>
                The App is intended solely for use by authorised company personnel. 
                It is not directed at children under 18. We do not knowingly collect personal information 
                from minors. If you become aware that a minor has accessed the App, please notify us immediately.
              </p>
            }
          />

          <PolicySection
            number="11"
            title="Changes to This Privacy Policy"
            content={
              <p>
                We may update this Privacy Policy periodically to reflect changes in the App's features, 
                legal requirements, or our data practices. Material changes will be communicated to users 
                via in-app notification and by updating the "Last updated" date above. Continued use of 
                the App following notification of changes constitutes acceptance of the updated policy.
              </p>
            }
          />

          <PolicySection
            number="12"
            title="Contact & Information Officer"
            content={
              <>
                <p className="mb-4">
                  For any questions, requests, or concerns regarding this Privacy Policy or the processing 
                  of your personal information, contact the Information Officer via your system administrator.
                </p>
                <div className="space-y-3 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-slate-500 shrink-0" />
                    <span className="text-sm text-slate-700 dark:text-slate-300">South Africa</span>
                  </div>
                </div>
                <p className="text-xs text-slate-400 mt-3">
                  You also have the right to lodge a complaint with the Information Regulator of South Africa: 
                  <a href="mailto:inforeg@justice.gov.za" className="text-emerald-600 ml-1">inforeg@justice.gov.za</a>
                </p>
              </>
            }
          />
        </div>
      </div>
    </div>
  );
}

function PolicySection({ number, title, content }) {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold text-slate-900 dark:text-white">
          {number}. {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
        {content}
      </CardContent>
    </Card>
  );
}