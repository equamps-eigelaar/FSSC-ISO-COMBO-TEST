import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import {
  Calendar as CalendarIcon, ChevronLeft, ChevronRight,
  Clock, AlertTriangle, CheckCircle2, Circle, Search, X
} from "lucide-react";
import SwipeableActionItem from "@/components/mobile/SwipeableActionItem";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, isToday, isPast, addMonths, subMonths, parseISO, startOfWeek, endOfWeek } from "date-fns";

const PRIORITY_CONFIG = {
  critical: { label: "Critical", className: "bg-rose-100 text-rose-700 border-rose-200" },
  high:     { label: "High",     className: "bg-orange-100 text-orange-700 border-orange-200" },
  medium:   { label: "Medium",   className: "bg-slate-100 text-slate-600 border-slate-200" },
  low:      { label: "Low",      className: "bg-slate-50 text-slate-400 border-slate-200" },
};

const STATUS_CONFIG = {
  pending:     { label: "Pending",     className: "bg-slate-100 text-slate-600",   icon: Circle },
  in_progress: { label: "In Progress", className: "bg-blue-100 text-blue-700",     icon: Clock },
  completed:   { label: "Completed",   className: "bg-emerald-100 text-emerald-700", icon: CheckCircle2 },
  blocked:     { label: "Blocked",     className: "bg-rose-100 text-rose-700",     icon: AlertTriangle },
};

const DOT_COLORS = {
  critical: "bg-rose-500",
  high:     "bg-orange-400",
  medium:   "bg-blue-400",
  low:      "bg-slate-300",
};

export default function ActionItems() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [search, setSearch] = useState("");
  const queryClient = useQueryClient();

  const { data: actions = [], isLoading } = useQuery({
    queryKey: ["action-items"],
    queryFn: () => base44.entities.ActionItem.list("-created_date", 200),
  });

  const { data: requirements = [] } = useQuery({
    queryKey: ["compliance-requirements-actions"],
    queryFn: () => base44.entities.ComplianceRequirement.list("clause_number", 200),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ActionItem.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["action-items"] }),
  });

  // Combine action items + overdue requirements into calendar items
  const allCalendarItems = useMemo(() => {
    const items = actions.map(a => ({
      id: a.id,
      type: "action",
      title: a.title,
      due_date: a.due_date,
      priority: a.priority,
      status: a.status,
      raw: a,
    }));

    const overdue = requirements
      .filter(r => r.due_date && r.status !== "compliant")
      .map(r => ({
        id: `req-${r.id}`,
        type: "requirement",
        title: `${r.clause_number} ${r.clause_title}`,
        due_date: r.due_date,
        priority: r.priority,
        status: r.status,
        raw: r,
      }));

    return [...items, ...overdue];
  }, [actions, requirements]);

  // Build a map: dateStr -> items
  const dateMap = useMemo(() => {
    const map = {};
    allCalendarItems.forEach(item => {
      if (!item.due_date) return;
      const key = item.due_date.split("T")[0];
      if (!map[key]) map[key] = [];
      map[key].push(item);
    });
    return map;
  }, [allCalendarItems]);

  // Calendar grid days
  const calendarDays = useMemo(() => {
    const start = startOfWeek(startOfMonth(currentMonth), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(currentMonth), { weekStartsOn: 1 });
    return eachDayOfInterval({ start, end });
  }, [currentMonth]);

  // Filtered list
  const filteredItems = useMemo(() => {
    return allCalendarItems.filter(item => {
      if (selectedDate) {
        const key = item.due_date?.split("T")[0];
        if (key !== format(selectedDate, "yyyy-MM-dd")) return false;
      }
      if (statusFilter !== "all" && item.status !== statusFilter) return false;
      if (priorityFilter !== "all" && item.priority !== priorityFilter) return false;
      if (search && !item.title.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [allCalendarItems, selectedDate, statusFilter, priorityFilter, search]);

  const overdueCount = allCalendarItems.filter(i => i.due_date && isPast(parseISO(i.due_date)) && i.status !== "completed" && i.status !== "compliant").length;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Action Items</h1>
            <p className="text-sm text-slate-500 mt-0.5">
              {allCalendarItems.length} items · {overdueCount > 0 && <span className="text-rose-600 font-medium">{overdueCount} overdue</span>}
            </p>
          </div>
        </div>

        {/* Overdue Banner */}
        {overdueCount > 0 && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-rose-50 border border-rose-100">
            <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
            <span className="text-sm text-rose-700 font-medium">{overdueCount} items are overdue</span>
            <button
              className="ml-auto text-xs text-rose-500 underline"
              onClick={() => { setStatusFilter("all"); setPriorityFilter("all"); setSelectedDate(null); setSearch("overdue"); }}
            >
              View overdue
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Calendar */}
          <div className="xl:col-span-1">
            <Card className="border-0 shadow-sm min-w-[300px]">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4 text-emerald-600" />
                    {format(currentMonth, "MMMM yyyy")}
                  </CardTitle>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} className="p-1.5 rounded hover:bg-slate-100 text-slate-500">
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} className="p-1.5 rounded hover:bg-slate-100 text-slate-500">
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-3">
                {/* Day headers */}
                <div className="grid grid-cols-7 mb-1">
                  {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map(d => (
                    <div key={d} className="text-center text-[11px] font-semibold text-slate-400 py-1 w-full">{d}</div>
                  ))}
                </div>
                {/* Days grid */}
                <div className="grid grid-cols-7 gap-y-0.5">
                  {calendarDays.map(day => {
                    const key = format(day, "yyyy-MM-dd");
                    const items = dateMap[key] || [];
                    const isSelected = selectedDate && isSameDay(day, selectedDate);
                    const isCurrentMonth = isSameMonth(day, currentMonth);
                    const hasOverdue = items.some(i => isPast(day) && i.status !== "completed" && i.status !== "compliant");

                    return (
                      <button
                        key={key}
                        onClick={() => setSelectedDate(isSelected ? null : day)}
                        className={`relative flex flex-col items-center py-1.5 rounded-md text-[11px] font-medium transition-all w-full
                          ${isSelected ? "bg-emerald-600 text-white" : isToday(day) ? "bg-emerald-50 text-emerald-700 font-bold" : isCurrentMonth ? "text-slate-700 hover:bg-slate-100" : "text-slate-300"}
                          ${hasOverdue && !isSelected ? "ring-1 ring-rose-300" : ""}
                        `}
                      >
                        {format(day, "d")}
                        {items.length > 0 && (
                          <div className="flex gap-0.5 mt-0.5 flex-wrap justify-center">
                            {items.slice(0, 3).map((item, i) => (
                              <span key={i} className={`w-1 h-1 rounded-full ${isSelected ? "bg-white" : DOT_COLORS[item.priority] || "bg-slate-300"}`} />
                            ))}
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>

                {selectedDate && (
                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500">{format(selectedDate, "dd MMM yyyy")} · {filteredItems.length} items</span>
                    <button onClick={() => setSelectedDate(null)} className="text-xs text-slate-400 hover:text-slate-600">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* Legend */}
                <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap gap-x-3 gap-y-1">
                  {Object.entries(DOT_COLORS).map(([p, c]) => (
                    <div key={p} className="flex items-center gap-1 text-[10px] text-slate-500">
                      <span className={`w-2 h-2 rounded-full ${c}`} />
                      {p.charAt(0).toUpperCase() + p.slice(1)}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* List */}
          <div className="xl:col-span-2 space-y-4">
            {/* Filters */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-3">
                <div className="flex gap-2 flex-wrap items-center">
                  <div className="relative flex-1 min-w-[180px]">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      placeholder="Search items..."
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      className="pl-9 border-slate-200 h-9 text-sm"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-36 h-9 border-slate-200 text-sm">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="blocked">Blocked</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                    <SelectTrigger className="w-36 h-9 border-slate-200 text-sm">
                      <SelectValue placeholder="Priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priorities</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                  {(statusFilter !== "all" || priorityFilter !== "all" || search || selectedDate) && (
                    <Button variant="ghost" size="sm" className="h-9 text-slate-500" onClick={() => { setStatusFilter("all"); setPriorityFilter("all"); setSearch(""); setSelectedDate(null); }}>
                      <X className="w-3.5 h-3.5 mr-1" /> Clear
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {filteredItems.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="py-14 text-center">
                  <CalendarIcon className="w-10 h-10 text-slate-200 mx-auto mb-3" />
                  <p className="text-slate-500 text-sm">
                    {selectedDate ? `No items due on ${format(selectedDate, "MMM d")}` : "No items match your filters"}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-2">
                {filteredItems.map(item => {
                  const isOverdue = item.due_date && isPast(parseISO(item.due_date)) && item.status !== "completed" && item.status !== "compliant";
                  const statusCfg = STATUS_CONFIG[item.status] || STATUS_CONFIG.pending;
                  const StatusIcon = statusCfg.icon;
                  const priorityCfg = PRIORITY_CONFIG[item.priority] || PRIORITY_CONFIG.medium;

                  // Use swipeable card for action-type items
                  if (item.type === "action") {
                    return (
                      <SwipeableActionItem
                        key={item.id}
                        action={item.raw}
                        onComplete={(id) => updateMutation.mutate({ id, data: { status: "completed" } })}
                        onDelete={(id) => updateMutation.mutate({ id, data: { status: "blocked" } })}
                        onClick={() => updateMutation.mutate({ id: item.id, data: { status: item.status === "pending" ? "in_progress" : item.status === "in_progress" ? "completed" : item.status } })}
                      />
                    );
                  }

                  // Requirement items use static card
                  return (
                    <Card key={item.id} className={`border-0 shadow-sm ${isOverdue ? "border-l-2 border-l-rose-400" : ""}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-2.5 flex-1 min-w-0">
                          <StatusIcon className={`w-4 h-4 mt-0.5 shrink-0 ${item.status === "completed" ? "text-emerald-500" : item.status === "blocked" ? "text-rose-500" : item.status === "in_progress" ? "text-blue-500" : "text-slate-400"}`} />
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm font-medium leading-snug ${item.status === "completed" ? "line-through text-slate-400" : "text-slate-800"}`}>
                              {item.title}
                            </p>
                            <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                              <Badge variant="outline" className={`text-[10px] px-1.5 py-0 h-4 ${priorityCfg.className}`}>
                                {priorityCfg.label}
                              </Badge>
                              <Badge className={`text-[10px] px-1.5 py-0 h-4 ${statusCfg.className}`}>
                                {statusCfg.label}
                              </Badge>
                              <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 bg-purple-50 text-purple-600 border-purple-200">
                                Requirement
                              </Badge>
                              {item.due_date && (
                                <span className={`text-[10px] flex items-center gap-0.5 ${isOverdue ? "text-rose-600 font-medium" : "text-slate-400"}`}>
                                  <Clock className="w-2.5 h-2.5" />
                                  {isOverdue ? "Overdue · " : ""}{format(parseISO(item.due_date), "dd MMM yyyy")}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}