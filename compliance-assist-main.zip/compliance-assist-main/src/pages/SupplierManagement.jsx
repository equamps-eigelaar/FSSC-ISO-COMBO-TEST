import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Users, Plus, MessageSquare, FileText, CheckCircle2, AlertTriangle,
  Loader2, Mail, Search, Trash2, Eye, BarChart2
} from "lucide-react";
import SupplierPerformanceKPIs from "@/components/supplier/SupplierPerformanceKPIs";
import SupplierAlertSystem from "@/components/supplier/SupplierAlertSystem";
import { toast } from "sonner";
import SupplierMessageThread from "@/components/supplier/SupplierMessageThread";

const STATUS_COLORS = {
  pending:   "bg-amber-100 text-amber-800",
  active:    "bg-emerald-100 text-emerald-800",
  suspended: "bg-red-100 text-red-800",
  inactive:  "bg-slate-100 text-slate-600",
};
const RISK_COLORS = {
  low: "text-emerald-700", medium: "text-amber-700", high: "text-orange-700", critical: "text-red-700"
};

export default function SupplierManagement() {
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [showMessages, setShowMessages] = useState(false);
  const [showPerformance, setShowPerformance] = useState(false);
  const [internalUser, setInternalUser] = useState(null);
  const queryClient = useQueryClient();

  React.useEffect(() => {
    base44.auth.me().then(setInternalUser).catch(() => {});
  }, []);

  const { data: suppliers = [], isLoading } = useQuery({
    queryKey: ["supplier-profiles"],
    queryFn: () => base44.entities.SupplierProfile.list("-created_date", 200),
  });

  const { data: messages = [] } = useQuery({
    queryKey: ["all-supplier-messages"],
    queryFn: () => base44.entities.SupplierMessage.list("-created_date", 500),
  });

  const { data: assessments = [] } = useQuery({
    queryKey: ["all-supplier-assessments"],
    queryFn: () => base44.entities.SupplierSelfAssessment.list("-created_date", 500),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SupplierProfile.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["supplier-profiles"] }); toast.success("Supplier removed"); }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SupplierProfile.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["supplier-profiles"] }); toast.success("Updated"); }
  });

  const filtered = suppliers.filter(s =>
    search === "" ||
    s.company_name?.toLowerCase().includes(search.toLowerCase()) ||
    s.email?.toLowerCase().includes(search.toLowerCase())
  );

  const unreadBySupplier = {};
  messages.forEach(m => {
    if (m.direction === "supplier_to_internal" && !m.is_read) {
      unreadBySupplier[m.supplier_email] = (unreadBySupplier[m.supplier_email] || 0) + 1;
    }
  });

  const handleOpenPerformance = (supplier) => {
    setSelectedSupplier(supplier);
    setShowPerformance(true);
  };

  const handleOpenMessages = (supplier) => {
    setSelectedSupplier(supplier);
    setShowMessages(true);
    // Mark as read
    messages.filter(m => m.supplier_email === supplier.email && !m.is_read && m.direction === "supplier_to_internal")
      .forEach(m => base44.entities.SupplierMessage.update(m.id, { is_read: true }));
  };

  const supplierMessages = selectedSupplier
    ? messages.filter(m => m.supplier_email === selectedSupplier.email)
    : [];

  const supplierAssessments = selectedSupplier
    ? assessments.filter(a => a.assigned_to === selectedSupplier.email)
    : [];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
          <div className="min-w-0">
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Supplier Management</h1>
            <p className="text-sm text-slate-500 mt-1">Manage external supplier portal access and communications</p>
          </div>
          <Button onClick={() => setShowAdd(true)} className="bg-emerald-600 hover:bg-emerald-700 gap-2 shrink-0 self-start sm:self-auto">
            <Plus className="w-4 h-4" /> Add Supplier
          </Button>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <StatCard label="Total Suppliers" value={suppliers.length} color="blue" />
          <StatCard label="Active" value={suppliers.filter(s => s.status === "active").length} color="emerald" />
          <StatCard label="Pending" value={suppliers.filter(s => s.status === "pending").length} color="amber" />
          <StatCard label="Unread Messages" value={Object.values(unreadBySupplier).reduce((a, b) => a + b, 0)} color="red" />
        </div>

        {/* Alerts Section */}
        <div className="mb-6">
          <SupplierAlertSystem
            suppliers={suppliers}
            assessments={assessments}
            messages={messages}
          />
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Search suppliers…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>

        {/* Supplier list */}
        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
        ) : filtered.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-12 text-center">
              <Users className="w-12 h-12 text-slate-200 mx-auto mb-4" />
              <p className="text-slate-500">No suppliers yet. Add your first supplier to get started.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {filtered.map(supplier => {
              const unread = unreadBySupplier[supplier.email] || 0;
              const supplierAss = assessments.filter(a => a.assigned_to === supplier.email);
              return (
                <Card key={supplier.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                      <span className="text-emerald-700 font-semibold text-sm">
                        {supplier.company_name?.[0]?.toUpperCase() || "S"}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="font-medium text-slate-900 text-sm">{supplier.company_name}</p>
                        <Badge className={`text-xs ${STATUS_COLORS[supplier.status] || STATUS_COLORS.pending}`}>
                          {supplier.status}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-500">{supplier.email} · {supplier.category?.replace(/_/g, ' ')}</p>
                      <div className="flex items-center gap-3 mt-1 text-xs text-slate-400">
                        <span>{supplierAss.length} assessment{supplierAss.length !== 1 ? 's' : ''}</span>
                        {supplier.compliance_score != null && (
                          <span className={`font-semibold ${RISK_COLORS[supplier.compliance_rating] || ""}`}>
                            {supplier.compliance_score}% compliant
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Select value={supplier.status} onValueChange={v => updateMutation.mutate({ id: supplier.id, data: { status: v } })}>
                        <SelectTrigger className="h-8 text-xs w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="suspended">Suspended</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button size="sm" variant="outline" className="h-8 gap-1.5" onClick={() => handleOpenPerformance(supplier)}>
                        <BarChart2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline text-xs">KPIs</span>
                      </Button>
                      <Button size="sm" variant="outline" className="relative h-8" onClick={() => handleOpenMessages(supplier)}>
                        <MessageSquare className="w-3.5 h-3.5" />
                        {unread > 0 && (
                          <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 text-white text-[9px] rounded-full flex items-center justify-center">
                            {unread}
                          </span>
                        )}
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8 text-slate-400 hover:text-red-500"
                        onClick={() => deleteMutation.mutate(supplier.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Supplier Dialog */}
      {showAdd && <AddSupplierDialog onClose={() => setShowAdd(false)} onCreated={() => { queryClient.invalidateQueries({ queryKey: ["supplier-profiles"] }); setShowAdd(false); }} />}

      {/* Performance Dialog */}
      {showPerformance && selectedSupplier && (
        <Dialog open={showPerformance} onOpenChange={setShowPerformance}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-emerald-600" />
                Performance — {selectedSupplier.company_name}
              </DialogTitle>
            </DialogHeader>
            <SupplierPerformanceKPIs
              assessments={assessments.filter(a => a.assigned_to === selectedSupplier.email)}
              messages={messages.filter(m => m.supplier_email === selectedSupplier.email)}
              documents={[]}
              profile={selectedSupplier}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Message Dialog */}
      {showMessages && selectedSupplier && (
        <Dialog open={showMessages} onOpenChange={setShowMessages}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Messages — {selectedSupplier.company_name}</DialogTitle>
            </DialogHeader>
            <SupplierMessageThread
              user={internalUser}
              supplierEmail={selectedSupplier.email}
              messages={supplierMessages}
              isInternal
              onSent={() => { queryClient.invalidateQueries({ queryKey: ["all-supplier-messages"] }); }}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

function StatCard({ label, value, color }) {
  const colors = { blue: "text-blue-600", emerald: "text-emerald-600", amber: "text-amber-600", red: "text-red-600" };
  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4 text-center">
        <div className={`text-2xl font-bold ${colors[color]}`}>{value}</div>
        <div className="text-xs text-slate-500 mt-1">{label}</div>
      </CardContent>
    </Card>
  );
}

function AddSupplierDialog({ onClose, onCreated }) {
  const [form, setForm] = useState({ company_name: "", email: "", contact_name: "", phone: "", country: "", category: "packaging", status: "pending", notes: "" });
  const [saving, setSaving] = useState(false);
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSave = async () => {
    if (!form.company_name || !form.email) { toast.error("Company name and email are required"); return; }
    setSaving(true);
    try {
      await base44.entities.SupplierProfile.create(form);
      // Invite to app
      try { await base44.users.inviteUser(form.email, "user"); } catch (e) { /* already exists is fine */ }
      toast.success("Supplier added and invited to portal");
      onCreated();
    } catch (err) {
      toast.error("Failed to add supplier");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Add Supplier</DialogTitle></DialogHeader>
        <div className="space-y-3 pt-2">
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Company Name *</Label><Input value={form.company_name} onChange={e => f("company_name", e.target.value)} /></div>
            <div><Label>Contact Name</Label><Input value={form.contact_name} onChange={e => f("contact_name", e.target.value)} /></div>
            <div><Label>Email *</Label><Input type="email" value={form.email} onChange={e => f("email", e.target.value)} /></div>
            <div><Label>Phone</Label><Input value={form.phone} onChange={e => f("phone", e.target.value)} /></div>
            <div>
              <Label>Category</Label>
              <Select value={form.category} onValueChange={v => f("category", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="raw_material">Raw Material</SelectItem>
                  <SelectItem value="packaging">Packaging</SelectItem>
                  <SelectItem value="service">Service</SelectItem>
                  <SelectItem value="logistics">Logistics</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Country</Label><Input value={form.country} onChange={e => f("country", e.target.value)} /></div>
          </div>
          <div><Label>Internal Notes</Label><Textarea rows={2} value={form.notes} onChange={e => f("notes", e.target.value)} className="resize-none" /></div>
          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              {saving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Mail className="w-4 h-4 mr-1" />}
              Add & Invite
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}