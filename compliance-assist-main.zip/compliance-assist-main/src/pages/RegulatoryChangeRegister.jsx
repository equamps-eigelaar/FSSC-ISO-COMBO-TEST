import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  BookOpen, Plus, Search, Filter, AlertTriangle, CheckCircle2,
  Clock, Calendar, Edit2, Trash2, ChevronDown, ChevronUp
} from "lucide-react";
import { format } from "date-fns";

const SOURCES = ["ISO 22000", "FSSC 22000", "TS 22002-4", "Local Regulation", "Internal Policy", "Customer Requirement", "Other"];
const CHANGE_TYPES = ["new_requirement", "amendment", "withdrawal", "guidance_update", "internal_policy"];
const STATUSES = ["identified", "under_review", "action_required", "in_progress", "implemented", "not_applicable"];
const IMPACT_LEVELS = ["low", "medium", "high", "critical"];

const statusConfig = {
  identified: { label: "Identified", color: "bg-blue-100 text-blue-700" },
  under_review: { label: "Under Review", color: "bg-purple-100 text-purple-700" },
  action_required: { label: "Action Required", color: "bg-rose-100 text-rose-700" },
  in_progress: { label: "In Progress", color: "bg-amber-100 text-amber-700" },
  implemented: { label: "Implemented", color: "bg-emerald-100 text-emerald-700" },
  not_applicable: { label: "Not Applicable", color: "bg-slate-100 text-slate-500" },
};

const impactConfig = {
  low: { color: "bg-emerald-100 text-emerald-700" },
  medium: { color: "bg-amber-100 text-amber-700" },
  high: { color: "bg-orange-100 text-orange-700" },
  critical: { color: "bg-rose-100 text-rose-700" },
};

const EMPTY_FORM = {
  title: "", reference: "", source: "ISO 22000", change_type: "amendment",
  description: "", impact_level: "medium", impact_assessment: "",
  affected_clauses: "", effective_date: "", identified_date: format(new Date(), "yyyy-MM-dd"),
  implementation_deadline: "", status: "identified", assigned_to: "", actions_required: "", notes: "",
};

export default function RegulatoryChangeRegister() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterImpact, setFilterImpact] = useState("all");
  const [filterSource, setFilterSource] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [expandedId, setExpandedId] = useState(null);

  const { data: changes = [], isLoading } = useQuery({
    queryKey: ["regulatory-changes"],
    queryFn: () => base44.entities.RegulatoryChange.list("-created_date", 200),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.RegulatoryChange.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["regulatory-changes"] }); setDialogOpen(false); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RegulatoryChange.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["regulatory-changes"] }); setDialogOpen(false); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RegulatoryChange.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["regulatory-changes"] }),
  });

  const openCreate = () => { setEditingItem(null); setForm(EMPTY_FORM); setDialogOpen(true); };
  const openEdit = (item) => {
    setEditingItem(item);
    setForm({ ...item, affected_clauses: (item.affected_clauses || []).join(", ") });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    const payload = {
      ...form,
      affected_clauses: form.affected_clauses ? form.affected_clauses.split(",").map(s => s.trim()).filter(Boolean) : [],
    };
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const filtered = changes.filter(c => {
    const matchSearch = !search || c.title?.toLowerCase().includes(search.toLowerCase()) || c.reference?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "all" || c.status === filterStatus;
    const matchImpact = filterImpact === "all" || c.impact_level === filterImpact;
    const matchSource = filterSource === "all" || c.source === filterSource;
    return matchSearch && matchStatus && matchImpact && matchSource;
  });

  const stats = {
    total: changes.length,
    actionRequired: changes.filter(c => c.status === "action_required").length,
    critical: changes.filter(c => c.impact_level === "critical").length,
    implemented: changes.filter(c => c.status === "implemented").length,
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Regulatory Change Register</h1>
              <p className="text-sm text-slate-500">Track regulatory and standard updates affecting your operations</p>
            </div>
          </div>
          <Button onClick={openCreate} className="bg-indigo-600 hover:bg-indigo-700 gap-2">
            <Plus className="w-4 h-4" /> Add Change
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { label: "Total Changes", value: stats.total, color: "text-slate-700", bg: "bg-white" },
            { label: "Action Required", value: stats.actionRequired, color: "text-rose-600", bg: "bg-rose-50" },
            { label: "Critical Impact", value: stats.critical, color: "text-rose-700", bg: "bg-rose-50" },
            { label: "Implemented", value: stats.implemented, color: "text-emerald-700", bg: "bg-emerald-50" },
          ].map(s => (
            <Card key={s.label} className="border-0 shadow-sm">
              <CardContent className={`p-4 ${s.bg} rounded-xl`}>
                <div className={`text-3xl font-bold ${s.color}`}>{s.value}</div>
                <div className="text-xs text-slate-500 mt-1">{s.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input placeholder="Search changes..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40"><SelectValue placeholder="All Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  {STATUSES.map(s => <SelectItem key={s} value={s}>{statusConfig[s]?.label || s}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={filterImpact} onValueChange={setFilterImpact}>
                <SelectTrigger className="w-36"><SelectValue placeholder="All Impact" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Impact</SelectItem>
                  {IMPACT_LEVELS.map(l => <SelectItem key={l} value={l} className="capitalize">{l}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={filterSource} onValueChange={setFilterSource}>
                <SelectTrigger className="w-40"><SelectValue placeholder="All Sources" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sources</SelectItem>
                  {SOURCES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* List */}
        {isLoading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-16 text-center">
              <BookOpen className="w-12 h-12 text-slate-200 mx-auto mb-3" />
              <p className="text-slate-400 font-medium">No regulatory changes found</p>
              <p className="text-slate-400 text-sm mt-1">Click "Add Change" to start tracking regulatory updates</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filtered.map(item => {
              const sc = statusConfig[item.status] || { label: item.status, color: "bg-slate-100 text-slate-600" };
              const ic = impactConfig[item.impact_level] || { color: "bg-slate-100 text-slate-600" };
              const isExpanded = expandedId === item.id;
              return (
                <Card key={item.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className="font-semibold text-slate-900 text-sm">{item.title}</span>
                          {item.reference && <span className="text-xs font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">{item.reference}</span>}
                        </div>
                        <div className="flex flex-wrap gap-1.5 mt-1.5">
                          <Badge className={sc.color + " text-xs"}>{sc.label}</Badge>
                          <Badge className={ic.color + " text-xs capitalize"}>{item.impact_level} impact</Badge>
                          <Badge variant="outline" className="text-xs">{item.source}</Badge>
                          <Badge variant="outline" className="text-xs capitalize">{(item.change_type || "").replace(/_/g, " ")}</Badge>
                        </div>
                        {item.effective_date && (
                          <div className="flex items-center gap-1 mt-2 text-xs text-slate-400">
                            <Calendar className="w-3 h-3" />
                            Effective: {format(new Date(item.effective_date), "dd MMM yyyy")}
                            {item.implementation_deadline && (
                              <span className="ml-2">· Deadline: {format(new Date(item.implementation_deadline), "dd MMM yyyy")}</span>
                            )}
                          </div>
                        )}
                        {isExpanded && (
                          <div className="mt-3 space-y-2 text-sm text-slate-600 border-t pt-3">
                            {item.description && <p><span className="font-medium text-slate-700">Description: </span>{item.description}</p>}
                            {item.impact_assessment && <p><span className="font-medium text-slate-700">Impact: </span>{item.impact_assessment}</p>}
                            {item.actions_required && <p><span className="font-medium text-slate-700">Actions Required: </span>{item.actions_required}</p>}
                            {item.assigned_to && <p><span className="font-medium text-slate-700">Assigned To: </span>{item.assigned_to}</p>}
                            {item.affected_clauses?.length > 0 && (
                              <p><span className="font-medium text-slate-700">Affected Clauses: </span>{item.affected_clauses.join(", ")}</p>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setExpandedId(isExpanded ? null : item.id)}>
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(item)}>
                          <Edit2 className="w-4 h-4 text-slate-400" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => deleteMutation.mutate(item.id)}>
                          <Trash2 className="w-4 h-4 text-rose-400" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Regulatory Change" : "Add Regulatory Change"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
            <div className="sm:col-span-2">
              <Label className="text-xs font-medium">Title *</Label>
              <Input className="mt-1" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="e.g. FSSC 22000 Version 6 Update" />
            </div>
            <div>
              <Label className="text-xs font-medium">Reference</Label>
              <Input className="mt-1" value={form.reference} onChange={e => setForm({ ...form, reference: e.target.value })} placeholder="e.g. ISO 22000:2018 §8.5" />
            </div>
            <div>
              <Label className="text-xs font-medium">Source</Label>
              <Select value={form.source} onValueChange={v => setForm({ ...form, source: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{SOURCES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs font-medium">Change Type</Label>
              <Select value={form.change_type} onValueChange={v => setForm({ ...form, change_type: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{CHANGE_TYPES.map(t => <SelectItem key={t} value={t} className="capitalize">{t.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs font-medium">Impact Level</Label>
              <Select value={form.impact_level} onValueChange={v => setForm({ ...form, impact_level: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{IMPACT_LEVELS.map(l => <SelectItem key={l} value={l} className="capitalize">{l}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs font-medium">Status</Label>
              <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{statusConfig[s]?.label || s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs font-medium">Assigned To</Label>
              <Input className="mt-1" value={form.assigned_to} onChange={e => setForm({ ...form, assigned_to: e.target.value })} placeholder="email@company.com" />
            </div>
            <div>
              <Label className="text-xs font-medium">Effective Date</Label>
              <Input type="date" className="mt-1" value={form.effective_date} onChange={e => setForm({ ...form, effective_date: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs font-medium">Implementation Deadline</Label>
              <Input type="date" className="mt-1" value={form.implementation_deadline} onChange={e => setForm({ ...form, implementation_deadline: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-xs font-medium">Affected Clauses (comma-separated)</Label>
              <Input className="mt-1" value={form.affected_clauses} onChange={e => setForm({ ...form, affected_clauses: e.target.value })} placeholder="e.g. 8.5.1, 7.6.3" />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-xs font-medium">Description</Label>
              <Textarea className="mt-1 h-20" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Describe the regulatory change..." />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-xs font-medium">Impact Assessment</Label>
              <Textarea className="mt-1 h-20" value={form.impact_assessment} onChange={e => setForm({ ...form, impact_assessment: e.target.value })} placeholder="How does this affect current operations?" />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-xs font-medium">Actions Required</Label>
              <Textarea className="mt-1 h-20" value={form.actions_required} onChange={e => setForm({ ...form, actions_required: e.target.value })} placeholder="What needs to be done to comply?" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={!form.title || createMutation.isPending || updateMutation.isPending} className="bg-indigo-600 hover:bg-indigo-700">
              {editingItem ? "Save Changes" : "Add Change"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}