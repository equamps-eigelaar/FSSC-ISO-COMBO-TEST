import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useOfflineQuery } from "@/components/offline/useOfflineQuery";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertTriangle,
  Search,
  Plus,
  CheckCircle,
  XCircle,
  Clock,
  FileEdit,
  Filter,
} from "lucide-react";
import { usePermissions } from "@/components/permissions/usePermissions";
import InitiateRiskDialog from "@/components/risk/InitiateRiskDialog";
import RiskWorkflowCard from "@/components/risk/RiskWorkflowCard";
import RequirementsNeedingRisk from "@/components/risk/RequirementsNeedingRisk";
import RiskHeatmap from "@/components/risk/RiskHeatmap";
import RiskTemplateManager from "@/components/risk/RiskTemplateManager";
import GMPInspection from "@/components/risk/GMPInspection";
import FacilityRiskReport from "@/components/risk/FacilityRiskReport";
import QMSAddendum1Report from "@/components/risk/QMSAddendum1Report";
import RiskAnalyticsDashboard from "@/components/risk/RiskAnalyticsDashboard";
import PullToRefresh from "@/components/mobile/PullToRefresh";
import MobileSelect from "@/components/mobile/MobileSelect";

const WORKFLOW_STATUS_CONFIG = {
  draft: { label: "Draft", icon: FileEdit, className: "bg-slate-100 text-slate-600" },
  pending_review: { label: "Pending Review", icon: Clock, className: "bg-amber-50 text-amber-700" },
  approved: { label: "Approved", icon: CheckCircle, className: "bg-emerald-50 text-emerald-700" },
  rejected: { label: "Rejected", icon: XCircle, className: "bg-rose-50 text-rose-700" },
  revision_required: { label: "Revision Required", icon: AlertTriangle, className: "bg-orange-50 text-orange-700" },
};

export default function RiskWorkflow() {
  const [search, setSearch] = useState("");
  const [showInitiate, setShowInitiate] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [showTemplates, setShowTemplates] = useState(false);
  const [selectedHeatmapRisks, setSelectedHeatmapRisks] = useState(null);

  const { permissions, user } = usePermissions();
  const queryClient = useQueryClient();

  const { data: risks = [], isLoading, refetch } = useOfflineQuery(
    ["risk-assessments-workflow"],
    "RiskAssessment",
    () => base44.entities.RiskAssessment.list("-created_date", 200)
  );

  const { data: requirements = [] } = useOfflineQuery(
    ["compliance-requirements"],
    "ComplianceRequirement",
    () => base44.entities.ComplianceRequirement.list("-created_date", 200)
  );

  const handleRefresh = async () => {
    await refetch();
  };

  const filteredRisks = risks.filter(r => {
    const matchSearch = search === "" ||
      r.hazard_description?.toLowerCase().includes(search.toLowerCase()) ||
      r.requirement_id?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || r.workflow_status === statusFilter;
    const matchPriority = priorityFilter === "all" || r.priority === priorityFilter;
    return matchSearch && matchStatus && matchPriority;
  });

  const myAssigned = filteredRisks.filter(r => r.assigned_to === user?.email);
  const pendingApproval = filteredRisks.filter(r => r.workflow_status === "pending_review");
  const drafts = filteredRisks.filter(r => r.workflow_status === "draft");
  const approved = filteredRisks.filter(r => r.workflow_status === "approved");

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Risk Assessment Workflow
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              {filteredRisks.length} risk assessment{filteredRisks.length !== 1 ? "s" : ""}
            </p>
          </div>
          {permissions.canManageRisks && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowTemplates(!showTemplates)}
              >
                Templates
              </Button>
              <Button onClick={() => setShowInitiate(true)} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                Initiate Assessment
              </Button>
            </div>
          )}
        </div>

        {/* Templates Section */}
        {showTemplates && (
          <div className="mb-6">
            <RiskTemplateManager />
          </div>
        )}

        {/* Risk Heatmap */}
        <div className="mb-6">
          <RiskHeatmap 
            risks={risks}
            onCellClick={(likelihood, severity, cellRisks) => {
              if (cellRisks.length > 0) {
                setSelectedHeatmapRisks({ likelihood, severity, risks: cellRisks });
              }
            }}
          />
        </div>

        {/* Selected Heatmap Risks */}
        {selectedHeatmapRisks && (
          <Card className="border-0 shadow-sm mb-6 bg-slate-50">
            <CardHeader className="border-b border-slate-200">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold capitalize">
                  {selectedHeatmapRisks.likelihood.replace(/_/g, ' ')} × {selectedHeatmapRisks.severity} Risks
                  <span className="ml-2 text-slate-500">({selectedHeatmapRisks.risks.length})</span>
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedHeatmapRisks(null)}
                >
                  Clear
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-3">
                {selectedHeatmapRisks.risks.map(risk => (
                  <RiskWorkflowCard key={risk.id} risk={risk} requirements={requirements} />
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <StatCard label="Pending Review" count={pendingApproval.length} color="amber" />
          <StatCard label="My Assigned" count={myAssigned.length} color="blue" />
          <StatCard label="Drafts" count={drafts.length} color="slate" />
          <StatCard label="Approved" count={approved.length} color="emerald" />
        </div>

        {/* Filters */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search assessments..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 border-slate-200 min-h-[44px]"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-48 border-slate-200 min-h-[44px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="pending_review">Pending Review</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="revision_required">Revision Required</SelectItem>
                </SelectContent>
              </Select>
              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger className="w-full sm:w-40 border-slate-200 min-h-[44px]">
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="bg-white border border-slate-200 flex-wrap h-auto gap-1">
            <TabsTrigger value="all">All Assessments</TabsTrigger>
            <TabsTrigger value="analytics" className="gap-1.5">
              Analytics & AI
            </TabsTrigger>
            <TabsTrigger value="pending">Pending Review</TabsTrigger>
            <TabsTrigger value="assigned">My Assigned</TabsTrigger>
            <TabsTrigger value="needs-assessment">Needs Assessment</TabsTrigger>
            <TabsTrigger value="gmp-inspection">GMP Inspection</TabsTrigger>
            <TabsTrigger value="facility-report">Facility Risk Report</TabsTrigger>
            <TabsTrigger value="qms-addendum1">QMS Addendum 1</TabsTrigger>
          </TabsList>

          <TabsContent value="analytics">
            <RiskAnalyticsDashboard risks={risks} />
          </TabsContent>

          <TabsContent value="all" className="space-y-4">
            {filteredRisks.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-12 text-center">
                  <AlertTriangle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No risk assessments found</p>
                </CardContent>
              </Card>
            ) : (
              filteredRisks.map(risk => (
                <RiskWorkflowCard key={risk.id} risk={risk} requirements={requirements} />
              ))
            )}
          </TabsContent>

          <TabsContent value="pending" className="space-y-4">
            {pendingApproval.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-12 text-center">
                  <CheckCircle className="w-12 h-12 text-emerald-300 mx-auto mb-4" />
                  <p className="text-slate-500">No assessments pending review</p>
                </CardContent>
              </Card>
            ) : (
              pendingApproval.map(risk => (
                <RiskWorkflowCard key={risk.id} risk={risk} requirements={requirements} />
              ))
            )}
          </TabsContent>

          <TabsContent value="assigned" className="space-y-4">
            {myAssigned.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-12 text-center">
                  <FileEdit className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No assessments assigned to you</p>
                </CardContent>
              </Card>
            ) : (
              myAssigned.map(risk => (
                <RiskWorkflowCard key={risk.id} risk={risk} requirements={requirements} />
              ))
            )}
          </TabsContent>

          <TabsContent value="needs-assessment">
            <RequirementsNeedingRisk requirements={requirements} risks={risks} />
          </TabsContent>

          <TabsContent value="gmp-inspection">
            <GMPInspection />
          </TabsContent>

          <TabsContent value="facility-report">
            <FacilityRiskReport />
          </TabsContent>

          <TabsContent value="qms-addendum1">
            <QMSAddendum1Report />
          </TabsContent>
        </Tabs>
        </div>
      </div>

      <InitiateRiskDialog open={showInitiate} onClose={() => setShowInitiate(false)} />
    </PullToRefresh>
  );
}

function StatCard({ label, count, color }) {
  const colorMap = {
    amber: { bg: "bg-amber-50", text: "text-amber-700" },
    blue: { bg: "bg-blue-50", text: "text-blue-700" },
    slate: { bg: "bg-slate-100", text: "text-slate-600" },
    emerald: { bg: "bg-emerald-50", text: "text-emerald-700" },
  };
  const c = colorMap[color];

  return (
    <Card className="border-0 shadow-sm">
      <CardContent className="p-4">
        <div className={`text-2xl font-bold ${c.text} mb-1`}>{count}</div>
        <div className="text-xs text-slate-500 font-medium">{label}</div>
      </CardContent>
    </Card>
  );
}