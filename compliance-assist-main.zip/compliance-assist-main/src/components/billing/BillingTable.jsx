import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Calendar } from "lucide-react";
import XeroInvoiceDialog from "@/components/billing/XeroInvoiceDialog";
import InvoiceApprovalDialog from "@/components/billing/InvoiceApprovalDialog";

export default function BillingTable({ records, onUpdateStatus, isUpdating, onRefresh }) {
  const [editingId, setEditingId] = useState(null);
  const [editStatus, setEditStatus] = useState("");
  const [editInvoiceNumber, setEditInvoiceNumber] = useState("");
  const [editInvoiceDate, setEditInvoiceDate] = useState("");
  const [xeroRecord, setXeroRecord] = useState(null);
  const [approvalRecord, setApprovalRecord] = useState(null);

  const handleOpenEdit = (record) => {
    setEditingId(record.id);
    setEditStatus(record.billing_status);
    setEditInvoiceNumber(record.invoice_number || "");
    setEditInvoiceDate(record.invoice_date || "");
  };

  const handleSaveEdit = () => {
    onUpdateStatus({
      id: editingId,
      status: editStatus,
      invoiceNumber: editInvoiceNumber || null,
      invoiceDate: editInvoiceDate || null,
    });
    setEditingId(null);
  };

  const getBillingTypeBadge = (type) => {
    if (type === "audit") return <Badge className="bg-blue-100 text-blue-800">Audit</Badge>;
    return <Badge className="bg-purple-100 text-purple-800">Template</Badge>;
  };

  const getCustomerBadge = (type) => {
    if (type === "internal") return <Badge variant="outline" className="border-blue-200">Internal</Badge>;
    return <Badge variant="outline" className="border-green-200">External</Badge>;
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "pending": return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      case "invoiced": return <Badge className="bg-blue-100 text-blue-800">Invoiced</Badge>;
      case "paid": return <Badge className="bg-green-100 text-green-800">Paid</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getApprovalBadge = (status) => {
    switch (status) {
      case "pending_approval": return <Badge className="bg-orange-100 text-orange-800 text-[10px]">Awaiting Review</Badge>;
      case "approved": return <Badge className="bg-emerald-100 text-emerald-800 text-[10px]">Approved</Badge>;
      case "rejected": return <Badge className="bg-red-100 text-red-800 text-[10px]">Rejected</Badge>;
      default: return null;
    }
  };

  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-slate-200 bg-slate-50">
            <tr>
              <th className="text-left py-3 px-4 font-medium text-slate-600">Date</th>
              <th className="text-left py-3 px-4 font-medium text-slate-600">Type</th>
              <th className="text-left py-3 px-4 font-medium text-slate-600">Customer</th>
              <th className="text-left py-3 px-4 font-medium text-slate-600">Description</th>
              <th className="text-right py-3 px-4 font-medium text-slate-600">Qty</th>
              <th className="text-right py-3 px-4 font-medium text-slate-600">Unit Cost</th>
              <th className="text-right py-3 px-4 font-medium text-slate-600">Total</th>
              <th className="text-left py-3 px-4 font-medium text-slate-600">Status</th>
              <th className="text-left py-3 px-4 font-medium text-slate-600">Invoice</th>
              <th className="text-center py-3 px-4 font-medium text-slate-600">Actions</th>
            </tr>
          </thead>
          <tbody>
            {records.map((record) => (
              <tr key={record.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                <td className="py-3 px-4 text-slate-900">{new Date(record.transaction_date).toLocaleDateString()}</td>
                <td className="py-3 px-4">{getBillingTypeBadge(record.billable_type)}</td>
                <td className="py-3 px-4">
                  <div>
                    <p className="font-medium text-slate-900">{record.customer_name}</p>
                    <p className="text-xs text-slate-500">{getCustomerBadge(record.customer_type)}</p>
                  </div>
                </td>
                <td className="py-3 px-4 text-slate-700">{record.entity_name || "—"}</td>
                <td className="py-3 px-4 text-right text-slate-900">{record.quantity}</td>
                <td className="py-3 px-4 text-right text-slate-900">
                  <div>${record.unit_cost.toFixed(2)}</div>
                  <div className="text-xs text-slate-400">R {(record.unit_cost * 18.5).toFixed(2)}</div>
                </td>
                <td className="py-3 px-4 text-right font-medium text-emerald-700">
                  <div>${record.total_cost.toFixed(2)}</div>
                  <div className="text-xs text-slate-400">R {(record.total_cost * 18.5).toFixed(2)}</div>
                </td>
                <td className="py-3 px-4">
                  <div className="space-y-1">
                    {getStatusBadge(record.billing_status)}
                    {getApprovalBadge(record.xero_approval_status)}
                  </div>
                </td>
                <td className="py-3 px-4 text-slate-700 text-sm">{record.invoice_number || "—"}</td>
                <td className="py-3 px-4 text-center">
                  <div className="flex items-center justify-center gap-1 flex-wrap">
                    <Button variant="ghost" size="sm" onClick={() => handleOpenEdit(record)}>Edit</Button>
                    {record.billing_status === "pending" && record.xero_approval_status !== "pending_approval" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50 text-xs gap-1"
                        onClick={() => setXeroRecord(record)}
                      >
                        <img src="https://www.xero.com/favicon.ico" className="w-3 h-3" alt="" />
                        Draft
                      </Button>
                    )}
                    {record.xero_approval_status === "pending_approval" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-orange-700 hover:text-orange-800 hover:bg-orange-50 text-xs gap-1"
                        onClick={() => setApprovalRecord(record)}
                      >
                        <img src="https://www.xero.com/favicon.ico" className="w-3 h-3" alt="" />
                        Review
                      </Button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <XeroInvoiceDialog
        open={!!xeroRecord}
        onOpenChange={(v) => { if (!v) setXeroRecord(null); }}
        record={xeroRecord}
        onSuccess={() => { setXeroRecord(null); if (onRefresh) onRefresh(); }}
      />

      <InvoiceApprovalDialog
        open={!!approvalRecord}
        onOpenChange={(v) => { if (!v) setApprovalRecord(null); }}
        record={approvalRecord}
        onSuccess={() => { setApprovalRecord(null); if (onRefresh) onRefresh(); }}
      />

      <Dialog open={editingId !== null} onOpenChange={(open) => !open && setEditingId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Billing Status</DialogTitle>
            <DialogDescription>Update the status and invoice details for this billing record.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Status</label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="invoiced">Invoiced</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {editStatus !== "pending" && (
              <>
                <div>
                  <label className="text-sm font-medium">Invoice Number</label>
                  <Input
                    value={editInvoiceNumber}
                    onChange={(e) => setEditInvoiceNumber(e.target.value)}
                    placeholder="e.g., INV-2024-001"
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Invoice Date
                  </label>
                  <Input type="date" value={editInvoiceDate} onChange={(e) => setEditInvoiceDate(e.target.value)} className="mt-1" />
                </div>
              </>
            )}
            <div className="flex gap-2 justify-end pt-4">
              <Button variant="outline" onClick={() => setEditingId(null)}>
                Cancel
              </Button>
              <Button onClick={handleSaveEdit} disabled={isUpdating}>
                {isUpdating ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}