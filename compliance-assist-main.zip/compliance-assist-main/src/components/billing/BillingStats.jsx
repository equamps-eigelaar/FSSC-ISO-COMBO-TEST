import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { DollarSign, Clock, FileText, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

// 1 USD ≈ 18.5 ZAR (approximate — update as needed)
const USD_TO_ZAR = 18.5;

const formatAmount = (amount, currency) => {
  if (currency === "ZAR") {
    return `R ${(amount * USD_TO_ZAR).toLocaleString("en-ZA", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
  return `$${amount.toFixed(2)}`;
};

const StatCard = ({ label, amount, icon: Icon, color, currency }) => (
  <Card>
    <CardContent className="pt-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-600">{label}</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{formatAmount(amount, currency)}</p>
          {currency === "ZAR" && (
            <p className="text-xs text-slate-400 mt-0.5">${amount.toFixed(2)} USD</p>
          )}
          {currency === "USD" && (
            <p className="text-xs text-slate-400 mt-0.5">R {(amount * USD_TO_ZAR).toFixed(2)} ZAR</p>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </CardContent>
  </Card>
);

export default function BillingStats({ stats }) {
  const [currency, setCurrency] = useState("USD");

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-end gap-1">
        <span className="text-xs text-slate-500 mr-2">Display currency:</span>
        <Button
          size="sm"
          variant={currency === "USD" ? "default" : "outline"}
          className="h-7 px-3 text-xs"
          onClick={() => setCurrency("USD")}
        >
          $ USD
        </Button>
        <Button
          size="sm"
          variant={currency === "ZAR" ? "default" : "outline"}
          className="h-7 px-3 text-xs"
          onClick={() => setCurrency("ZAR")}
        >
          R ZAR
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard label="Total Revenue" amount={stats.total} icon={DollarSign} color="bg-emerald-100 text-emerald-700" currency={currency} />
        <StatCard label="Pending" amount={stats.pending} icon={Clock} color="bg-yellow-100 text-yellow-700" currency={currency} />
        <StatCard label="Invoiced" amount={stats.invoiced} icon={FileText} color="bg-blue-100 text-blue-700" currency={currency} />
        <StatCard label="Paid" amount={stats.paid} icon={CheckCircle2} color="bg-green-100 text-green-700" currency={currency} />
      </div>
    </div>
  );
}