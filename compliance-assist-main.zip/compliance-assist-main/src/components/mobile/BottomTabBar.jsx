import React, { useRef, useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { LayoutDashboard, ClipboardList, ShieldCheck, CheckCircle2 } from 'lucide-react';

const TABS = [
  { name: 'Dashboard', icon: LayoutDashboard, page: 'Dashboard' },
  { name: 'Audits', icon: ClipboardList, page: 'MobileAudit' },
  { name: 'Actions', icon: CheckCircle2, page: 'MobileActionItems' },
  { name: 'Requirements', icon: ClipboardList, page: 'Requirements' },
];

// Stack preservation: store the navigation history per tab
const tabStacks = {};
TABS.forEach(tab => {
  tabStacks[tab.page] = [tab.page];
});

export default function BottomTabBar({ currentPageName }) {
  const navigate = useNavigate();
  const [lastTabPage, setLastTabPage] = useState(null);

  useEffect(() => {
    // Update the stack for the current page if it's not a deep navigation
    if (currentPageName && !currentPageName.includes('Detail')) {
      const rootPage = TABS.find(t => currentPageName.startsWith(t.page))?.page;
      if (rootPage && !tabStacks[rootPage].includes(currentPageName)) {
        tabStacks[rootPage].push(currentPageName);
      }
    }
  }, [currentPageName]);

  const handleTabClick = (e, tab) => {
    // Get the last deep page in this tab's stack
    const stack = tabStacks[tab.page] || [tab.page];
    const targetPage = stack[stack.length - 1] || tab.page;

    if (currentPageName === targetPage) {
      // Already on this page — scroll to top
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // Navigate to the last page in this tab's stack
      if (targetPage !== tab.page) {
        e.preventDefault();
        navigate(createPageUrl(targetPage));
      }
      // Allow default link navigation for root pages
    }
  };

  return (
    <div 
      className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 z-40 select-none"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="grid grid-cols-4 h-16">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentPageName === tab.page;
          return (
            <Link
              key={tab.page}
              to={createPageUrl(tab.page)}
              onClick={(e) => handleTabClick(e, tab)}
              className="flex flex-col items-center justify-center gap-1 min-h-[44px] active:bg-slate-50 dark:active:bg-slate-800 transition-colors"
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-emerald-600' : 'text-slate-400 dark:text-slate-500'}`} />
              <span className={`text-[10px] font-medium ${isActive ? 'text-emerald-600' : 'text-slate-500 dark:text-slate-400'}`}>
                {tab.name}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}