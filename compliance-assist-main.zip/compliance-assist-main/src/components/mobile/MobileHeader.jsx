import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ChevronLeft, ShieldCheck, Menu, X, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';

// Pages that are "tab roots" — back should go to Dashboard, not browser history
const ROOT_PAGES = ['Dashboard', 'Requirements', 'RiskWorkflow', 'RawMaterialTraceability', 'ActionItems', 'RiskPredictions', 'MobileAudit', 'MobileActionItems', 'DailyMonitoring', 'DocumentRepository', 'Analytics', 'Settings', 'Training', 'Reports'];

const NAV_ITEMS = [
  { name: "Dashboard", page: "Dashboard" },
  { name: "Audit Prep", page: "AuditPrep" },
  { name: "Field Audits", page: "MobileAudit" },
  { name: "Daily Monitoring", page: "DailyMonitoring" },
  { name: "Requirements", page: "Requirements" },
  { name: "Risk Workflow", page: "RiskWorkflow" },
  { name: "Action Items", page: "ActionItems" },
  { name: "Self Assessment", page: "SelfAssessment" },
  { name: "Supplier Portal", page: "SupplierPortal" },
  { name: "Templates", page: "DocumentTemplates" },
  { name: "Documents", page: "DocumentRepository" },
  { name: "Audit Trail", page: "ActivityMonitor" },
  { name: "Training", page: "Training" },
  { name: "Batch Traceability", page: "FoodBatchTraceability" },
  { name: "Raw Materials", page: "RawMaterialTraceability" },
  { name: "AI Audits", page: "ComplianceAudits" },
  { name: "Analytics", page: "Analytics" },
  { name: "Settings", page: "Settings" },
];

export default function MobileHeader({ currentPageName }) {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [orgName, setOrgName] = useState("");

  useEffect(() => {
    base44.auth.me().then(user => {
      if (user?.organization_id) {
        base44.entities.Organization.filter({ id: user.organization_id }).then(orgs => {
          if (orgs?.[0]?.name) setOrgName(orgs[0].name);
        }).catch(() => {});
      }
    }).catch(() => {});
  }, []);
  
  const isRootPage = ROOT_PAGES.includes(currentPageName);
  
  return (
    <>
      <div 
        className="lg:hidden fixed top-0 left-0 right-0 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 z-40 select-none"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="h-14 px-4 flex items-center justify-between">
          {!isRootPage ? (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl('Dashboard'))}
              className="min-h-[44px] min-w-[44px]"
            >
              <ChevronLeft className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            </Button>
          ) : (
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center">
                <ShieldCheck className="w-3.5 h-3.5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-slate-900 dark:text-white leading-tight">FSSC 22000 Compliance Monitoring</span>
                {orgName && <span className="text-[10px] text-slate-400 dark:text-slate-500 leading-tight">{orgName}</span>}
              </div>
            </div>
          )}
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-300 shadow-[0_0_6px_2px_rgba(125,211,252,0.6)]"></span>
            <div className="text-sm font-semibold text-slate-900 dark:text-white">
              {currentPageName.replace(/([A-Z])/g, ' $1').trim()}
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="min-h-[44px] min-w-[44px] text-rose-500 dark:text-rose-400"
              title="Log out / Switch User"
              onClick={() => base44.auth.logout()}
            >
              <LogOut className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="min-h-[52px] min-w-[52px] h-13 w-13"
              onClick={() => setMenuOpen(v => !v)}
            >
              {menuOpen ? <X className="w-6 h-6 text-slate-600 dark:text-slate-300" /> : <Menu className="w-6 h-6 text-slate-600 dark:text-slate-300" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Full-screen dropdown nav */}
      {menuOpen && (
        <div
          className="lg:hidden fixed top-0 left-0 right-0 bottom-0 z-50 bg-white dark:bg-slate-900 overflow-y-auto"
          style={{ paddingTop: 'calc(3.5rem + env(safe-area-inset-top, 0px))', paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
        >
          <div className="absolute top-0 left-0 right-0 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 z-10 flex items-center justify-between px-4 h-14"
            style={{ paddingTop: 'env(safe-area-inset-top)' }}>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center">
                <ShieldCheck className="w-3.5 h-3.5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-slate-900 dark:text-white leading-tight">FSSC 22000 Compliance Monitoring</span>
                {orgName && <span className="text-[10px] text-slate-400 dark:text-slate-500 leading-tight">{orgName}</span>}
              </div>
            </div>
            <Button variant="ghost" size="icon" className="min-h-[44px] min-w-[44px]" onClick={() => setMenuOpen(false)}>
              <X className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            </Button>
          </div>
          <nav className="p-4 space-y-1">
            {NAV_ITEMS.map(item => {
              const active = currentPageName === item.page;
              return (
                <Link
                  key={item.page}
                  to={createPageUrl(item.page)}
                  onClick={() => setMenuOpen(false)}
                  className={`flex items-center px-4 py-3 rounded-xl text-sm font-medium transition-colors min-h-[48px]
                    ${active
                      ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                >
                  {item.name}
                </Link>
              );
            })}
          </nav>
          <div className="p-4 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => base44.auth.logout()}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-colors min-h-[48px]"
            >
              <LogOut className="w-4 h-4" />
              Log out / Switch User
            </button>
          </div>
        </div>
      )}
    </>
  );
}