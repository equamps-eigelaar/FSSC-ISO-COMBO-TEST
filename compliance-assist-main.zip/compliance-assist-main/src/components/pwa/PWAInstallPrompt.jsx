import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { X, Smartphone, Monitor, Apple, Download } from "lucide-react";

function detectPlatform() {
  const ua = navigator.userAgent;
  if (/android/i.test(ua)) return "android";
  if (/ipad|iphone|ipod/i.test(ua)) return "ios";
  if (/windows/i.test(ua)) return "windows";
  if (/mac/i.test(ua)) return "mac";
  return "desktop";
}

function isInStandaloneMode() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    window.navigator.standalone === true
  );
}

const STORAGE_KEY = "pwa_install_dismissed";
const PROMPT_COUNT_KEY = "pwa_prompt_count";
const LAST_PROMPT_KEY = "pwa_last_prompt";
const MAX_PROMPTS = 3;
const REPROMPT_DELAY_MS = 24 * 60 * 60 * 1000; // 24 hours between prompts

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [show, setShow] = useState(false);
  const [platform, setPlatform] = useState("desktop");
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    if (isInStandaloneMode()) return;
    // Permanently dismissed after install or after max prompts shown and closed last time
    if (localStorage.getItem(STORAGE_KEY)) return;

    const count = parseInt(localStorage.getItem(PROMPT_COUNT_KEY) || "0", 10);
    const lastPrompt = parseInt(localStorage.getItem(LAST_PROMPT_KEY) || "0", 10);
    const now = Date.now();

    // Already shown max times and enough time hasn't passed — skip
    if (count >= MAX_PROMPTS) {
      localStorage.setItem(STORAGE_KEY, "1");
      return;
    }

    // Don't re-prompt within 24h (except first time)
    if (count > 0 && now - lastPrompt < REPROMPT_DELAY_MS) return;

    setPlatform(detectPlatform());

    const handler = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShow(true);
    };

    window.addEventListener("beforeinstallprompt", handler);

    const p = detectPlatform();
    if (p === "ios" || p === "mac") {
      const timer = setTimeout(() => setShow(true), 1500);
      return () => {
        clearTimeout(timer);
        window.removeEventListener("beforeinstallprompt", handler);
      };
    }

    const fallback = setTimeout(() => {
      setShow(true);
    }, 2000);

    return () => {
      clearTimeout(fallback);
      window.removeEventListener("beforeinstallprompt", handler);
    };
  }, []);

  const dismiss = () => {
    setShow(false);
    const count = parseInt(localStorage.getItem(PROMPT_COUNT_KEY) || "0", 10) + 1;
    localStorage.setItem(PROMPT_COUNT_KEY, String(count));
    localStorage.setItem(LAST_PROMPT_KEY, String(Date.now()));
    if (count >= MAX_PROMPTS) {
      localStorage.setItem(STORAGE_KEY, "1");
    }
  };

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") setInstalled(true);
      setDeferredPrompt(null);
    }
    dismiss();
  };

  if (!show) return null;

  const isIOS = platform === "ios";
  const isAndroid = platform === "android";
  const isWindows = platform === "windows";
  const promptCount = parseInt(localStorage.getItem(PROMPT_COUNT_KEY) || "0", 10) + 1;
  const remaining = MAX_PROMPTS - promptCount;

  return (
    <AnimatePresence>
      {show && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[99] bg-slate-900/50 backdrop-blur-sm"
            onClick={dismiss}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.92 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="fixed top-6 left-4 z-[100] w-full max-w-sm px-4"
          >
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden">
            {/* Top accent */}
            <div className="h-1 bg-gradient-to-r from-emerald-500 to-emerald-600" />

            <div className="p-5">
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center flex-shrink-0">
                    {isIOS ? (
                      <Apple className="w-5 h-5 text-white" />
                    ) : isAndroid ? (
                      <Smartphone className="w-5 h-5 text-white" />
                    ) : (
                      <Monitor className="w-5 h-5 text-white" />
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900 text-sm">Install the App</p>
                    <p className="text-xs text-slate-500">
                      {isIOS
                        ? "Add to your Home Screen"
                        : isAndroid
                        ? "Install on your Android device"
                        : isWindows
                        ? "Install on your Windows PC"
                        : "Install on your device"}
                    </p>
                  </div>
                </div>
                <button
                  onClick={dismiss}
                  className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors flex-shrink-0"
                >
                  <X className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              {/* Instructions */}
              {isIOS ? (
                <div className="bg-slate-50 rounded-xl p-3 mb-4 text-xs text-slate-600 space-y-1.5">
                  <p className="font-medium text-slate-700">How to install on iOS:</p>
                  <p>1. Tap the <strong>Share</strong> button (□↑) in Safari</p>
                  <p>2. Scroll down and tap <strong>"Add to Home Screen"</strong></p>
                  <p>3. Tap <strong>Add</strong> to confirm</p>
                </div>
              ) : (
                <p className="text-xs text-slate-500 mb-4 leading-relaxed">
                  Get quick access, offline support, and a faster experience — no app store required.
                </p>
              )}

              {/* Actions */}
              <div className="flex gap-2">
                {!isIOS && (
                  <Button
                    onClick={handleInstall}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 gap-2 text-sm h-9"
                  >
                    <Download className="w-4 h-4" />
                    Install Now
                  </Button>
                )}
                <Button
                  variant="ghost"
                  onClick={dismiss}
                  className="text-slate-500 text-sm h-9"
                >
                  {isIOS ? "Got it" : "Not now"}
                </Button>
              </div>

              {/* Reminder badge */}
              {remaining > 0 && (
                <p className="text-center text-[10px] text-slate-400 mt-3">
                  We'll remind you {remaining} more time{remaining !== 1 ? "s" : ""}
                </p>
              )}
            </div>
          </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}