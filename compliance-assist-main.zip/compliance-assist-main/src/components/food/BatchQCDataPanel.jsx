import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { CheckCircle2, XCircle, Plus, Trash2, Pencil, FlaskConical, Save, X } from "lucide-react";

const EMPTY_QC = {
  operator: "",
  machine: "",
  release_decision: "pending",
  release_notes: "",
  test_results: [],
  raw_material_lots: [],
};

const EMPTY_TEST = { parameter: "", value: "", unit: "", specification: "", pass_fail: "pass" };
const EMPTY_LOT = { material_name: "", lot_number: "", supplier: "" };

const decisionColors = {
  pending: "bg-amber-50 text-amber-700 border-amber-200",
  released: "bg-emerald-50 text-emerald-700 border-emerald-200",
  rejected: "bg-red-50 text-red-700 border-red-200",
  on_hold: "bg-slate-50 text-slate-700 border-slate-200",
};

export default function BatchQCDataPanel({ batch, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(batch.qc_data || EMPTY_QC);

  const saveData = async (data) => {
    setSaving(true);
    await base44.entities.FoodBatchRecord.update(batch.id, { qc_data: data });
    setSaving(false);
    setEditing(false);
    if (onSaved) onSaved();
  };

  const hasData = batch.qc_data && (
    batch.qc_data.operator ||
    batch.qc_data.machine ||
    batch.qc_data.test_results?.length > 0 ||
    batch.qc_data.raw_material_lots?.length > 0
  );

  // --- Test Results helpers ---
  const addTest = () => setForm(f => ({ ...f, test_results: [...(f.test_results || []), { ...EMPTY_TEST }] }));
  const removeTest = (i) => setForm(f => ({ ...f, test_results: f.test_results.filter((_, idx) => idx !== i) }));
  const updateTest = (i, field, val) => setForm(f => ({
    ...f,
    test_results: f.test_results.map((t, idx) => idx === i ? { ...t, [field]: val } : t),
  }));

  // --- Lot helpers ---
  const addLot = () => setForm(f => ({ ...f, raw_material_lots: [...(f.raw_material_lots || []), { ...EMPTY_LOT }] }));
  const removeLot = (i) => setForm(f => ({ ...f, raw_material_lots: f.raw_material_lots.filter((_, idx) => idx !== i) }));
  const updateLot = (i, field, val) => setForm(f => ({
    ...f,
    raw_material_lots: f.raw_material_lots.map((l, idx) => idx === i ? { ...l, [field]: val } : l),
  }));

  const handleEdit = () => {
    setForm(batch.qc_data || EMPTY_QC);
    setEditing(true);
  };

  const handleCancel = () => {
    setForm(batch.qc_data || EMPTY_QC);
    setEditing(false);
  };

  // ---- READ VIEW ----
  if (!editing) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold text-slate-800 text-base">Batch QC Data</h3>
          </div>
          <Button size="sm" variant="outline" onClick={handleEdit} className="gap-1.5">
            <Pencil className="w-3.5 h-3.5" /> {hasData ? "Edit" : "Add QC Data"}
          </Button>
        </div>

        {!hasData ? (
          <div className="text-center py-8 text-slate-400 border border-dashed rounded-lg">
            <FlaskConical className="w-10 h-10 mx-auto mb-2 text-slate-300" />
            <p className="text-sm">No QC data recorded for this batch.</p>
          </div>
        ) : (
          <>
            {/* Header info */}
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-slate-500 text-xs">Batch Number</p>
                <p className="font-medium text-slate-900">{batch.batch_number}</p>
              </div>
              <div>
                <p className="text-slate-500 text-xs">Production Date</p>
                <p className="font-medium text-slate-900">{new Date(batch.production_date).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-slate-500 text-xs">Operator</p>
                <p className="font-medium text-slate-900">{batch.qc_data.operator || "—"}</p>
              </div>
              <div>
                <p className="text-slate-500 text-xs">Machine</p>
                <p className="font-medium text-slate-900">{batch.qc_data.machine || "—"}</p>
              </div>
            </div>

            {/* Release decision */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Release Decision:</span>
              <Badge variant="outline" className={decisionColors[batch.qc_data.release_decision || "pending"]}>
                {(batch.qc_data.release_decision || "pending").replace(/_/g, " ")}
              </Badge>
            </div>
            {batch.qc_data.release_notes && (
              <p className="text-xs text-slate-500 italic">{batch.qc_data.release_notes}</p>
            )}

            {/* Test results */}
            {batch.qc_data.test_results?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-slate-600 mb-2">QC Test Results</p>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 text-xs">
                        <th className="text-left p-2 border border-slate-200">Parameter</th>
                        <th className="text-left p-2 border border-slate-200">Value</th>
                        <th className="text-left p-2 border border-slate-200">Unit</th>
                        <th className="text-left p-2 border border-slate-200">Specification</th>
                        <th className="text-center p-2 border border-slate-200">Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      {batch.qc_data.test_results.map((t, i) => (
                        <tr key={i} className="border-b border-slate-100">
                          <td className="p-2 border border-slate-200 font-medium">{t.parameter}</td>
                          <td className="p-2 border border-slate-200">{t.value}</td>
                          <td className="p-2 border border-slate-200 text-slate-500">{t.unit}</td>
                          <td className="p-2 border border-slate-200 text-slate-500">{t.specification}</td>
                          <td className="p-2 border border-slate-200 text-center">
                            {t.pass_fail === "pass"
                              ? <CheckCircle2 className="w-4 h-4 text-emerald-500 mx-auto" />
                              : <XCircle className="w-4 h-4 text-red-500 mx-auto" />}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Raw material lots */}
            {batch.qc_data.raw_material_lots?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-slate-600 mb-2">Raw Material Lots</p>
                <div className="space-y-1.5">
                  {batch.qc_data.raw_material_lots.map((lot, i) => (
                    <div key={i} className="flex gap-4 text-xs bg-slate-50 rounded p-2">
                      <span className="font-medium text-slate-800">{lot.material_name}</span>
                      <span className="text-slate-600">Lot: <strong>{lot.lot_number}</strong></span>
                      {lot.supplier && <span className="text-slate-500">{lot.supplier}</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    );
  }

  // ---- EDIT VIEW ----
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FlaskConical className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-slate-800 text-base">Batch QC Data</h3>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="ghost" onClick={handleCancel}><X className="w-3.5 h-3.5" /></Button>
          <Button size="sm" onClick={() => saveData(form)} disabled={saving} className="gap-1.5 bg-emerald-600 hover:bg-emerald-700">
            <Save className="w-3.5 h-3.5" /> Save
          </Button>
        </div>
      </div>

      {/* Static fields */}
      <div className="grid grid-cols-2 gap-3 text-sm">
        <div>
          <Label className="text-xs text-slate-500">Batch Number</Label>
          <p className="font-medium text-slate-900 mt-0.5">{batch.batch_number}</p>
        </div>
        <div>
          <Label className="text-xs text-slate-500">Production Date</Label>
          <p className="font-medium text-slate-900 mt-0.5">{new Date(batch.production_date).toLocaleDateString()}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs mb-1 block">Operator</Label>
          <Input value={form.operator || ""} onChange={e => setForm(f => ({ ...f, operator: e.target.value }))} placeholder="Operator name" />
        </div>
        <div>
          <Label className="text-xs mb-1 block">Machine</Label>
          <Input value={form.machine || ""} onChange={e => setForm(f => ({ ...f, machine: e.target.value }))} placeholder="Equipment / machine ID" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs mb-1 block">Release Decision</Label>
          <Select value={form.release_decision || "pending"} onValueChange={v => setForm(f => ({ ...f, release_decision: v }))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="released">Released</SelectItem>
              <SelectItem value="on_hold">On Hold</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs mb-1 block">Release Notes</Label>
          <Input value={form.release_notes || ""} onChange={e => setForm(f => ({ ...f, release_notes: e.target.value }))} placeholder="Optional notes" />
        </div>
      </div>

      {/* Test Results */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs font-semibold text-slate-600">QC Test Results</Label>
          <Button size="sm" variant="outline" onClick={addTest} className="gap-1 h-7 text-xs">
            <Plus className="w-3 h-3" /> Add Row
          </Button>
        </div>
        {(form.test_results || []).length === 0 && (
          <p className="text-xs text-slate-400 italic">No test results added yet.</p>
        )}
        <div className="space-y-2">
          {(form.test_results || []).map((t, i) => (
            <div key={i} className="grid grid-cols-[1fr_1fr_0.6fr_1fr_0.6fr_auto] gap-2 items-center">
              <Input value={t.parameter} onChange={e => updateTest(i, "parameter", e.target.value)} placeholder="Parameter" className="h-8 text-xs" />
              <Input value={t.value} onChange={e => updateTest(i, "value", e.target.value)} placeholder="Value" className="h-8 text-xs" />
              <Input value={t.unit} onChange={e => updateTest(i, "unit", e.target.value)} placeholder="Unit" className="h-8 text-xs" />
              <Input value={t.specification} onChange={e => updateTest(i, "specification", e.target.value)} placeholder="Spec / limit" className="h-8 text-xs" />
              <Select value={t.pass_fail} onValueChange={v => updateTest(i, "pass_fail", v)}>
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pass">Pass</SelectItem>
                  <SelectItem value="fail">Fail</SelectItem>
                </SelectContent>
              </Select>
              <Button size="icon" variant="ghost" onClick={() => removeTest(i)} className="h-8 w-8 text-red-400 hover:text-red-600">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Raw Material Lots */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs font-semibold text-slate-600">Raw Material Lots</Label>
          <Button size="sm" variant="outline" onClick={addLot} className="gap-1 h-7 text-xs">
            <Plus className="w-3 h-3" /> Add Lot
          </Button>
        </div>
        {(form.raw_material_lots || []).length === 0 && (
          <p className="text-xs text-slate-400 italic">No lots added yet.</p>
        )}
        <div className="space-y-2">
          {(form.raw_material_lots || []).map((l, i) => (
            <div key={i} className="grid grid-cols-[1fr_1fr_1fr_auto] gap-2 items-center">
              <Input value={l.material_name} onChange={e => updateLot(i, "material_name", e.target.value)} placeholder="Material name" className="h-8 text-xs" />
              <Input value={l.lot_number} onChange={e => updateLot(i, "lot_number", e.target.value)} placeholder="Lot number" className="h-8 text-xs" />
              <Input value={l.supplier} onChange={e => updateLot(i, "supplier", e.target.value)} placeholder="Supplier" className="h-8 text-xs" />
              <Button size="icon" variant="ghost" onClick={() => removeLot(i)} className="h-8 w-8 text-red-400 hover:text-red-600">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}