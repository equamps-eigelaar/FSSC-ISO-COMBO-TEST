import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, Pencil, Plus, X, Save, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function ComplianceProfilePanel({ productCode, productName }) {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [newParam, setNewParam] = useState("");
  const [newCustomer, setNewCustomer] = useState({ customer_name: "", variant_notes: "" });

  const { data: profiles = [], isLoading } = useQuery({
    queryKey: ["compliance-profile", productCode],
    queryFn: () => base44.entities.ProductComplianceProfile.filter({ product_code: productCode }),
    enabled: !!productCode,
  });

  const profile = profiles[0] || null;

  const emptyForm = {
    product_name: productName || "",
    product_code: productCode || "",
    specification_reference: "",
    standard_coc_statement: "",
    standard_coa_parameters: [],
    tolerances: "",
    regulatory_requirements: "",
    customer_specific_variants: [],
  };

  const [form, setForm] = useState(emptyForm);

  React.useEffect(() => {
    if (profile) setForm(profile);
    else setForm({ ...emptyForm, product_name: productName || "", product_code: productCode || "" });
  }, [profile, productCode, productName]);

  const saveMutation = useMutation({
    mutationFn: (data) =>
      profile
        ? base44.entities.ProductComplianceProfile.update(profile.id, data)
        : base44.entities.ProductComplianceProfile.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-profile", productCode] });
      toast.success("Compliance profile saved");
      setEditing(false);
    },
    onError: () => toast.error("Failed to save compliance profile"),
  });

  const addParam = () => {
    if (!newParam.trim()) return;
    setForm(f => ({ ...f, standard_coa_parameters: [...(f.standard_coa_parameters || []), newParam.trim()] }));
    setNewParam("");
  };

  const removeParam = (idx) =>
    setForm(f => ({ ...f, standard_coa_parameters: f.standard_coa_parameters.filter((_, i) => i !== idx) }));

  const addCustomer = () => {
    if (!newCustomer.customer_name.trim()) return;
    setForm(f => ({ ...f, customer_specific_variants: [...(f.customer_specific_variants || []), { ...newCustomer }] }));
    setNewCustomer({ customer_name: "", variant_notes: "" });
  };

  const removeCustomer = (idx) =>
    setForm(f => ({ ...f, customer_specific_variants: f.customer_specific_variants.filter((_, i) => i !== idx) }));

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 py-8 text-slate-400 justify-center">
        <Loader2 className="w-4 h-4 animate-spin" /> Loading compliance profile...
      </div>
    );
  }

  if (!editing && !profile) {
    return (
      <div className="text-center py-10">
        <ShieldCheck className="w-10 h-10 text-slate-300 mx-auto mb-3" />
        <p className="text-slate-500 text-sm mb-4">No compliance profile set for this product yet.</p>
        <Button size="sm" onClick={() => setEditing(true)}>
          <Plus className="w-4 h-4 mr-1" /> Create Compliance Profile
        </Button>
      </div>
    );
  }

  if (!editing) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="text-sm font-semibold text-slate-700">Compliance Profile</span>
            <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200">Active</Badge>
          </div>
          <Button size="sm" variant="outline" onClick={() => setEditing(true)}>
            <Pencil className="w-3.5 h-3.5 mr-1" /> Edit
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <p className="text-xs text-slate-500">Product Name</p>
            <p className="font-medium text-slate-900">{profile.product_name}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Product Code</p>
            <p className="font-medium text-slate-900">{profile.product_code}</p>
          </div>
          {profile.specification_reference && (
            <div className="col-span-2">
              <p className="text-xs text-slate-500">Specification Reference</p>
              <p className="font-medium text-slate-900">{profile.specification_reference}</p>
            </div>
          )}
        </div>

        {profile.standard_coc_statement && (
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <p className="text-xs font-medium text-slate-500 mb-1">Standard CoC Statement</p>
            <p className="text-sm text-slate-800 whitespace-pre-line">{profile.standard_coc_statement}</p>
          </div>
        )}

        {profile.standard_coa_parameters?.length > 0 && (
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1.5">Standard CoA Parameters</p>
            <div className="flex flex-wrap gap-1.5">
              {profile.standard_coa_parameters.map((p, i) => (
                <Badge key={i} variant="outline" className="text-xs">{p}</Badge>
              ))}
            </div>
          </div>
        )}

        {profile.tolerances && (
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1">Tolerances</p>
            <p className="text-sm text-slate-800 whitespace-pre-line">{profile.tolerances}</p>
          </div>
        )}

        {profile.regulatory_requirements && (
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1">Regulatory Requirements</p>
            <p className="text-sm text-slate-800 whitespace-pre-line">{profile.regulatory_requirements}</p>
          </div>
        )}

        {profile.customer_specific_variants?.length > 0 && (
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1.5">Customer-Specific Variants</p>
            <div className="space-y-1.5">
              {profile.customer_specific_variants.map((v, i) => (
                <div key={i} className="p-2 bg-blue-50 border border-blue-100 rounded text-sm">
                  <span className="font-medium text-blue-900">{v.customer_name}</span>
                  {v.variant_notes && <p className="text-blue-700 text-xs mt-0.5">{v.variant_notes}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // Edit form
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-semibold text-slate-700">Edit Compliance Profile</span>
        <Button size="sm" variant="ghost" onClick={() => { setEditing(false); if (profile) setForm(profile); }}>
          Cancel
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">Product Name</Label>
          <Input value={form.product_name} onChange={e => setForm(f => ({ ...f, product_name: e.target.value }))} />
        </div>
        <div>
          <Label className="text-xs">Product Code</Label>
          <Input value={form.product_code} onChange={e => setForm(f => ({ ...f, product_code: e.target.value }))} />
        </div>
      </div>

      <div>
        <Label className="text-xs">Specification Reference</Label>
        <Input
          placeholder="e.g. SPEC-001 Rev 3"
          value={form.specification_reference}
          onChange={e => setForm(f => ({ ...f, specification_reference: e.target.value }))}
        />
      </div>

      <div>
        <Label className="text-xs">Standard CoC Statement</Label>
        <Textarea
          rows={3}
          placeholder="This is to certify that the above product conforms to..."
          value={form.standard_coc_statement}
          onChange={e => setForm(f => ({ ...f, standard_coc_statement: e.target.value }))}
        />
      </div>

      <div>
        <Label className="text-xs">Standard CoA Parameters</Label>
        <div className="flex flex-wrap gap-1.5 mb-2 min-h-[28px]">
          {(form.standard_coa_parameters || []).map((p, i) => (
            <Badge key={i} variant="outline" className="text-xs gap-1">
              {p}
              <button type="button" onClick={() => removeParam(i)} className="hover:text-red-500">
                <X className="w-2.5 h-2.5" />
              </button>
            </Badge>
          ))}
        </div>
        <div className="flex gap-2">
          <Input
            placeholder="e.g. Tensile Strength"
            value={newParam}
            onChange={e => setNewParam(e.target.value)}
            onKeyDown={e => e.key === "Enter" && (e.preventDefault(), addParam())}
            className="text-sm"
          />
          <Button type="button" size="sm" variant="outline" onClick={addParam}>
            <Plus className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      <div>
        <Label className="text-xs">Tolerances</Label>
        <Textarea
          rows={2}
          placeholder="e.g. Width ±0.5mm, Thickness ±2µm"
          value={form.tolerances}
          onChange={e => setForm(f => ({ ...f, tolerances: e.target.value }))}
        />
      </div>

      <div>
        <Label className="text-xs">Regulatory Requirements</Label>
        <Textarea
          rows={2}
          placeholder="e.g. FSSC 22000, EU Regulation 10/2011, SANS 10237"
          value={form.regulatory_requirements}
          onChange={e => setForm(f => ({ ...f, regulatory_requirements: e.target.value }))}
        />
      </div>

      <div>
        <Label className="text-xs">Customer-Specific Variants (optional)</Label>
        <div className="space-y-1.5 mb-2">
          {(form.customer_specific_variants || []).map((v, i) => (
            <div key={i} className="flex items-start gap-2 p-2 bg-blue-50 border border-blue-100 rounded text-sm">
              <div className="flex-1">
                <span className="font-medium text-blue-900">{v.customer_name}</span>
                {v.variant_notes && <p className="text-blue-700 text-xs">{v.variant_notes}</p>}
              </div>
              <button type="button" onClick={() => removeCustomer(i)} className="text-slate-400 hover:text-red-500 mt-0.5">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Input
            placeholder="Customer name"
            value={newCustomer.customer_name}
            onChange={e => setNewCustomer(c => ({ ...c, customer_name: e.target.value }))}
            className="text-sm"
          />
          <Input
            placeholder="Variant notes"
            value={newCustomer.variant_notes}
            onChange={e => setNewCustomer(c => ({ ...c, variant_notes: e.target.value }))}
            className="text-sm"
          />
        </div>
        <Button type="button" size="sm" variant="outline" className="mt-2" onClick={addCustomer}>
          <Plus className="w-3.5 h-3.5 mr-1" /> Add Customer Variant
        </Button>
      </div>

      <div className="flex justify-end pt-2 border-t">
        <Button
          size="sm"
          onClick={() => saveMutation.mutate(form)}
          disabled={saveMutation.isPending}
          className="bg-emerald-600 hover:bg-emerald-700"
        >
          {saveMutation.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" /> : <Save className="w-3.5 h-3.5 mr-1" />}
          Save Profile
        </Button>
      </div>
    </div>
  );
}