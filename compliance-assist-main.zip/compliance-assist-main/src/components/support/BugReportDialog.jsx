import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

export default function BugReportDialog({ open, onOpenChange }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("bug");
  const [priority, setPriority] = useState("medium");
  const [reporterEmail, setReporterEmail] = useState("");
  const [reporterName, setReporterName] = useState("");
  const [billable, setBillable] = useState(false);
  const queryClient = useQueryClient();

  const generateTicketNumber = () => {
    const count = Math.floor(Math.random() * 10000);
    return `TKT-${String(count).padStart(6, '0')}`;
  };

  const createTicketMutation = useMutation({
    mutationFn: async (ticketData) => {
      const ticket = await base44.entities.SupportTicket.create(ticketData);
      
      // Send notification email
      await base44.functions.invoke('sendTicketNotification', {
        ticketId: ticket.id,
        ticketNumber: ticket.ticket_number,
        title: ticket.title,
        description: ticket.description,
        reporterEmail: ticket.reporter_email,
        category: ticket.category,
        priority: ticket.priority,
      });

      return ticket;
    },
    onSuccess: (ticket) => {
      queryClient.invalidateQueries({ queryKey: ["tickets"] });
      toast.success(`Ticket ${ticket.ticket_number} created successfully`, {
        description: "A confirmation email has been sent to you."
      });
      handleReset();
      onOpenChange(false);
    },
    onError: () => toast.error("Failed to create ticket"),
  });

  const handleSubmit = () => {
    if (!title.trim() || !description.trim() || !reporterEmail.trim()) {
      toast.error("Please fill in all required fields");
      return;
    }

    const ticketNumber = generateTicketNumber();

    createTicketMutation.mutate({
      ticket_number: ticketNumber,
      title,
      description,
      category,
      priority,
      reporter_name: reporterName || "Anonymous",
      reporter_email: reporterEmail,
      billable,
      status: "open",
    });
  };

  const handleReset = () => {
    setTitle("");
    setDescription("");
    setCategory("bug");
    setPriority("medium");
    setReporterEmail("");
    setReporterName("");
    setBillable(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Report a Bug</DialogTitle>
          <DialogDescription>
            Help us improve by reporting any issues you encounter
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div>
            <Label className="text-xs">Your Email *</Label>
            <Input
              type="email"
              placeholder="your.email@example.com"
              value={reporterEmail}
              onChange={(e) => setReporterEmail(e.target.value)}
              className="mt-1.5"
            />
          </div>

          <div>
            <Label className="text-xs">Your Name (optional)</Label>
            <Input
              placeholder="Your name"
              value={reporterName}
              onChange={(e) => setReporterName(e.target.value)}
              className="mt-1.5"
            />
          </div>

          <div>
            <Label className="text-xs">Title *</Label>
            <Input
              placeholder="Brief description of the issue"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1.5"
            />
          </div>

          <div>
            <Label className="text-xs">Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="bug">Bug</SelectItem>
                <SelectItem value="feature_request">Feature Request</SelectItem>
                <SelectItem value="documentation">Documentation</SelectItem>
                <SelectItem value="performance">Performance</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-xs">Priority</Label>
            <Select value={priority} onValueChange={setPriority}>
              <SelectTrigger className="mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-xs">Description *</Label>
            <Textarea
              placeholder="Please describe the issue in detail..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1.5 h-24"
            />
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <Checkbox
              id="billable"
              checked={billable}
              onCheckedChange={setBillable}
            />
            <Label htmlFor="billable" className="text-xs cursor-pointer font-normal">
              This is a billable ticket
            </Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={createTicketMutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {createTicketMutation.isPending ? "Submitting..." : "Submit Ticket"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}