import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";

function Field({ label, type = "text", placeholder, options, rows = 3 }) {
  const base = "border border-slate-300 rounded px-2 py-1 text-sm w-full bg-white focus:outline-none focus:border-emerald-500";
  return (
    <div className="flex flex-col gap-1">
      {label && <label className="text-xs font-medium text-slate-600">{label}</label>}
      {type === "select" ? (
        <select className={base}>
          <option value="">— Select —</option>
          {options?.map(o => <option key={o}>{o}</option>)}
        </select>
      ) : type === "textarea" ? (
        <textarea className={base} rows={rows} placeholder={placeholder} />
      ) : (
        <input type={type} className={base} placeholder={placeholder} />
      )}
    </div>
  );
}

function SectionHeading({ children }) {
  return (
    <div className="border-b border-emerald-100 pb-1 mb-1 mt-2">
      <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-700">{children}</h3>
    </div>
  );
}

function QuestionBlock({ num, question, name, options, children }) {
  return (
    <div className="space-y-2 border border-slate-200 rounded-lg p-3 bg-slate-50/40">
      <p className="text-sm font-semibold text-slate-800">{num}. {question}</p>
      {options && (
        <div className="flex flex-wrap gap-4">
          {options.map(v => (
            <label key={v} className="flex items-center gap-1.5 text-sm">
              <input type="radio" name={name} className="accent-emerald-600" /> {v}
            </label>
          ))}
        </div>
      )}
      {children}
    </div>
  );
}

export default function SupplierQualityQuestionnaire() {
  const handlePrint = () => {
    const allergens = ["Cereals containing Gluten (wheat, rye, barley, oats)", "Crustaceans", "Eggs", "Fish", "Peanuts", "Soybeans", "Milk / Dairy (incl. lactose)", "Tree Nuts (almonds, cashews, etc.)", "Celery", "Mustard", "Sesame seeds", "Sulphur dioxide / Sulphites", "Lupin", "Molluscs"];
    const foMethods = ["Metal detection", "X-ray inspection", "Optical / vision system", "Sieve / filter", "Glass & brittle plastic policy", "Magnet", "Restricted items policy", "Foreign body investigation procedure"];
    const traceCovers = ["Raw materials received", "In-process / WIP", "Finished goods", "Returned goods", "Rework", "Outsourced processing"];

    const win = window.open("", "_blank");
    win.document.write(`<!DOCTYPE html><html><head><title>Supplier Quality & Food Safety Questionnaire</title>
      <style>
        body{font-family:Arial,sans-serif;font-size:12px;color:#0f172a;margin:30px}
        h1{font-size:18px;margin-bottom:2px}
        h2{font-size:13px;color:#065f46;border-bottom:1px solid #d1fae5;padding-bottom:4px;margin-top:18px;margin-bottom:10px}
        p.sub{color:#64748b;font-size:11px;margin-bottom:20px}
        label{font-size:10px;font-weight:600;color:#475569;display:block;margin-bottom:2px;margin-top:8px}
        input[type=text],input[type=date],select,textarea{border:1px solid #cbd5e1;border-radius:4px;padding:4px 6px;width:100%;font-size:11px;box-sizing:border-box}
        .row{display:grid;gap:10px;margin-bottom:8px}.g2{grid-template-columns:1fr 1fr}.g3{grid-template-columns:1fr 1fr 1fr}
        .question{margin-bottom:14px;padding:10px;background:#f8fafc;border-radius:6px;border-left:3px solid #10b981}
        .q-text{font-size:12px;font-weight:600;color:#0f172a;margin-bottom:6px}
        .radio-row{display:flex;gap:16px;margin-bottom:6px;flex-wrap:wrap}
        .radio-row label{font-weight:normal;display:flex;align-items:center;gap:4px;font-size:11px;margin-top:0}
        .chk-grid{display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-top:4px}
        .chk-grid label{font-weight:normal;display:flex;align-items:center;gap:4px;font-size:11px;margin-top:0}
        .warn{margin-top:8px;padding:6px 8px;background:#fffbeb;border:1px solid #fde68a;border-radius:4px;font-size:10px;color:#92400e}
        .sig{display:flex;gap:20px;margin-top:20px;padding-top:12px;border-top:1px solid #e2e8f0}
        .sig-box{flex:1;border-top:1px solid #94a3b8;padding-top:4px;font-size:10px;color:#64748b;margin-top:30px}
        @media print{body{margin:15px}}
      </style>
    </head><body>
      <h1>Supplier Quality &amp; Food Safety Questionnaire</h1>
      <p class="sub">FSSC 22000 v6.0 &middot; Supplier Approval &amp; Monitoring Programme</p>

      <div class="row g3">
        <div><label>Supplier / Company Name</label><input type="text" /></div>
        <div><label>Contact Person</label><input type="text" /></div>
        <div><label>Date Completed</label><input type="date" /></div>
        <div><label>Physical Address</label><input type="text" /></div>
        <div><label>Telephone</label><input type="text" /></div>
        <div><label>Email</label><input type="text" /></div>
      </div>

      <h2>Section 1 &mdash; Quality Management System &amp; Certification</h2>
      <div class="question">
        <div class="q-text">1. Does the company follow any recognised quality system? Or is the company certified to a Global Standard or a GFSI-approved Standard?</div>
        <div class="radio-row"><label><input type="radio" name="q1" /> Yes</label><label><input type="radio" name="q1" /> No</label></div>
        <label>Please specify the standard(s) and certification body:</label>
        <input type="text" placeholder="e.g. FSSC 22000 v6.0, BRC Issue 9, ISO 22000:2018, SQF..." />
        <div class="row g3" style="margin-top:8px">
          <div><label>Certificate Number</label><input type="text" /></div>
          <div><label>Certificate Issue Date</label><input type="date" /></div>
          <div><label>Certificate Expiry Date</label><input type="date" /></div>
        </div>
        <label>Certification Body / Auditing Organisation</label><input type="text" />
        <div class="warn">&#9888; Please attach a copy of the current valid certificate to this questionnaire.</div>
      </div>

      <div class="question">
        <div class="q-text">2. Does the company handle, store, process, or pack any allergen-containing materials on your site?</div>
        <div class="radio-row"><label><input type="radio" name="q2" /> Yes</label><label><input type="radio" name="q2" /> No</label></div>
        <label>If yes, please specify the allergens present on site:</label>
        <div class="chk-grid">${allergens.map(a => `<label><input type="checkbox" /> ${a}</label>`).join("")}</div>
        <label style="margin-top:8px">How are allergens controlled and segregated on site?</label>
        <textarea rows="3"></textarea>
      </div>

      <h2>Section 2 &mdash; HACCP &amp; GMP</h2>
      <div class="question">
        <div class="q-text">3. Does the company have a HACCP / HARA System in place?</div>
        <div class="radio-row"><label><input type="radio" name="q3" /> Yes &mdash; Full HACCP plan documented and implemented</label><label><input type="radio" name="q3" /> No</label></div>
        <label>If not, please explain the Company's Product Safety System:</label>
        <textarea rows="3" placeholder="Describe the food / product safety system in place..."></textarea>
      </div>

      <div class="question">
        <div class="q-text">4. If the company is not following a HACCP or ISO programme, are Good Manufacturing Practices (GMPs) in place?</div>
        <div class="radio-row">
          <label><input type="radio" name="q4" /> Yes &mdash; Documented GMPs in place</label>
          <label><input type="radio" name="q4" /> No</label>
          <label><input type="radio" name="q4" /> N/A &mdash; HACCP / ISO system is implemented</label>
        </div>
        <label>Is the GMP Programme audited internally at least once per year?</label>
        <div class="radio-row"><label><input type="radio" name="q4b" /> Yes</label><label><input type="radio" name="q4b" /> No</label></div>
        <label>Last internal GMP audit date:</label><input type="date" />
      </div>

      <h2>Section 3 &mdash; Training &amp; Operational Controls</h2>
      <div class="question">
        <div class="q-text">5. How often is GMP / Hygiene training conducted with staff?</div>
        <div class="radio-row">
          <label><input type="radio" name="q5" /> Monthly</label>
          <label><input type="radio" name="q5" /> Quarterly</label>
          <label><input type="radio" name="q5" /> 6-Monthly</label>
          <label><input type="radio" name="q5" /> Annually</label>
          <label><input type="radio" name="q5" /> Ad hoc only</label>
        </div>
        <label>Does training include cleaning &amp; sanitation practices?</label>
        <div class="radio-row"><label><input type="radio" name="q5b" /> Yes</label><label><input type="radio" name="q5b" /> No</label></div>
        <label>Additional training notes:</label><textarea rows="2"></textarea>
      </div>

      <div class="question">
        <div class="q-text">6. Pest Control Measures</div>
        <label>Pest control programme in place?</label>
        <div class="radio-row">
          <label><input type="radio" name="q6a" /> Yes &mdash; External contractor</label>
          <label><input type="radio" name="q6a" /> Yes &mdash; In-house</label>
          <label><input type="radio" name="q6a" /> No</label>
        </div>
        <label>Inspection frequency:</label>
        <div class="radio-row">
          <label><input type="radio" name="q6b" /> Monthly</label>
          <label><input type="radio" name="q6b" /> Quarterly</label>
          <label><input type="radio" name="q6b" /> 6-Monthly</label>
          <label><input type="radio" name="q6b" /> Annually</label>
        </div>
        <label>Service provider name:</label><input type="text" />
        <label>Are pest control records maintained and available for inspection?</label>
        <div class="radio-row"><label><input type="radio" name="q6c" /> Yes</label><label><input type="radio" name="q6c" /> No</label></div>
      </div>

      <div class="question">
        <div class="q-text">7. Microbiological Testing of Products, Staff Hands and Clothing</div>
        <label>Micro testing of products conducted?</label>
        <div class="radio-row"><label><input type="radio" name="q7a" /> Yes</label><label><input type="radio" name="q7a" /> No</label><label><input type="radio" name="q7a" /> N/A</label></div>
        <label>Micro testing of staff hands and clothing?</label>
        <div class="radio-row"><label><input type="radio" name="q7b" /> Yes</label><label><input type="radio" name="q7b" /> No</label><label><input type="radio" name="q7b" /> N/A</label></div>
        <label>Testing frequency and laboratory used:</label><textarea rows="2"></textarea>
      </div>

      <div class="question">
        <div class="q-text">8. Cleaning &amp; Sanitation &mdash; including staff training on good cleaning &amp; sanitation practices</div>
        <label>Documented cleaning and sanitation programme in place?</label>
        <div class="radio-row"><label><input type="radio" name="q8a" /> Yes</label><label><input type="radio" name="q8a" /> No</label></div>
        <label>Staff trained on cleaning &amp; sanitation practices?</label>
        <div class="radio-row"><label><input type="radio" name="q8b" /> Yes</label><label><input type="radio" name="q8b" /> No</label></div>
        <label>Cleaning records maintained?</label>
        <div class="radio-row"><label><input type="radio" name="q8c" /> Yes</label><label><input type="radio" name="q8c" /> No</label></div>
        <label>Describe cleaning verification method (e.g. ATP swabs, visual inspection):</label>
        <textarea rows="2"></textarea>
      </div>

      <div class="question">
        <div class="q-text">9. Management of Non-Conforming Products</div>
        <label>Non-conforming product procedure documented?</label>
        <div class="radio-row"><label><input type="radio" name="q9a" /> Yes</label><label><input type="radio" name="q9a" /> No</label></div>
        <label>How are non-conforming products identified, segregated and dispositioned?</label>
        <textarea rows="3"></textarea>
        <label>Records of non-conformances maintained?</label>
        <div class="radio-row"><label><input type="radio" name="q9b" /> Yes</label><label><input type="radio" name="q9b" /> No</label></div>
      </div>

      <div class="question">
        <div class="q-text">10. Foreign Object Control</div>
        <label>Foreign object control measures in place?</label>
        <div class="radio-row"><label><input type="radio" name="q10a" /> Yes</label><label><input type="radio" name="q10a" /> No</label></div>
        <label>Methods used (select all applicable):</label>
        <div class="chk-grid">${foMethods.map(m => `<label><input type="checkbox" /> ${m}</label>`).join("")}</div>
        <label style="margin-top:8px">Additional notes on foreign object controls:</label>
        <textarea rows="2"></textarea>
      </div>

      <h2>Section 4 &mdash; Traceability &amp; Recall</h2>
      <div class="question">
        <div class="q-text">11. Is a Traceability System for products in place?</div>
        <div class="radio-row"><label><input type="radio" name="q11a" /> Yes</label><label><input type="radio" name="q11a" /> No</label></div>
        <label>How often is the Traceability System tested?</label>
        <div class="radio-row">
          <label><input type="radio" name="q11b" /> Monthly</label>
          <label><input type="radio" name="q11b" /> Quarterly</label>
          <label><input type="radio" name="q11b" /> 6-Monthly</label>
          <label><input type="radio" name="q11b" /> Annually</label>
          <label><input type="radio" name="q11b" /> Never tested</label>
        </div>
        <label>Date of last traceability exercise:</label><input type="date" />
        <label>Describe your traceability system:</label>
        <textarea rows="4">All raw material batches recorded per shift on Production batch records. Batch and date info recorded on reels. Batch information and reel numbers recorded on COC attached to all delivery notes.</textarea>
        <label>Traceability covers (select all that apply):</label>
        <div class="chk-grid">${traceCovers.map(t => `<label><input type="checkbox" /> ${t}</label>`).join("")}</div>
      </div>

      <div class="question">
        <div class="q-text">12. Does a Product Recall / Withdrawal procedure exist for all products?</div>
        <div class="radio-row">
          <label><input type="radio" name="q12a" /> Yes &mdash; documented and tested</label>
          <label><input type="radio" name="q12a" /> Yes &mdash; documented but not yet tested</label>
          <label><input type="radio" name="q12a" /> No</label>
        </div>
        <label>Date of last mock recall exercise:</label><input type="date" />
        <label>Recall Co-ordinator (name &amp; contact):</label><input type="text" />
        <label>Additional notes:</label><textarea rows="2"></textarea>
      </div>

      <div class="sig">
        <div><div class="sig-box">Completed By (Name &amp; Title)</div></div>
        <div><div class="sig-box">Signature</div></div>
        <div><div class="sig-box">Date</div></div>
      </div>
      <p style="font-size:10px;color:#94a3b8;margin-top:20px;text-align:center;">Supplier Quality &amp; Food Safety Questionnaire &middot; FSSC 22000 v6.0</p>
      <script>window.onload=function(){window.print()}</script>
    </body></html>`);
    win.document.close();
  };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3 flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-sm font-semibold">Supplier Quality & Food Safety Questionnaire</CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">FSSC 22000 v6.0 Supplier Approval Programme — Printable PDF</p>
        </div>
        <Button size="sm" variant="outline" onClick={handlePrint} className="gap-1.5 shrink-0">
          <Printer className="w-3.5 h-3.5" /> Print / PDF
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <Field label="Supplier / Company Name" placeholder="Legal trading name" />
            <Field label="Contact Person" placeholder="Name and title" />
            <Field label="Date Completed" type="date" />
            <Field label="Physical Address" placeholder="Full address" />
            <Field label="Telephone" placeholder="Phone number" />
            <Field label="Email" placeholder="Email address" />
          </div>

          <SectionHeading>Section 1 — Quality Management System & Certification</SectionHeading>

          <QuestionBlock num="1" question="Does the company follow any recognised quality system? Or is the company certified to a Global Standard or a GFSI-approved Standard?" name="q1" options={["Yes", "No"]}>
            <Field label="Please specify standard(s) and certification body:" placeholder="e.g. FSSC 22000 v6.0, BRC Issue 9, ISO 22000:2018..." />
            <div className="grid grid-cols-3 gap-3">
              <Field label="Certificate Number" placeholder="Cert ref" />
              <Field label="Certificate Issue Date" type="date" />
              <Field label="Certificate Expiry Date" type="date" />
            </div>
            <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded text-xs text-amber-800">⚠ Please attach a copy of the current valid certificate.</div>
          </QuestionBlock>

          <QuestionBlock num="2" question="Does the company handle, store, process, or pack any allergen-containing materials on your site?" name="q2" options={["Yes", "No"]}>
            <Field label="If yes, specify allergens and controls in place:" type="textarea" rows={2} placeholder="e.g. Gluten, nuts — segregated storage, dedicated equipment, cleaning validation..." />
          </QuestionBlock>

          <SectionHeading>Section 2 — HACCP & GMP</SectionHeading>

          <QuestionBlock num="3" question="Does the company have a HACCP / HARA System in place?" name="q3" options={["Yes — Full HACCP plan documented and implemented", "No"]}>
            <Field label="If not, please explain the Company's Product Safety System:" type="textarea" rows={2} placeholder="Describe product safety controls..." />
          </QuestionBlock>

          <QuestionBlock num="4" question="If not following HACCP/ISO, are Good Manufacturing Practices (GMPs) in place?" name="q4" options={["Yes — Documented GMPs in place", "No", "N/A — HACCP/ISO implemented"]}>
            <p className="text-xs font-semibold text-slate-700 mt-2">Is the GMP Programme audited internally at least once per year?</p>
            <div className="flex gap-4">
              {["Yes", "No"].map(v => <label key={v} className="flex items-center gap-1.5 text-sm"><input type="radio" name="q4b" className="accent-emerald-600" /> {v}</label>)}
            </div>
            <Field label="Last internal GMP audit date:" type="date" />
          </QuestionBlock>

          <SectionHeading>Section 3 — Training & Operational Controls</SectionHeading>

          <QuestionBlock num="5" question="How often is GMP/hygiene training done with staff?" name="q5" options={["Monthly", "Quarterly", "6-Monthly", "Annually", "Ad hoc only"]}>
            <Field label="Additional training notes (includes cleaning & sanitation training?):" type="textarea" rows={2} placeholder="Describe training content and frequency..." />
          </QuestionBlock>

          <QuestionBlock num="6" question="Pest control measures — describe programme, provider, frequency and record-keeping:" name="q6" options={["Yes — External contractor", "Yes — In-house", "No"]}>
            <Field label="Service provider / frequency / records available:" type="textarea" rows={2} placeholder="e.g. Rentokil — monthly inspections — records maintained on site..." />
          </QuestionBlock>

          <QuestionBlock num="7" question="Micro testing of products, staff hands and clothing:" name="q7" options={["Yes — products and staff", "Yes — products only", "No"]}>
            <Field label="Testing frequency and laboratory used:" type="textarea" rows={2} placeholder="Scope, frequency, accredited lab name..." />
          </QuestionBlock>

          <QuestionBlock num="8" question="Cleaning and sanitation — describe programme and training of staff on good cleaning & sanitation practices:" name="q8" options={["Yes — documented programme and training", "Partial", "No"]}>
            <Field label="Cleaning verification method:" type="textarea" rows={2} placeholder="e.g. ATP swabs after each clean, visual inspection, supervisor sign-off..." />
          </QuestionBlock>

          <QuestionBlock num="9" question="Management of non-conforming products — describe procedure:" name="q9" options={["Documented procedure in place", "Informal process only", "No procedure"]}>
            <Field label="Describe how non-conforming products are identified, segregated and dispositioned:" type="textarea" rows={2} placeholder="..." />
          </QuestionBlock>

          <QuestionBlock num="10" question="Foreign object control — describe measures in place:" name="q10" options={["Yes — formal programme", "Partial measures only", "No"]}>
            <Field label="Methods used (metal detection, X-ray, glass policy, magnets, etc.):" type="textarea" rows={2} placeholder="Describe all foreign body prevention measures..." />
          </QuestionBlock>

          <SectionHeading>Section 4 — Traceability & Recall</SectionHeading>

          <QuestionBlock num="11" question="Is a traceability system for products in place?" name="q11" options={["Yes", "No"]}>
            <div className="grid grid-cols-2 gap-3">
              <Field label="How often is the Traceability System tested?" type="select" options={["Monthly", "Quarterly", "6-Monthly", "Annually", "Never tested"]} />
              <Field label="Date of last traceability exercise:" type="date" />
            </div>
            <Field label="Describe your traceability system:" type="textarea" rows={3} placeholder="All raw material batches recorded per shift on Production batch records. Batch and date info recorded on reels. Batch information and reel numbers recorded on COC attached to all delivery notes." />
          </QuestionBlock>

          <QuestionBlock num="12" question="Does a Product Recall / Withdrawal procedure exist for all products?" name="q12" options={["Yes — documented and tested", "Yes — documented, not yet tested", "No"]}>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Date of last mock recall exercise:" type="date" />
              <Field label="Recall Co-ordinator (name & contact):" placeholder="Name and phone/email" />
            </div>
          </QuestionBlock>

          <div className="flex gap-6 pt-2 border-t border-slate-100">
            <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Completed By (Name & Title)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
            <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Reviewed By (QA Manager)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}