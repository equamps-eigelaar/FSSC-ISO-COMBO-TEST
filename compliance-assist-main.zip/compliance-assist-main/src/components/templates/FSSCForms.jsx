import React, { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Printer, ClipboardList, Truck, Users, CheckSquare, AlertTriangle, BarChart3, FileText, Lock } from "lucide-react";
import SupplierQualityQuestionnaire from "./SupplierQualityQuestionnaire";
import SignFormDialog from "@/components/signatures/SignFormDialog";

// ─── Shared Helpers ───────────────────────────────────────────────────────────

function Field({ label, type = "text", placeholder, width = "full", options, rows = 3 }) {
  const base = "border border-slate-300 rounded px-2 py-1 text-sm w-full bg-white focus:outline-none focus:border-emerald-500";
  const w = width === "half" ? "w-1/2" : width === "third" ? "w-1/3" : "w-full";
  return (
    <div className={`flex flex-col gap-1 ${w}`}>
      <label className="text-xs font-medium text-slate-600">{label}</label>
      {type === "select" ? (
        <select className={base}>
          <option value="">— Select —</option>
          {options?.map(o => <option key={o}>{o}</option>)}
        </select>
      ) : type === "textarea" ? (
        <textarea className={base} rows={rows} placeholder={placeholder} />
      ) : type === "checkbox" ? (
        <div className="flex items-center gap-2 mt-1">
          <input type="checkbox" className="w-4 h-4 accent-emerald-600" />
          <span className="text-sm text-slate-600">{placeholder}</span>
        </div>
      ) : (
        <input type={type} className={base} placeholder={placeholder} />
      )}
    </div>
  );
}

function Row({ children, cols = 2 }) {
  return (
    <div className={`grid grid-cols-${cols} gap-3`}>
      {children}
    </div>
  );
}

function SectionHeading({ children }) {
  return (
    <div className="col-span-full border-b border-emerald-100 pb-1 mb-1">
      <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-700">{children}</h3>
    </div>
  );
}

function FormWrapper({ title, subtitle, onPrint, children, onSign }) {
  const ref = useRef();
  const handlePrint = () => {
    const content = ref.current.innerHTML;
    const win = window.open("", "_blank");
    win.document.write(`<!DOCTYPE html><html><head><title>${title}</title>
      <style>
        body{font-family:Arial,sans-serif;font-size:12px;color:#0f172a;margin:24px}
        h1{font-size:16px;margin-bottom:4px}p.sub{color:#64748b;font-size:11px;margin-bottom:16px}
        label{font-size:10px;font-weight:600;color:#475569;display:block;margin-bottom:2px}
        input,select,textarea{border:1px solid #cbd5e1;border-radius:4px;padding:4px 6px;width:100%;font-size:11px;box-sizing:border-box}
        .grid{display:grid;gap:10px}.g2{grid-template-columns:1fr 1fr}.g3{grid-template-columns:1fr 1fr 1fr}
        .section-head{border-bottom:1px solid #d1fae5;padding-bottom:3px;margin-bottom:6px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#065f46}
        .field{margin-bottom:8px}.row{margin-bottom:10px}
        table{width:100%;border-collapse:collapse;margin-top:8px}
        th{background:#f8fafc;font-size:10px;padding:4px 6px;text-align:left;border:1px solid #e2e8f0}
        td{font-size:11px;padding:4px 6px;border:1px solid #e2e8f0;height:22px}
        .sig{display:flex;gap:20px;margin-top:12px}
        .sig-box{flex:1;border-top:1px solid #94a3b8;padding-top:4px;font-size:10px;color:#64748b}
        @media print{body{margin:10px}.no-print{display:none}}
      </style>
    </head><body>
      <h1>${title}</h1><p class="sub">${subtitle || "FSSC 22000 v6.0"}</p>
      ${content}
    <script>window.onload=function(){window.print()}</script></body></html>`);
    win.document.close();
  };

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3 flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-sm font-semibold">{title}</CardTitle>
          {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
        <div className="flex gap-2 shrink-0">
          <Button size="sm" variant="outline" onClick={handlePrint} className="gap-1.5">
            <Printer className="w-3.5 h-3.5" /> Print / PDF
          </Button>
          {onSign && (
            <Button size="sm" variant="outline" onClick={onSign} className="gap-1.5 border-emerald-300 text-emerald-700 hover:bg-emerald-50">
              <Lock className="w-3.5 h-3.5" /> Sign & Lock
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div ref={ref} className="space-y-4">
          {children}
        </div>
      </CardContent>
    </Card>
  );
}

// ─── FOOD SAFETY FORMS ────────────────────────────────────────────────────────

function CCPMonitoringForm({ onSign }) {
  return (
    <FormWrapper title="CCP Monitoring Record" subtitle="HACCP Critical Control Point — FSSC 22000 Cl. 8.5.4" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="CCP Number" placeholder="e.g. CCP-01" />
        <Field label="CCP Description" placeholder="e.g. Metal Detection" />
        <Field label="Date" type="date" />
        <Field label="Product / Line" placeholder="Product name or line" />
        <Field label="Shift" type="select" options={["Morning (06:00–14:00)", "Afternoon (14:00–22:00)", "Night (22:00–06:00)"]} />
        <Field label="Operator Name" placeholder="Full name" />
      </div>

      <div>
        <SectionHeading>Critical Limits</SectionHeading>
        <div className="grid grid-cols-3 gap-3">
          <Field label="Parameter" placeholder="e.g. Fe sphere" />
          <Field label="Critical Limit" placeholder="e.g. ≤ 1.5 mm Fe" />
          <Field label="Monitoring Method" placeholder="e.g. Test piece" />
        </div>
      </div>

      <div>
        <SectionHeading>Monitoring Log</SectionHeading>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50">
                {["Time", "Product Batch", "Fe Result (mm)", "Non-Fe Result (mm)", "SS Result (mm)", "Within Limit?", "Operator Initials"].map(h => (
                  <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: 8 }).map((_, i) => (
                <tr key={i}>
                  {Array.from({ length: 7 }).map((_, j) => (
                    <td key={j} className="border border-slate-200 px-1 py-0.5">
                      <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <SectionHeading>Corrective Action (if deviation)</SectionHeading>
          <div className="space-y-2">
            <Field label="Deviation Noted" type="textarea" rows={2} placeholder="Describe the deviation..." />
            <Field label="Corrective Action Taken" type="textarea" rows={2} placeholder="Immediate action taken..." />
            <Field label="Product Disposition" type="select" options={["Released", "Reworked", "Held — Pending Review", "Destroyed"]} />
          </div>
        </div>
        <div>
          <SectionHeading>Verification</SectionHeading>
          <div className="space-y-2">
            <Field label="Verified By" placeholder="Supervisor / QA name" />
            <Field label="Verification Date" type="date" />
            <Field label="Verification Notes" type="textarea" rows={2} placeholder="Notes..." />
          </div>
        </div>
      </div>

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Operator Signature</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Supervisor Signature</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">QA Approval</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function PRPCheckForm({ onSign }) {
  const prpItems = [
    "Establishment layout prevents cross-contamination",
    "Utilities (air, water, energy) are controlled and tested",
    "Equipment maintenance schedule is current",
    "Pest control baits/traps inspected and logged",
    "Personnel hygiene practices observed & compliant",
    "Cleaning & sanitation schedule completed",
    "Allergen controls are in place and documented",
    "Foreign body prevention measures checked",
    "Calibrated instruments available & in date",
    "Temperature-sensitive storage areas within spec",
    "Signage and PPE requirements displayed & enforced",
    "Waste disposal conducted correctly",
  ];

  return (
    <FormWrapper title="PRP Verification Checklist" subtitle="Prerequisite Programme Check — FSSC 22000 / ISO/TS 22002-4" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Date" type="date" />
        <Field label="Auditor / Inspector" placeholder="Name" />
        <Field label="Area / Zone" type="select" options={["Production Floor", "Packaging Area", "Warehouse / Despatch", "Staff Amenities", "Maintenance Workshop", "Outdoor / Perimeter"]} />
      </div>

      <div>
        <SectionHeading>PRP Inspection Items</SectionHeading>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50">
                <th className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600 w-8">#</th>
                <th className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">PRP Requirement</th>
                <th className="border border-slate-200 px-2 py-1.5 text-center font-semibold text-slate-600 w-20">Compliant</th>
                <th className="border border-slate-200 px-2 py-1.5 text-center font-semibold text-slate-600 w-20">Non-Compliant</th>
                <th className="border border-slate-200 px-2 py-1.5 text-center font-semibold text-slate-600 w-20">N/A</th>
                <th className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">Comments</th>
              </tr>
            </thead>
            <tbody>
              {prpItems.map((item, i) => (
                <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                  <td className="border border-slate-200 px-2 py-1.5 text-slate-400">{i + 1}</td>
                  <td className="border border-slate-200 px-2 py-1.5">{item}</td>
                  {["C", "NC", "NA"].map(v => (
                    <td key={v} className="border border-slate-200 px-2 py-1 text-center">
                      <input type="checkbox" className="w-4 h-4 accent-emerald-600" />
                    </td>
                  ))}
                  <td className="border border-slate-200 px-1 py-0.5">
                    <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Non-Conformances Raised" type="textarea" rows={3} placeholder="Detail any NCRs..." />
        <Field label="Immediate Actions Taken" type="textarea" rows={3} placeholder="Actions..." />
      </div>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Overall Rating" type="select" options={["Satisfactory", "Minor Issues — Action Required", "Major Issues — Immediate Action"]} />
        <Field label="Next Scheduled Check" type="date" />
        <Field label="Signature" placeholder="Inspector signature" />
      </div>
    </FormWrapper>
  );
}

function AllergenControlForm({ onSign }) {
  return (
    <FormWrapper title="Allergen Control Check" subtitle="Allergen Management — ISO/TS 22002-4 Cl. 12" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Date" type="date" />
        <Field label="Shift" type="select" options={["Morning", "Afternoon", "Night"]} />
        <Field label="Completed By" placeholder="Name" />
        <Field label="Production Line / Area" placeholder="Line / area description" />
        <Field label="Products Manufactured Today" placeholder="List products" />
        <Field label="Known Allergens Present On-Site" placeholder="e.g. Nuts, Gluten, Dairy" />
      </div>

      <SectionHeading>Pre-Production Allergen Check</SectionHeading>
      {[
        "Line clearance completed from previous run",
        "All allergen-containing raw materials correctly labelled and segregated",
        "Allergen risk assessment for today's schedule reviewed",
        "Cleaning validated before allergen-free or low-allergen run",
        "Rework allergen status verified before use",
        "Staff briefed on allergen risks for today's production",
      ].map((item, i) => (
        <div key={i} className="flex items-center gap-3 py-1.5 border-b border-slate-100">
          <span className="text-xs text-slate-500 w-4">{i + 1}</span>
          <span className="text-sm flex-1">{item}</span>
          <div className="flex gap-3">
            {["Yes", "No", "N/A"].map(v => (
              <label key={v} className="flex items-center gap-1 text-xs text-slate-500">
                <input type="radio" name={`allergen-${i}`} className="accent-emerald-600" /> {v}
              </label>
            ))}
          </div>
        </div>
      ))}

      <div className="grid grid-cols-2 gap-3 mt-2">
        <Field label="Swab / Rinse Test Results (if applicable)" placeholder="Pass / Fail / Not done" />
        <Field label="Corrective Actions if 'No' Noted" type="textarea" rows={2} placeholder="Describe actions..." />
      </div>
      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Operator Signature</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Supervisor Verification</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function CleaningRecordForm({ onSign }) {
  return (
    <FormWrapper title="Cleaning & Sanitation Record" subtitle="Sanitation Control — ISO/TS 22002-4 Cl. 11" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Date" type="date" />
        <Field label="Area / Equipment" placeholder="e.g. Slitter Line 2" />
        <Field label="Cleaning Type" type="select" options={["Scheduled Routine Clean", "Deep Clean", "Post-Production Clean", "Allergen Changeover Clean", "Corrective Clean"]} />
        <Field label="Cleaning Method" type="select" options={["Dry Clean", "Wet Clean — Low Pressure", "Wet Clean — High Pressure", "Chemical Sanitisation", "CIP (Clean In Place)"]} />
        <Field label="Chemicals Used (Name & Concentration)" placeholder="e.g. Chemex 200 @ 2%" />
        <Field label="Contact Time (minutes)" placeholder="e.g. 10" type="number" />
        <Field label="Water Temperature (°C)" placeholder="e.g. 65" type="number" />
        <Field label="Cleaned By" placeholder="Name" />
        <Field label="Start Time" type="time" />
        <Field label="End Time" type="time" />
        <Field label="PPE Used" placeholder="e.g. Gloves, Apron, Goggles" />
        <Field label="Equipment / Tools Used" placeholder="e.g. Mop, Squeegee, Brush" />
      </div>

      <SectionHeading>Post-Clean Verification</SectionHeading>
      {[
        "All food contact surfaces visually clean — no residue",
        "No chemical residue detected",
        "Equipment reassembled correctly",
        "Drains clear and odour-free",
        "Area dry and ready for production",
        "Cleaning chemicals stored and secured",
      ].map((item, i) => (
        <div key={i} className="flex items-center gap-3 py-1 border-b border-slate-100">
          <span className="text-xs text-slate-500 w-4">{i + 1}</span>
          <span className="text-sm flex-1">{item}</span>
          <div className="flex gap-3">
            {["Pass", "Fail", "N/A"].map(v => (
              <label key={v} className="flex items-center gap-1 text-xs text-slate-500">
                <input type="radio" name={`clean-${i}`} className="accent-emerald-600" /> {v}
              </label>
            ))}
          </div>
        </div>
      ))}

      <div className="grid grid-cols-2 gap-3 mt-2">
        <Field label="Swab / ATP Test Result" placeholder="e.g. ATP 25 RLU — Pass" />
        <Field label="Corrective Action (if Failed)" type="textarea" rows={2} placeholder="Re-clean details..." />
      </div>
      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Cleaning Operator</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Verified By (Supervisor/QA)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

// ─── SUPPLIER & MATERIAL FORMS ────────────────────────────────────────────────

function SupplierApprovalForm({ onSign }) {
  return (
    <FormWrapper title="Supplier Approval Form" subtitle="Supplier Management — FSSC 22000 Cl. 7.1.6 / ISO/TS 22002-4" onSign={onSign}>
      <SectionHeading>Supplier Details</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Supplier Company Name" placeholder="Legal trading name" />
        <Field label="Contact Person" placeholder="Name" />
        <Field label="Phone / Email" placeholder="Contact details" />
        <Field label="Physical Address" placeholder="Address" />
        <Field label="Country of Origin" placeholder="Country" />
        <Field label="Date of Assessment" type="date" />
        <Field label="Materials / Services Supplied" placeholder="List products or services" />
        <Field label="Annual Spend Estimate (ZAR)" type="number" placeholder="e.g. 500000" />
        <Field label="Supplier Category" type="select" options={["Raw Material — Food Contact", "Raw Material — Non-Food Contact", "Packaging Material", "Chemical / Cleaning", "Service Provider", "Utility Provider"]} />
      </div>

      <SectionHeading>Certification & Compliance</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Certification / Standard", "Certificate Number", "Issuing Body", "Expiry Date", "Verified?"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {["FSSC 22000 / BRC / SQF", "ISO 9001", "ISO 14001", "HACCP Certification", "Other"].map((cert, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                <td className="border border-slate-200 px-2 py-1.5 text-slate-600 font-medium">{cert}</td>
                {[1, 2, 3].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type={j === 3 ? "date" : "text"} className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                <td className="border border-slate-200 px-2 py-1 text-center">
                  <input type="checkbox" className="w-4 h-4 accent-emerald-600" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionHeading>Risk Assessment</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Supplier Risk Level" type="select" options={["Low", "Medium", "High", "Critical"]} />
        <Field label="Previous Non-Conformances" type="select" options={["None", "Minor (resolved)", "Major (resolved)", "Ongoing issues"]} />
        <Field label="On-Site Audit Required?" type="select" options={["Yes — Schedule Audit", "No — Desk-top Review Sufficient", "Waived — Certified Supplier"]} />
      </div>
      <Field label="Assessment Notes / Rationale" type="textarea" rows={3} placeholder="Summarise the basis for approval or rejection..." />

      <SectionHeading>Decision</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Approval Status" type="select" options={["Approved", "Conditionally Approved", "Rejected", "Pending Further Information"]} />
        <Field label="Valid Until" type="date" />
        <Field label="Next Review Date" type="date" />
      </div>
      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Completed By (QA/Procurement)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Approved By (Management)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function RawMaterialReceivingForm({ onSign }) {
  return (
    <FormWrapper title="Raw Material Receiving Inspection" subtitle="Incoming Material Control — FSSC 22000 Cl. 8.5.1.4" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Date Received" type="date" />
        <Field label="Time Received" type="time" />
        <Field label="Received By" placeholder="Name" />
        <Field label="Purchase Order Number" placeholder="PO number" />
        <Field label="Supplier Name" placeholder="Supplier" />
        <Field label="Delivery Vehicle / Ref" placeholder="Vehicle reg / waybill" />
        <Field label="Material Name / Description" placeholder="Material" />
        <Field label="Material Code / SKU" placeholder="Code" />
        <Field label="Batch / Lot Number" placeholder="Batch" />
        <Field label="Quantity Received" placeholder="e.g. 500 kg" />
        <Field label="Unit of Measure" type="select" options={["kg", "L", "units", "rolls", "pallets", "boxes"]} />
        <Field label="Expiry / Best Before Date" type="date" />
      </div>

      <SectionHeading>Transport & Delivery Condition</SectionHeading>
      {[
        "Vehicle clean, dry and free from odours/pests",
        "Vehicle temperature within specification (if applicable)",
        "Load secure — no shifting or damage observed",
        "Seals intact on delivery vehicle",
      ].map((item, i) => (
        <div key={i} className="flex items-center gap-3 py-1 border-b border-slate-100">
          <span className="text-xs text-slate-500 w-4">{i + 1}</span>
          <span className="text-sm flex-1">{item}</span>
          <div className="flex gap-3">
            {["Pass", "Fail", "N/A"].map(v => (
              <label key={v} className="flex items-center gap-1 text-xs text-slate-500">
                <input type="radio" name={`transport-${i}`} className="accent-emerald-600" /> {v}
              </label>
            ))}
          </div>
        </div>
      ))}

      <SectionHeading>Material / Packaging Inspection</SectionHeading>
      {[
        "Packaging intact — no damage, tears or contamination",
        "Labels correct and legible (material name, batch, expiry)",
        "Certificates of Analysis (CoA) received and match batch",
        "Allergen declaration / Food Safety Data Sheet received",
        "Colour, odour and appearance within specification",
        "No evidence of pest activity or infestation",
      ].map((item, i) => (
        <div key={i} className="flex items-center gap-3 py-1 border-b border-slate-100">
          <span className="text-xs text-slate-500 w-4">{i + 1}</span>
          <span className="text-sm flex-1">{item}</span>
          <div className="flex gap-3">
            {["Pass", "Fail", "N/A"].map(v => (
              <label key={v} className="flex items-center gap-1 text-xs text-slate-500">
                <input type="radio" name={`material-${i}`} className="accent-emerald-600" /> {v}
              </label>
            ))}
          </div>
        </div>
      ))}

      <div className="grid grid-cols-2 gap-3">
        <Field label="Temperature at Receipt (°C)" type="number" placeholder="If applicable" />
        <Field label="Storage Location Assigned" placeholder="e.g. Rack B-3, Cold Store 1" />
        <Field label="Disposition Decision" type="select" options={["Accepted — Released to Production", "Accepted — Quarantine Pending CoA", "Rejected — Return to Supplier", "Rejected — Destroy"]} />
        <Field label="Non-Conformance Reference (if rejected)" placeholder="NCR number" />
      </div>
      <Field label="Remarks / Corrective Actions" type="textarea" rows={2} placeholder="Any additional notes..." />

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Receiving Inspector</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">QA Verification</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function BatchReleaseForm({ onSign }) {
  return (
    <FormWrapper title="Batch Release / Disposition Record" subtitle="Product Release — FSSC 22000 Cl. 8.9.4" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Product Name" placeholder="Finished product" />
        <Field label="Batch / Lot Number" placeholder="Batch number" />
        <Field label="Production Date" type="date" />
        <Field label="Production Line" placeholder="Line / machine" />
        <Field label="Batch Quantity (units / kg / m)" placeholder="e.g. 2500 m" />
        <Field label="Customer / Despatch Order" placeholder="Customer or order ref" />
      </div>

      <SectionHeading>Quality Checks</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Check", "Specification", "Actual Result", "Pass / Fail"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              ["Film thickness / gauge", "Per spec sheet", "", ""],
              ["Print quality / register", "Within tolerance", "", ""],
              ["Seal integrity / bond strength", "Per spec", "", ""],
              ["Metal detection clearance", "CCP pass", "", ""],
              ["Dimensional check (width/length)", "±2% tolerance", "", ""],
              ["Visual appearance / defects", "No visible defects", "", ""],
              ["Labelling accuracy", "Correct product label", "", ""],
              ["Packaging integrity", "No damage/leaks", "", ""],
            ].map(([check, spec], i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                <td className="border border-slate-200 px-2 py-1.5 font-medium">{check}</td>
                <td className="border border-slate-200 px-2 py-1.5 text-slate-500">{spec}</td>
                <td className="border border-slate-200 px-1 py-0.5"><input type="text" className="w-full text-xs border-0 outline-none bg-transparent" /></td>
                <td className="border border-slate-200 px-2 py-1">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Pass</option>
                    <option>Fail</option>
                    <option>N/A</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Hold / Quarantine Reason (if applicable)" type="textarea" rows={2} placeholder="Reason for hold..." />
        <Field label="Corrective Actions Taken" type="textarea" rows={2} placeholder="Actions..." />
        <Field label="Final Disposition" type="select" options={["Released — Approved for Despatch", "Released — With Concession (approved)", "On Hold — Pending Investigation", "Rejected — Rework", "Rejected — Destroy", "Returned to Production"]} />
        <Field label="Concession Reference (if applicable)" placeholder="Concession number" />
      </div>

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">QA Inspector</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Production Supervisor</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">QA Manager Release</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

// ─── DOCUMENTATION & RECORDS FORMS ───────────────────────────────────────────

function FoodSafetyStatementForm({ onSign }) {
  return (
    <FormWrapper title="Food Safety Policy Statement" subtitle="Food Safety Policy — FSSC 22000 Cl. 5.2" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Organisation Name" placeholder="Company name" />
        <Field label="Site / Facility" placeholder="Site address" />
        <Field label="Document Reference" placeholder="e.g. FSP-001" />
        <Field label="Version" placeholder="e.g. Rev 3" />
        <Field label="Issue Date" type="date" />
        <Field label="Review Date" type="date" />
      </div>

      <SectionHeading>Policy Statement</SectionHeading>
      <Field
        label="Food Safety Policy Statement (draft / record existing policy)"
        type="textarea"
        rows={6}
        placeholder="e.g. We are committed to manufacturing packaging materials that are safe and fit for their intended food contact purpose. We achieve this by maintaining and continually improving our Food Safety Management System in compliance with FSSC 22000 v6.0..."
      />

      <SectionHeading>Policy Commitments</SectionHeading>
      {[
        "Comply with all applicable food safety legislation and regulatory requirements",
        "Meet or exceed customer and contractual food safety requirements",
        "Identify and control all food safety hazards relevant to flexible packaging manufacture",
        "Implement and maintain effective PRPs, HACCP plan and operational controls",
        "Provide adequate resources, training and a culture of food safety awareness",
        "Continually improve the effectiveness of the Food Safety Management System",
        "Communicate food safety requirements to all employees and relevant external parties",
        "Conduct regular management reviews and internal audits to verify FSMS effectiveness",
      ].map((item, i) => (
        <div key={i} className="flex items-center gap-3 py-1.5 border-b border-slate-100">
          <input type="checkbox" className="w-4 h-4 accent-emerald-600 shrink-0" />
          <span className="text-sm">{item}</span>
        </div>
      ))}

      <SectionHeading>Food Safety Objectives (this review period)</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Objective", "Target / KPI", "Responsible", "Target Date", "Status"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>
                {[0, 1, 2, 3].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type={j === 3 ? "date" : "text"} className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>On Track</option>
                    <option>Behind</option>
                    <option>Achieved</option>
                    <option>Not Started</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Field label="Distribution List (who has received this policy)" type="textarea" rows={2} placeholder="All staff, notice boards, induction packs, supplier portal..." />

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Authorised By (MD / CEO)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Food Safety Team Leader</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Quality Manager</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function HACCPStudyForm({ onSign }) {
  return (
    <FormWrapper title="HACCP Study Record" subtitle="Hazard Analysis & HACCP Plan — FSSC 22000 Cl. 8.5 / Codex Alimentarius" onSign={onSign}>
      <SectionHeading>Study Details</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Product / Product Group" placeholder="e.g. Flexible laminate pouches" />
        <Field label="Study Reference" placeholder="e.g. HACCP-2026-001" />
        <Field label="Study Date" type="date" />
        <Field label="Food Safety Team Members" placeholder="Names and roles" />
        <Field label="Scope of Study" placeholder="e.g. Gravure printing, lamination, slitting" />
        <Field label="Review Date" type="date" />
      </div>

      <SectionHeading>Product Description</SectionHeading>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Product Name / Description" placeholder="Full product description" />
        <Field label="Intended Use & Consumer" placeholder="e.g. Primary food packaging — general population" />
        <Field label="Process Steps Included" type="textarea" rows={2} placeholder="e.g. Receiving → Printing → Lamination → Slitting → Despatch" />
        <Field label="Ingredients / Raw Materials" type="textarea" rows={2} placeholder="Substrates, inks, adhesives, solvents..." />
      </div>

      <SectionHeading>Hazard Analysis Table</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Process Step", "Hazard Type", "Hazard Description", "Likelihood (1-5)", "Severity (1-5)", "Risk Score", "Significant?", "Control Measure"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 10 }).map((_, i) => (
              <tr key={i}>
                {[0, 1, 2].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                {[3, 4, 5].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5 w-12">
                    <input type="number" min="1" max="5" className="w-full text-xs border-0 outline-none bg-transparent text-center" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5 w-16">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Yes</option>
                    <option>No</option>
                  </select>
                </td>
                <td className="border border-slate-200 px-1 py-0.5">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionHeading>CCP / OPRP Determination (Decision Tree Summary)</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Ref #", "Process Step", "Hazard", "CCP or OPRP?", "Critical Limit / Action Limit", "Monitoring Method", "Corrective Action"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>
                {[0, 1, 2].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5 w-24">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>CCP</option>
                    <option>OPRP</option>
                    <option>PRP only</option>
                  </select>
                </td>
                {[3, 4, 5].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Field label="Validation Statement (confirm controls are effective)" type="textarea" rows={2} placeholder="Evidence that control measures achieve their intended purpose..." />

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Food Safety Team Leader</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Team Member</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Management Approval</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function PestControlRecordForm({ onSign }) {
  const pestTypes = ["Rodent (mice)", "Rodent (rats)", "Crawling insects", "Flying insects", "Birds", "Other"];
  return (
    <FormWrapper title="Pest Control Inspection Record" subtitle="Pest Control — ISO/TS 22002-4 Cl. 9" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Inspection Date" type="date" />
        <Field label="Inspection Type" type="select" options={["Routine Monthly Inspection", "Follow-up Inspection", "Reactive / Complaint Inspection", "Annual Full Survey"]} />
        <Field label="Service Provider / Inspector" placeholder="Company or name" />
        <Field label="Contract Reference" placeholder="Pest control contract number" />
        <Field label="Areas Inspected" placeholder="e.g. All internal areas, perimeter" />
        <Field label="Weather Conditions" placeholder="e.g. Dry, 24°C" />
      </div>

      <SectionHeading>Trap / Bait Station Log</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Station #", "Location", "Type", "Activity Found", "Pest Type", "Bait Consumed?", "Action Taken", "Refilled/Replaced?"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 10 }).map((_, i) => (
              <tr key={i}>
                <td className="border border-slate-200 px-1 py-0.5 w-10">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" placeholder={`S${i + 1}`} />
                </td>
                <td className="border border-slate-200 px-1 py-0.5">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
                <td className="border border-slate-200 px-1 py-0.5 w-24">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Rodent bait box</option>
                    <option>Glue board</option>
                    <option>Insect light trap</option>
                    <option>Pheromone trap</option>
                    <option>Snap trap</option>
                  </select>
                </td>
                {[0, 1].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5 w-16">
                    <select className="text-xs border-0 outline-none bg-transparent w-full">
                      <option value="">—</option>
                      <option>Yes</option>
                      <option>No</option>
                    </select>
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5 w-20">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    {pestTypes.map(p => <option key={p}>{p}</option>)}
                  </select>
                </td>
                <td className="border border-slate-200 px-1 py-0.5">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
                <td className="border border-slate-200 px-1 py-0.5 w-16">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Yes</option>
                    <option>No</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionHeading>Overall Infestation Assessment</SectionHeading>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Overall Pest Pressure Level" type="select" options={["None — No activity detected", "Low — Minor activity, monitoring ongoing", "Medium — Active infestation, treatment required", "High — Severe infestation, immediate action"]} />
        <Field label="Treatment Applied (chemical/method)" placeholder="e.g. Rodenticide bait replenished, insecticide applied" />
        <Field label="Active Ingredients Used" placeholder="Chemical name & concentration" />
        <Field label="MSDS / Product Label Available?" type="select" options={["Yes — on file", "No — obtain from contractor"]} />
        <Field label="Areas Requiring Follow-Up" type="textarea" rows={2} placeholder="Specific areas of concern..." />
        <Field label="Recommended Corrective Actions" type="textarea" rows={2} placeholder="Actions for site management..." />
      </div>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Re-inspection Required?" type="select" options={["No — next routine visit", "Yes — within 2 weeks", "Yes — within 1 month"]} />
        <Field label="Next Scheduled Visit" type="date" />
        <Field label="Certificate of Service Issued?" type="select" options={["Yes", "No — pending"]} />
      </div>

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Pest Control Technician</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Site Representative</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function RetentionSampleTestingForm({ onSign }) {
  return (
    <FormWrapper title="Retention Sample Testing Record" subtitle="Retention Samples & Product Testing — FSSC 22000 Cl. 8.9" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Sample Reference Number" placeholder="e.g. RS-2026-047" />
        <Field label="Product Name" placeholder="Product / SKU" />
        <Field label="Batch / Lot Number" placeholder="Batch number" />
        <Field label="Production Date" type="date" />
        <Field label="Sample Taken By" placeholder="Name" />
        <Field label="Date Sample Retained" type="date" />
        <Field label="Sample Quantity / Size" placeholder="e.g. 3 × 500 mm length" />
        <Field label="Storage Location" placeholder="e.g. QA Lab — Shelf C" />
        <Field label="Retention Period (months)" type="number" placeholder="e.g. 24" />
        <Field label="Customer / Order Reference" placeholder="If customer-specific" />
        <Field label="Packaging / Storage Conditions" placeholder="e.g. Sealed bag, ambient, dark" />
        <Field label="Scheduled Destruction Date" type="date" />
      </div>

      <SectionHeading>Test Results</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Test Parameter", "Test Method", "Specification / Limit", "Result", "Unit", "Pass / Fail", "Tested By", "Test Date"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              "Film thickness / gauge",
              "Tensile strength",
              "Seal strength / peel force",
              "Oxygen transmission rate (OTR)",
              "Water vapour transmission rate (WVTR)",
              "Print colour delta-E (colour change)",
              "Migration test (if applicable)",
              "Appearance / visual assessment",
              "Odour assessment",
              "Other",
            ].map((param, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                <td className="border border-slate-200 px-2 py-1.5 font-medium text-slate-700">{param}</td>
                {[1, 2, 3, 4].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5 w-16">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Pass</option>
                    <option>Fail</option>
                    <option>N/A</option>
                  </select>
                </td>
                {[5, 6].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type={j === 6 ? "date" : "text"} className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Overall Test Result" type="select" options={["All tests passed — sample compliant", "One or more tests failed — investigate", "Tests incomplete — pending"]} />
        <Field label="Action Required (if failed)" type="textarea" rows={2} placeholder="Describe follow-up actions..." />
        <Field label="External Laboratory (if used)" placeholder="Lab name and accreditation" />
        <Field label="Lab Report Reference" placeholder="Lab report number" />
      </div>

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">QA Analyst</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">QA Manager Review</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function CleaningScheduleForm({ onSign }) {
  const areas = [
    "Production Floor — General",
    "Printing Machine (Gravure/Flexo)",
    "Laminator",
    "Slitter",
    "Film Roller Storage Area",
    "Ink Room / Mixing Area",
    "Solvent / Chemical Store",
    "Warehouse / Despatch",
    "Staff Canteen / Kitchen",
    "Toilets / Changerooms",
    "Office Areas",
    "Outdoor / Perimeter / Drains",
  ];

  return (
    <FormWrapper title="Master Cleaning Schedule" subtitle="Cleaning Programme — ISO/TS 22002-4 Cl. 11" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Site / Facility" placeholder="Facility name" />
        <Field label="Document Reference" placeholder="e.g. CS-001" />
        <Field label="Schedule Period" placeholder="e.g. Jan 2026" />
        <Field label="Prepared By" placeholder="Name" />
        <Field label="Approved By" placeholder="Name" />
        <Field label="Issue Date" type="date" />
      </div>

      <SectionHeading>Cleaning Frequency Master Schedule</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              <th className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">Area / Equipment</th>
              <th className="border border-slate-200 px-2 py-1.5 text-center font-semibold text-slate-600 w-12">Shift</th>
              <th className="border border-slate-200 px-2 py-1.5 text-center font-semibold text-slate-600 w-12">Daily</th>
              <th className="border border-slate-200 px-2 py-1.5 text-center font-semibold text-slate-600 w-16">Weekly</th>
              <th className="border border-slate-200 px-2 py-1.5 text-center font-semibold text-slate-600 w-16">Monthly</th>
              <th className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">Method / Chemical</th>
              <th className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">Responsible</th>
            </tr>
          </thead>
          <tbody>
            {areas.map((area, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                <td className="border border-slate-200 px-2 py-1.5 font-medium">{area}</td>
                {[0, 1, 2, 3].map(j => (
                  <td key={j} className="border border-slate-200 px-2 py-1 text-center">
                    <input type="checkbox" className="w-4 h-4 accent-emerald-600" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" placeholder="e.g. Wet — Chemex @ 2%" />
                </td>
                <td className="border border-slate-200 px-1 py-0.5">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" placeholder="e.g. Operator" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionHeading>Monthly Completion Sign-Off</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              <th className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">Week</th>
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Supervisor Initial", "Issues Noted"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-center font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {["Week 1", "Week 2", "Week 3", "Week 4"].map((week, i) => (
              <tr key={i}>
                <td className="border border-slate-200 px-2 py-1.5 font-medium text-slate-600">{week}</td>
                {[0, 1, 2, 3, 4, 5].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-1 text-center">
                    <input type="text" className="w-10 text-xs border-0 outline-none bg-transparent text-center" placeholder="✓" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Prepared By</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Approved By (QA Manager)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function CalibrationCertificateForm({ onSign }) {
  return (
    <FormWrapper title="Calibration Certificate & Equipment Register" subtitle="Equipment Calibration — ISO/TS 22002-4 Cl. 8 / FSSC 22000 Cl. 7.1.5" onSign={onSign}>
      <SectionHeading>Equipment Details</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Equipment Name / Description" placeholder="e.g. Digital Vernier Calliper" />
        <Field label="Asset / Tag Number" placeholder="e.g. CAL-042" />
        <Field label="Serial Number" placeholder="Manufacturer serial" />
        <Field label="Manufacturer" placeholder="Brand name" />
        <Field label="Model Number" placeholder="Model" />
        <Field label="Location" placeholder="e.g. QA Lab — Bench 3" />
        <Field label="Measurement Range" placeholder="e.g. 0–150 mm" />
        <Field label="Accuracy Required" placeholder="e.g. ±0.02 mm" />
        <Field label="Calibration Frequency" type="select" options={["Monthly", "Quarterly", "6-Monthly", "Annually", "As Required"]} />
      </div>

      <SectionHeading>Calibration Record</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Calibration Date" type="date" />
        <Field label="Calibrated By" placeholder="Name / Company" />
        <Field label="Calibration Method" placeholder="e.g. ISO 9001 in-house / SANAS accredited lab" />
        <Field label="Reference Standard Used" placeholder="e.g. Reference gauge block — Cert No. STD-001" />
        <Field label="Reference Standard Cert. No." placeholder="Traceability reference" />
        <Field label="SANAS / ILAC Accreditation?" type="select" options={["Yes — accredited lab", "No — in-house calibration", "N/A"]} />
      </div>

      <SectionHeading>Calibration Results</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Measurement Point", "Nominal Value", "Reference Value", "As-Found Reading", "As-Left Reading", "Error / Deviation", "Within Tolerance?"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>
                {[0, 1, 2, 3, 4, 5].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5 w-20">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Yes — Pass</option>
                    <option>No — Fail</option>
                    <option>Adjusted</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Overall Calibration Outcome" type="select" options={["Calibrated — Passed, in service", "Calibrated — Adjusted, now in service", "Failed — Out of service (tagged)", "Failed — Withdrawn for repair"]} />
        <Field label="Next Calibration Due Date" type="date" />
        <Field label="Calibration Certificate Number" placeholder="Certificate reference" />
        <Field label="Action for Out-of-Tolerance Readings" type="textarea" rows={2} placeholder="Describe investigation and actions taken for previous measurements..." />
      </div>

      <SectionHeading>Equipment Register Summary</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Asset No.", "Equipment", "Location", "Last Calibration", "Next Due", "Status"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 8 }).map((_, i) => (
              <tr key={i}>
                {[0, 1, 2].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                {[3, 4].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type="date" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5 w-24">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>In service</option>
                    <option>Out of service</option>
                    <option>Due for calibration</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Calibrated By</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Reviewed By (QA)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function ServiceAgreementForm({ onSign }) {
  return (
    <FormWrapper title="Service Agreement Register" subtitle="External Service Provider Management — FSSC 22000 Cl. 7.1.6" onSign={onSign}>
      <SectionHeading>Service Provider Details</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Service Provider Name" placeholder="Company name" />
        <Field label="Contact Person" placeholder="Name and role" />
        <Field label="Phone / Email" placeholder="Contact details" />
        <Field label="Physical Address" placeholder="Address" />
        <Field label="Service Category" type="select" options={["Pest Control", "Equipment Calibration", "Equipment Maintenance", "Laboratory Testing", "Cleaning & Hygiene", "Security", "Waste Management", "Utilities", "IT Services", "Certification Body", "Other"]} />
        <Field label="Annual Contract Value (ZAR)" type="number" placeholder="e.g. 85000" />
      </div>

      <SectionHeading>Agreement Details</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Agreement / Contract Reference" placeholder="Contract number" />
        <Field label="Agreement Start Date" type="date" />
        <Field label="Agreement Expiry Date" type="date" />
        <Field label="Service Frequency" type="select" options={["Once-off", "Daily", "Weekly", "Monthly", "Quarterly", "6-Monthly", "Annually", "On demand"]} />
        <Field label="SLA Response Time" placeholder="e.g. 4 hours for emergency" />
        <Field label="Auto-Renewal?" type="select" options={["Yes — auto-renews", "No — manual renewal required"]} />
      </div>
      <Field label="Scope of Services Provided" type="textarea" rows={3} placeholder="Detailed description of services included in the agreement..." />
      <Field label="Food Safety Requirements Communicated to Provider" type="textarea" rows={2} placeholder="e.g. No unauthorised chemicals, food safety induction required, MSDS to be provided..." />

      <SectionHeading>Compliance & Approval</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Requirement", "Required?", "Received / Verified", "Expiry Date", "Notes"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              "Public Liability Insurance",
              "Professional Indemnity Insurance",
              "Workmen's Compensation (COIDA)",
              "BBBEE Certificate",
              "Relevant industry certification (e.g. SANS, SABS)",
              "Food safety induction completed",
              "NDA / Confidentiality Agreement signed",
              "Service Level Agreement (SLA) signed",
            ].map((req, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                <td className="border border-slate-200 px-2 py-1.5 font-medium">{req}</td>
                <td className="border border-slate-200 px-2 py-1 text-center w-16">
                  <input type="checkbox" className="w-4 h-4 accent-emerald-600" />
                </td>
                <td className="border border-slate-200 px-2 py-1 text-center w-16">
                  <input type="checkbox" className="w-4 h-4 accent-blue-500" />
                </td>
                <td className="border border-slate-200 px-1 py-0.5 w-32">
                  <input type="date" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
                <td className="border border-slate-200 px-1 py-0.5">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionHeading>Performance Review</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Review Date", "Performance Rating", "Issues Noted", "Actions Required", "Reviewed By"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 4 }).map((_, i) => (
              <tr key={i}>
                <td className="border border-slate-200 px-1 py-0.5 w-28">
                  <input type="date" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
                <td className="border border-slate-200 px-1 py-0.5 w-28">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Excellent</option>
                    <option>Good</option>
                    <option>Acceptable</option>
                    <option>Poor — action required</option>
                  </select>
                </td>
                {[0, 1, 2].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Field label="Current Approval Status" type="select" options={["Approved — Active", "Approved — Under Review", "Suspended — Pending Resolution", "Terminated"]} />
        <Field label="Approval Valid Until" type="date" />
        <Field label="Next Review Date" type="date" />
      </div>

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Procurement / QA Manager</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Authorised By (Management)</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

// ─── MANAGEMENT FORMS ─────────────────────────────────────────────────────────

function InternalAuditForm({ onSign }) {
  const clauses = [
    "4 — Context of the Organisation",
    "5 — Leadership & Commitment",
    "6 — Planning",
    "7 — Support (Resources, Awareness, Communication)",
    "8 — Operation (PRPs, HACCP, Traceability, NC control)",
    "9 — Performance Evaluation",
    "10 — Improvement",
    "ISO/TS 22002-4 PRP Programs",
  ];

  return (
    <FormWrapper title="Internal Audit Report" subtitle="Internal Audit — FSSC 22000 Cl. 9.2" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Audit Reference Number" placeholder="e.g. IA-2026-001" />
        <Field label="Audit Date" type="date" />
        <Field label="Audit Type" type="select" options={["Planned Internal Audit", "Unannounced Audit", "Follow-up Audit", "Pre-Certification Audit"]} />
        <Field label="Lead Auditor" placeholder="Name" />
        <Field label="Co-Auditor (if any)" placeholder="Name" />
        <Field label="Auditee / Department" placeholder="Department or function" />
      </div>

      <SectionHeading>Scope & Clauses Audited</SectionHeading>
      <div className="grid grid-cols-2 gap-2">
        {clauses.map((clause, i) => (
          <label key={i} className="flex items-center gap-2 text-sm cursor-pointer">
            <input type="checkbox" className="w-4 h-4 accent-emerald-600" />
            {clause}
          </label>
        ))}
      </div>

      <SectionHeading>Findings Summary</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Ref #", "Clause", "Finding Description", "Classification", "Evidence"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 6 }).map((_, i) => (
              <tr key={i}>
                <td className="border border-slate-200 px-1 py-1 w-12">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" placeholder={`F-${i + 1}`} />
                </td>
                <td className="border border-slate-200 px-1 py-1 w-16">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
                <td className="border border-slate-200 px-1 py-1">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
                <td className="border border-slate-200 px-1 py-1 w-32">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Major NC</option>
                    <option>Minor NC</option>
                    <option>Observation</option>
                    <option>Opportunity for Improvement</option>
                  </select>
                </td>
                <td className="border border-slate-200 px-1 py-1">
                  <input type="text" className="w-full text-xs border-0 outline-none bg-transparent" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Field label="Major NCs" type="number" placeholder="Count" />
        <Field label="Minor NCs" type="number" placeholder="Count" />
        <Field label="Observations" type="number" placeholder="Count" />
        <Field label="Overall Audit Conclusion" type="select" options={["Satisfactory — No Major Findings", "Conditional — Minor NCs to be Addressed", "Unsatisfactory — Major NCs Require Immediate Action"]} />
        <Field label="CARs Required By Date" type="date" />
        <Field label="Follow-up Audit Required?" type="select" options={["No", "Yes — within 30 days", "Yes — within 60 days", "Yes — before certification"]} />
      </div>
      <Field label="Positive Findings / Best Practices Observed" type="textarea" rows={2} placeholder="Strengths noted during the audit..." />
      <Field label="Auditor's Summary & Recommendations" type="textarea" rows={3} placeholder="Overall observations and recommendations..." />

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Lead Auditor</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Auditee / Area Manager</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Food Safety Team Leader</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function CorrectiveActionForm({ onSign }) {
  return (
    <FormWrapper title="Corrective Action Request (CAR)" subtitle="Non-Conformance & Corrective Action — FSSC 22000 Cl. 10.1" onSign={onSign}>
      <div className="grid grid-cols-3 gap-3">
        <Field label="CAR Reference Number" placeholder="e.g. CAR-2026-012" />
        <Field label="Date Raised" type="date" />
        <Field label="Raised By" placeholder="Name" />
        <Field label="Source of Non-Conformance" type="select" options={["Internal Audit", "External / Certification Audit", "Customer Complaint", "Supplier Issue", "Process Deviation / CCP Breach", "PRP Failure", "Management Review", "Regulatory Inspection", "Near Miss / Incident", "Other"]} />
        <Field label="Reference (Audit Ref / Complaint Ref)" placeholder="Reference number" />
        <Field label="Priority" type="select" options={["Critical — Immediate Action (24h)", "High — Action within 7 days", "Medium — Action within 30 days", "Low — Action within 90 days"]} />
        <Field label="Assigned To" placeholder="Responsible person/dept" />
        <Field label="Target Close-Out Date" type="date" />
        <Field label="FSSC 22000 Clause Reference" placeholder="e.g. Cl. 8.9.3" />
      </div>

      <SectionHeading>1. Non-Conformance Description</SectionHeading>
      <Field label="Describe the non-conformance in detail" type="textarea" rows={3} placeholder="What happened, where, when and who was involved..." />
      <Field label="Immediate Containment Actions Taken" type="textarea" rows={2} placeholder="Actions taken immediately to contain the issue..." />

      <SectionHeading>2. Root Cause Analysis</SectionHeading>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Root Cause Analysis Method" type="select" options={["5-Why Analysis", "Fishbone / Ishikawa Diagram", "Fault Tree Analysis", "FMEA", "Other"]} />
        <Field label="Analysed By" placeholder="Name" />
      </div>
      <Field label="Root Cause(s) Identified" type="textarea" rows={3} placeholder="State the fundamental root cause(s) — not symptoms..." />

      <SectionHeading>3. Corrective Actions</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["#", "Action Description", "Responsible Person", "Due Date", "Completed Date", "Evidence"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>
                <td className="border border-slate-200 px-2 py-1.5 text-slate-400 w-6">{i + 1}</td>
                {[1, 2, 3, 4, 5].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type={j === 3 || j === 4 ? "date" : "text"} className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionHeading>4. Preventive Measures (Systemic Changes)</SectionHeading>
      <Field label="Systemic / Preventive Actions to Prevent Recurrence" type="textarea" rows={3} placeholder="Changes to procedures, training, systems, controls..." />
      <Field label="Effectiveness Criteria (how will you know it's working?)" type="textarea" rows={2} placeholder="Define measurable criteria for effectiveness verification..." />

      <SectionHeading>5. Verification & Close-Out</SectionHeading>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Verification Date" type="date" />
        <Field label="Verified By" placeholder="Name" />
        <Field label="Verification Result" type="select" options={["Effective — CAR Closed", "Partially Effective — Extended", "Ineffective — Re-opened"]} />
      </div>
      <Field label="Verification Notes / Evidence of Effectiveness" type="textarea" rows={2} placeholder="How effectiveness was verified..." />

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Raised By</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Responsible Person</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">QA / FSTL Close-Out</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

function ManagementReviewForm({ onSign }) {
  const inputs = [
    "Follow-up actions from previous management reviews",
    "Changes in external and internal issues relevant to the FSMS",
    "Information on food safety performance (KPIs, trends)",
    "Non-conformances and corrective action status",
    "Audit results (internal, external, customer audits)",
    "Customer feedback, complaints and compliments",
    "Objectives and targets — achievement status",
    "Effectiveness of actions to address risks and opportunities",
    "Adequacy of resources (people, infrastructure, environment)",
    "Training and competence status",
    "Communication issues (internal and external)",
    "Emergency situations or incidents",
    "Supplier performance",
    "Regulatory and legal changes",
    "Opportunities for continual improvement",
  ];

  return (
    <FormWrapper title="Management Review Record" subtitle="Management Review — FSSC 22000 Cl. 9.3">
      <div className="grid grid-cols-3 gap-3">
        <Field label="Meeting Date" type="date" />
        <Field label="Meeting Reference" placeholder="e.g. MR-2026-Q1" />
        <Field label="Location / Format" type="select" options={["On-Site — Boardroom", "On-Site — Production Floor", "Virtual / Online", "Hybrid"]} />
        <Field label="Chairperson" placeholder="Name and title" />
        <Field label="Food Safety Team Leader" placeholder="Name" />
        <Field label="Review Period Covered" placeholder="e.g. Q1 2026 / Jan–Mar 2026" />
      </div>

      <SectionHeading>Attendees</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["Name", "Title / Department", "Present", "Apologies"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {["Managing Director / CEO", "Food Safety Team Leader (FSTL)", "Production Manager", "Quality Assurance Manager", "Maintenance Manager", "Procurement / Supply Chain", "HR / Training Manager", "Sales / Customer Liaison"].map((role, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50/50"}>
                <td className="border border-slate-200 px-1 py-0.5"><input type="text" className="w-full text-xs border-0 outline-none bg-transparent" /></td>
                <td className="border border-slate-200 px-2 py-1.5 text-slate-500">{role}</td>
                <td className="border border-slate-200 px-2 py-1 text-center"><input type="checkbox" className="w-4 h-4 accent-emerald-600" /></td>
                <td className="border border-slate-200 px-2 py-1 text-center"><input type="checkbox" className="w-4 h-4 accent-amber-500" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionHeading>Review Inputs — Discussion Summary</SectionHeading>
      <div className="space-y-2">
        {inputs.map((input, i) => (
          <div key={i} className="border border-slate-200 rounded-lg p-3">
            <p className="text-xs font-semibold text-slate-700 mb-1.5">{i + 1}. {input}</p>
            <textarea className="w-full text-sm border border-slate-200 rounded px-2 py-1.5 focus:outline-none focus:border-emerald-500 resize-none" rows={2} placeholder="Summary of discussion / findings..." />
          </div>
        ))}
      </div>

      <SectionHeading>Review Outputs — Decisions & Action Items</SectionHeading>
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50">
              {["#", "Decision / Action", "Responsible", "Target Date", "Resources Required", "Priority"].map(h => (
                <th key={h} className="border border-slate-200 px-2 py-1.5 text-left font-semibold text-slate-600">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 8 }).map((_, i) => (
              <tr key={i}>
                <td className="border border-slate-200 px-2 py-1.5 text-slate-400 w-6">{i + 1}</td>
                {[1, 2, 3, 4].map(j => (
                  <td key={j} className="border border-slate-200 px-1 py-0.5">
                    <input type={j === 3 ? "date" : "text"} className="w-full text-xs border-0 outline-none bg-transparent" />
                  </td>
                ))}
                <td className="border border-slate-200 px-1 py-0.5">
                  <select className="text-xs border-0 outline-none bg-transparent w-full">
                    <option value="">—</option>
                    <option>Critical</option>
                    <option>High</option>
                    <option>Medium</option>
                    <option>Low</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Overall FSMS Suitability, Adequacy & Effectiveness" type="select" options={["Adequate & Effective — No changes required", "Adequate — Minor improvements identified", "Requires Improvement — Actions assigned", "Inadequate — Major actions required"]} />
        <Field label="Next Management Review Date" type="date" />
      </div>
      <Field label="Additional Remarks / Notes from Chairperson" type="textarea" rows={2} placeholder="Closing remarks..." />

      <div className="flex gap-6 pt-2 border-t border-slate-100">
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Chairperson</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Food Safety Team Leader</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
        <div className="flex-1"><p className="text-xs text-slate-500 mb-6">Minute Taker / Recorder</p><div className="border-t border-slate-400 pt-1 text-xs text-slate-400">Signature / Date</div></div>
      </div>
    </FormWrapper>
  );
}

// ─── EXPORTED MAIN COMPONENT ──────────────────────────────────────────────────

const FORM_GROUPS = [
  {
    key: "food_safety",
    label: "Food Safety",
    icon: ClipboardList,
    color: "emerald",
    forms: [
      { key: "ccp", label: "CCP Monitoring Record", component: <CCPMonitoringForm /> },
      { key: "prp", label: "PRP Verification Checklist", component: <PRPCheckForm /> },
      { key: "allergen", label: "Allergen Control Check", component: <AllergenControlForm /> },
      { key: "cleaning", label: "Cleaning & Sanitation Record", component: <CleaningRecordForm /> },
    ]
  },
  {
    key: "supplier",
    label: "Supplier & Materials",
    icon: Truck,
    color: "blue",
    forms: [
      { key: "supplier_questionnaire", label: "Supplier Quality Questionnaire", component: <SupplierQualityQuestionnaire /> },
      { key: "supplier_approval", label: "Supplier Approval Form", component: <SupplierApprovalForm /> },
      { key: "raw_material", label: "Raw Material Receiving Inspection", component: <RawMaterialReceivingForm /> },
      { key: "batch_release", label: "Batch Release / Disposition", component: <BatchReleaseForm /> },
    ]
  },
  {
    key: "documentation",
    label: "Documentation",
    icon: FileText,
    color: "orange",
    forms: [
      { key: "food_safety_statement", label: "Food Safety Policy Statement", component: <FoodSafetyStatementForm /> },
      { key: "haccp_study", label: "HACCP Study Record", component: <HACCPStudyForm /> },
      { key: "pest_control", label: "Pest Control Record", component: <PestControlRecordForm /> },
      { key: "retention_testing", label: "Retention Sample Testing", component: <RetentionSampleTestingForm /> },
      { key: "cleaning_schedule", label: "Cleaning Schedule", component: <CleaningScheduleForm /> },
      { key: "calibration", label: "Calibration Certificate", component: <CalibrationCertificateForm /> },
      { key: "service_agreement", label: "Service Agreements", component: <ServiceAgreementForm /> },
    ]
  },
  {
    key: "management",
    label: "Management",
    icon: Users,
    color: "violet",
    forms: [
      { key: "internal_audit", label: "Internal Audit Report", component: <InternalAuditForm /> },
      { key: "corrective_action", label: "Corrective Action Request (CAR)", component: <CorrectiveActionForm /> },
      { key: "management_review", label: "Management Review Record", component: <ManagementReviewForm /> },
    ]
  }
];

export default function FSSCForms() {
  const [activeGroup, setActiveGroup] = useState("food_safety");
  const [activeForm, setActiveForm] = useState("ccp");
  const [signDialog, setSignDialog] = useState(null); // { formKey, formTitle }

  const currentGroup = FORM_GROUPS.find(g => g.key === activeGroup);
  const currentForm = currentGroup?.forms.find(f => f.key === activeForm);

  const handleGroupChange = (key) => {
    setActiveGroup(key);
    setActiveForm(FORM_GROUPS.find(g => g.key === key)?.forms[0]?.key);
  };

  const openSign = (formKey, formTitle) => {
    setSignDialog({ formKey, formTitle });
  };

  // Re-build FORM_GROUPS with onSign injected
  const FORM_GROUPS_WITH_SIGN = FORM_GROUPS.map(group => ({
    ...group,
    forms: group.forms.map(form => ({
      ...form,
      component: React.cloneElement(form.component, {
        onSign: () => openSign(form.key, form.label)
      })
    }))
  }));

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <CheckSquare className="w-5 h-5 text-emerald-600" />
        <div>
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white">FSSC 22000 v6.0 Compliance Forms</h2>
          <p className="text-xs text-slate-500">Fill in and print/PDF any form directly from the browser</p>
        </div>
      </div>

      {/* Group tabs */}
      <Tabs value={activeGroup} onValueChange={handleGroupChange}>
        <TabsList>
          {FORM_GROUPS_WITH_SIGN.map(g => (
            <TabsTrigger key={g.key} value={g.key} className="gap-1.5">
              <g.icon className="w-3.5 h-3.5" />
              {g.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {FORM_GROUPS_WITH_SIGN.map(group => (
          <TabsContent key={group.key} value={group.key} className="mt-4">
            {/* Form sub-nav */}
            <div className="flex gap-2 flex-wrap mb-5">
              {group.forms.map(form => (
                <button
                  key={form.key}
                  onClick={() => setActiveForm(form.key)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                    activeForm === form.key
                      ? "bg-emerald-600 text-white border-emerald-600"
                      : "bg-white text-slate-600 border-slate-200 hover:border-emerald-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700"
                  }`}
                >
                  {form.label}
                </button>
              ))}
            </div>

            {/* Active form */}
            {group.forms.find(f => f.key === activeForm)?.component}
          </TabsContent>
        ))}
      </Tabs>

      {/* Sign dialog */}
      {signDialog && (
        <SignFormDialog
          open={!!signDialog}
          onClose={() => setSignDialog(null)}
          formKey={signDialog.formKey}
          formTitle={signDialog.formTitle}
        />
      )}
    </div>
  );
}