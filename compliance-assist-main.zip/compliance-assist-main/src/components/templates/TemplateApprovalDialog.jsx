import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Clock, CheckCircle2, XCircle, FileText, Send,
  ChevronDown, ChevronUp, History
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";

const STATUS_CONFIG = {
  draft:        { label: "Draft",        className: "bg-slate-100 text-slate-600 border-slate-200",    icon: FileText },
  under_review: { label: "Under Review", className: "bg-amber-100 text-amber-700 border-amber-200",    icon: Clock },
  approved:     { label: "Approved",     className: "bg-emerald-100 text-emerald-700 border-emerald-200", icon: CheckCircle2 },
  rejected:     { label: "Rejected",     className: "bg-rose-100 text-rose-700 border-rose-200",       icon: XCircle },
};

function StatusBadge({ status }) {
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.draft;
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${cfg.className}`}>
      <Icon className="w-3 h-3" /> {cfg.label}
    </span>
  );
}

export default function TemplateApprovalDialog({ open, onClose, template }) {
  const [changeSummary, setChangeSummary] = useState("");
  const [approverEmail, setApproverEmail] = useState("");
  const [reviewNotes, setReviewNotes] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const queryClient = useQueryClient();

  const { data: approvals = [] } = useQuery({
    queryKey: ["template-approvals", template?.id],
    queryFn: () => base44.entities.TemplateApproval.filter({ template_id: template.id }, "-created_date", 20),
    enabled: !!template?.id,
  });

  const { data: user } = useQuery({
    queryKey: ["current-user"],
    queryFn: () => base44.auth.me(),
  });

  const latest = approvals[0];
  const history = approvals.slice(1);

  const submitMutation = useMutation({
    mutationFn: async () => {
      const currentVersion = latest?.version_number || 0;
      const newVersionNum = currentVersion + 1;
      const major = Math.floor(newVersionNum);
      const versionLabel = `v${major}.0`;
      return base44.entities.TemplateApproval.create({
        template_id: template.id,
        template_name: template.name,
        version: versionLabel,
        version_number: newVersionNum,
        status: "under_review",
        submitted_by: user?.email || "",
        submitted_at: new Date().toISOString(),
        approver_email: approverEmail,
        change_summary: changeSummary,
        content_snapshot: template.content,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["template-approvals", template?.id] });
      queryClient.invalidateQueries({ queryKey: ["template-approvals-all"] });
      setChangeSummary("");
      setApproverEmail("");
      toast.success("Submitted for review");
      // Send in-app notification if approver is set
      if (approverEmail) {
        base44.integrations.Core.SendEmail({
          to: approverEmail,
          subject: `Document Review Required: ${template.name}`,
          body: `A document template has been submitted for your review.\n\nTemplate: ${template.name}\nChange Summary: ${changeSummary || "No description provided"}\n\nPlease log in to review and approve or reject this document.`,
        }).catch(() => {}); // non-blocking
      }
    },
    onError: () => toast.error("Failed to submit for review"),
  });

  const approveMutation = useMutation({
    mutationFn: () =>
      base44.entities.TemplateApproval.update(latest.id, {
        status: "approved",
        reviewed_by: user?.email || "",
        reviewed_at: new Date().toISOString(),
        review_notes: reviewNotes,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["template-approvals", template?.id] });
      queryClient.invalidateQueries({ queryKey: ["template-approvals-all"] });
      // Update the DocumentTemplate's current_version
      base44.entities.DocumentTemplate.update(template.id, {
        current_version: latest?.version || "v1.0",
      });
      setReviewNotes("");
      toast.success("Document approved");
    },
    onError: () => toast.error("Failed to approve"),
  });

  const rejectMutation = useMutation({
    mutationFn: () =>
      base44.entities.TemplateApproval.update(latest.id, {
        status: "rejected",
        reviewed_by: user?.email || "",
        reviewed_at: new Date().toISOString(),
        review_notes: reviewNotes,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["template-approvals", template?.id] });
      queryClient.invalidateQueries({ queryKey: ["template-approvals-all"] });
      setReviewNotes("");
      toast.success("Document rejected");
    },
    onError: () => toast.error("Failed to reject"),
  });

  if (!template) return null;

  const canSubmit = !latest || latest.status === "approved" || latest.status === "rejected";
  const pendingReview = latest?.status === "under_review";

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-base">Document Approval — {template.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Current status */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100">
            <div>
              <p className="text-xs text-slate-500 mb-1">Current Status</p>
              <StatusBadge status={latest?.status || "draft"} />
            </div>
            {latest?.version && (
              <div className="text-right">
                <p className="text-xs text-slate-500 mb-0.5">Version</p>
                <span className="text-sm font-semibold text-slate-700">{latest.version}</span>
              </div>
            )}
          </div>

          {/* Latest submission details */}
          {latest && (
            <div className="text-xs text-slate-500 space-y-1 px-1">
              {latest.submitted_by && <p>Submitted by: <span className="text-slate-700">{latest.submitted_by}</span></p>}
              {latest.submitted_at && <p>Submitted: <span className="text-slate-700">{format(parseISO(latest.submitted_at), "dd MMM yyyy HH:mm")}</span></p>}
              {latest.change_summary && <p>Changes: <span className="text-slate-700">{latest.change_summary}</span></p>}
              {latest.approver_email && <p>Approver: <span className="text-slate-700">{latest.approver_email}</span></p>}
              {latest.review_notes && (
                <div className={`mt-2 p-2 rounded border text-xs ${latest.status === "rejected" ? "border-rose-200 bg-rose-50 text-rose-700" : "border-emerald-200 bg-emerald-50 text-emerald-700"}`}>
                  <span className="font-medium">Reviewer note:</span> {latest.review_notes}
                </div>
              )}
            </div>
          )}

          {/* Submit for review panel */}
          {canSubmit && (
            <div className="border border-slate-200 rounded-lg p-4 space-y-3">
              <p className="text-sm font-medium text-slate-700">Submit New Version for Review</p>
              <div className="space-y-2">
                <Label className="text-xs text-slate-500">Change Summary</Label>
                <Textarea
                  placeholder="Briefly describe what changed in this version..."
                  value={changeSummary}
                  onChange={e => setChangeSummary(e.target.value)}
                  rows={2}
                  className="text-sm resize-none"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs text-slate-500">Approver Email (optional — will receive email notification)</Label>
                <Input
                  type="email"
                  placeholder="approver@company.com"
                  value={approverEmail}
                  onChange={e => setApproverEmail(e.target.value)}
                  className="text-sm"
                />
              </div>
              <Button
                size="sm"
                onClick={() => submitMutation.mutate()}
                disabled={submitMutation.isPending}
                className="w-full gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                {submitMutation.isPending ? "Submitting..." : "Submit for Review"}
              </Button>
            </div>
          )}

          {/* Approve / Reject panel (for approvers) */}
          {pendingReview && (
            <div className="border border-amber-200 rounded-lg p-4 space-y-3 bg-amber-50">
              <p className="text-sm font-medium text-amber-800">Review & Decision</p>
              <div className="space-y-2">
                <Label className="text-xs text-amber-700">Reviewer Notes (optional)</Label>
                <Textarea
                  placeholder="Add comments or reason for rejection..."
                  value={reviewNotes}
                  onChange={e => setReviewNotes(e.target.value)}
                  rows={2}
                  className="text-sm resize-none"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => approveMutation.mutate()}
                  disabled={approveMutation.isPending || rejectMutation.isPending}
                  className="flex-1 gap-1.5 bg-emerald-600 hover:bg-emerald-700"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => rejectMutation.mutate()}
                  disabled={approveMutation.isPending || rejectMutation.isPending}
                  className="flex-1 gap-1.5 border-rose-200 text-rose-600 hover:bg-rose-50"
                >
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </Button>
              </div>
            </div>
          )}

          {/* Version history */}
          {history.length > 0 && (
            <div>
              <button
                onClick={() => setShowHistory(v => !v)}
                className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-700 font-medium"
              >
                <History className="w-3.5 h-3.5" />
                Version History ({history.length} previous)
                {showHistory ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
              {showHistory && (
                <div className="mt-2 space-y-2 border-l-2 border-slate-100 pl-3">
                  {history.map(h => (
                    <div key={h.id} className="text-xs text-slate-500">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-slate-700">{h.version}</span>
                        <StatusBadge status={h.status} />
                        {h.submitted_at && <span>{format(parseISO(h.submitted_at), "dd MMM yyyy")}</span>}
                      </div>
                      {h.change_summary && <p className="mt-0.5 pl-1">{h.change_summary}</p>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}