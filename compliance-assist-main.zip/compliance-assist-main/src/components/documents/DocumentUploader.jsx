import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Upload, Loader2, X, Plus } from "lucide-react";
import { toast } from "sonner";

const DOCUMENT_TYPES = [
  { value: "supplier_certificate", label: "Supplier Certificate" },
  { value: "safety_data_sheet", label: "Safety Data Sheet" },
  { value: "inspection_report", label: "Inspection Report" },
  { value: "test_report", label: "Test Report" },
  { value: "compliance_evidence", label: "Compliance Evidence" },
  { value: "risk_analysis", label: "Risk Analysis" },
  { value: "procedure", label: "Procedure" },
  { value: "specification", label: "Specification" },
  { value: "other", label: "Other" },
];

const SUGGESTED_TAGS = [
  "ISO 22000", "HACCP", "GMP", "allergen", "CCP", "OPRP", "PRP",
  "audit", "policy", "evidence", "approved", "review-required",
];

export default function DocumentUploader({ entityType, entityId, open, onClose, clauseNumber }) {
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState(null);
  const [tagInput, setTagInput] = useState("");
  const [form, setForm] = useState({
    document_type: "compliance_evidence",
    description: "",
    expiry_date: "",
    tags: clauseNumber ? [clauseNumber] : [],
    current_version: "1.0",
    control_status: "uncontrolled",
  });

  const queryClient = useQueryClient();

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) setFile(selectedFile);
  };

  const addTag = (tag) => {
    const t = tag.trim();
    if (t && !form.tags.includes(t)) {
      setForm({ ...form, tags: [...form.tags, t] });
    }
    setTagInput("");
  };

  const removeTag = (tag) => {
    setForm({ ...form, tags: form.tags.filter(t => t !== tag) });
  };

  const handleUpload = async () => {
    if (!file) { toast.error("Please select a file"); return; }
    setUploading(true);
    try {
      const user = await base44.auth.me();
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      const doc = await base44.entities.Document.create({
        file_name: file.name,
        file_url,
        file_size: file.size,
        file_type: file.type,
        document_type: form.document_type,
        linked_entity_type: entityType,
        linked_entity_id: entityId,
        description: form.description,
        uploaded_by: user.email,
        expiry_date: form.expiry_date || null,
        tags: form.tags,
        current_version: form.current_version,
        control_status: form.control_status,
      });

      // Auto-create initial revision
      await base44.entities.DocumentRevision.create({
        document_id: doc.id,
        version: form.current_version,
        file_url,
        file_size: file.size,
        change_summary: "Initial upload",
        revision_type: "major",
        status: "draft",
        is_current: true,
      });

      // AI analysis for compliance docs
      if (['supplier_certificate', 'safety_data_sheet', 'test_report', 'compliance_evidence'].includes(form.document_type)) {
        base44.functions.invoke('analyzeComplianceDocument', { document_id: doc.id })
          .catch(err => console.error('Analysis failed:', err));
      }

      queryClient.invalidateQueries({ queryKey: ["documents"] });
      queryClient.invalidateQueries({ queryKey: ["document-revisions"] });
      toast.success("Document uploaded successfully");
      onClose();
      setFile(null);
      setForm({ document_type: "compliance_evidence", description: "", expiry_date: "", tags: clauseNumber ? [clauseNumber] : [], current_version: "1.0", control_status: "uncontrolled" });
    } catch {
      toast.error("Failed to upload document");
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Upload Document</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          {/* File */}
          <div>
            <Label className="text-xs">File *</Label>
            <Input type="file" onChange={handleFileChange} accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg" className="cursor-pointer mt-1" />
            {file && <p className="text-xs text-slate-500 mt-1">{file.name} ({(file.size / 1024).toFixed(1)} KB)</p>}
          </div>

          {/* Type */}
          <div>
            <Label className="text-xs">Document Type *</Label>
            <Select value={form.document_type} onValueChange={(v) => setForm({ ...form, document_type: v })}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {DOCUMENT_TYPES.map(type => (
                  <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div>
            <Label className="text-xs">Description</Label>
            <Textarea
              placeholder="Brief description of the document..."
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={2}
              className="mt-1"
            />
          </div>

          {/* Version & Control */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Initial Version</Label>
              <Input
                placeholder="1.0"
                value={form.current_version}
                onChange={(e) => setForm({ ...form, current_version: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-xs">Control Status</Label>
              <Select value={form.control_status} onValueChange={(v) => setForm({ ...form, control_status: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="uncontrolled">Uncontrolled</SelectItem>
                  <SelectItem value="controlled">Controlled</SelectItem>
                  <SelectItem value="under_review">Under Review</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Tags */}
          <div>
            <Label className="text-xs">Tags / Clause Links</Label>
            <div className="flex gap-2 mt-1">
              <Input
                placeholder="Type a tag and press Enter..."
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") { e.preventDefault(); addTag(tagInput); }
                }}
                className="flex-1"
              />
              <Button type="button" variant="outline" size="icon" onClick={() => addTag(tagInput)}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {/* Suggested tags */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {SUGGESTED_TAGS.filter(t => !form.tags.includes(t)).slice(0, 8).map(t => (
                <button key={t} onClick={() => addTag(t)} className="text-xs px-2 py-0.5 rounded-full border border-slate-200 text-slate-500 hover:border-emerald-400 hover:text-emerald-700 transition-colors">
                  + {t}
                </button>
              ))}
            </div>
            {/* Selected tags */}
            {form.tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {form.tags.map(tag => (
                  <Badge key={tag} variant="secondary" className="gap-1 pr-1">
                    {tag}
                    <button onClick={() => removeTag(tag)} className="hover:text-rose-600">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Expiry */}
          <div>
            <Label className="text-xs">Expiry Date (Optional)</Label>
            <Input type="date" value={form.expiry_date} onChange={(e) => setForm({ ...form, expiry_date: e.target.value })} className="mt-1" />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={uploading}>Cancel</Button>
          <Button onClick={handleUpload} disabled={!file || uploading} className="bg-emerald-600 hover:bg-emerald-700">
            {uploading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Uploading...</> : <><Upload className="w-4 h-4 mr-2" />Upload</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}