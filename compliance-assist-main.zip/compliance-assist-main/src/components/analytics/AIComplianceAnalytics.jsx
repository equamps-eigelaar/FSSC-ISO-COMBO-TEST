import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell, ReferenceLine,
} from "recharts";
import {
  Sparkles, AlertTriangle, TrendingDown, TrendingUp,
  ArrowRight, RefreshCw, Lightbulb, Target, ChevronDown, ChevronUp,
} from "lucide-react";
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns";

const SECTION_LABELS = {
  "4": "Context",
  "5": "Leadership",
  "6": "Planning",
  "7": "Support",
  "8": "Operation",
  "9": "Performance",
  "10": "Improvement",
  "TS": "TS 22002-4",
};

function sectionShort(section) {
  const key = section?.split(" ")[0];
  return SECTION_LABELS[key] || section?.split(" - ")[1] || section || "Other";
}

export default function AIComplianceAnalytics({ requirements = [], risks = [] }) {
  const [aiInsights, setAiInsights] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expandedPlan, setExpandedPlan] = useState(null);

  // --- Recurring gaps by section ---
  const gapsBySection = React.useMemo(() => {
    const map = {};
    requirements.forEach(r => {
      const section = sectionShort(r.section);
      if (!map[section]) map[section] = { section, nonCompliant: 0, notStarted: 0, total: 0, overdue: 0 };
      map[section].total++;
      if (r.status === "non_compliant") map[section].nonCompliant++;
      if (r.status === "not_started") map[section].notStarted++;
      if (r.due_date && new Date(r.due_date) < new Date() && r.status !== "compliant") map[section].overdue++;
    });
    return Object.values(map)
      .map(s => ({ ...s, gapScore: s.nonCompliant * 3 + s.notStarted * 2 + s.overdue }))
      .sort((a, b) => b.gapScore - a.gapScore)
      .slice(0, 8);
  }, [requirements]);

  // --- Risk reduction trend (last 6 months based on created_date) ---
  const riskTrend = React.useMemo(() => {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const start = startOfMonth(date);
      const end = endOfMonth(date);
      const monthRisks = risks.filter(r => {
        const d = new Date(r.created_date);
        return d >= start && d <= end;
      });
      const highCrit = monthRisks.filter(r => r.risk_level === "high" || r.risk_level === "critical").length;
      const mitigated = monthRisks.filter(r => r.status === "under_control").length;
      months.push({
        month: format(date, "MMM"),
        total: monthRisks.length,
        highCritical: highCrit,
        mitigated,
      });
    }
    return months;
  }, [risks]);

  // --- Non-compliant sections for AI prompt ---
  const nonCompliantSections = React.useMemo(() => {
    return gapsBySection.filter(s => s.nonCompliant > 0 || s.notStarted > 0);
  }, [gapsBySection]);

  const generateInsights = async () => {
    setLoading(true);
    try {
      const summary = nonCompliantSections.map(s =>
        `${s.section}: ${s.nonCompliant} non-compliant, ${s.notStarted} not started, ${s.overdue} overdue (out of ${s.total} total)`
      ).join("; ");

      const riskSummary = `High/critical risks: ${risks.filter(r => r.risk_level === "high" || r.risk_level === "critical").length} of ${risks.length} total. Mitigated: ${risks.filter(r => r.status === "under_control").length}`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a food safety compliance expert. Analyse this FSSC 22000 compliance data for a packaging manufacturer and provide actionable insights.

Compliance gaps by section: ${summary || "No significant gaps found"}
Risk profile: ${riskSummary}

Return a JSON object with:
{
  "summary": "2-sentence executive summary of the compliance situation",
  "recurring_gaps": [
    { "area": "section name", "root_cause": "likely root cause in 1 sentence", "severity": "high|medium|low", "frequency": "description of how recurring this is" }
  ],
  "improvement_plans": [
    { "area": "section name", "title": "plan title", "steps": ["step 1", "step 2", "step 3"], "timeline": "e.g. 30 days", "expected_impact": "description" }
  ],
  "risk_observation": "1-2 sentences about the risk reduction trend",
  "overall_health": "good|fair|critical"
}

Provide at most 4 recurring_gaps and 3 improvement_plans. Be specific and practical.`,
        response_json_schema: {
          type: "object",
          properties: {
            summary: { type: "string" },
            recurring_gaps: { type: "array", items: { type: "object" } },
            improvement_plans: { type: "array", items: { type: "object" } },
            risk_observation: { type: "string" },
            overall_health: { type: "string" },
          },
        },
      });
      setAiInsights(result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const severityColor = (s) => {
    if (s === "high") return "bg-rose-100 text-rose-700";
    if (s === "medium") return "bg-amber-100 text-amber-700";
    return "bg-slate-100 text-slate-600";
  };

  const healthColor = (h) => {
    if (h === "good") return "text-emerald-600";
    if (h === "critical") return "text-rose-600";
    return "text-amber-600";
  };

  const healthBg = (h) => {
    if (h === "good") return "bg-emerald-50 border-emerald-200";
    if (h === "critical") return "bg-rose-50 border-rose-200";
    return "bg-amber-50 border-amber-200";
  };

  return (
    <div className="space-y-6">

      {/* Recurring Gaps Chart */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-500" />
            Recurring Compliance Gaps by Section
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          {gapsBySection.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-8">No compliance data available</p>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={gapsBySection} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="section" tick={{ fontSize: 11 }} stroke="#64748b" />
                <YAxis tick={{ fontSize: 11 }} stroke="#64748b" />
                <Tooltip
                  formatter={(value, name) => [value, name === "nonCompliant" ? "Non-Compliant" : name === "notStarted" ? "Not Started" : "Overdue"]}
                  contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }}
                />
                <Bar dataKey="nonCompliant" name="Non-Compliant" fill="#ef4444" radius={[4, 4, 0, 0]} stackId="a" />
                <Bar dataKey="notStarted" name="Not Started" fill="#94a3b8" radius={[4, 4, 0, 0]} stackId="a" />
                <Bar dataKey="overdue" name="Overdue" fill="#f59e0b" radius={[4, 4, 0, 0]} stackId="b" />
              </BarChart>
            </ResponsiveContainer>
          )}
          <div className="flex gap-4 justify-center mt-2 flex-wrap">
            {[["#ef4444", "Non-Compliant"], ["#94a3b8", "Not Started"], ["#f59e0b", "Overdue"]].map(([color, label]) => (
              <span key={label} className="flex items-center gap-1.5 text-xs text-slate-500">
                <span className="w-3 h-3 rounded-sm inline-block" style={{ background: color }} />
                {label}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Risk Reduction Trend */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <TrendingDown className="w-4 h-4 text-emerald-600" />
            Risk Reduction Trend (Last 6 Months)
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={riskTrend} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#64748b" />
              <YAxis tick={{ fontSize: 11 }} stroke="#64748b" />
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }} />
              <Line type="monotone" dataKey="highCritical" stroke="#ef4444" strokeWidth={2} dot={{ r: 4 }} name="High/Critical Risks" />
              <Line type="monotone" dataKey="mitigated" stroke="#10b981" strokeWidth={2} dot={{ r: 4 }} name="Mitigated" strokeDasharray="5 3" />
              <Line type="monotone" dataKey="total" stroke="#94a3b8" strokeWidth={1.5} dot={{ r: 3 }} name="Total Risks" />
            </LineChart>
          </ResponsiveContainer>
          <div className="flex gap-4 justify-center mt-2 flex-wrap">
            {[["#ef4444", "High/Critical"], ["#10b981", "Mitigated"], ["#94a3b8", "Total"]].map(([color, label]) => (
              <span key={label} className="flex items-center gap-1.5 text-xs text-slate-500">
                <span className="w-3 h-3 rounded-sm inline-block" style={{ background: color }} />
                {label}
              </span>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Insights Panel */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-violet-500" />
              AI-Driven Compliance Insights
            </CardTitle>
            <Button
              onClick={generateInsights}
              disabled={loading}
              size="sm"
              className="bg-violet-600 hover:bg-violet-700 gap-2 text-xs"
            >
              {loading ? (
                <><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Analysing...</>
              ) : (
                <><Sparkles className="w-3.5 h-3.5" /> {aiInsights ? "Refresh Analysis" : "Generate Analysis"}</>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-5">
          {!aiInsights && !loading && (
            <div className="text-center py-10">
              <Sparkles className="w-10 h-10 text-violet-200 mx-auto mb-3" />
              <p className="text-slate-500 text-sm font-medium">AI Analysis Not Yet Generated</p>
              <p className="text-slate-400 text-xs mt-1 max-w-xs mx-auto">
                Click "Generate Analysis" to identify recurring gaps and get actionable improvement plans based on your compliance data.
              </p>
            </div>
          )}

          {loading && (
            <div className="text-center py-10">
              <div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="text-slate-500 text-sm">Analysing compliance patterns...</p>
            </div>
          )}

          {aiInsights && !loading && (
            <div className="space-y-6">
              {/* Overall Health + Summary */}
              <div className={`rounded-xl border p-4 ${healthBg(aiInsights.overall_health)}`}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Overall Health</span>
                  <span className={`text-sm font-bold capitalize ${healthColor(aiInsights.overall_health)}`}>
                    {aiInsights.overall_health}
                  </span>
                </div>
                <p className="text-sm text-slate-700 leading-relaxed">{aiInsights.summary}</p>
                {aiInsights.risk_observation && (
                  <p className="text-xs text-slate-500 mt-2 italic">{aiInsights.risk_observation}</p>
                )}
              </div>

              {/* Recurring Gaps */}
              {aiInsights.recurring_gaps?.length > 0 && (
                <div>
                  <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                    Identified Recurring Gaps
                  </h3>
                  <div className="space-y-3">
                    {aiInsights.recurring_gaps.map((gap, i) => (
                      <div key={i} className="flex gap-3 p-3 rounded-lg bg-slate-50 border border-slate-100">
                        <div className="w-7 h-7 rounded-full bg-rose-100 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-xs font-bold text-rose-600">{i + 1}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <span className="text-sm font-semibold text-slate-800">{gap.area}</span>
                            <Badge className={`text-[10px] px-1.5 py-0 ${severityColor(gap.severity)}`}>{gap.severity}</Badge>
                          </div>
                          <p className="text-xs text-slate-600 leading-relaxed">{gap.root_cause}</p>
                          {gap.frequency && (
                            <p className="text-[11px] text-slate-400 mt-1">{gap.frequency}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Improvement Plans */}
              {aiInsights.improvement_plans?.length > 0 && (
                <div>
                  <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3 flex items-center gap-1.5">
                    <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                    Actionable Improvement Plans
                  </h3>
                  <div className="space-y-3">
                    {aiInsights.improvement_plans.map((plan, i) => (
                      <div key={i} className="rounded-xl border border-slate-100 overflow-hidden">
                        <button
                          className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-50 transition-colors"
                          onClick={() => setExpandedPlan(expandedPlan === i ? null : i)}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
                              <Target className="w-4 h-4 text-emerald-600" />
                            </div>
                            <div className="text-left">
                              <p className="text-sm font-semibold text-slate-800">{plan.title}</p>
                              <p className="text-xs text-slate-500">{plan.area} · {plan.timeline}</p>
                            </div>
                          </div>
                          {expandedPlan === i ? (
                            <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                          )}
                        </button>
                        {expandedPlan === i && (
                          <div className="px-4 pb-4 bg-slate-50 border-t border-slate-100">
                            <ol className="space-y-2 mt-3">
                              {plan.steps?.map((step, si) => (
                                <li key={si} className="flex gap-2.5 text-xs text-slate-700">
                                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center shrink-0 mt-0.5 text-[10px]">
                                    {si + 1}
                                  </span>
                                  <span className="leading-relaxed pt-0.5">{step}</span>
                                </li>
                              ))}
                            </ol>
                            {plan.expected_impact && (
                              <div className="mt-3 flex gap-2 text-xs text-emerald-700 bg-emerald-50 rounded-lg p-2.5 border border-emerald-100">
                                <TrendingUp className="w-4 h-4 shrink-0 mt-0.5" />
                                <span><strong>Expected impact:</strong> {plan.expected_impact}</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}