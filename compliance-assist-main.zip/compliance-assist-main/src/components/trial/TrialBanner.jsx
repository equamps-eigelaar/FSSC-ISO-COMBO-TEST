import React, { useState, useEffect } from "react";
import { useTrialStatus } from "./useTrialStatus";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Clock, AlertTriangle, Lock, X } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const DISMISS_KEY = "subscription_reminder_dismissed_date";
const SHOW_DURATION_MS = 5 * 60 * 1000; // 5 minutes

export default function TrialBanner() {
  const { trialStatus, loading } = useTrialStatus();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (loading || !trialStatus || trialStatus.status === "active") return;

    const today = new Date().toDateString();
    const lastDismissed = localStorage.getItem(DISMISS_KEY);

    if (lastDismissed !== today) {
      setVisible(true);
      const timer = setTimeout(() => setVisible(false), SHOW_DURATION_MS);
      return () => clearTimeout(timer);
    }
  }, [loading, trialStatus]);

  const handleDismiss = () => {
    localStorage.setItem(DISMISS_KEY, new Date().toDateString());
    setVisible(false);
  };

  if (loading || !trialStatus) return null;

  if (trialStatus.status === "active") return null; // paid, no banner needed

  if (!visible) return null;

  if (trialStatus.status === "trial_expired") {
    return (
      <div className="bg-rose-600 text-white px-4 py-3 flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 flex-shrink-0" />
          <span className="text-sm font-medium">Your free trial has expired. Subscribe to continue using the Compliance Tracker.</span>
        </div>
        <div className="flex items-center gap-2">
          <Link to={createPageUrl("PricingPlans")}>
            <Button size="sm" variant="secondary" className="bg-white text-rose-600 hover:bg-rose-50 font-semibold select-none">
              View Plans
            </Button>
          </Link>
          <button onClick={handleDismiss} className="text-white/70 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  if (trialStatus.status === "trialing") {
    const isUrgent = trialStatus.daysLeft <= 2;
    return (
      <div className={`${isUrgent ? "bg-amber-500" : "bg-emerald-600"} text-white px-4 py-2.5 flex items-center justify-between gap-4 flex-wrap`}>
        <div className="flex items-center gap-2">
          {isUrgent ? (
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          ) : (
            <Clock className="w-4 h-4 flex-shrink-0" />
          )}
          <span className="text-sm font-medium">
            {trialStatus.daysLeft === 0
              ? "Your free trial expires today!"
              : `Free trial: ${trialStatus.daysLeft} day${trialStatus.daysLeft === 1 ? "" : "s"} remaining — full access included.`}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Link to={createPageUrl("PricingPlans")}>
            <Button size="sm" variant="secondary" className="bg-white text-emerald-700 hover:bg-emerald-50 font-semibold select-none text-xs">
              Subscribe Now
            </Button>
          </Link>
          <button onClick={handleDismiss} className="text-white/70 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return null;
}