import React, { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { SelectItem } from "@/components/ui/select";
import MobileSelect from "@/components/mobile/MobileSelect";
import { AlertTriangle, Sparkles, ShieldAlert } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import AIRiskRecommendations from "./AIRiskRecommendations";

const calculateRiskLevel = (likelihood, severity) => {
  const likelihoodScore = { rare: 1, unlikely: 2, possible: 3, likely: 4, almost_certain: 5 }[likelihood] || 0;
  const severityScore = { negligible: 1, minor: 2, moderate: 3, major: 4, catastrophic: 5 }[severity] || 0;
  const score = likelihoodScore * severityScore;
  
  if (score <= 4) return "low";
  if (score <= 10) return "medium";
  if (score <= 15) return "high";
  return "critical";
};

export default function RiskAssessmentDialog({ open, onClose, requirementId, assessment, requirement }) {
  const [form, setForm] = useState({
    requirement_id: requirementId,
    hazard_type: "biological",
    hazard_description: "",
    likelihood: "possible",
    severity: "moderate",
    risk_level: "medium",
    mitigation_strategy: "",
    residual_risk: "",
    review_date: "",
    status: "identified",
    is_ccp: false,
    is_oprp: false,
    ccp_number: "",
    critical_limits: "",
    monitoring_procedure: "",
    corrective_action_plan: "",
    verification_procedure: "",
  });
  const [loadingAI, setLoadingAI] = useState(false);
  const [autoScore, setAutoScore] = useState(null);

  const queryClient = useQueryClient();

  const { data: templates = [] } = useQuery({
    queryKey: ["risk-templates"],
    queryFn: () => base44.entities.RiskTemplate.list("-created_date", 100),
  });

  useEffect(() => {
    if (assessment) {
      setForm(assessment);
    } else {
      setForm({
        requirement_id: requirementId,
        hazard_type: "biological",
        hazard_description: "",
        likelihood: "possible",
        severity: "moderate",
        risk_level: "medium",
        mitigation_strategy: "",
        residual_risk: "",
        review_date: "",
        status: "identified",
        is_ccp: false,
        is_oprp: false,
        ccp_number: "",
        critical_limits: "",
        monitoring_procedure: "",
        corrective_action_plan: "",
        verification_procedure: "",
      });
    }
  }, [assessment, requirementId, open]);

  useEffect(() => {
    const riskLevel = calculateRiskLevel(form.likelihood, form.severity);
    setForm(prev => ({ ...prev, risk_level: riskLevel }));
  }, [form.likelihood, form.severity]);

  useEffect(() => {
    const fetchAutoScore = async () => {
      if (form.likelihood && form.severity) {
        try {
          const response = await base44.functions.invoke('calculateRiskScore', {
            likelihood: form.likelihood,
            severity: form.severity,
            hazard_type: form.hazard_type,
          });
          setAutoScore(response.data);
        } catch (error) {
          console.error('Failed to calculate risk score:', error);
        }
      }
    };
    fetchAutoScore();
  }, [form.likelihood, form.severity, form.hazard_type]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.RiskAssessment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["risk-assessments", requirementId] });
      onClose();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RiskAssessment.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["risk-assessments", requirementId] });
      onClose();
    },
  });

  const getAISuggestions = async () => {
    if (!requirement) {
      toast.error("Requirement details not available");
      return;
    }

    setLoadingAI(true);
    try {
      const prompt = `You are a packaging safety expert analyzing compliance requirements for package manufacturing. Based on the following compliance requirement, suggest potential packaging safety hazards and risk assessments.

Requirement Details:
- Clause: ${requirement.clause_number}
- Title: ${requirement.clause_title}
- Section: ${requirement.section}
- Description: ${requirement.description || "Not provided"}

Provide 3 different hazard scenarios (one biological, one chemical, one physical) with:
1. Hazard description
2. Likelihood (rare/unlikely/possible/likely/almost_certain)
3. Severity (negligible/minor/moderate/major/catastrophic)
4. Mitigation strategy

Focus on realistic, practical hazards specific to package manufacturing in packaging safety context.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            hazards: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  hazard_type: { type: "string", enum: ["biological", "chemical", "physical"] },
                  hazard_description: { type: "string" },
                  likelihood: { type: "string", enum: ["rare", "unlikely", "possible", "likely", "almost_certain"] },
                  severity: { type: "string", enum: ["negligible", "minor", "moderate", "major", "catastrophic"] },
                  mitigation_strategy: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (result.hazards && result.hazards.length > 0) {
        const firstHazard = result.hazards[0];
        setForm(prev => ({
          ...prev,
          hazard_type: firstHazard.hazard_type,
          hazard_description: firstHazard.hazard_description,
          likelihood: firstHazard.likelihood,
          severity: firstHazard.severity,
          mitigation_strategy: firstHazard.mitigation_strategy,
        }));
        toast.success("AI suggestions applied! Review and adjust as needed.");
      }
    } catch (error) {
      toast.error("Failed to get AI suggestions");
      console.error(error);
    } finally {
      setLoadingAI(false);
    }
  };

  const handleSubmit = () => {
    if (assessment) {
      const { id, created_date, updated_date, created_by, ...data } = form;
      updateMutation.mutate({ id: assessment.id, data });
    } else {
      createMutation.mutate(form);
    }
  };

  const handleApplyTemplate = (template) => {
    const reviewDate = new Date();
    reviewDate.setDate(reviewDate.getDate() + (template.review_frequency_days || 90));
    
    setForm(prev => ({
      ...prev,
      hazard_type: template.hazard_type,
      mitigation_strategy: template.standard_controls?.join('\n') || '',
      review_date: reviewDate.toISOString().split('T')[0],
      is_ccp: !!template.is_ccp_template,
      is_oprp: !!template.is_oprp_template,
      critical_limits: template.default_critical_limits || '',
      monitoring_procedure: template.default_monitoring_procedure || '',
      corrective_action_plan: template.default_corrective_action || '',
      verification_procedure: template.default_verification || '',
    }));
    toast.success('Template applied');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-rose-500" />
                {assessment ? "Edit" : "Add"} Risk Assessment
              </DialogTitle>
              {autoScore && (
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="text-xs">Score: {autoScore.risk_score}</Badge>
                  <Badge variant="outline" className="text-xs">Similar: {autoScore.similar_cases}</Badge>
                  <Badge variant="outline" className="text-xs">Review: {autoScore.recommended_review_days}d</Badge>
                </div>
              )}
            </div>
            {!assessment && requirement && (
              <Button
                variant="outline"
                size="sm"
                onClick={getAISuggestions}
                disabled={loadingAI}
                className="gap-2"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {loadingAI ? "Analyzing..." : "AI Suggestions"}
              </Button>
            )}
          </div>
        </DialogHeader>
        <div className="space-y-4 py-2">
          {!assessment && templates.length > 0 && (
            <div>
              <Label className="text-xs text-slate-500 mb-2 block">Quick Start from Template</Label>
              <div className="flex flex-wrap gap-2">
                {templates.filter(t => t.is_active).slice(0, 5).map(template => (
                  <Button
                    key={template.id}
                    variant="outline"
                    size="sm"
                    onClick={() => handleApplyTemplate(template)}
                    className="text-xs"
                  >
                    {template.name}
                  </Button>
                ))}
              </div>
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Hazard Type</Label>
              <MobileSelect value={form.hazard_type} onValueChange={(v) => setForm({ ...form, hazard_type: v })} placeholder="Select hazard type" label="Hazard Type" triggerClassName="w-full">
                <SelectItem value="biological">🦠 Biological</SelectItem>
                <SelectItem value="chemical">⚗️ Chemical</SelectItem>
                <SelectItem value="physical">🔩 Physical</SelectItem>
                <SelectItem value="radiological">☢️ Radiological</SelectItem>
                <SelectItem value="allergen">⚠️ Allergen</SelectItem>
              </MobileSelect>
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <MobileSelect value={form.status} onValueChange={(v) => setForm({ ...form, status: v })} placeholder="Select status" label="Status" triggerClassName="w-full">
                <SelectItem value="identified">Identified</SelectItem>
                <SelectItem value="under_control">Under Control</SelectItem>
                <SelectItem value="requires_action">Requires Action</SelectItem>
              </MobileSelect>
            </div>
          </div>

          <div>
            <Label className="text-xs">Hazard Description</Label>
            <Textarea
              placeholder="Describe the packaging safety hazard..."
              value={form.hazard_description}
              onChange={(e) => setForm({ ...form, hazard_description: e.target.value })}
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Likelihood</Label>
              <MobileSelect value={form.likelihood} onValueChange={(v) => setForm({ ...form, likelihood: v })} placeholder="Select likelihood" label="Likelihood" triggerClassName="w-full">
                <SelectItem value="rare">Rare</SelectItem>
                <SelectItem value="unlikely">Unlikely</SelectItem>
                <SelectItem value="possible">Possible</SelectItem>
                <SelectItem value="likely">Likely</SelectItem>
                <SelectItem value="almost_certain">Almost Certain</SelectItem>
              </MobileSelect>
            </div>
            <div>
              <Label className="text-xs">Severity</Label>
              <MobileSelect value={form.severity} onValueChange={(v) => setForm({ ...form, severity: v })} placeholder="Select severity" label="Severity" triggerClassName="w-full">
                <SelectItem value="negligible">Negligible</SelectItem>
                <SelectItem value="minor">Minor</SelectItem>
                <SelectItem value="moderate">Moderate</SelectItem>
                <SelectItem value="major">Major</SelectItem>
                <SelectItem value="catastrophic">Catastrophic</SelectItem>
              </MobileSelect>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <p className="text-xs text-slate-500 mb-1">Calculated Risk Level</p>
            <div className="flex items-center gap-2">
              <AlertTriangle className={`w-4 h-4 ${form.risk_level === 'critical' || form.risk_level === 'high' ? 'text-rose-500' : 'text-slate-400'}`} />
              <span className="text-sm font-semibold text-slate-900 uppercase">{form.risk_level}</span>
            </div>
          </div>

          <div>
            <Label className="text-xs">Mitigation Strategy / Control Measures</Label>
            <Textarea
              placeholder="Describe actions to control or reduce the risk..."
              value={form.mitigation_strategy}
              onChange={(e) => setForm({ ...form, mitigation_strategy: e.target.value })}
              rows={3}
            />
          </div>

          {/* AI Recommendations */}
          {!assessment && form.hazard_description && (
            <AIRiskRecommendations
              hazardType={form.hazard_type}
              hazardDescription={form.hazard_description}
              likelihood={form.likelihood}
              severity={form.severity}
              requirementId={requirementId}
              onApply={(strategy) => setForm({ ...form, mitigation_strategy: strategy })}
            />
          )}

          {/* HACCP Section */}
          <div className="border border-amber-200 bg-amber-50 rounded-lg p-4 space-y-4">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600" />
              <h3 className="text-sm font-semibold text-amber-800">HACCP Classification</h3>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_ccp"
                  checked={!!form.is_ccp}
                  onCheckedChange={(v) => setForm({ ...form, is_ccp: !!v, is_oprp: v ? false : form.is_oprp })}
                />
                <Label htmlFor="is_ccp" className="text-xs font-medium cursor-pointer">Critical Control Point (CCP)</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_oprp"
                  checked={!!form.is_oprp}
                  onCheckedChange={(v) => setForm({ ...form, is_oprp: !!v, is_ccp: v ? false : form.is_ccp })}
                />
                <Label htmlFor="is_oprp" className="text-xs font-medium cursor-pointer">Operational PRP (OPRP)</Label>
              </div>
            </div>

            {(form.is_ccp || form.is_oprp) && (
              <div className="space-y-3">
                <div>
                  <Label className="text-xs">{form.is_ccp ? "CCP" : "OPRP"} Reference Number</Label>
                  <Input
                    value={form.ccp_number || ""}
                    onChange={(e) => setForm({ ...form, ccp_number: e.target.value })}
                    placeholder={form.is_ccp ? "e.g. CCP-01" : "e.g. OPRP-01"}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-xs">Critical Limits</Label>
                  <Textarea
                    value={form.critical_limits || ""}
                    onChange={(e) => setForm({ ...form, critical_limits: e.target.value })}
                    placeholder="e.g. Temperature ≤ 4°C; pH ≤ 4.6; metal detection sensitivity ≥ 2mm Fe"
                    rows={2}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-xs">Monitoring Procedure</Label>
                  <Textarea
                    value={form.monitoring_procedure || ""}
                    onChange={(e) => setForm({ ...form, monitoring_procedure: e.target.value })}
                    placeholder="What is monitored, how, frequency, and who is responsible..."
                    rows={2}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-xs">Corrective Action Plan</Label>
                  <Textarea
                    value={form.corrective_action_plan || ""}
                    onChange={(e) => setForm({ ...form, corrective_action_plan: e.target.value })}
                    placeholder="Actions to take when critical limits are exceeded..."
                    rows={2}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-xs">Verification Procedure</Label>
                  <Textarea
                    value={form.verification_procedure || ""}
                    onChange={(e) => setForm({ ...form, verification_procedure: e.target.value })}
                    placeholder="How will control effectiveness be verified (calibration, testing, audits)..."
                    rows={2}
                    className="mt-1"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Residual Risk (After Mitigation)</Label>
              <MobileSelect value={form.residual_risk} onValueChange={(v) => setForm({ ...form, residual_risk: v })} placeholder="Select..." label="Residual Risk" triggerClassName="w-full">
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </MobileSelect>
            </div>
            <div>
              <Label className="text-xs">Review Date</Label>
              <Input
                type="date"
                value={form.review_date || ""}
                onChange={(e) => setForm({ ...form, review_date: e.target.value })}
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={handleSubmit}
            disabled={!form.hazard_description || createMutation.isPending || updateMutation.isPending}
            className="bg-rose-600 hover:bg-rose-700"
          >
            {createMutation.isPending || updateMutation.isPending ? "Saving..." : assessment ? "Update" : "Add"} Assessment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}