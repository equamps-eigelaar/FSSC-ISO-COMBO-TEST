import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Printer, FileText, CheckCircle2, XCircle, AlertCircle, MinusCircle } from "lucide-react";

const SECTIONS = [
  {
    title: "Personnel Facilities",
    items: [
      { id: "pf1", question: "Are Manufacturing Staff provided with separate toilets and changing facilities for males and females?" },
    ],
  },
  {
    title: "Health & Safety",
    items: [
      { id: "hs1", question: "Does the company have at least one trained first aid officer on site at all times of production?" },
      { id: "hs2", question: "Does the company have a trained health and safety representative on-site at all times of production?" },
      { id: "hs3", question: "Does the company have trained fire marshals in the case of a fire outbreak?" },
    ],
  },
  {
    title: "Receiving / Incoming Goods",
    items: [
      { id: "rg1", question: "Are received goods subject to a quality check?" },
      { id: "rg2", question: "Are Incoming Vehicle Inspection checks in place?" },
      { id: "rg3", question: "Are the receiving staff trained?" },
    ],
  },
  {
    title: "Dispatch / Outgoing Goods",
    items: [
      { id: "og1", question: "Are goods delivered by your vehicles?" },
      { id: "og2", question: "If not, is the delivery company in use being audited/monitored to ensure proper procedures are followed?" },
      { id: "og3", question: "Is there an Outgoing Vehicle Inspection check in place?" },
      { id: "og4", question: "Are the products being dispatched and checked by trained personnel?" },
      { id: "og5", question: "Are outgoing products supplied with COA's/COC?" },
    ],
  },
  {
    title: "Waste Management (Site of Manufacture)",
    items: [
      { id: "wm1", question: "How is the waste stored?", freeText: true },
    ],
  },
];

const VERIFICATION_DOCS = [
  { id: "vd1", label: "User's Site Valid Certification to applicable standards attached?" },
  { id: "vd2", label: "Product Specifications, TDSs, SDS and Statement of Compliance attached?" },
  { id: "vd3", label: "Traceability Test of the most recent product supplied to the manufacturer attached?" },
  { id: "vd4", label: "Allergen Declaration/Policy attached?" },
];

const RESPONSE_OPTIONS = [
  { value: "yes", label: "Yes", icon: CheckCircle2, color: "text-emerald-600" },
  { value: "no", label: "No", icon: XCircle, color: "text-rose-600" },
  { value: "na", label: "N/A", icon: MinusCircle, color: "text-slate-400" },
  { value: "partial", label: "Partial", icon: AlertCircle, color: "text-amber-500" },
];

const DOC_STATUS = [
  { value: "attached", label: "Attached", color: "bg-emerald-100 text-emerald-700" },
  { value: "pending", label: "Pending", color: "bg-amber-100 text-amber-700" },
  { value: "not_applicable", label: "N/A", color: "bg-slate-100 text-slate-600" },
  { value: "missing", label: "Missing", color: "bg-rose-100 text-rose-700" },
];

export default function FacilityRiskReport() {
  const [responses, setResponses] = useState({});
  const [notes, setNotes] = useState({});
  const [freeText, setFreeText] = useState({});
  const [docStatus, setDocStatus] = useState({});

  const setResponse = (id, value) => setResponses(prev => ({ ...prev, [id]: value }));
  const setNote = (id, value) => setNotes(prev => ({ ...prev, [id]: value }));
  const setFreeTextVal = (id, value) => setFreeText(prev => ({ ...prev, [id]: value }));
  const setDoc = (id, value) => setDocStatus(prev => ({ ...prev, [id]: value }));

  const handlePrint = () => window.print();

  const totalItems = SECTIONS.reduce((acc, s) => acc + s.items.length, 0);
  const answered = Object.keys(responses).length;
  const yesCount = Object.values(responses).filter(v => v === "yes").length;
  const noCount = Object.values(responses).filter(v => v === "no").length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-0 shadow-sm bg-gradient-to-r from-emerald-50 to-slate-50">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <CardTitle className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                Facility Risk Report Template
              </CardTitle>
              <p className="text-sm text-slate-500 mt-1">Complete all sections to generate a facility risk assessment report</p>
            </div>
            <Button variant="outline" size="sm" onClick={handlePrint} className="print:hidden">
              <Printer className="w-4 h-4 mr-2" />
              Print
            </Button>
          </div>
          {/* Progress */}
          <div className="flex flex-wrap gap-3 mt-3">
            <Badge className="bg-slate-100 text-slate-600">{answered}/{totalItems} Answered</Badge>
            <Badge className="bg-emerald-100 text-emerald-700">{yesCount} Yes</Badge>
            <Badge className="bg-rose-100 text-rose-700">{noCount} No</Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Question Sections */}
      {SECTIONS.map(section => (
        <Card key={section.title} className="border-0 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-3">
            <CardTitle className="text-sm font-semibold text-slate-800">{section.title}</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {section.items.map((item, idx) => (
              <div key={item.id} className={`p-4 ${idx < section.items.length - 1 ? "border-b border-slate-50" : ""}`}>
                <p className="text-sm text-slate-700 font-medium mb-3">{item.question}</p>
                {item.freeText ? (
                  <textarea
                    className="w-full text-sm border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none min-h-[80px]"
                    placeholder="Describe waste storage procedures..."
                    value={freeText[item.id] || ""}
                    onChange={e => setFreeTextVal(item.id, e.target.value)}
                  />
                ) : (
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-2">
                      {RESPONSE_OPTIONS.map(opt => {
                        const Icon = opt.icon;
                        const selected = responses[item.id] === opt.value;
                        return (
                          <button
                            key={opt.value}
                            onClick={() => setResponse(item.id, opt.value)}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all
                              ${selected
                                ? "border-emerald-500 bg-emerald-50 text-emerald-700 shadow-sm"
                                : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50"
                              }`}
                          >
                            <Icon className={`w-3.5 h-3.5 ${selected ? "text-emerald-600" : opt.color}`} />
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                    <input
                      className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-600 placeholder:text-slate-400"
                      placeholder="Add notes or observations (optional)..."
                      value={notes[item.id] || ""}
                      onChange={e => setNote(item.id, e.target.value)}
                    />
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      ))}

      {/* Verification of Required Documents */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-3">
          <CardTitle className="text-sm font-semibold text-slate-800">Verification of Required Documents</CardTitle>
          <p className="text-xs text-slate-500 mt-0.5">Confirm status of all required supporting documentation</p>
        </CardHeader>
        <CardContent className="p-0">
          {VERIFICATION_DOCS.map((doc, idx) => (
            <div key={doc.id} className={`p-4 ${idx < VERIFICATION_DOCS.length - 1 ? "border-b border-slate-50" : ""}`}>
              <p className="text-sm text-slate-700 font-medium mb-2">{doc.label}</p>
              <div className="flex flex-wrap gap-2">
                {DOC_STATUS.map(s => {
                  const selected = docStatus[doc.id] === s.value;
                  return (
                    <button
                      key={s.value}
                      onClick={() => setDoc(doc.id, s.value)}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all
                        ${selected
                          ? `${s.color} border-current shadow-sm`
                          : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                        }`}
                    >
                      {s.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Summary */}
      <Card className="border-0 shadow-sm bg-slate-50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-slate-800">Report Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-slate-600">
          <div className="flex justify-between"><span>Total Questions</span><span className="font-semibold">{totalItems}</span></div>
          <div className="flex justify-between"><span>Answered</span><span className="font-semibold">{answered}</span></div>
          <div className="flex justify-between text-emerald-700"><span>Compliant (Yes)</span><span className="font-semibold">{yesCount}</span></div>
          <div className="flex justify-between text-rose-600"><span>Non-Compliant (No)</span><span className="font-semibold">{noCount}</span></div>
          <div className="flex justify-between"><span>Partial / N/A</span><span className="font-semibold">{answered - yesCount - noCount}</span></div>
          <div className="flex justify-between"><span>Documents Verified</span><span className="font-semibold">{Object.values(docStatus).filter(v => v === "attached").length}/{VERIFICATION_DOCS.length}</span></div>
        </CardContent>
      </Card>
    </div>
  );
}