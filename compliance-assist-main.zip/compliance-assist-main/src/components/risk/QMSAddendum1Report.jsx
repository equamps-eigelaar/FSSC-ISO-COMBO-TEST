import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Printer, FileText, CheckCircle2, XCircle, MinusCircle, ChevronDown, ChevronUp } from "lucide-react";

const CHEMICALS = [
  {
    chemical: "4-Methylbenzophenone",
    description: "4-Methylbenzophenone is found in the raw materials of certain UV curing inks and varnishes. Packaging suppliers should provide letter of declaration to confirm that 4-Methylbenzophenone free inks are used for food packaging.",
    action: "Ensure declaration letter received from relevant suppliers; Food suppliers are responsible for specifying 4-Methylbenzophenone free food packaging.",
  },
  {
    chemical: "ITX (2-isopropyl thioxanthone)",
    description: "ITX is found in the raw materials of certain UV curing inks and varnishes. Packaging suppliers should provide letter of declaration to confirm that ITX free inks are used for food packaging.",
    action: "Ensure declaration letter received from relevant suppliers; Food suppliers are responsible for specifying ITX free packaging.",
  },
  {
    chemical: "Michler's Ketone (4,4'-bis(dimethylamino)benzophenone)",
    description: "Michler's ketone is an intermediate in the production of dyes and pigments for paper board. It can be present in recycled paper and board packaging. Limit: below 0.0016 mg/dm².",
    action: "Ensure declaration letter received from relevant suppliers; Specify limit of 0.0016 mg/dm² for food packaging and that the presence of Michler's ketone in food is not detectable.",
  },
  {
    chemical: "DEAB (4,4'-bis(diethylamino)benzophenone)",
    description: "DEAB is an intermediate in the production of dyes and pigments for paper and board. It can also be present in recycled paper and board packaging. Limit: below 0.0016 mg/dm².",
    action: "Ensure declaration letter received from relevant suppliers; Specify limit of 0.0016 mg/dm² for food packaging and that the presence of DEAB in food is not detectable.",
  },
  {
    chemical: "DIBP (Di–Iso Butyl Phthalate)",
    description: "DIBP is found in paper and board packaging due to phthalate containing glues used in non-food contact packaging entering the recycling waste stream. Packaging suppliers should provide letter of declaration to confirm that DIBP-free packaging is supplied for food products.",
    action: "Ensure declaration letter received from relevant suppliers; Food suppliers are responsible for specifying DIBP-free food packaging.",
  },
  {
    chemical: "PAHs (Polycyclic Aromatic Hydrocarbons)",
    description: "PAHs are known for their carcinogenic, mutagenic, and teratogenic properties. The sum of listed PAH's tested in paper and board packaging must be below 0.0016 mg/dm².",
    action: "Ensure declaration letter received from relevant suppliers; Ensure the sum of listed PAH's tested in paper and board packaging is below 0.0016 mg/dm².",
  },
  {
    chemical: "PVC (Polyvinyl Chloride) and its derivatives",
    description: "Hazardous substances are released during the production, incineration, and/or disposal of PVC and its derivatives. These include VCM, chloride, ethylene dichloride, HCl, chlorine, alkyltins, phthalates, heavy metals, and dioxins.",
    action: "Ensure PVC and its derivatives free packaging is supplied for food products; Specify PVC and PVdC free packaging materials.",
  },
  {
    chemical: "VCM (Vinyl Chloride Monomer)",
    description: "VCM in food contact materials is regulated by Council Directive 78/142/EEC. Residual content of VCM in finished material or article is limited to 1 mg/kg. VCM should not be detectable in foodstuffs.",
    action: "Provide a compliance letter of declaration that VCM in supplied packaging material does not exceed the limits imposed by 78/142/EEC; Ensure VCM restrictions in packaging and food products are met.",
  },
  {
    chemical: "Triclosan (2,4,4'-trichloro-2'-hydroxydiphenyl ether)",
    description: "Triclosan is an antibacterial and antifungal agent associated with endocrine disruption. Removed from additives permitted in plastic materials intended for food contact under Directive 2002/72/EC.",
    action: "Provide a letter of declaration to confirm that Triclosan free packaging is supplied for food packaging; Specify Triclosan free food packaging.",
  },
  {
    chemical: "BADGE, BFDGE and NOGE",
    description: "Regulation (EC) 1895/2005 permits BADGE use within SML of 9 mg/kg in food or 9 mg/6dm². Packaging containing BADGE must be accompanied by a written declaration of compliance.",
    action: "Ensure packaging complies with SML in 1895/2005/EC; Provide written declaration; Provide letter of declaration for BFDGE and NOGE-free packaging.",
  },
  {
    chemical: "Heavy Metals",
    description: "Per EC Packaging Directive 94/62/EC, the sum of lead, cadmium, mercury, and hexavalent chromium must not exceed 100 ppm on or after 30 June 2001.",
    action: "Provide a letter of declaration for compliance with 94/62/EC and BFR Recommendation XXXVI for food packaging; Ensure heavy metal restrictions in packaging are met.",
  },
  {
    chemical: "PFOS (Perfluoro-octanesulfonic acid)",
    description: "PFOS and related chemicals are used in grease resistant coatings in paper/carton board. PFOS is persistent, bioaccumulative, and toxic. Practically banned in the EU since 2006 (2006/122/EC).",
    action: "Provide a letter of declaration to confirm PFOS free packaging is supplied for food products; Specify PFOS free food packaging.",
  },
  {
    chemical: "PFOA (Perfluoro-octanoic acid)",
    description: "PFOA and its salts are used in water and oil repellent coatings and chemicals in paper/carton board. PFOA poses health risks similar to PFOS.",
    action: "Provide a letter of declaration if any packaging contains PFOA; Ensure a letter of declaration for PFOA containing packaging is received.",
  },
  {
    chemical: "Oxo Degradable Additives",
    description: "Oxo degradable packaging systems are not considered compostable. These plastics contaminate the recycling stream and reduce the quality of recycled polymers. Small particles may pose risks to wildlife.",
    action: "Provide a letter of declaration to confirm that Oxo degradable additives are not used for food packaging; Specify Oxo degradable free food packaging.",
  },
];

const COMPLIANCE_OPTIONS = [
  { value: "compliant", label: "Compliant", icon: CheckCircle2, cls: "border-emerald-500 bg-emerald-50 text-emerald-700" },
  { value: "non_compliant", label: "Non-Compliant", icon: XCircle, cls: "border-rose-500 bg-rose-50 text-rose-700" },
  { value: "na", label: "N/A", icon: MinusCircle, cls: "border-slate-400 bg-slate-100 text-slate-600" },
];

export default function QMSAddendum1Report() {
  const [responses, setResponses] = useState({});
  const [notes, setNotes] = useState({});
  const [companyName, setCompanyName] = useState("");
  const [signedBy, setSignedBy] = useState("");
  const [signDate, setSignDate] = useState("");
  const [expanded, setExpanded] = useState({});

  const setResponse = (chemical, value) => setResponses(prev => ({ ...prev, [chemical]: value }));
  const setNote = (chemical, value) => setNotes(prev => ({ ...prev, [chemical]: value }));
  const toggleExpand = (chemical) => setExpanded(prev => ({ ...prev, [chemical]: !prev[chemical] }));

  const total = CHEMICALS.length;
  const compliant = Object.values(responses).filter(v => v === "compliant").length;
  const nonCompliant = Object.values(responses).filter(v => v === "non_compliant").length;
  const naCount = Object.values(responses).filter(v => v === "na").length;
  const answered = Object.keys(responses).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-0 shadow-sm bg-gradient-to-r from-blue-50 to-slate-50">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs font-semibold text-blue-600 uppercase tracking-wide mb-1">Addendum 1</p>
              <CardTitle className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Raw Materials Supplier QMS Self Assessment
              </CardTitle>
              <p className="text-xs text-slate-500 mt-1">
                Complete this section. If not applicable, indicate N/A in the Compliance column.
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={() => window.print()} className="print:hidden shrink-0">
              <Printer className="w-4 h-4 mr-2" />
              Print
            </Button>
          </div>
          <div className="flex flex-wrap gap-2 mt-3">
            <Badge className="bg-slate-100 text-slate-600">{answered}/{total} Reviewed</Badge>
            <Badge className="bg-emerald-100 text-emerald-700">{compliant} Compliant</Badge>
            <Badge className="bg-rose-100 text-rose-700">{nonCompliant} Non-Compliant</Badge>
            <Badge className="bg-slate-100 text-slate-500">{naCount} N/A</Badge>
          </div>
        </CardHeader>
      </Card>

      {/* Chemical Items */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-3">
          <CardTitle className="text-sm font-semibold text-slate-800">Chemical Compliance Assessment</CardTitle>
        </CardHeader>
        <CardContent className="p-0 divide-y divide-slate-50">
          {CHEMICALS.map((item, idx) => {
            const selected = responses[item.chemical];
            const isExpanded = expanded[item.chemical];
            return (
              <div key={idx} className="p-4">
                {/* Top row: chemical name + compliance buttons */}
                <div className="flex items-start gap-3 flex-wrap sm:flex-nowrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-slate-800">{item.chemical}</p>
                      <button
                        onClick={() => toggleExpand(item.chemical)}
                        className="text-slate-400 hover:text-slate-600 transition-colors"
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                    {isExpanded && (
                      <div className="mt-2 space-y-2">
                        <p className="text-xs text-slate-600 leading-relaxed">{item.description}</p>
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5">
                          <p className="text-xs font-semibold text-amber-700 mb-0.5">Action Required</p>
                          <p className="text-xs text-amber-800 leading-relaxed">{item.action}</p>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-1.5 shrink-0">
                    {COMPLIANCE_OPTIONS.map(opt => {
                      const Icon = opt.icon;
                      const isSelected = selected === opt.value;
                      return (
                        <button
                          key={opt.value}
                          onClick={() => setResponse(item.chemical, opt.value)}
                          className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all
                            ${isSelected ? opt.cls + " shadow-sm" : "border-slate-200 bg-white text-slate-500 hover:border-slate-300"}`}
                        >
                          <Icon className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">{opt.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
                {/* Notes */}
                <input
                  className="mt-2 w-full text-xs border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-600 placeholder:text-slate-400"
                  placeholder="Notes or observations..."
                  value={notes[item.chemical] || ""}
                  onChange={e => setNote(item.chemical, e.target.value)}
                />
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Sign Off */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-3">
          <CardTitle className="text-sm font-semibold text-slate-800">Company Sign-Off</CardTitle>
        </CardHeader>
        <CardContent className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Company Name</label>
            <input
              className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
              value={companyName}
              onChange={e => setCompanyName(e.target.value)}
              placeholder="Enter company name..."
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Name & Signature</label>
            <input
              className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
              value={signedBy}
              onChange={e => setSignedBy(e.target.value)}
              placeholder="Full name..."
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Date</label>
            <input
              type="date"
              className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500"
              value={signDate}
              onChange={e => setSignDate(e.target.value)}
            />
          </div>
        </CardContent>
        <div className="px-4 pb-4">
          <p className="text-xs text-slate-400">
            Please return the completed assessment, signed and with copies attached to vicky@unsam.co.za
          </p>
        </div>
      </Card>

      {/* Summary */}
      <Card className="border-0 shadow-sm bg-slate-50">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-slate-800">Assessment Summary</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="bg-white rounded-lg p-3 shadow-sm">
            <div className="text-2xl font-bold text-slate-700">{total}</div>
            <div className="text-xs text-slate-500 mt-1">Total Items</div>
          </div>
          <div className="bg-emerald-50 rounded-lg p-3 shadow-sm">
            <div className="text-2xl font-bold text-emerald-700">{compliant}</div>
            <div className="text-xs text-emerald-600 mt-1">Compliant</div>
          </div>
          <div className="bg-rose-50 rounded-lg p-3 shadow-sm">
            <div className="text-2xl font-bold text-rose-700">{nonCompliant}</div>
            <div className="text-xs text-rose-600 mt-1">Non-Compliant</div>
          </div>
          <div className="bg-slate-100 rounded-lg p-3 shadow-sm">
            <div className="text-2xl font-bold text-slate-600">{total - answered}</div>
            <div className="text-xs text-slate-500 mt-1">Pending Review</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}