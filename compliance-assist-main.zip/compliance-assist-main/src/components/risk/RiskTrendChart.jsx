import React, { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, ReferenceLine
} from "recharts";
import { format, subMonths, startOfMonth, endOfMonth, parseISO } from "date-fns";

const LEVEL_COLORS = {
  critical: "#f43f5e",
  high: "#f97316",
  medium: "#f59e0b",
  low: "#10b981",
  total: "#6366f1",
};

function buildMonthlyTrend(risks) {
  const now = new Date();
  const months = Array.from({ length: 6 }, (_, i) => {
    const d = subMonths(now, 5 - i);
    return {
      label: format(d, "MMM yy"),
      start: startOfMonth(d),
      end: endOfMonth(d),
    };
  });

  return months.map(({ label, start, end }) => {
    // Risks that existed (were created) by the end of this month
    const active = risks.filter(r => {
      const created = r.created_date ? new Date(r.created_date) : null;
      return created && created <= end;
    });

    const critical = active.filter(r => r.risk_level === "critical").length;
    const high = active.filter(r => r.risk_level === "high").length;
    const medium = active.filter(r => r.risk_level === "medium").length;
    const low = active.filter(r => r.risk_level === "low").length;

    return { label, total: active.length, critical, high, medium, low };
  });
}

function Trend({ current, previous, label }) {
  if (previous === undefined || previous === null) return null;
  const diff = current - previous;
  if (diff === 0) return (
    <span className="flex items-center gap-0.5 text-slate-500 text-xs">
      <Minus className="w-3 h-3" /> No change
    </span>
  );
  // For risks, going down is good (green), going up is bad (red)
  const isGood = diff < 0;
  return (
    <span className={`flex items-center gap-0.5 text-xs font-semibold ${isGood ? "text-emerald-600" : "text-rose-600"}`}>
      {isGood ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
      {isGood ? "" : "+"}{diff} {label}
    </span>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-lg p-3 text-xs min-w-[150px]">
      <p className="font-semibold text-slate-700 mb-2">{label}</p>
      {payload.map((p) => (
        <div key={p.dataKey} className="flex items-center justify-between gap-4 mb-1">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: p.color }} />
            <span className="capitalize text-slate-600">{p.dataKey}</span>
          </span>
          <span className="font-bold text-slate-800">{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function RiskTrendChart({ risks = [] }) {
  const trendData = useMemo(() => buildMonthlyTrend(risks), [risks]);

  const lastMonth = trendData[trendData.length - 1];
  const prevMonth = trendData[trendData.length - 2];

  const summaryStats = [
    { label: "Critical", key: "critical", color: LEVEL_COLORS.critical },
    { label: "High", key: "high", color: LEVEL_COLORS.high },
    { label: "Medium", key: "medium", color: LEVEL_COLORS.medium },
    { label: "Low", key: "low", color: LEVEL_COLORS.low },
  ];

  if (risks.length === 0) return null;

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <CardTitle className="text-sm font-semibold text-slate-800 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-500" />
              Risk Trend — Last 6 Months
            </CardTitle>
            <p className="text-xs text-slate-500 mt-0.5">
              Cumulative risk counts by severity level over time
            </p>
          </div>
          {/* Month-over-month summary */}
          <div className="flex flex-wrap gap-3">
            {summaryStats.map(s => (
              <div key={s.key} className="flex flex-col items-end">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="w-2 h-2 rounded-full" style={{ background: s.color }} />
                  <span className="text-xs text-slate-500">{s.label}</span>
                </div>
                <span className="text-base font-bold" style={{ color: s.color }}>
                  {lastMonth?.[s.key] ?? 0}
                </span>
                <Trend current={lastMonth?.[s.key] ?? 0} previous={prevMonth?.[s.key]} label="vs prev" />
              </div>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-2">
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={trendData} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis
              dataKey="label"
              tick={{ fontSize: 11, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 11, fill: "#94a3b8" }}
              axisLine={false}
              tickLine={false}
              allowDecimals={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              iconType="circle"
              iconSize={8}
              wrapperStyle={{ fontSize: 11, paddingTop: 12 }}
            />
            <Line
              type="monotone"
              dataKey="total"
              name="Total"
              stroke={LEVEL_COLORS.total}
              strokeWidth={2.5}
              dot={{ r: 3, fill: LEVEL_COLORS.total }}
              activeDot={{ r: 5 }}
              strokeDasharray="5 3"
            />
            <Line
              type="monotone"
              dataKey="critical"
              name="Critical"
              stroke={LEVEL_COLORS.critical}
              strokeWidth={2}
              dot={{ r: 3, fill: LEVEL_COLORS.critical }}
              activeDot={{ r: 5 }}
            />
            <Line
              type="monotone"
              dataKey="high"
              name="High"
              stroke={LEVEL_COLORS.high}
              strokeWidth={2}
              dot={{ r: 3, fill: LEVEL_COLORS.high }}
              activeDot={{ r: 5 }}
            />
            <Line
              type="monotone"
              dataKey="medium"
              name="Medium"
              stroke={LEVEL_COLORS.medium}
              strokeWidth={2}
              dot={{ r: 3, fill: LEVEL_COLORS.medium }}
              activeDot={{ r: 5 }}
            />
            <Line
              type="monotone"
              dataKey="low"
              name="Low"
              stroke={LEVEL_COLORS.low}
              strokeWidth={2}
              dot={{ r: 3, fill: LEVEL_COLORS.low }}
              activeDot={{ r: 5 }}
            />
          </LineChart>
        </ResponsiveContainer>
        <p className="text-[10px] text-slate-400 mt-2 text-center">
          Counts reflect risks registered by end of each month · Downward trend indicates safety improvement
        </p>
      </CardContent>
    </Card>
  );
}