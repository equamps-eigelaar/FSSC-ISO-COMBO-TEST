import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";

const DISCLAIMER_KEY = "compliance_disclaimer_accepted";

export default function DisclaimerDialog() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [isAccepted, setIsAccepted] = useState(false);

  useEffect(() => {
    const hasAccepted = localStorage.getItem(DISCLAIMER_KEY) === "true";
    if (!hasAccepted) {
      setIsOpen(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(DISCLAIMER_KEY, "true");
    setIsOpen(false);
    navigate(createPageUrl("Dashboard"));
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col" onPointerDownOutside={(e) => e.preventDefault()}>
         <DialogHeader className="shrink-0">
           <DialogTitle className="flex items-center gap-2 text-rose-600">
             <AlertTriangle className="w-5 h-5" />
             Legal Disclaimer
           </DialogTitle>
         </DialogHeader>

         <div className="space-y-4 overflow-y-auto flex-1">
          <Alert className="border-rose-200 bg-rose-50">
            <AlertTriangle className="h-4 w-4 text-rose-600" />
            <AlertDescription className="text-rose-900 ml-2">
              Please read and accept the terms below before using this application.
            </AlertDescription>
          </Alert>

          <div className="space-y-4 text-sm text-slate-600">
            <div>
              <h3 className="font-semibold text-slate-900 mb-2">User Responsibility</h3>
              <p>
                It is the user's responsibility to adhere to all requirements outlined in the compliance clauses and standards referenced in this application. This application is provided as a management tool to assist with compliance tracking and documentation, but does not guarantee compliance with applicable regulations or standards.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Third-Party Audits</h3>
              <p>
                We strongly recommend that both this application and your organization's current compliance level be thoroughly reviewed and validated by an independent third-party auditor before, during, and after any external audit by regulatory bodies or certification auditors. No digital tool can substitute for professional audit verification.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-slate-900 mb-2">Limitation of Liability</h3>
              <p>
                While this application strives to provide accurate compliance information, it is provided "as is" without warranties of any kind. Users acknowledge that compliance with regulations is their sole responsibility, and this application should be used in conjunction with professional compliance guidance.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-start gap-3 py-3 border-t border-slate-200 shrink-0">
          <Checkbox
            id="accept-disclaimer"
            checked={isAccepted}
            onCheckedChange={setIsAccepted}
            className="mt-1"
          />
          <label
            htmlFor="accept-disclaimer"
            className="text-sm text-slate-600 cursor-pointer flex-1 leading-relaxed"
          >
            I understand and accept responsibility for ensuring compliance with all applicable requirements. I acknowledge that this application is a management tool and recommend independent third-party review before external audits.
          </label>
        </div>

        <DialogFooter className="gap-2 shrink-0">
          <Button
            onClick={handleAccept}
            disabled={!isAccepted}
            className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Agree
          </Button>
          <Button
            onClick={handleAccept}
            variant="outline"
            className="text-rose-600 hover:text-rose-700 hover:bg-rose-50 border-rose-200"
            title="Accept without reading (not recommended)"
          >
            Accept & Continue
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}