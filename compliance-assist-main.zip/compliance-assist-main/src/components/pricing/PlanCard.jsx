import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, FileDown } from "lucide-react";
import PayPalButton from "./PayPalButton";
import { toast } from "sonner";

function downloadQuotePDF(plan, billingCycle) {
  const price = billingCycle === "annual"
    ? (plan.price_annual || Math.round(plan.price_monthly * 0.85))
    : plan.price_monthly;
  const annual = plan.price_annual || Math.round(plan.price_monthly * 0.85);
  const today = new Date().toLocaleDateString("en-ZA");
  const validUntil = new Date(Date.now() + 30 * 86400000).toLocaleDateString("en-ZA");

  const html = `
<!DOCTYPE html><html><head><meta charset="utf-8"/>
<style>
  body{font-family:Arial,sans-serif;color:#1e293b;padding:40px;max-width:700px;margin:auto}
  .logo{display:flex;align-items:center;gap:12px;margin-bottom:32px}
  .logo-icon{background:#059669;color:#fff;border-radius:8px;width:40px;height:40px;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:bold}
  h1{font-size:22px;font-weight:800;color:#0f172a;margin:0}
  .sub{font-size:12px;color:#64748b}
  .section{margin:24px 0;padding:20px;border:1px solid #e2e8f0;border-radius:8px}
  .section h2{font-size:14px;text-transform:uppercase;letter-spacing:1px;color:#64748b;margin:0 0 12px 0}
  .row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f1f5f9;font-size:14px}
  .row:last-child{border-bottom:none;font-weight:700;font-size:16px;padding-top:10px}
  .feature{font-size:13px;padding:4px 0;color:#374151}
  .badge{display:inline-block;background:#d1fae5;color:#065f46;border-radius:20px;padding:2px 10px;font-size:11px;font-weight:600;margin-bottom:8px}
  .footer{margin-top:40px;font-size:11px;color:#94a3b8;border-top:1px solid #e2e8f0;padding-top:16px}
</style></head><body>
<div class="logo"><div class="logo-icon">✓</div><div><h1>FSSC 22000 Compliance Monitoring</h1><div class="sub">Pricing Quote</div></div></div>
<div class="section">
  <h2>Quote Details</h2>
  <div class="row"><span>Date</span><span>${today}</span></div>
  <div class="row"><span>Valid Until</span><span>${validUntil}</span></div>
  <div class="row"><span>Plan</span><span>${plan.name}</span></div>
  <div class="row"><span>Billing Cycle</span><span>${billingCycle === "annual" ? "Annual" : "Monthly"}</span></div>
</div>
<div class="section">
  <h2>Pricing</h2>
  ${plan.tagline ? `<div class="badge">${plan.tagline}</div>` : ""}
  <div class="row"><span>Monthly Rate</span><span>R ${plan.price_monthly?.toLocaleString()}</span></div>
  <div class="row"><span>Annual Rate</span><span>R ${annual?.toLocaleString()}/mo</span></div>
  ${plan.max_users > 0 ? `<div class="row"><span>Max Users</span><span>${plan.max_users}</span></div>` : ""}
  <div class="row"><span>Total (${billingCycle === "annual" ? "12 months" : "1 month"})</span><span>R ${(billingCycle === "annual" ? annual * 12 : price)?.toLocaleString()} ZAR</span></div>
</div>
<div class="section">
  <h2>Included Features</h2>
  ${(plan.features || []).map(f => `<div class="feature">✓ ${f}</div>`).join("")}
</div>
<div class="footer">
  Prices exclude VAT where applicable. This quote is valid for 30 days. Invoiced via Xero. 
  Contact us to confirm your subscription.
</div>
</body></html>`;

  const w = window.open("", "_blank");
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 500);
}

export default function PlanCard({ plan, billingCycle, onSelect, onCreateInvoice, isAdmin = false, currentSubscription = null }) {
  const [showPayPal, setShowPayPal] = useState(false);
  const price = billingCycle === "annual"
    ? (plan.price_annual || Math.round(plan.price_monthly * 0.85))
    : plan.price_monthly;

  const annualSavings = plan.price_monthly > 0
    ? Math.round((plan.price_monthly - (plan.price_annual || Math.round(plan.price_monthly * 0.85))) * 12)
    : 0;

  const tierColors = {
    base: "border-slate-200 bg-white",
    basic: "border-slate-200 bg-white",
    pro: "border-emerald-500 bg-white ring-2 ring-emerald-500",
    compliance: "border-emerald-500 bg-white ring-2 ring-emerald-500",
    enterprise: "border-slate-700 bg-slate-900 text-white",
  };

  const isEnterprise = plan.tier === "enterprise";
  const isPro = plan.tier === "pro";

  return (
    <Card className={`relative flex flex-col h-full transition-shadow hover:shadow-xl ${tierColors[plan.tier] || "border-slate-200 bg-white"}`}>
      {currentSubscription?.plan_id === plan.id && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <Badge className="bg-blue-600 text-white px-4 py-1 text-xs font-semibold shadow">
            Your Current Plan
          </Badge>
        </div>
      )}
      {plan.is_popular && currentSubscription?.plan_id !== plan.id && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <Badge className="bg-emerald-600 text-white px-4 py-1 text-xs font-semibold shadow">
            Most Popular
          </Badge>
        </div>
      )}

      <CardHeader className="pb-4 pt-8 px-6">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className={`text-xl font-bold ${isEnterprise ? "text-white" : "text-slate-900"}`}>
              {plan.name}
            </h3>
            {plan.tagline && (
              <p className={`text-sm mt-1 ${isEnterprise ? "text-slate-300" : "text-slate-500"}`}>
                {plan.tagline}
              </p>
            )}
          </div>
        </div>

        <div className="mt-4">
          {plan.price_monthly === 0 ? (
            <div className={`text-4xl font-extrabold ${isEnterprise ? "text-white" : "text-slate-900"}`}>
              Custom
            </div>
          ) : (
            <>
              <div className="flex items-end gap-1">
                <span className={`text-sm font-medium mt-1 ${isEnterprise ? "text-slate-300" : "text-slate-500"}`}>R</span>
                <span className={`text-4xl font-extrabold leading-none ${isEnterprise ? "text-white" : "text-slate-900"}`}>
                  {price.toLocaleString()}
                </span>
                <span className={`text-sm mb-1 ${isEnterprise ? "text-slate-300" : "text-slate-500"}`}>
                  {plan.plan_type === "once_off" ? "" : plan.plan_type === "hourly" ? "/hr" : plan.plan_type === "per_person" ? "/person" : "/mo"}
                </span>
              </div>
              {plan.price_usd > 0 && (
                <p className={`text-xs mt-1 font-medium ${isEnterprise ? "text-slate-400" : "text-slate-400"}`}>
                  OR ${plan.price_usd.toLocaleString()}{plan.plan_type === "once_off" ? "" : plan.plan_type === "hourly" ? "/hr" : plan.plan_type === "per_person" ? "/person" : "/mo"}
                </p>
              )}
              {billingCycle === "annual" && annualSavings > 0 && plan.plan_type === "subscription" && (
                <p className="text-xs text-emerald-600 font-medium mt-1">
                  Save R{annualSavings.toLocaleString()}/year
                </p>
              )}
              {plan.plan_type === "once_off" && (
                <p className="text-xs text-amber-600 font-medium mt-1">Once-off payment</p>
              )}
            </>
          )}
          {plan.max_users > 0 && (
            <p className={`text-xs mt-2 ${isEnterprise ? "text-slate-400" : "text-slate-400"}`}>
              Up to {plan.max_users} users
            </p>
          )}
          {plan.max_users === 0 && (
            <p className={`text-xs mt-2 ${isEnterprise ? "text-slate-400" : "text-slate-400"}`}>
              Unlimited users
            </p>
          )}
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col px-6 pb-8">
        <ul className="space-y-2.5 mb-8 flex-1">
          {(plan.features || []).map((feature, i) => (
            <li key={i} className="flex items-start gap-2.5">
              <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${isEnterprise ? "text-emerald-400" : "text-emerald-600"}`} />
              <span className={`text-sm ${isEnterprise ? "text-slate-300" : "text-slate-600"}`}>{feature}</span>
            </li>
          ))}
        </ul>

        <div className="space-y-2">
          {onSelect && (
            <Button
              onClick={() => {
                if (!isAdmin && plan.price_monthly > 0) {
                  setShowPayPal(v => !v);
                } else {
                  onSelect(plan);
                }
              }}
              className={`w-full font-semibold ${
                isPro
                  ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                  : isEnterprise
                  ? "bg-white text-slate-900 hover:bg-slate-100"
                  : "bg-slate-900 hover:bg-slate-800 text-white"
              }`}
            >
              {isAdmin ? "Edit Plan" : plan.price_monthly === 0 ? "Contact Sales" : showPayPal ? "Hide Payment" : "Pay with PayPal →"}
            </Button>
          )}
          {!isAdmin && showPayPal && plan.price_monthly > 0 && (
            <div className="pt-2">
              <PayPalButton
                amount={price}
                currency="USD"
                planName={plan.name}
                onSuccess={(order) => {
                  toast.success(`Payment successful! Order ID: ${order.id}`);
                  setShowPayPal(false);
                }}
                onError={() => toast.error("Payment failed. Please try again.")}
              />
            </div>
          )}
          {isAdmin && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className={`flex-1 text-xs ${isEnterprise ? "border-slate-600 text-slate-300 hover:bg-slate-800" : ""}`}
                onClick={() => downloadQuotePDF(plan, billingCycle)}
              >
                <FileDown className="w-3.5 h-3.5 mr-1" /> PDF Quote
              </Button>
              {onCreateInvoice && (
                <Button
                  variant="outline"
                  size="sm"
                  className={`flex-1 text-xs ${isEnterprise ? "border-slate-600 text-slate-300 hover:bg-slate-800" : ""}`}
                  onClick={() => onCreateInvoice(plan)}
                >
                  Push to Xero
                </Button>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}