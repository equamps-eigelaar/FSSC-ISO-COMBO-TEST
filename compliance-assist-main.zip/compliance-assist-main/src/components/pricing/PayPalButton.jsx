import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2 } from "lucide-react";

export default function PayPalButton({ amount, currency = "USD", planName, onSuccess, onError }) {
    const containerRef = useRef(null);
    const cardRef = useRef(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const rendered = useRef(false);

    useEffect(() => {
        let scriptEl = null;

        async function init() {
            const { data } = await base44.functions.invoke("getPaypalClientId");
            const clientId = data?.clientId;
            if (!clientId) {
                setError("PayPal is not configured.");
                setLoading(false);
                return;
            }

            // Remove existing script if any
            const existing = document.getElementById("paypal-sdk");
            if (existing) existing.remove();
            rendered.current = false;

            scriptEl = document.createElement("script");
            scriptEl.id = "paypal-sdk";
            scriptEl.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=${currency}&enable-funding=card,venmo`;
            scriptEl.onload = () => {
                setLoading(false);
                if (!rendered.current && containerRef.current) {
                    rendered.current = true;
                    const orderConfig = {
                        createOrder: (data, actions) => actions.order.create({
                            purchase_units: [{
                                description: planName,
                                amount: { value: String(amount), currency_code: currency }
                            }]
                        }),
                        onApprove: async (data, actions) => {
                            const order = await actions.order.capture();
                            onSuccess && onSuccess(order);
                        },
                        onError: (err) => { onError && onError(err); }
                    };

                    // PayPal button
                    window.paypal.Buttons({
                        ...orderConfig,
                        style: { layout: "vertical", color: "gold", shape: "rect", label: "paypal" },
                    }).render(containerRef.current);

                    // Debit/Credit card button
                    if (window.paypal.Buttons.isEligible && window.paypal.Buttons({
                        fundingSource: window.paypal.FUNDING?.CARD
                    }).isEligible()) {
                        window.paypal.Buttons({
                            ...orderConfig,
                            fundingSource: window.paypal.FUNDING.CARD,
                            style: { layout: "vertical", shape: "rect", label: "pay" },
                        }).render(cardRef.current);
                    } else if (cardRef.current) {
                        cardRef.current.innerHTML = "";
                    }
                }
            };
            scriptEl.onerror = () => {
                setError("Failed to load PayPal.");
                setLoading(false);
            };
            document.body.appendChild(scriptEl);
        }

        init();

        return () => {
            // cleanup: don't remove script on unmount to avoid flicker on re-render
        };
    }, [amount, currency, planName]);

    if (error) return <p className="text-xs text-rose-500 text-center">{error}</p>;
    if (loading) return (
        <div className="flex justify-center py-2">
            <Loader2 className="w-5 h-5 animate-spin text-slate-400" />
        </div>
    );

    return (
        <div className="space-y-2">
            <div ref={containerRef} />
            <div ref={cardRef} />
        </div>
    );
}