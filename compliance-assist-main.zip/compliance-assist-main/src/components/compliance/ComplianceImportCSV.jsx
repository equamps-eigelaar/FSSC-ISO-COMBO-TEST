import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle, Upload, CheckCircle2, Loader2, X } from "lucide-react";
import { toast } from "sonner";

const FRAMEWORK_OPTIONS = {
  food_safety: "Food Safety Management System",
  prerequisite: "Prerequisite Programmes",
  custom: "Custom Framework",
};

const FIELD_MAPPINGS = {
  food_safety: [
    "Clause Number",
    "Clause Title",
    "Description",
    "Status",
    "Priority",
    "Section",
  ],
  prerequisite: [
    "Clause Number",
    "Clause Title",
    "Description",
    "Status",
    "Priority",
    "Category",
  ],
};

export default function ComplianceImportCSV() {
  const [file, setFile] = useState(null);
  const [csvData, setCsvData] = useState(null);
  const [framework, setFramework] = useState("food_safety");
  const [columnMapping, setColumnMapping] = useState({});
  const [validationResults, setValidationResults] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState("upload");

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.name.endsWith(".csv")) {
      toast.error("Please select a CSV file");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const csv = event.target.result;
        const lines = csv.split("\n").filter(line => line.trim());
        
        if (lines.length < 2) {
          toast.error("CSV must have header row and at least one data row");
          return;
        }

        // Parse CSV manually
        const headers = parseCSVLine(lines[0]);
        const data = lines.slice(1).map(line => {
          const values = parseCSVLine(line);
          const row = {};
          headers.forEach((header, idx) => {
            row[header] = values[idx] || "";
          });
          return row;
        });

        setCsvData(data);
        setFile(selectedFile);
        initializeMapping(data[0]);
        setStep("mapping");
      } catch (error) {
        toast.error("Failed to parse CSV: " + error.message);
      }
    };

    reader.readAsText(selectedFile);
  };

  const parseCSVLine = (line) => {
    const result = [];
    let current = "";
    let insideQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === "," && !insideQuotes) {
        result.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result;
  };

  const initializeMapping = (firstRow) => {
    const csvColumns = Object.keys(firstRow);
    const expectedFields = FIELD_MAPPINGS[framework] || [];
    const mapping = {};

    csvColumns.forEach((col) => {
      const match = expectedFields.find(
        (field) =>
          col.toLowerCase().includes(field.toLowerCase()) ||
          field.toLowerCase().includes(col.toLowerCase())
      );
      mapping[col] = match || "";
    });

    setColumnMapping(mapping);
  };

  const handleValidate = async () => {
    setIsProcessing(true);
    try {
      const response = await base44.functions.invoke("validateComplianceImport", {
        data: csvData,
        mapping: columnMapping,
        framework: framework,
      });

      setValidationResults(response.validation);
      setStep("validation");
    } catch (error) {
      toast.error("Validation failed: " + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImport = async () => {
    if (!validationResults?.isValid) {
      toast.error("Fix validation errors before importing");
      return;
    }

    setIsProcessing(true);
    try {
      await base44.functions.invoke("importComplianceData", {
        data: csvData,
        mapping: columnMapping,
        framework: framework,
        validationResults: validationResults,
      });

      toast.success("Compliance data imported successfully");
      resetForm();
    } catch (error) {
      toast.error("Import failed: " + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const resetForm = () => {
    setFile(null);
    setCsvData(null);
    setColumnMapping({});
    setValidationResults(null);
    setStep("upload");
  };

  if (step === "upload") {
    return (
      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="framework" className="font-semibold">
            Select Framework
          </Label>
          <Select value={framework} onValueChange={setFramework}>
            <SelectTrigger id="framework">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(FRAMEWORK_OPTIONS).map(([key, label]) => (
                <SelectItem key={key} value={key}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-emerald-500 hover:bg-emerald-50 transition-colors cursor-pointer">
          <input
            type="file"
            accept=".csv"
            onChange={handleFileSelect}
            className="hidden"
            id="csv-input"
          />
          <label htmlFor="csv-input" className="cursor-pointer block">
            <Upload className="w-8 h-8 text-slate-400 mx-auto mb-3" />
            <p className="font-semibold text-slate-900">Click to upload CSV</p>
            <p className="text-sm text-slate-600 mt-1">
              or drag and drop your compliance data file
            </p>
          </label>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-900">
            <strong>Tip:</strong> Your CSV should include columns for clause numbers, descriptions, status, and priority.
          </p>
        </div>
      </div>
    );
  }

  if (step === "mapping") {
    return (
      <div className="space-y-6">
        <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-emerald-900">CSV loaded successfully</p>
            <p className="text-sm text-emerald-800 mt-1">
              {csvData?.length} records found. Map columns to framework fields.
            </p>
          </div>
        </div>

        <div>
          <h3 className="font-semibold text-slate-900 mb-3">Column Mapping</h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {Object.keys(csvData?.[0] || {}).map((csvColumn) => (
              <div key={csvColumn} className="flex items-end gap-3">
                <div className="flex-1">
                  <Label className="text-xs font-semibold text-slate-600 uppercase block mb-1">
                    CSV Column: {csvColumn}
                  </Label>
                  <Select
                    value={columnMapping[csvColumn] || ""}
                    onValueChange={(value) =>
                      setColumnMapping({ ...columnMapping, [csvColumn]: value })
                    }
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Select field..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Skip this column</SelectItem>
                      {(FIELD_MAPPINGS[framework] || []).map((field) => (
                        <SelectItem key={field} value={field}>
                          {field}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={resetForm}>
            Cancel
          </Button>
          <Button
            onClick={handleValidate}
            disabled={isProcessing}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {isProcessing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Validate Data
          </Button>
        </div>
      </div>
    );
  }

  if (step === "validation") {
    const { isValid, errors = [], warnings = [], summary } = validationResults || {};

    return (
      <div className="space-y-6">
        {isValid ? (
          <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-emerald-900">Data validation passed</p>
              <p className="text-sm text-emerald-800 mt-1">{summary}</p>
            </div>
          </div>
        ) : (
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-rose-900">Validation errors found</p>
              <p className="text-sm text-rose-800 mt-1">{summary}</p>
            </div>
          </div>
        )}

        {errors.length > 0 && (
          <div>
            <h3 className="font-semibold text-slate-900 mb-2">Errors</h3>
            <div className="space-y-2 bg-slate-50 p-4 rounded-lg">
              {errors.map((error, idx) => (
                <div key={idx} className="text-sm text-rose-700">
                  • {error}
                </div>
              ))}
            </div>
          </div>
        )}

        {warnings.length > 0 && (
          <div>
            <h3 className="font-semibold text-slate-900 mb-2">Warnings</h3>
            <div className="space-y-2 bg-slate-50 p-4 rounded-lg">
              {warnings.map((warning, idx) => (
                <div key={idx} className="text-sm text-amber-700">
                  • {warning}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={resetForm}>
            Start Over
          </Button>
          {isValid && (
            <Button
              onClick={handleImport}
              disabled={isProcessing}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {isProcessing && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Import Data
            </Button>
          )}
        </div>
      </div>
    );
  }

  return null;
}