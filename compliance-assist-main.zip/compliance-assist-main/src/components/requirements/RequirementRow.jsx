import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronRight, Clock, AlertTriangle } from "lucide-react";

const STATUS_CONFIG = {
  not_started: { label: "Not Started", className: "bg-slate-100 text-slate-600" },
  in_progress: { label: "In Progress", className: "bg-blue-50 text-blue-700" },
  partial: { label: "Partial", className: "bg-amber-50 text-amber-700" },
  compliant: { label: "Compliant", className: "bg-emerald-50 text-emerald-700" },
  non_compliant: { label: "Non-Compliant", className: "bg-rose-50 text-rose-700" },
};

const PRIORITY_CONFIG = {
  critical: { label: "Critical", className: "bg-rose-50 text-rose-600 border-rose-200" },
  high: { label: "High", className: "bg-orange-50 text-orange-600 border-orange-200" },
  medium: { label: "Medium", className: "bg-slate-50 text-slate-500 border-slate-200" },
  low: { label: "Low", className: "bg-slate-50 text-slate-400 border-slate-200" },
};

const STATUS_FLOW = {
  not_started: ["in_progress"],
  in_progress: ["partial", "compliant", "non_compliant"],
  partial: ["in_progress", "compliant", "non_compliant"],
  non_compliant: ["in_progress", "partial"],
  compliant: ["in_progress"],
};

export default function RequirementRow({ requirement, onStatusChange, canEdit = true, canApprove = false, isHidden = false }) {
  if (isHidden) return null;

  const status = STATUS_CONFIG[requirement.status] || STATUS_CONFIG.not_started;
  const priority = PRIORITY_CONFIG[requirement.priority] || PRIORITY_CONFIG.medium;
  const isOverdue = requirement.due_date && new Date(requirement.due_date) < new Date() && requirement.status !== "compliant";
  const isNonCompliant = requirement.status === "non_compliant";
  const nextStatuses = STATUS_FLOW[requirement.status] || [];

  return (
    <Link
      to={createPageUrl("RequirementDetail") + `?id=${requirement.id}`}
      className={`block px-4 sm:px-5 py-3.5 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors group
        ${isNonCompliant ? "border-l-2 border-rose-400" : isOverdue ? "border-l-2 border-amber-400" : ""}`}
    >
      {/* Mobile layout: stacked */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          {/* Clause number + title */}
          <div className="flex items-start gap-2 mb-1.5">
            {requirement.clause_number && (
              <span className="text-[11px] font-mono font-bold text-slate-400 shrink-0 mt-0.5">
                {requirement.clause_number}
              </span>
            )}
            <span className="text-sm font-medium text-slate-800 dark:text-slate-100 group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors leading-snug">
              {requirement.clause_title}
            </span>
          </div>

          {/* Badges row */}
          <div className="flex flex-wrap gap-1.5 items-center">
            <Badge variant="outline" className={`text-[11px] px-1.5 py-0 h-5 ${priority.className}`}>
              {priority.label}
            </Badge>
            {isOverdue && (
              <Badge className="text-[11px] px-1.5 py-0 h-5 bg-amber-100 text-amber-700 gap-1">
                <Clock className="w-2.5 h-2.5" />Overdue
              </Badge>
            )}
            {isNonCompliant && (
              <Badge className="text-[11px] px-1.5 py-0 h-5 bg-rose-100 text-rose-700 gap-1">
                <AlertTriangle className="w-2.5 h-2.5" />Non-Compliant
              </Badge>
            )}

            {/* Quick-advance buttons — desktop hover only */}
            {canEdit && nextStatuses.length > 0 && (
              <div
                className="hidden sm:flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={e => e.preventDefault()}
              >
                {nextStatuses.map(ns => (
                  <button
                    key={ns}
                    onClick={e => { e.preventDefault(); e.stopPropagation(); onStatusChange(ns); }}
                    className={`text-[10px] px-1.5 py-0.5 rounded border font-medium transition-colors ${STATUS_CONFIG[ns]?.className} hover:opacity-80`}
                  >
                    → {STATUS_CONFIG[ns]?.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right side: status + chevron */}
        <div className="flex items-center gap-1.5 shrink-0 mt-0.5" onClick={e => e.stopPropagation()}>
          <Select value={requirement.status} onValueChange={onStatusChange} disabled={!canEdit}>
            <SelectTrigger className={`h-7 text-[11px] border-0 w-28 sm:w-32 px-2 ${status.className} ${!canEdit ? "opacity-60 cursor-not-allowed" : ""}`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="not_started">Not Started</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="partial">Partial</SelectItem>
              <SelectItem value="compliant">Compliant</SelectItem>
              <SelectItem value="non_compliant">Non-Compliant</SelectItem>
            </SelectContent>
          </Select>
          <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-slate-500 shrink-0" />
        </div>
      </div>

      {/* Mobile quick-advance (tap targets) */}
      {canEdit && nextStatuses.length > 0 && (
        <div
          className="flex sm:hidden gap-2 mt-2 flex-wrap"
          onClick={e => e.preventDefault()}
        >
          {nextStatuses.map(ns => (
            <button
              key={ns}
              onClick={e => { e.preventDefault(); e.stopPropagation(); onStatusChange(ns); }}
              className={`text-xs px-3 py-1.5 rounded-full border font-medium min-h-[36px] ${STATUS_CONFIG[ns]?.className} active:scale-95 transition-transform`}
            >
              → {STATUS_CONFIG[ns]?.label}
            </button>
          ))}
        </div>
      )}
    </Link>
  );
}