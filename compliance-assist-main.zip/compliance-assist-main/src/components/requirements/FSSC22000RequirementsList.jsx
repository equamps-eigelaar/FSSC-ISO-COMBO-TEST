import React from "react";

const FSSC_REQUIREMENTS = [
  // Part 2 - ISO 22000 Requirements
  { clause: "4.1", title: "Understanding the organization and its context", section: "4 - Context of the Organization" },
  { clause: "4.2", title: "Understanding the needs and expectations of interested parties", section: "4 - Context of the Organization" },
  { clause: "4.3", title: "Determining the scope of the food safety management system", section: "4 - Context of the Organization" },
  { clause: "4.4", title: "Food safety management system", section: "4 - Context of the Organization" },
  { clause: "5.1", title: "Leadership and commitment", section: "5 - Leadership" },
  { clause: "5.2", title: "Policy", section: "5 - Leadership" },
  { clause: "5.3", title: "Organizational roles, responsibilities and authorities", section: "5 - Leadership" },
  { clause: "6.1", title: "Actions to address risks and opportunities", section: "6 - Planning" },
  { clause: "6.2", title: "Objectives of the food safety management system and planning to achieve them", section: "6 - Planning" },
  { clause: "6.3", title: "Planning of changes", section: "6 - Planning" },
  { clause: "7.1", title: "Resources", section: "7 - Support" },
  { clause: "7.1.1", title: "General", section: "7 - Support" },
  { clause: "7.1.2", title: "People", section: "7 - Support" },
  { clause: "7.1.3", title: "Infrastructure", section: "7 - Support" },
  { clause: "7.1.4", title: "Work environment", section: "7 - Support" },
  { clause: "7.1.5", title: "Externally developed elements of the FSMS", section: "7 - Support" },
  { clause: "7.1.6", title: "Control of externally provided processes, products or services", section: "7 - Support" },
  { clause: "7.2", title: "Competence", section: "7 - Support" },
  { clause: "7.3", title: "Awareness", section: "7 - Support" },
  { clause: "7.4", title: "Communication", section: "7 - Support" },
  { clause: "7.4.1", title: "General", section: "7 - Support" },
  { clause: "7.4.2", title: "External communication", section: "7 - Support" },
  { clause: "7.4.3", title: "Internal communication", section: "7 - Support" },
  { clause: "7.5", title: "Documented information", section: "7 - Support" },
  { clause: "7.5.1", title: "General", section: "7 - Support" },
  { clause: "7.5.2", title: "Creating and updating documented information", section: "7 - Support" },
  { clause: "7.5.3", title: "Control of documented information", section: "7 - Support" },
  { clause: "8.1", title: "Operational planning and control", section: "8 - Operation" },
  { clause: "8.2", title: "Prerequisite programmes (PRPs)", section: "8 - Operation" },
  { clause: "8.2.1", title: "General", section: "8 - Operation" },
  { clause: "8.2.2", title: "Selection and establishment of PRPs", section: "8 - Operation" },
  { clause: "8.2.3", title: "Approval of PRPs", section: "8 - Operation" },
  { clause: "8.2.4", title: "PRP documentation and updating", section: "8 - Operation" },
  { clause: "8.3", title: "Traceability system", section: "8 - Operation" },
  { clause: "8.4", title: "Emergency preparedness and response", section: "8 - Operation" },
  { clause: "8.4.1", title: "General", section: "8 - Operation" },
  { clause: "8.4.2", title: "Handling of emergencies and incidents", section: "8 - Operation" },
  { clause: "8.5", title: "Hazard control", section: "8 - Operation" },
  { clause: "8.5.1", title: "Preliminary steps to enable hazard analysis", section: "8 - Operation" },
  { clause: "8.5.2", title: "Hazard analysis", section: "8 - Operation" },
  { clause: "8.5.3", title: "Validation of control measures and combinations of control measures", section: "8 - Operation" },
  { clause: "8.5.4", title: "Hazard control plan (HACCP/OPRP plan)", section: "8 - Operation" },
  { clause: "8.6", title: "Updating the preliminary information and documents specifying the PRPs and the hazard control plan", section: "8 - Operation" },
  { clause: "8.7", title: "Control of monitoring and measuring", section: "8 - Operation" },
  { clause: "8.8", title: "Verification related to PRPs and the hazard control plan", section: "8 - Operation" },
  { clause: "8.8.1", title: "Verification", section: "8 - Operation" },
  { clause: "8.8.2", title: "Analysis of results of verification activities", section: "8 - Operation" },
  { clause: "8.9", title: "Control of product and process nonconformities", section: "8 - Operation" },
  { clause: "8.9.1", title: "General", section: "8 - Operation" },
  { clause: "8.9.2", title: "Corrections", section: "8 - Operation" },
  { clause: "8.9.3", title: "Corrective actions", section: "8 - Operation" },
  { clause: "8.9.4", title: "Handling of potentially unsafe products", section: "8 - Operation" },
  { clause: "8.9.5", title: "Withdrawal/recall", section: "8 - Operation" },
  { clause: "9.1", title: "Monitoring, measurement, analysis and evaluation", section: "9 - Performance Evaluation" },
  { clause: "9.1.1", title: "General", section: "9 - Performance Evaluation" },
  { clause: "9.1.2", title: "Analysis and evaluation", section: "9 - Performance Evaluation" },
  { clause: "9.2", title: "Internal audit", section: "9 - Performance Evaluation" },
  { clause: "9.3", title: "Management review", section: "9 - Performance Evaluation" },
  { clause: "9.3.1", title: "General", section: "9 - Performance Evaluation" },
  { clause: "9.3.2", title: "Management review inputs", section: "9 - Performance Evaluation" },
  { clause: "9.3.3", title: "Management review outputs", section: "9 - Performance Evaluation" },
  { clause: "10.1", title: "Nonconformity and corrective action", section: "10 - Improvement" },
  { clause: "10.2", title: "Continual improvement", section: "10 - Improvement" },
  { clause: "10.3", title: "Update of the FSMS", section: "10 - Improvement" },
  // FSSC 22000 Additional Requirements
  { clause: "2.5.1", title: "Management of Services and Purchased Materials", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.2", title: "Product Labeling and Printed Materials", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.3", title: "Food Defense", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.3.1", title: "Threat Assessment", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.3.2", title: "Food Defense Plan", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.4", title: "Food Fraud Mitigation", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.4.1", title: "Vulnerability Assessment", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.4.2", title: "Food Fraud Mitigation Plan", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.5", title: "Logo Use", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.6", title: "Management of Allergens", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.7", title: "Environmental Monitoring (BIII, C, I & K)", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.8", title: "Food Safety and Quality Culture", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.9", title: "Quality Control", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.10", title: "Transport, Storage and Warehousing", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.11", title: "Hazard Control and Measures for Preventing Cross-Contamination", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.12", title: "PRP Verification (BIII, C, D, G, I & K)", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.13", title: "Product Design and Development (BIII, C, D, E, F, I & K)", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.14", title: "Health Status (Category D)", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.15", title: "Equipment Management", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.16", title: "Food Loss and Waste (Excl. I)", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.17", title: "Communication Requirements", section: "FSSC 22000 Additional Requirements" },
  { clause: "2.5.18", title: "Requirements for Multi-Site Certification (E, F & G)", section: "FSSC 22000 Additional Requirements" },
  // ISO/TS 22002-4 PRPs (Packaging)
  { clause: "4", title: "Construction and layout of buildings and associated utilities", section: "TS 22002-4 - Establishment" },
  { clause: "5", title: "Layout of premises and workspace", section: "TS 22002-4 - Establishment" },
  { clause: "6", title: "Utilities – air, water, energy", section: "TS 22002-4 - Utilities" },
  { clause: "7", title: "Waste and sewage disposal", section: "TS 22002-4 - Establishment" },
  { clause: "8", title: "Equipment suitability, cleaning and maintenance", section: "TS 22002-4 - Equipment" },
  { clause: "9", title: "Management of purchased materials", section: "TS 22002-4 - Establishment" },
  { clause: "10", title: "Cross-contamination prevention measures", section: "TS 22002-4 - Establishment" },
  { clause: "11", title: "Cleaning and disinfecting", section: "TS 22002-4 - Hygiene" },
  { clause: "12", title: "Pest control", section: "TS 22002-4 - Hygiene" },
  { clause: "13", title: "Personnel hygiene and employee facilities", section: "TS 22002-4 - Personnel" },
  { clause: "14", title: "Rework", section: "TS 22002-4 - Establishment" },
  { clause: "15", title: "Product recall procedures", section: "TS 22002-4 - Establishment" },
  { clause: "16", title: "Warehousing", section: "TS 22002-4 - Establishment" },
  { clause: "17", title: "Transport", section: "TS 22002-4 - Transportation" },
  { clause: "18", title: "Specific requirements for packaging materials", section: "TS 22002-4 - Product Information" },
];

const SECTION_COLORS = {
  "4 - Context of the Organization": "bg-purple-50 border-purple-200 text-purple-700",
  "5 - Leadership": "bg-blue-50 border-blue-200 text-blue-700",
  "6 - Planning": "bg-cyan-50 border-cyan-200 text-cyan-700",
  "7 - Support": "bg-teal-50 border-teal-200 text-teal-700",
  "8 - Operation": "bg-emerald-50 border-emerald-200 text-emerald-700",
  "9 - Performance Evaluation": "bg-amber-50 border-amber-200 text-amber-700",
  "10 - Improvement": "bg-orange-50 border-orange-200 text-orange-700",
  "FSSC 22000 Additional Requirements": "bg-rose-50 border-rose-200 text-rose-700",
};

export default function FSSC22000RequirementsList() {
  const sections = [...new Set(FSSC_REQUIREMENTS.map(r => r.section))];

  return (
    <div className="space-y-6">
      <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
        <p className="text-sm text-emerald-800 font-medium">FSSC 22000 Version 6.0 — Full Requirements List</p>
        <p className="text-xs text-emerald-600 mt-1">Based on ISO 22000:2018, ISO/TS 22002-4:2013 and FSSC 22000 Additional Requirements</p>
      </div>

      {sections.map((section) => {
        const items = FSSC_REQUIREMENTS.filter(r => r.section === section);
        const colorClass = SECTION_COLORS[section] || "bg-slate-50 border-slate-200 text-slate-700";
        return (
          <div key={section}>
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold mb-2 ${colorClass}`}>
              {section}
              <span className="opacity-60">({items.length})</span>
            </div>
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 overflow-hidden divide-y divide-slate-50 dark:divide-slate-800">
              {items.map((req) => (
                <div key={req.clause} className="flex items-start gap-3 px-4 py-3">
                  <span className="text-xs font-mono font-semibold text-slate-500 dark:text-slate-400 w-16 shrink-0 mt-0.5">{req.clause}</span>
                  <span className="text-sm text-slate-700 dark:text-slate-300">{req.title}</span>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}