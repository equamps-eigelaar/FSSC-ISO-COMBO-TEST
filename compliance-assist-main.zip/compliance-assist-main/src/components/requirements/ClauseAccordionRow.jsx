import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronDown, ChevronRight, Clock, AlertTriangle, BookOpen, FileText, ExternalLink } from "lucide-react";
import { base44 } from "@/api/base44Client";

const STATUS_CONFIG = {
  not_started: { label: "Not Started", className: "bg-slate-100 text-slate-600" },
  in_progress: { label: "In Progress", className: "bg-blue-50 text-blue-700" },
  partial: { label: "Partial", className: "bg-amber-50 text-amber-700" },
  compliant: { label: "Compliant", className: "bg-emerald-50 text-emerald-700" },
  non_compliant: { label: "Non-Compliant", className: "bg-rose-50 text-rose-700" },
};

const PRIORITY_CONFIG = {
  critical: { label: "Critical", className: "bg-rose-50 text-rose-600 border-rose-200" },
  high: { label: "High", className: "bg-orange-50 text-orange-600 border-orange-200" },
  medium: { label: "Medium", className: "bg-slate-50 text-slate-500 border-slate-200" },
  low: { label: "Low", className: "bg-slate-50 text-slate-400 border-slate-200" },
};

const STATUS_FLOW = {
  not_started: ["in_progress"],
  in_progress: ["partial", "compliant", "non_compliant"],
  partial: ["in_progress", "compliant", "non_compliant"],
  non_compliant: ["in_progress", "partial"],
  compliant: ["in_progress"],
};

// Static interpretation guide links per clause prefix
const INTERPRETATION_GUIDE = {
  "4": "https://www.fssc.com/schemes/fssc-22000/",
  "5": "https://www.fssc.com/schemes/fssc-22000/",
  "6": "https://www.fssc.com/schemes/fssc-22000/",
  "7": "https://www.fssc.com/schemes/fssc-22000/",
  "8": "https://www.fssc.com/schemes/fssc-22000/",
  "9": "https://www.fssc.com/schemes/fssc-22000/",
  "10": "https://www.fssc.com/schemes/fssc-22000/",
};

function getInterpretationGuideUrl(clauseNumber) {
  if (!clauseNumber) return "https://www.fssc.com/schemes/fssc-22000/";
  const prefix = clauseNumber.split(".")[0];
  return INTERPRETATION_GUIDE[prefix] || "https://www.fssc.com/schemes/fssc-22000/";
}

export default function ClauseAccordionRow({ requirement, onStatusChange, canEdit = true, canApprove = false, isHidden = false }) {
  const [expanded, setExpanded] = useState(false);
  const [linkedTemplates, setLinkedTemplates] = useState([]);
  const [loadingTemplates, setLoadingTemplates] = useState(false);

  useEffect(() => {
    if (expanded && linkedTemplates.length === 0 && !loadingTemplates) {
      setLoadingTemplates(true);
      base44.entities.DocumentTemplate.list()
        .then((templates) => {
          const linked = templates.filter(
            (t) => t.linked_requirement_ids && t.linked_requirement_ids.includes(requirement.id)
          );
          setLinkedTemplates(linked);
        })
        .finally(() => setLoadingTemplates(false));
    }
  }, [expanded, requirement.id]);

  if (isHidden) return null;

  const status = STATUS_CONFIG[requirement.status] || STATUS_CONFIG.not_started;
  const priority = PRIORITY_CONFIG[requirement.priority] || PRIORITY_CONFIG.medium;
  const isOverdue = requirement.due_date && new Date(requirement.due_date) < new Date() && requirement.status !== "compliant";
  const isNonCompliant = requirement.status === "non_compliant";
  const nextStatuses = STATUS_FLOW[requirement.status] || [];

  return (
    <div className={`${isNonCompliant ? "border-l-2 border-rose-400" : isOverdue ? "border-l-2 border-amber-400" : ""}`}>
      {/* Header row — clickable to expand */}
      <div
        className="flex items-start justify-between gap-2 px-4 sm:px-5 py-3.5 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors group cursor-pointer select-none"
        onClick={() => setExpanded((v) => !v)}
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-start gap-2 mb-1.5">
            {/* Expand toggle */}
            <span className="shrink-0 mt-0.5 text-slate-400">
              {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </span>
            {requirement.clause_number && (
              <span className="text-[11px] font-mono font-bold text-slate-400 shrink-0 mt-0.5">
                {requirement.clause_number}
              </span>
            )}
            <span className="text-sm font-medium text-slate-800 dark:text-slate-100 group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors leading-snug">
              {requirement.clause_title}
            </span>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap gap-1.5 items-center pl-5">
            <Badge variant="outline" className={`text-[11px] px-1.5 py-0 h-5 ${priority.className}`}>
              {priority.label}
            </Badge>
            {isOverdue && (
              <Badge className="text-[11px] px-1.5 py-0 h-5 bg-amber-100 text-amber-700 gap-1">
                <Clock className="w-2.5 h-2.5" />Overdue
              </Badge>
            )}
            {isNonCompliant && (
              <Badge className="text-[11px] px-1.5 py-0 h-5 bg-rose-100 text-rose-700 gap-1">
                <AlertTriangle className="w-2.5 h-2.5" />Non-Compliant
              </Badge>
            )}

            {/* Desktop quick-advance */}
            {canEdit && nextStatuses.length > 0 && (
              <div
                className="hidden sm:flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={e => e.stopPropagation()}
              >
                {nextStatuses.map(ns => (
                  <button
                    key={ns}
                    onClick={e => { e.stopPropagation(); onStatusChange(ns); }}
                    className={`text-[10px] px-1.5 py-0.5 rounded border font-medium transition-colors ${STATUS_CONFIG[ns]?.className} hover:opacity-80`}
                  >
                    → {STATUS_CONFIG[ns]?.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Status selector + detail link */}
        <div className="flex items-center gap-1.5 shrink-0 mt-0.5" onClick={e => e.stopPropagation()}>
          <Select value={requirement.status} onValueChange={onStatusChange} disabled={!canEdit}>
            <SelectTrigger className={`h-7 text-[11px] border-0 w-28 sm:w-32 px-2 ${status.className} ${!canEdit ? "opacity-60 cursor-not-allowed" : ""}`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="not_started">Not Started</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="partial">Partial</SelectItem>
              <SelectItem value="compliant">Compliant</SelectItem>
              <SelectItem value="non_compliant">Non-Compliant</SelectItem>
            </SelectContent>
          </Select>
          <Link
            to={createPageUrl("RequirementDetail") + `?id=${requirement.id}`}
            onClick={e => e.stopPropagation()}
            className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-600"
            title="Open detail"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* Mobile quick-advance */}
      {canEdit && nextStatuses.length > 0 && (
        <div className="flex sm:hidden gap-2 px-4 pb-2 flex-wrap" onClick={e => e.stopPropagation()}>
          {nextStatuses.map(ns => (
            <button
              key={ns}
              onClick={e => { e.stopPropagation(); onStatusChange(ns); }}
              className={`text-xs px-3 py-1.5 rounded-full border font-medium min-h-[36px] ${STATUS_CONFIG[ns]?.className} active:scale-95 transition-transform`}
            >
              → {STATUS_CONFIG[ns]?.label}
            </button>
          ))}
        </div>
      )}

      {/* Expanded panel */}
      {expanded && (
        <div className="px-5 sm:px-7 pb-4 pt-1 bg-slate-50/60 dark:bg-slate-800/30 border-t border-slate-100 dark:border-slate-700/50 space-y-4">

          {/* Requirement description */}
          {requirement.description ? (
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Requirement</p>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{requirement.description}</p>
            </div>
          ) : (
            <p className="text-xs text-slate-400 italic">No requirement description added.</p>
          )}

          {/* Interpretation Guide link */}
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-600 shrink-0" />
            <a
              href={getInterpretationGuideUrl(requirement.clause_number)}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-emerald-700 hover:text-emerald-800 underline font-medium"
            >
              View FSSC 22000 Interpretation Guide
            </a>
          </div>

          {/* Linked document templates */}
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5" /> Linked Document Templates
            </p>
            {loadingTemplates ? (
              <p className="text-xs text-slate-400">Loading templates…</p>
            ) : linkedTemplates.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {linkedTemplates.map((t) => (
                  <Link
                    key={t.id}
                    to={createPageUrl("DocumentTemplates") + `?id=${t.id}`}
                    className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700 transition-colors"
                  >
                    <FileText className="w-3 h-3 text-slate-400" />
                    {t.name}
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No document templates linked to this clause.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}