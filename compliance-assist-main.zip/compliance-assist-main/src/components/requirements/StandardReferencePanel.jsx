import React, { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, BookOpen } from "lucide-react";

const STANDARD_CLAUSES = [
  {
    id: "2.5.1",
    title: "Management of Services and Purchased Materials",
    scope: "All food chain categories",
    content: `a) Laboratory analysis services used for verification and/or validation of food safety shall be conducted by a competent laboratory (internal and external) with the capability to produce precise and repeatable test results using validated test methods and best practices (e.g. ISO 17025 accreditation).

b) For categories C, D, I, FII, G and K: The organization shall have a documented procedure for procurement in emergency situations to ensure products still conform to specified requirements and the supplier has been evaluated.

c) For categories C0, CI, CIII and CIV: The organization shall have a policy for the procurement of animals, fish and seafood subject to control of prohibited substances (e.g., pharmaceuticals, veterinary medicines, heavy metals, and pesticides).

d) For categories C, D, I, FII, G and K: The organization shall establish, implement, and maintain a review process for raw material and finished product specifications to ensure continued compliance with food safety, quality, legal and customer requirements.

e) For category I: The organization shall establish criteria related to use of recycled packaging as a raw material input into the production of finished packaging material.`,
  },
  {
    id: "2.5.2",
    title: "Product Labeling and Printed Materials",
    scope: "All food chain categories",
    content: `a) Finished products shall be labelled according to all applicable statutory and regulatory requirements in the country of intended sale, including allergen and customer specific requirements.

b) Where a product is unlabeled, all relevant product information shall be made available to ensure the safe use of the food by the customer or consumer.

c) Where a claim (e.g., allergen, nutritional, method of production, chain of custody, raw material status) is made on the product label, the organization shall maintain evidence of validation to support the claim and shall have verification systems in place, including traceability and mass balance.

d) For category I: Artwork management and print control procedures shall be established and implemented. The procedure shall address: approval of artwork standard; managing changes and obsolete artwork; approval of each print run; detecting printing errors; ensuring segregation of differing print variants; and accounting for unused printed product.`,
  },
  {
    id: "2.5.3",
    title: "Food Defense",
    scope: "All food chain categories",
    content: `Threat Assessment:
a) Conduct and document the food defense threat assessment, based on a defined methodology, to identify and evaluate potential threats linked to the processes and products within scope.
b) Develop and implement appropriate mitigation measures for significant threats.

Plan:
a) The organization shall have a documented food defense plan based on the threat assessment, specifying mitigation measures and verification procedures.
b) The food defense plan shall be implemented and supported by the organization's FSMS.
c) The plan shall comply with applicable legislation, cover the processes and products within scope, and be kept up to date.
d) For category FII: The organization shall ensure that their suppliers have a food defense plan in place.`,
  },
  {
    id: "2.5.4",
    title: "Food Fraud Mitigation",
    scope: "All food chain categories",
    content: `Vulnerability Assessment:
a) Conduct and document the food fraud vulnerability assessment, based on a defined methodology, to identify and assess potential vulnerabilities.
b) Develop and implement appropriate mitigation measures for significant vulnerabilities. The assessment shall cover the processes and products within the scope of the organization.

Plan:
a) The organization shall have a documented food fraud mitigation plan based on the output of the vulnerability assessment, specifying mitigation measures and verification procedures.
b) The food fraud mitigation plan shall be implemented and supported by the organization's FSMS.
c) The plan shall comply with the applicable legislation, cover the processes and products within scope, and be kept up to date.
d) For category FII: The organization shall ensure that their suppliers have a food fraud mitigation plan in place.`,
  },
  {
    id: "2.5.5",
    title: "Logo Use",
    scope: "All food chain categories",
    content: `a) Certified organizations shall use the FSSC 22000 logo only for marketing activities such as the organization's printed matter, website, and other promotional material.

b) In case of using the logo, the certified organization shall request a copy of the latest FSSC logo from their Certification Body, and comply with the specified color specifications (Green PMS 348 U; Grey 60% black).

c) The certified organization is not allowed to use the FSSC 22000 logo or make reference to its certified status on:
   - A product or its labelling/packaging
   - Certificates of analysis or certificates of conformance (CoA's or CoC's)
   - In any manner that implies FSSC 22000 approves a product, process, or service
   - Where exclusions to the scope of certification apply.`,
  },
  {
    id: "2.5.6",
    title: "Management of Allergens",
    scope: "All food chain categories",
    content: `The organization shall have a documented allergen management plan that includes:
a) A list of all allergens handled on site, including in raw materials and finished products.
b) Risk assessment covering all potential sources of allergen cross-contamination.
c) Identification and implementation of control measures to reduce or eliminate the risk of cross-contamination, based on the risk assessment outcome.
d) Validation and verification of control measures shall be implemented and maintained as documented information. Where more than one product is produced in the same production area with different allergen profiles, verification testing (e.g., surface testing, air sampling and/or product testing) shall be conducted at a frequency based on risk.
e) Precautionary or warning labels shall only be used where the risk assessment identifies allergen cross-contamination as a risk to the consumer, even though all necessary control measures have been effectively implemented.
f) All personnel shall receive training in allergen awareness and specific training on allergen control measures associated with their area of work.
g) The allergen management plan shall be reviewed at least annually, and following any significant change impacting food safety, a public recall, or a product withdrawal related to allergens. The review shall include evaluation of the effectiveness of existing control measures.
h) For Category D: Where there is no allergen-related legislation for the country of sale pertaining to animal feed, this section may be indicated as 'Not Applicable,' unless a claim relating to an allergen status has been made.`,
  },
  {
    id: "2.5.7",
    title: "Environmental Monitoring",
    scope: "Food chain categories BIII, C, I & K",
    content: `The organization shall have in place:
a) A risk-based environmental monitoring program for relevant pathogens, spoilage, and indicator organisms.
b) A documented procedure for the evaluation of the effectiveness of all controls on preventing contamination from the manufacturing environment. This shall include, at a minimum, the evaluation of microbiological controls present; and shall comply with legal and customer requirements.
c) Data of the environmental monitoring activities, including regular trend analysis.
d) The environmental monitoring program shall be reviewed for continued effectiveness and suitability, at least annually, and more often if required, including when the following triggers occur:
   - Significant changes related to products, processes, or legislation
   - When no positive testing results have been obtained over an extended period
   - Trend in out of specification microbiological results linked to environmental monitoring
   - A repeat detection of pathogens during routine environmental monitoring
   - When there are alerts, recalls or withdrawals relating to products produced by the organization.`,
  },
  {
    id: "2.5.8",
    title: "Food Safety and Quality Culture",
    scope: "All food chain categories",
    content: `a) In accordance with and in addition to clause 5.1 of ISO 22000:2018, senior management shall establish, implement, and maintain a food safety and quality culture objective(s) as part of the management system. The following elements shall be addressed as a minimum:
   - Communication
   - Training
   - Employee feedback and engagement
   - Performance measurement of defined activities covering all sections of the organization impacting on food safety and quality.

b) The objective(s) shall be supported by a documented food safety and quality culture plan, with targets and timelines, and included in the management review and continuous improvement processes of the management system.`,
  },
  {
    id: "2.5.9",
    title: "Quality Control",
    scope: "All food chain categories",
    content: `a) The organization shall:
   i. Establish, implement, and maintain a quality policy and quality objectives (in addition to and aligned with clauses 5.2 and 6.2 of ISO 22000:2018).
   ii. Establish, implement and maintain quality parameters in line with finished product specifications, for all products and/or product groups within the scope of certification, including product release that addresses quality control and testing.
   iii. Undertake analysis and evaluation of the results of the quality control parameters and include it as an input for the management review (in addition to and aligned with clauses 9.1 and 9.3 of ISO 22000:2018).
   iv. Include quality elements within the scope of the internal audit (in addition to and aligned with clause 9.2 of ISO 22000:2018).

b) Quantity control procedures, including for unit, weight, and volume, shall be established and implemented, to ensure products meet applicable customer and legal requirements. This shall include a program for calibration and verification of equipment used for quality and quantity control.

c) Line start-up and change-over procedures shall be established and implemented to ensure products, including packaging and labelling, meet applicable customer and legal requirements. This shall include having controls in place to ensure labelling and packaging from the previous run have been removed from the line.`,
  },
  {
    id: "2.5.10",
    title: "Transport, Storage and Warehousing",
    scope: "All food chain categories",
    content: `a) The organization shall establish, implement, and maintain a procedure and specified stock rotation system that includes FEFO principles in conjunction with the FIFO requirements.

b) For category C0: In addition to ISO/TS 22002-1:2009 clause 16.2, the organization shall have specified requirements in place that define post-slaughter time and temperature in relation to chilling or freezing of the products.

c) For category FI: In addition to BSI/PAS 221:2013 clause 9.3, the organization shall ensure that product is transported and delivered under conditions which minimize the potential for contamination.

d) Where transport tankers are used, in addition to clause 8.2.4 of ISO 22000:2018:
   i. Organizations using tankers for transportation of their final product shall have a documented risk-based plan to address transport tank cleaning, considering potential sources of cross-contamination and appropriate control measures, including cleaning validation. Measures shall be in place to assess cleanliness of the tanker at the point of reception of the empty tanker, prior to loading.
   ii. For organizations receiving raw material in tankers, the supplier agreement shall include as a minimum: tanker cleaning validation, restrictions linked to prior use, and applicable control measures relevant to the product being transported.`,
  },
  {
    id: "2.5.11",
    title: "Hazard Control and Measures for Preventing Cross-Contamination",
    scope: "All food chain categories, excluding FII",
    content: `a) For categories BIII, C and I: The organization shall have specific requirements in place where packaging is used to impart or provide a functional effect on food (e.g., shelf-life extension).

b) For category C0: The organization shall have specified requirements for an inspection process at lairage and/or at evisceration to ensure animals are fit for human consumption.

c) For category D: The organization shall have in place procedures to manage the use of ingredients/additives that contain components that can have an adverse animal health impact.

d) For all food chain categories (excluding FII), the following requirements relating to foreign matter management apply, in addition to clause 8.2.4 (h) of ISO 22000:2018:
   i. The organization shall have a risk assessment in place to determine the need and type of foreign body detection equipment required. Where no foreign body detection equipment is deemed necessary, justification shall be maintained as documented information.
   ii. A documented procedure shall be in place for the management and use of the equipment selected.
   iii. The organization shall have controls in place for foreign matter management including procedures for the management of all breakages linked to potential physical contamination (e.g., metal, ceramic, hard plastic).`,
  },
  {
    id: "2.5.12",
    title: "PRP Verification",
    scope: "Food chain categories BIII, C, D, G, I & K",
    content: `The following additional requirement applies to ISO 22000:2018 clause 8.8.1:

The organization shall establish, implement, and maintain routine (e.g., monthly) site inspections/PRP checks to verify that the site (internal and external), production environment and processing equipment are maintained in a suitable condition to ensure food safety. The frequency and content of the site inspections/PRP checks shall be based on risk with defined sampling criteria and linked to the relevant technical specification.`,
  },
  {
    id: "2.5.13",
    title: "Product Design and Development",
    scope: "Food chain categories BIII, C, D, E, F, I & K",
    content: `A product design and development procedure shall be established, implemented, and maintained for new products and changes to product or manufacturing processes to ensure safe and legal products are produced. This shall include the following:

a) Evaluation of the impact of the change on the FSMS taking into account any new food safety hazards (including allergens) introduced and updating the hazard analysis accordingly.
b) Consideration of the impact on the process flow for the new product and existing products and processes.
c) Resource and training needs.
d) Equipment and maintenance requirements.
e) The need to conduct production and shelf-life trials to validate product formulation and processes are capable of producing a safe product and meet customer requirements. A process for on-going shelf-life verification shall be in place, at a frequency based on risk.
f) Where a ready-to-cook product is produced, the cooking instructions provided on the product label or packaging shall be validated to ensure food safety is maintained.`,
  },
  {
    id: "2.5.14",
    title: "Health Status",
    scope: "Food chain category D",
    content: `In addition to ISO/TS 22002-6 clause 4.10.1, the organization shall have a procedure to ensure that the health of personnel does not have an adverse effect on the feed production operations. Subject to legal restrictions in the country of operation, employees shall undergo a medical screening prior to employment in feed contact operations, unless documented hazards or medical assessment indicates otherwise. Additional medical examinations, where permitted, shall be carried out as required and at intervals defined by the organization.`,
  },
  {
    id: "2.5.15",
    title: "Equipment Management",
    scope: "All food chain categories, excluding FII",
    content: `In addition to clause 8.2.4 of ISO 22000:2018, the organization shall:

a) Have a documented purchase specification in place, which addresses hygienic design, applicable legal and customer requirements, and the intended use of the equipment, including product handled. The supplier shall provide evidence of meeting the purchase specification prior to installation.

b) Establish and implement a risk-based change management process for new equipment and/or any changes to existing equipment, which shall be adequately documented including evidence of successful commissioning. Possible effects on existing systems shall be assessed and adequate control measures determined and implemented.`,
  },
  {
    id: "2.5.16",
    title: "Food Loss and Waste",
    scope: "All food chain categories, excluding I",
    content: `In addition to clause 8 of ISO 22000:2018, the organization shall:

a) Have a documented policy and objectives detailing the organization's strategy to reduce food loss and waste within their organization and the related supply chain.
b) Have controls in place to manage products donated to not-for-profit organizations, employees, and other organizations; and ensure that these products are safe to consume.
c) Manage surplus products or by-products intended as animal feed/food to prevent contamination of these products.
d) These processes shall comply with the applicable legislation, be kept up to date, and not have a negative impact on food safety.`,
  },
  {
    id: "2.5.17",
    title: "Communication Requirements",
    scope: "All food chain categories",
    content: `In addition to clause 8.4.2 of ISO 22000:2018, the organization shall inform the certification body within 3 working days of the commencement of the events or situations below and implement suitable measures as part of their emergency preparedness and response process:

a) Serious events that impact the FSMS, legality and/or the integrity of the certification including situations that pose a threat to food safety, or certification integrity as a result of Force majeure, natural or man-made disasters (e.g., war, strike, terrorism, crime, flood, earthquake, malicious computer hacking).

b) Serious situations where the integrity of the certification is at risk and/or where the Foundation can be brought into disrepute. These include, but are not limited to:
   - Public food safety events (e.g., public recalls, withdrawals, calamities, food safety outbreaks)
   - Actions imposed by regulatory authorities as a result of a food safety issue(s), where additional monitoring or forced shutdown of production is required
   - Legal proceedings, prosecutions, malpractice, and negligence
   - Fraudulent activities and corruption.`,
  },
  {
    id: "2.5.18",
    title: "Requirements for Organization with Multi-Site Certification",
    scope: "Food chain categories E, F & G",
    content: `Central Function:
a) The management of the central function shall ensure that sufficient resources are available, and that roles, responsibilities and requirements are clearly defined for management, internal auditors, technical personnel reviewing internal audits and other key personnel involved in the FSMS.

Internal Audit Requirements (in addition to clause 9.2 of ISO 22000:2018):
a) An internal audit procedure and program shall be established by the central function covering the management system, central function, and all sites. Internal auditors shall be independent from the areas they audit and be assigned by the central function to ensure impartiality at site level.
b) The management system, centralized function and all sites shall be audited at least annually or more frequently based on a risk assessment.
c) Internal auditors shall meet specified work experience (2 years), education, and training requirements including a FSMS/QMS/FSSC 22000 Lead Auditor Course (40 hours) for lead auditors and an internal auditor course (16 hours) for other team auditors.
d) Internal audit reports shall be subject to a technical review by the central function, including addressing the non-conformities resulting from the internal audit.
e) Internal auditors and technical reviewers shall be subject to annual performance monitoring and calibration.`,
  },
];

function ClauseCard({ clause, isActive, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors mb-1 ${
        isActive
          ? "bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200"
          : "text-slate-600 hover:bg-slate-50 hover:text-slate-800"
      }`}
    >
      <span className="font-mono text-xs mr-2 text-slate-400">{clause.id}</span>
      <span className="leading-tight">{clause.title}</span>
    </button>
  );
}

export default function StandardReferencePanel({ highlightClause }) {
  const [activeClause, setActiveClause] = useState(() => {
    if (highlightClause) {
      const match = STANDARD_CLAUSES.find(c =>
        highlightClause.startsWith(c.id) || c.id.startsWith(highlightClause)
      );
      return match || STANDARD_CLAUSES[0];
    }
    return STANDARD_CLAUSES[0];
  });

  return (
    <div className="flex gap-4 h-[600px]">
      {/* Clause list */}
      <div className="w-56 shrink-0 border-r border-slate-100 pr-3">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 px-1">
          FSSC 22000 Additional Requirements
        </p>
        <ScrollArea className="h-[560px]">
          {STANDARD_CLAUSES.map(clause => (
            <ClauseCard
              key={clause.id}
              clause={clause}
              isActive={activeClause.id === clause.id}
              onClick={() => setActiveClause(clause)}
            />
          ))}
        </ScrollArea>
      </div>

      {/* Clause content */}
      <ScrollArea className="flex-1 h-[600px]">
        <div className="pr-2">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono font-bold text-slate-400">Clause {activeClause.id}</span>
                <Badge variant="outline" className="text-xs">{activeClause.scope}</Badge>
              </div>
              <h2 className="text-base font-bold text-slate-900 mt-0.5">{activeClause.title}</h2>
            </div>
          </div>

          <div className="bg-slate-50 rounded-xl p-5 border border-slate-100">
            <pre className="text-sm text-slate-700 whitespace-pre-wrap leading-relaxed font-sans">
              {activeClause.content}
            </pre>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}