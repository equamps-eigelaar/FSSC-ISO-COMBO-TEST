import React, { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LayoutTemplate, ChevronDown } from "lucide-react";

const SECTIONS = [
  "4 - Context of the Organization",
  "5 - Leadership",
  "6 - Planning",
  "7 - Support",
  "8 - Operation",
  "9 - Performance Evaluation",
  "10 - Improvement",
  "Prerequisite - Establishment",
  "Prerequisite - Utilities",
  "Prerequisite - Equipment",
  "Prerequisite - Hygiene",
  "Prerequisite - Personnel",
  "Prerequisite - Transportation",
  "Prerequisite - Product Information",
  "Prerequisite - Other Requirements",
];

const EMPTY = {
  clause_number: "",
  clause_title: "",
  section: SECTIONS[0],
  description: "",
  priority: "medium",
  status: "not_started",
};

export default function AddRequirementDialog({ open, onClose }) {
  const [form, setForm] = useState(EMPTY);
  const [showTemplates, setShowTemplates] = useState(false);
  const queryClient = useQueryClient();

  const { data: templates = [] } = useQuery({
    queryKey: ["requirement-templates"],
    queryFn: () => base44.entities.RequirementTemplate.list("-created_date", 100),
    enabled: open,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ComplianceRequirement.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["compliance-requirements"] });
      onClose();
      setForm(EMPTY);
      setShowTemplates(false);
    },
  });

  const applyTemplate = (tpl) => {
    setForm({
      clause_number: tpl.clause_number || "",
      clause_title: tpl.clause_title || "",
      section: tpl.section || SECTIONS[0],
      description: tpl.description || "",
      priority: tpl.priority || "medium",
      status: tpl.status || "not_started",
    });
    setShowTemplates(false);
  };

  const set = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  return (
    <Dialog open={open} onOpenChange={() => { onClose(); setForm(EMPTY); setShowTemplates(false); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Requirement</DialogTitle>
        </DialogHeader>

        {/* Template picker */}
        {templates.length > 0 && (
          <div className="border border-slate-100 dark:border-slate-800 rounded-lg overflow-hidden">
            <button
              type="button"
              onClick={() => setShowTemplates((v) => !v)}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors font-medium"
            >
              <LayoutTemplate className="w-4 h-4" />
              Use a template
              <ChevronDown className={`w-4 h-4 ml-auto transition-transform ${showTemplates ? "rotate-180" : ""}`} />
            </button>
            {showTemplates && (
              <div className="border-t border-slate-100 dark:border-slate-800 max-h-40 overflow-y-auto divide-y divide-slate-50 dark:divide-slate-800">
                {templates.map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => applyTemplate(tpl)}
                    className="w-full text-left px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  >
                    <span className="text-sm font-medium text-slate-700 dark:text-slate-200">{tpl.name}</span>
                    {tpl.clause_number && (
                      <span className="ml-2 text-xs font-mono text-slate-400">{tpl.clause_number}</span>
                    )}
                    <p className="text-xs text-slate-400 truncate">{tpl.clause_title}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="space-y-4 py-1">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Clause Number</Label>
              <Input placeholder="e.g. 4.1" value={form.clause_number} onChange={(e) => set("clause_number", e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">Section</Label>
              <Select value={form.section} onValueChange={(v) => set("section", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SECTIONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label className="text-xs">Title</Label>
            <Input placeholder="Clause title" value={form.clause_title} onChange={(e) => set("clause_title", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs">Description</Label>
            <Textarea
              placeholder="What does this clause require?"
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              rows={3}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Priority</Label>
              <Select value={form.priority} onValueChange={(v) => set("priority", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={(v) => set("status", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="not_started">Not Started</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                  <SelectItem value="compliant">Compliant</SelectItem>
                  <SelectItem value="non_compliant">Non-Compliant</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={() => createMutation.mutate(form)}
            disabled={!form.clause_number || !form.clause_title || createMutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {createMutation.isPending ? "Adding..." : "Add Requirement"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}