import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, LayoutTemplate } from "lucide-react";

const SECTIONS = [
  "4 - Context of the Organization",
  "5 - Leadership",
  "6 - Planning",
  "7 - Support",
  "8 - Operation",
  "9 - Performance Evaluation",
  "10 - Improvement",
  "Prerequisite - Establishment",
  "Prerequisite - Utilities",
  "Prerequisite - Equipment",
  "Prerequisite - Hygiene",
  "Prerequisite - Personnel",
  "Prerequisite - Transportation",
  "Prerequisite - Product Information",
  "Prerequisite - Other Requirements",
];

const PRIORITY_COLORS = {
  critical: "bg-rose-100 text-rose-700",
  high: "bg-orange-100 text-orange-700",
  medium: "bg-blue-100 text-blue-700",
  low: "bg-slate-100 text-slate-600",
};

const EMPTY_FORM = {
  name: "",
  clause_number: "",
  clause_title: "",
  section: SECTIONS[0],
  description: "",
  priority: "medium",
  status: "not_started",
};

function TemplateFormDialog({ open, onClose, initial }) {
  const [form, setForm] = useState(initial || EMPTY_FORM);
  const queryClient = useQueryClient();

  React.useEffect(() => {
    setForm(initial || EMPTY_FORM);
  }, [initial, open]);

  const mutation = useMutation({
    mutationFn: (data) =>
      initial?.id
        ? base44.entities.RequirementTemplate.update(initial.id, data)
        : base44.entities.RequirementTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["requirement-templates"] });
      onClose();
    },
  });

  const set = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{initial?.id ? "Edit Template" : "New Requirement Template"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-1">
          <div>
            <Label className="text-xs">Template Name *</Label>
            <Input placeholder="e.g. HACCP Plan Template" value={form.name} onChange={(e) => set("name", e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Clause Number</Label>
              <Input placeholder="e.g. 4.1" value={form.clause_number} onChange={(e) => set("clause_number", e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">Section</Label>
              <Select value={form.section} onValueChange={(v) => set("section", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SECTIONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label className="text-xs">Clause Title *</Label>
            <Input placeholder="Requirement title" value={form.clause_title} onChange={(e) => set("clause_title", e.target.value)} />
          </div>
          <div>
            <Label className="text-xs">Description</Label>
            <Textarea
              placeholder="What does this clause require?"
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              rows={3}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Default Priority</Label>
              <Select value={form.priority} onValueChange={(v) => set("priority", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Default Status</Label>
              <Select value={form.status} onValueChange={(v) => set("status", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="not_started">Not Started</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={() => mutation.mutate(form)}
            disabled={!form.name || !form.clause_title || mutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {mutation.isPending ? "Saving..." : initial?.id ? "Save Changes" : "Create Template"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function RequirementTemplateManager({ open, onClose }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const queryClient = useQueryClient();

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ["requirement-templates"],
    queryFn: () => base44.entities.RequirementTemplate.list("-created_date", 100),
    enabled: open,
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RequirementTemplate.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["requirement-templates"] }),
  });

  const handleEdit = (tpl) => {
    setEditing(tpl);
    setShowForm(true);
  };

  const handleNew = () => {
    setEditing(null);
    setShowForm(true);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                <LayoutTemplate className="w-5 h-5 text-emerald-600" />
                Requirement Templates
              </DialogTitle>
              <Button size="sm" onClick={handleNew} className="bg-emerald-600 hover:bg-emerald-700 mr-6">
                <Plus className="w-4 h-4 mr-1" /> New Template
              </Button>
            </div>
          </DialogHeader>
          <div className="overflow-y-auto flex-1 pr-1">
            {isLoading ? (
              <div className="flex justify-center py-10">
                <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : templates.length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <LayoutTemplate className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p className="text-sm">No templates yet. Create one to get started.</p>
              </div>
            ) : (
              <div className="space-y-2 py-1">
                {templates.map((tpl) => (
                  <div
                    key={tpl.id}
                    className="flex items-start gap-3 p-3 rounded-lg border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-emerald-200 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-sm font-semibold text-slate-800 dark:text-slate-100">{tpl.name}</span>
                        {tpl.clause_number && (
                          <span className="text-xs font-mono text-slate-400">{tpl.clause_number}</span>
                        )}
                        <Badge className={`text-xs ${PRIORITY_COLORS[tpl.priority] || PRIORITY_COLORS.medium}`}>
                          {tpl.priority}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{tpl.clause_title}</p>
                      {tpl.section && (
                        <p className="text-xs text-slate-400 mt-0.5">{tpl.section}</p>
                      )}
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => handleEdit(tpl)}>
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-rose-500 hover:text-rose-600 hover:bg-rose-50"
                        onClick={() => deleteMutation.mutate(tpl.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <TemplateFormDialog
        open={showForm}
        onClose={() => setShowForm(false)}
        initial={editing}
      />
    </>
  );
}