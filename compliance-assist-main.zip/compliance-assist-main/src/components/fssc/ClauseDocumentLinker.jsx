import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Paperclip, X, ExternalLink, Search, FileText, Plus } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

const CATEGORY_COLORS = {
  supplier_certificate: "bg-blue-50 text-blue-700",
  safety_data_sheet: "bg-orange-50 text-orange-700",
  inspection_report: "bg-purple-50 text-purple-700",
  test_report: "bg-amber-50 text-amber-700",
  compliance_evidence: "bg-emerald-50 text-emerald-700",
  risk_analysis: "bg-red-50 text-red-700",
  procedure: "bg-teal-50 text-teal-700",
  specification: "bg-indigo-50 text-indigo-700",
  audit_report: "bg-violet-50 text-violet-700",
  other: "bg-slate-100 text-slate-600",
};

export default function ClauseDocumentLinker({ clauseNumber, requirementId, canEdit }) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  // Fetch all documents
  const { data: allDocs = [] } = useQuery({
    queryKey: ["documents-for-linker"],
    queryFn: () => base44.entities.Document.list("-created_date", 200),
    enabled: open,
  });

  // Fetch the linked requirement to get current linked_requirement_ids
  const { data: requirement } = useQuery({
    queryKey: ["requirement-doc-link", requirementId],
    queryFn: () => base44.entities.ComplianceRequirement.filter({ id: requirementId }),
    enabled: !!requirementId,
    select: (data) => data?.[0],
  });

  // Docs already linked to this requirement (via Document.linked_requirement_ids)
  const { data: linkedDocs = [] } = useQuery({
    queryKey: ["linked-docs", clauseNumber],
    queryFn: async () => {
      const docs = await base44.entities.Document.list("-created_date", 200);
      return docs.filter(d => Array.isArray(d.linked_requirement_ids) && d.linked_requirement_ids.includes(requirementId));
    },
    enabled: !!requirementId,
  });

  const filteredDocs = allDocs.filter(doc => {
    if (!search) return true;
    const q = search.toLowerCase();
    return doc.title?.toLowerCase().includes(q) ||
      doc.file_name?.toLowerCase().includes(q) ||
      doc.category?.toLowerCase().includes(q) ||
      doc.tags?.some(t => t.toLowerCase().includes(q));
  });

  const isLinked = (docId) => linkedDocs.some(d => d.id === docId);

  const handleToggleLink = async (doc) => {
    if (!requirementId) {
      toast.error("Save the clause requirement first before linking documents.");
      return;
    }
    const currentIds = Array.isArray(doc.linked_requirement_ids) ? doc.linked_requirement_ids : [];
    const alreadyLinked = currentIds.includes(requirementId);
    const updatedIds = alreadyLinked
      ? currentIds.filter(id => id !== requirementId)
      : [...currentIds, requirementId];

    await base44.entities.Document.update(doc.id, { linked_requirement_ids: updatedIds });
    queryClient.invalidateQueries({ queryKey: ["linked-docs", clauseNumber] });
    queryClient.invalidateQueries({ queryKey: ["documents-for-linker"] });
    toast.success(alreadyLinked ? "Document unlinked" : "Document linked as evidence");
  };

  const handleUnlink = async (doc) => {
    const currentIds = Array.isArray(doc.linked_requirement_ids) ? doc.linked_requirement_ids : [];
    await base44.entities.Document.update(doc.id, {
      linked_requirement_ids: currentIds.filter(id => id !== requirementId),
    });
    queryClient.invalidateQueries({ queryKey: ["linked-docs", clauseNumber] });
    toast.success("Document unlinked");
  };

  return (
    <div>
      {/* Linked docs summary */}
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
          <Paperclip className="w-3 h-3 text-slate-500" /> Evidence Documents
          {linkedDocs.length > 0 && (
            <Badge variant="outline" className="text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200 ml-1">
              {linkedDocs.length}
            </Badge>
          )}
        </h4>
        {canEdit && (
          <Button
            size="sm"
            variant="outline"
            className="h-6 text-[10px] px-2"
            onClick={(e) => { e.stopPropagation(); setOpen(true); }}
          >
            <Plus className="w-3 h-3 mr-0.5" /> Attach
          </Button>
        )}
      </div>

      {/* Linked docs list */}
      {linkedDocs.length === 0 ? (
        <p className="text-[10px] text-slate-400 italic">No evidence documents linked yet.</p>
      ) : (
        <div className="space-y-1.5">
          {linkedDocs.map(doc => (
            <div key={doc.id} className="flex items-center gap-2 p-1.5 bg-slate-50 dark:bg-slate-800 rounded border border-slate-100 dark:border-slate-700 group">
              <FileText className="w-3 h-3 text-slate-400 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate">{doc.title || doc.file_name}</p>
                <div className="flex items-center gap-1 mt-0.5">
                  <span className={`text-[10px] px-1 rounded ${CATEGORY_COLORS[doc.category] || "bg-slate-100 text-slate-500"}`}>
                    {doc.category?.replace(/_/g, " ")}
                  </span>
                  {doc.current_version && (
                    <span className="text-[10px] text-slate-400">v{doc.current_version}</span>
                  )}
                  {doc.expiry_date && (
                    <span className={`text-[10px] ${new Date(doc.expiry_date) < new Date() ? "text-red-500" : "text-slate-400"}`}>
                      exp {format(new Date(doc.expiry_date), "dd MMM yy")}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                {doc.file_url && (
                  <a href={doc.file_url} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}>
                    <Button size="sm" variant="ghost" className="h-5 w-5 p-0">
                      <ExternalLink className="w-3 h-3 text-slate-400" />
                    </Button>
                  </a>
                )}
                {canEdit && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-5 w-5 p-0"
                    onClick={(e) => { e.stopPropagation(); handleUnlink(doc); }}
                  >
                    <X className="w-3 h-3 text-red-400" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Document picker dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xl max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
          <DialogHeader>
            <DialogTitle className="text-sm flex items-center gap-2">
              <Paperclip className="w-4 h-4 text-emerald-600" />
              Link Evidence Documents — Clause {clauseNumber}
            </DialogTitle>
          </DialogHeader>

          <div className="relative mb-3">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input
              className="pl-8 h-8 text-xs"
              placeholder="Search documents by name, category or tag..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          <div className="overflow-y-auto flex-1 space-y-1.5 pr-1">
            {filteredDocs.length === 0 && (
              <p className="text-sm text-slate-400 text-center py-6">No documents found. Upload documents in the Document Repository first.</p>
            )}
            {filteredDocs.map(doc => {
              const linked = isLinked(doc.id);
              return (
                <div
                  key={doc.id}
                  className={`flex items-start gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${linked ? "bg-emerald-50 border-emerald-200 dark:bg-emerald-900/20 dark:border-emerald-700" : "bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:border-emerald-200"}`}
                  onClick={() => handleToggleLink(doc)}
                >
                  <div className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 ${linked ? "bg-emerald-500 border-emerald-500" : "border-slate-300"}`}>
                    {linked && <CheckMark />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate">
                      {doc.title || doc.file_name}
                    </p>
                    <div className="flex items-center flex-wrap gap-1 mt-0.5">
                      <span className={`text-[10px] px-1 rounded ${CATEGORY_COLORS[doc.category] || "bg-slate-100 text-slate-500"}`}>
                        {doc.category?.replace(/_/g, " ")}
                      </span>
                      {doc.control_status && (
                        <span className={`text-[10px] px-1 rounded ${doc.control_status === "controlled" ? "bg-blue-50 text-blue-600" : "bg-slate-100 text-slate-500"}`}>
                          {doc.control_status}
                        </span>
                      )}
                      {doc.current_version && (
                        <span className="text-[10px] text-slate-400">v{doc.current_version}</span>
                      )}
                      {doc.expiry_date && (
                        <span className={`text-[10px] ${new Date(doc.expiry_date) < new Date() ? "text-red-500 font-medium" : "text-slate-400"}`}>
                          exp {format(new Date(doc.expiry_date), "dd MMM yyyy")}
                        </span>
                      )}
                    </div>
                    {doc.description && (
                      <p className="text-[10px] text-slate-400 truncate mt-0.5">{doc.description}</p>
                    )}
                  </div>
                  {doc.file_url && (
                    <a
                      href={doc.file_url}
                      target="_blank"
                      rel="noreferrer"
                      onClick={e => e.stopPropagation()}
                      className="shrink-0 text-slate-400 hover:text-emerald-600"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
            <span className="text-xs text-slate-400">{linkedDocs.length} document(s) linked to this clause</span>
            <Button size="sm" onClick={() => setOpen(false)}>Done</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function CheckMark() {
  return (
    <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 12 12" stroke="currentColor" strokeWidth={2.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M2 6l3 3 5-5" />
    </svg>
  );
}