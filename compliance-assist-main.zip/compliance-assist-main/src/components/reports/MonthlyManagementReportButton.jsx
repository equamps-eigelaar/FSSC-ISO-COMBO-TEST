import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { FileText, Loader2, CheckCircle } from "lucide-react";

export default function MonthlyManagementReportButton() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleGenerate = async () => {
    setLoading(true);
    setResult(null);
    const now = new Date();
    // Default: previous month
    const month = now.getMonth() === 0 ? 12 : now.getMonth();
    const year = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
    const res = await base44.functions.invoke("generateMonthlyManagementReport", { month, year });
    setResult(res.data);
    setLoading(false);
  };

  return (
    <div className="flex items-center gap-4 p-4 bg-emerald-50 border border-emerald-200 rounded-xl">
      <div className="flex-1">
        <p className="text-sm font-semibold text-emerald-800">Monthly Management Report</p>
        <p className="text-xs text-emerald-600 mt-0.5">
          Generates a PDF covering monitoring logs, non-compliant requirements, and high-risk findings. Auto-runs on the 1st of each month.
        </p>
        {result?.file_url && (
          <a
            href={result.file_url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 mt-2 text-xs font-medium text-emerald-700 hover:underline"
          >
            <CheckCircle className="w-3.5 h-3.5" />
            Report ready — click to download
          </a>
        )}
      </div>
      <Button
        onClick={handleGenerate}
        disabled={loading}
        className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2 shrink-0"
      >
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
        {loading ? "Generating…" : "Generate Now"}
      </Button>
    </div>
  );
}