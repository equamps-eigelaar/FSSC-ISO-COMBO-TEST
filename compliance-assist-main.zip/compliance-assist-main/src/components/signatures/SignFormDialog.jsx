import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Lock, Pen } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import DigitalSignaturePad from "./DigitalSignaturePad";

const DECLARATION = "I confirm that the information recorded in this form is accurate and complete to the best of my knowledge, and that this document has been prepared in accordance with our Food Safety Management System requirements.";

export default function SignFormDialog({ open, onClose, formKey, formTitle }) {
  const [signerName, setSignerName] = useState("");
  const [signerRole, setSignerRole] = useState("");
  const [formRef, setFormRef] = useState("");
  const [signatureData, setSignatureData] = useState(null);
  const [saving, setSaving] = useState(false);
  const [locked, setLocked] = useState(null);

  const handleSign = async () => {
    if (!signerName.trim()) { toast.error("Please enter your full name"); return; }
    if (!signatureData) { toast.error("Please draw your signature"); return; }

    setSaving(true);
    try {
      const user = await base44.auth.me();
      const timestamp = new Date().toISOString();
      const record = await base44.entities.SignedFormRecord.create({
        form_key: formKey,
        form_title: formTitle,
        signer_name: signerName.trim(),
        signer_role: signerRole.trim(),
        signer_email: user?.email || "unknown",
        signature_timestamp: timestamp,
        signature_data: signatureData,
        declaration: DECLARATION,
        status: "locked",
        form_reference: formRef.trim() || undefined,
      });
      setLocked({ record, timestamp, user });
      toast.success("Form signed and locked successfully");
    } catch (err) {
      toast.error("Failed to save signature. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    setSignerName("");
    setSignerRole("");
    setFormRef("");
    setSignatureData(null);
    setLocked(null);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pen className="w-4 h-4 text-emerald-600" />
            Sign & Lock Form
          </DialogTitle>
        </DialogHeader>

        {locked ? (
          <div className="space-y-4 py-2">
            <div className="flex flex-col items-center gap-3 p-6 bg-emerald-50 rounded-xl border border-emerald-200">
              <CheckCircle2 className="w-10 h-10 text-emerald-600" />
              <p className="font-semibold text-emerald-800 text-center">Form Signed &amp; Locked</p>
              <Badge className="bg-emerald-700 text-white gap-1.5">
                <Lock className="w-3 h-3" /> LOCKED
              </Badge>
            </div>
            <div className="text-sm space-y-2 border border-slate-200 rounded-lg p-4 bg-slate-50">
              <div className="flex justify-between">
                <span className="text-slate-500">Signed by</span>
                <span className="font-medium text-slate-800">{locked.record.signer_name}</span>
              </div>
              {locked.record.signer_role && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Role</span>
                  <span className="font-medium text-slate-800">{locked.record.signer_role}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-slate-500">User ID</span>
                <span className="font-mono text-xs text-slate-600">{locked.record.signer_email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Timestamp</span>
                <span className="font-mono text-xs text-slate-600">
                  {new Date(locked.timestamp).toLocaleString("en-ZA", { timeZone: "Africa/Johannesburg", dateStyle: "medium", timeStyle: "medium" })}
                </span>
              </div>
              {locked.record.form_reference && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Reference</span>
                  <span className="font-medium text-slate-800">{locked.record.form_reference}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-slate-500">Record ID</span>
                <span className="font-mono text-xs text-slate-400">{locked.record.id}</span>
              </div>
            </div>
            <p className="text-xs text-slate-400 text-center">This record is immutable and stored for audit purposes.</p>
            <Button onClick={handleClose} className="w-full bg-emerald-600 hover:bg-emerald-700">Close</Button>
          </div>
        ) : (
          <div className="space-y-4 py-2">
            <div className="text-sm text-slate-600 bg-slate-50 rounded-lg p-3 border border-slate-200">
              <p className="font-medium text-slate-700 mb-1">{formTitle}</p>
              <p className="text-xs text-slate-500">Signing this form will create a tamper-evident, locked record with your identity and timestamp.</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Full Name <span className="text-red-500">*</span></Label>
                <Input value={signerName} onChange={e => setSignerName(e.target.value)} placeholder="Your full name" className="text-sm" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Role / Title</Label>
                <Input value={signerRole} onChange={e => setSignerRole(e.target.value)} placeholder="e.g. QA Manager" className="text-sm" />
              </div>
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Form Reference Number (optional)</Label>
              <Input value={formRef} onChange={e => setFormRef(e.target.value)} placeholder="e.g. CCP-2026-001" className="text-sm" />
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Signature <span className="text-red-500">*</span></Label>
              <DigitalSignaturePad onSave={setSignatureData} onClear={() => setSignatureData(null)} />
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-xs text-amber-800 leading-relaxed">{DECLARATION}</p>
            </div>

            <div className="flex gap-2 pt-1">
              <Button variant="outline" onClick={handleClose} className="flex-1">Cancel</Button>
              <Button
                onClick={handleSign}
                disabled={saving || !signerName.trim() || !signatureData}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 gap-1.5"
              >
                <Lock className="w-3.5 h-3.5" />
                {saving ? "Signing..." : "Sign & Lock"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}