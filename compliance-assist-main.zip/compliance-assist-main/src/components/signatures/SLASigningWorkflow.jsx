import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2, Lock, Pen, Download } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import DigitalSignaturePad from "./DigitalSignaturePad";

const SLA_DECLARATION = "I acknowledge that I have read, understood, and agree to comply with all terms and conditions set out in the Service Level Agreement for the Package Manufacturing Compliance Tracker Platform. I confirm that my company will meet or exceed all expectations for food safety, quality, audit compliance, and security as outlined in this document.";

export default function SLASigningWorkflow({ open, onClose }) {
  const [step, setStep] = useState("form");
  const [companyName, setCompanyName] = useState("");
  const [signerName, setSignerName] = useState("");
  const [signerRole, setSignerRole] = useState("");
  const [signatureData, setSignatureData] = useState(null);
  const [saving, setSaving] = useState(false);
  const [signed, setSigned] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (open) {
      base44.auth.me().then(u => setUser(u)).catch(() => null);
    }
  }, [open]);

  const handleSign = async () => {
    if (!companyName.trim()) { toast.error("Please enter company name"); return; }
    if (!signerName.trim()) { toast.error("Please enter your full name"); return; }
    if (!signatureData) { toast.error("Please draw your signature"); return; }

    setSaving(true);
    try {
      const timestamp = new Date().toISOString();
      const record = await base44.entities.SignedFormRecord.create({
        form_key: "sla_agreement",
        form_title: "Service Level Agreement - Supplier Declaration",
        signer_name: signerName.trim(),
        signer_role: signerRole.trim(),
        signer_email: user?.email || "unknown",
        signature_timestamp: timestamp,
        signature_data: signatureData,
        declaration: SLA_DECLARATION,
        status: "locked",
        form_reference: `SLA-${companyName.substring(0, 3).toUpperCase()}-${new Date().getFullYear()}`,
      });
      setSigned({ record, timestamp, companyName });
      setStep("confirmation");
      toast.success("SLA signed and locked successfully");
    } catch (err) {
      toast.error("Failed to save signature. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    setStep("form");
    setCompanyName("");
    setSignerName("");
    setSignerRole("");
    setSignatureData(null);
    setSigned(null);
    onClose();
  };

  const handleDownloadProof = () => {
    if (!signed) return;
    const content = `
SERVICE LEVEL AGREEMENT - SIGNATURE PROOF
==========================================

Company: ${signed.companyName}
Signed by: ${signed.record.signer_name}
Role: ${signed.record.signer_role || "N/A"}
Timestamp: ${new Date(signed.timestamp).toLocaleString("en-ZA", { timeZone: "Africa/Johannesburg" })}
Record ID: ${signed.record.id}

DECLARATION AGREED TO:
${SLA_DECLARATION}

This document is a proof of digital signature for the SLA signed on the Package Manufacturing Compliance Tracker platform.
The signature is tamper-evident and immutable.
    `;
    const blob = new Blob([content], { type: "text/plain" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `SLA-Signature-${signed.record.id}.txt`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pen className="w-5 h-5 text-emerald-600" />
            Service Level Agreement - Digital Signature
          </DialogTitle>
          <DialogDescription>Sign and lock the SLA to create a tamper-evident record</DialogDescription>
        </DialogHeader>

        {step === "form" && (
          <div className="space-y-6 py-4">
            {/* Declaration box */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
              <p className="text-sm font-semibold text-emerald-800 mb-2">SLA Declaration</p>
              <p className="text-xs text-emerald-700 leading-relaxed">{SLA_DECLARATION}</p>
            </div>

            {/* Signer details */}
            <div className="space-y-4">
              <div>
                <Label className="text-sm font-semibold">Company Name <span className="text-red-500">*</span></Label>
                <Input
                  value={companyName}
                  onChange={e => setCompanyName(e.target.value)}
                  placeholder="Enter your company name"
                  className="mt-1.5"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-sm font-semibold">Full Name <span className="text-red-500">*</span></Label>
                  <Input
                    value={signerName}
                    onChange={e => setSignerName(e.target.value)}
                    placeholder="Your full name"
                    className="mt-1.5"
                  />
                </div>
                <div>
                  <Label className="text-sm font-semibold">Position / Title</Label>
                  <Input
                    value={signerRole}
                    onChange={e => setSignerRole(e.target.value)}
                    placeholder="e.g. Procurement Manager"
                    className="mt-1.5"
                  />
                </div>
              </div>

              {user && (
                <div className="text-xs text-slate-500 bg-slate-50 rounded-lg p-3 border border-slate-200">
                  <p><strong>Signing as:</strong> {user.email}</p>
                </div>
              )}
            </div>

            {/* Signature pad */}
            <div className="space-y-2">
              <Label className="text-sm font-semibold">Your Signature <span className="text-red-500">*</span></Label>
              <DigitalSignaturePad onSave={setSignatureData} onClear={() => setSignatureData(null)} />
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <Button variant="outline" onClick={handleClose} className="flex-1">Cancel</Button>
              <Button
                onClick={handleSign}
                disabled={saving || !companyName.trim() || !signerName.trim() || !signatureData}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 gap-2"
              >
                <Lock className="w-4 h-4" />
                {saving ? "Signing..." : "Sign & Lock Agreement"}
              </Button>
            </div>
          </div>
        )}

        {step === "confirmation" && signed && (
          <div className="space-y-6 py-4">
            {/* Success banner */}
            <div className="flex flex-col items-center gap-4 p-6 bg-emerald-50 rounded-xl border border-emerald-200">
              <CheckCircle2 className="w-12 h-12 text-emerald-600" />
              <div className="text-center">
                <p className="font-bold text-emerald-800 text-lg">Agreement Signed & Locked</p>
                <p className="text-sm text-emerald-700 mt-1">Digital signature recorded and stored</p>
              </div>
              <Badge className="bg-emerald-700 text-white gap-1.5 px-3 py-1">
                <Lock className="w-3 h-3" /> LOCKED & IMMUTABLE
              </Badge>
            </div>

            {/* Details */}
            <Card className="border-slate-200">
              <CardContent className="pt-6">
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between py-2 border-b border-slate-100">
                    <span className="text-slate-500">Company</span>
                    <span className="font-semibold text-slate-900">{signed.companyName}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-slate-100">
                    <span className="text-slate-500">Signed by</span>
                    <span className="font-semibold text-slate-900">{signed.record.signer_name}</span>
                  </div>
                  {signed.record.signer_role && (
                    <div className="flex justify-between py-2 border-b border-slate-100">
                      <span className="text-slate-500">Position</span>
                      <span className="font-semibold text-slate-900">{signed.record.signer_role}</span>
                    </div>
                  )}
                  <div className="flex justify-between py-2 border-b border-slate-100">
                    <span className="text-slate-500">Timestamp</span>
                    <span className="font-mono text-xs text-slate-600">
                      {new Date(signed.timestamp).toLocaleString("en-ZA", { timeZone: "Africa/Johannesburg", dateStyle: "medium", timeStyle: "medium" })}
                    </span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-slate-100">
                    <span className="text-slate-500">Reference</span>
                    <span className="font-mono text-xs font-semibold text-slate-700">{signed.record.form_reference}</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-slate-500">Record ID</span>
                    <span className="font-mono text-xs text-slate-400">{signed.record.id}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-xs text-blue-800 leading-relaxed">
                ✓ This signed agreement is stored securely in the database<br/>
                ✓ The signature is tamper-evident and cannot be modified<br/>
                ✓ A copy of this signature record can be retrieved at any time<br/>
                ✓ The timestamp confirms the exact moment of signature
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleDownloadProof} className="flex-1 gap-2">
                <Download className="w-4 h-4" />
                Download Proof
              </Button>
              <Button onClick={handleClose} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
                Done
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}